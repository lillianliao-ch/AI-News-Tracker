// Run automatically when page loads
function initializeExtension() {
    console.log("Headhunter Scraper: Initializing extension...");
    
    // Add manual trigger button
    try {
        addManualTriggerButton();
    } catch (error) {
        console.error("Headhunter Scraper: Failed to add manual trigger button", error);
    }
    
    // Wait for dynamic content and scrape automatically
    console.log("Headhunter Scraper: Waiting 2 seconds before automatic scraping...");
    setTimeout(() => {
        console.log("Headhunter Scraper: Auto-scraping initiated");
        try {
            scrapeDetail();
        } catch (error) {
            console.error("Headhunter Scraper: Error during automatic scraping", error);
        }
    }, 2000);
}

// Use multiple event listeners to ensure initialization
console.log("Headhunter Scraper: Setting up event listeners...");
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeExtension);
    console.log("Headhunter Scraper: DOMContentLoaded event listener added");
} else {
    // Document is already loaded
    console.log("Headhunter Scraper: Document already loaded, initializing immediately");
    initializeExtension();
}

// Also listen for load event as fallback
window.addEventListener('load', initializeExtension);
console.log("Headhunter Scraper: Load event listener added");

// Listen for URL changes in SPA applications
let lastUrl = location.href;
new MutationObserver(() => {
    const url = location.href;
    if (url !== lastUrl) {
        lastUrl = url;
        console.log("Headhunter Scraper: URL changed to", url);
        // Re-initialize extension when URL changes
        initializeExtension();
    }
}).observe(document, { subtree: true, childList: true });

console.log("Headhunter Scraper: URL change observer added");

// Add manual trigger button to the page
function addManualTriggerButton() {
    console.log("Headhunter Scraper: Attempting to add manual trigger button");
    
    // Check if button already exists
    if (document.getElementById('manual-scrape-button')) {
        console.log("Headhunter Scraper: Manual scrape button already exists");
        return;
    }
    
    // Create button element
    const button = document.createElement('button');
    button.id = 'manual-scrape-button';
    button.textContent = '手动抓取数据';
    
    // Apply styles
    const styles = {
        position: 'fixed',
        top: '10px',
        right: '10px',
        zIndex: '999999',
        backgroundColor: '#4CAF50', // Green background
        color: 'white',
        border: 'none',
        padding: '10px 15px',
        borderRadius: '5px',
        cursor: 'pointer',
        fontSize: '14px',
        fontWeight: 'bold',
        boxShadow: '0 2px 5px rgba(0,0,0,0.2)',
        transition: 'background-color 0.3s'
    };
    
    Object.assign(button.style, styles);
    
    // Add hover effect
    button.addEventListener('mouseenter', () => {
        button.style.backgroundColor = '#45a049';
    });
    
    button.addEventListener('mouseleave', () => {
        button.style.backgroundColor = '#4CAF50';
    });
    
    // Add click event listener
    button.addEventListener('click', () => {
        console.log("Headhunter Scraper: Manual scrape button clicked");
        try {
            scrapeDetail(null, true); // Pass true to indicate manual trigger
        } catch (error) {
            console.error("Headhunter Scraper: Error during manual scraping", error);
        }
    });
    
    // Try multiple methods to append button
    console.log("Headhunter Scraper: Attempting to append button to document");
    
    // Method 1: Append to body
    try {
        document.body.appendChild(button);
        console.log("Headhunter Scraper: Manual scrape button added to body");
        return;
    } catch (error) {
        console.error("Headhunter Scraper: Failed to append button to body", error);
    }
    
    // Method 2: Append to documentElement
    try {
        document.documentElement.appendChild(button);
        console.log("Headhunter Scraper: Manual scrape button added to documentElement");
        return;
    } catch (error) {
        console.error("Headhunter Scraper: Failed to append button to documentElement", error);
    }
    
    // Method 3: Insert as first child of body
    try {
        document.body.insertBefore(button, document.body.firstChild);
        console.log("Headhunter Scraper: Manual scrape button inserted as first child of body");
        return;
    } catch (error) {
        console.error("Headhunter Scraper: Failed to insert button as first child of body", error);
    }
    
    console.error("Headhunter Scraper: Failed to add manual scrape button to page using all methods");
}

// Listen for messages from background script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "scrape_detail") {
        scrapeDetail(sendResponse);
        return true; // Keep message channel open for async response
    }
});

function scrapeDetail(sendResponse, isManualTrigger = false) {
    console.log("Starting to scrape candidate detail page...", { isManualTrigger });
    console.log("Current page URL:", window.location.href);
    console.log("Full document HTML structure:", document.documentElement.outerHTML.substring(0, 5000)); // Log first 5000 characters of HTML for debugging
    const data = {};
    
    // Add URL to data for debugging
    data.url = window.location.href;

    // Helper to extract text safely
    const getText = (selector) => {
        const el = document.querySelector(selector);
        return el ? el.innerText.trim() : '';
    };

    // Basic Info
    // Based on the provided HTML structure:
    // span (姓名) - 候选人姓名
    // span (城市) - 城市信息
    // a (当前公司) - 当前公司
    // span (当前职位) - 当前职位

    console.log("Attempting to extract basic info...");
    
    // Extract name - look for span with title attribute matching the name
    // Based on the provided structure: <span _ngcontent-ng-c3704861777="" title="汪羽萌">汪羽萌</span>
    console.log("Searching for candidate name elements...");
    let nameEl = document.querySelector('span[title]'); 
    console.log("First attempt - span[title] element:", nameEl);
    
    // If not found, try other common selectors
    if (!nameEl) {
        nameEl = document.querySelector('.candidate-name');
        console.log("Second attempt - .candidate-name element:", nameEl);
    }
    
    if (!nameEl) {
        nameEl = document.querySelector('h1');
        console.log("Third attempt - h1 element:", nameEl);
    }
    
    if (!nameEl) {
        nameEl = document.querySelector('[class*="name"]');
        console.log("Fourth attempt - [class*=\"name\"] element:", nameEl);
    }
    
    if (!nameEl) {
        nameEl = document.querySelector('title');
        console.log("Fifth attempt - title element:", nameEl);
    }
    
    // Extract name from title attribute or text content
    if (nameEl) {
        console.log("Found name element, extracting name...");
        data.name = nameEl.getAttribute('title') || nameEl.innerText.trim();
        console.log("Raw name extracted:", data.name);
        // Clean up the name by removing extra info like ID
        if (data.name.includes('(ID:')) {
            data.name = data.name.split('(ID:')[0].trim();
        }
        console.log("Cleaned name:", data.name);
    } else {
        data.name = document.title ? document.title.split('(ID:')[0].trim() : '未知';
        console.log("No name element found, using document title or default:", data.name);
    }
    
    console.log("Final candidate name:", data.name);

    // Extract current company and position
    console.log("Attempting to extract current company and position...");
    // Based on the provided structure: <a _ngcontent-ng-c3704861777="" data-sref="client.detail({id:155})" title="上海睿璞人才服务有限公司" href="#/client/detail?id=155">上海睿璞人才服务有限公司</a>
    console.log("Searching for current company elements...");
    let currentCompanyEl = document.querySelector('a[data-sref*="client"], a[href*="client"]');
    console.log("First attempt - a[data-sref*=\"client\"], a[href*=\"client\"] element:", currentCompanyEl);
    
    if (!currentCompanyEl) {
        currentCompanyEl = document.querySelector('a[title]');
        console.log("Second attempt - a[title] element:", currentCompanyEl);
    }
    
    data.current_company = currentCompanyEl ? (currentCompanyEl.getAttribute('title') || currentCompanyEl.innerText.trim()) : "";
    console.log("Current company:", data.current_company);

    // Based on the provided structure: <span _ngcontent-ng-c3704861777="" data-toggle="tooltip" title="猎头顾问">猎头顾问</span>
    console.log("Searching for current position elements...");
    let currentPositionEl = document.querySelector('span[data-toggle="tooltip"][title]');
    console.log("First attempt - span[data-toggle=\"tooltip\"][title] element:", currentPositionEl);
    
    if (!currentPositionEl) {
        currentPositionEl = document.querySelector('span[title*="顾问"], span[title*="经理"], span[title*="总监"]');
        console.log("Second attempt - span[title*=\"顾问\"], span[title*=\"经理\"], span[title*=\"总监\"] element:", currentPositionEl);
    }
    
    data.current_position = currentPositionEl ? (currentPositionEl.getAttribute('title') || currentPositionEl.innerText.trim()) : "";
    console.log("Current position:", data.current_position);

    // Extract location/city
    console.log("Attempting to extract location...");
    // Based on the provided structure, location seems to be in a span with class 'label label-default'
    console.log("Searching for location elements with class 'label label-default'...");
    let locationElements = Array.from(document.querySelectorAll('span.label.label-default'));
    console.log("Found", locationElements.length, "span.label.label-default elements");
    
    // If not found, fall back to all spans
    if (locationElements.length === 0) {
        console.log("No span.label.label-default elements found, falling back to all span elements...");
        locationElements = Array.from(document.querySelectorAll('span'));
        console.log("Found", locationElements.length, "span elements in total");
    }
    
    // Find location element - look for one containing city names
    const cities = ['北京', '上海', '深圳', '广州', '杭州', '南京', '苏州', '无锡', '成都', '武汉', '西安', '长沙'];
    console.log("Looking for location elements containing city names:", cities.join(', '));
    let locationEl = locationElements.find(el => 
        el.textContent && cities.some(city => el.textContent.includes(city))
    );
    console.log("Location element with city name found:", locationEl);
    
    // If still not found, try to find any element with location-like content
    if (!locationEl) {
        console.log("No city name found, looking for elements with location-like content (市/区/县)...");
        locationEl = locationElements.find(el => 
            el.textContent && (
                el.textContent.includes('市') || 
                el.textContent.includes('区') || 
                el.textContent.includes('县')
            )
        );
        console.log("Location element with location-like content found:", locationEl);
    }
    
    data.location = locationEl ? locationEl.textContent.trim() : "未知";
    console.log("Final location:", data.location);

    // Combine basic info for raw info
    data.raw_basic_info = `姓名: ${data.name}\n当前公司: ${data.current_company}\n当前职位: ${data.current_position}\n地点: ${data.location || '未知'}`;
    console.log("Raw basic info:", data.raw_basic_info);

    // Work Experience
    console.log("Attempting to extract work experience...");
    let workExperienceSections = Array.from(document.querySelectorAll('div.detail-item'));
    console.log("Found", workExperienceSections.length, "detail-item elements");
    
    // Filter for work experience sections
    workExperienceSections = workExperienceSections.filter(section => {
        const header = section.querySelector('h3');
        return header && header.textContent.includes('工作经历');
    });
    
    console.log("Found", workExperienceSections.length, "work experience sections");
    
    if (workExperienceSections.length > 0) {
        const workExperiences = [];
        workExperienceSections.forEach((section, index) => {
            console.log(`Processing work experience section ${index + 1}`);
            try {
                // Extract company, position, duration, and description
                console.log(`Looking for company element in work experience ${index + 1}...`);
                const companyEl = section.querySelector('[data-field-name="company"] .field-value') || 
                                 section.querySelector('.detail-org');
                console.log(`Company element found:`, companyEl);
                
                console.log(`Looking for position element in work experience ${index + 1}...`);
                const positionEl = section.querySelector('[data-field-name="position"] .field-value') || 
                                  section.querySelector('.detail-title');
                console.log(`Position element found:`, positionEl);
                
                console.log(`Looking for duration element in work experience ${index + 1}...`);
                const durationEl = section.querySelector('[data-field-name="duration"] .field-value') || 
                                  section.querySelector('.detail-date');
                console.log(`Duration element found:`, durationEl);
                
                console.log(`Looking for description element in work experience ${index + 1}...`);
                const descriptionEl = section.querySelector('[data-field-name="description"] .field-value') || 
                                     section.querySelector('p');
                console.log(`Description element found:`, descriptionEl);
                
                const company = companyEl ? companyEl.textContent.trim() : '';
                const position = positionEl ? positionEl.textContent.trim() : '';
                const duration = durationEl ? durationEl.textContent.trim() : '';
                const description = descriptionEl ? descriptionEl.textContent.trim() : '';
                
                console.log(`Work experience ${index + 1} - Company:`, company);
                console.log(`Work experience ${index + 1} - Position:`, position);
                console.log(`Work experience ${index + 1} - Duration:`, duration);
                console.log(`Work experience ${index + 1} - Description:`, description);
                
                workExperiences.push({
                    company,
                    position,
                    duration,
                    description
                });
            } catch (error) {
                console.error(`Error processing work experience section ${index + 1}:`, error);
            }
        });
        
        data.workExperiences = workExperiences;
    } else {
        console.log("Work experience section not found");
        data.workExperiences = "工作经历 section not found";
    }

    // Education
    console.log("Attempting to extract education experiences...");
    let educationExperienceSections = Array.from(document.querySelectorAll('div.detail-item'));
    console.log("Found", educationExperienceSections.length, "detail-item elements");
    
    // Filter for education experience sections
    educationExperienceSections = educationExperienceSections.filter(section => {
        const header = section.querySelector('h3');
        return header && header.textContent.includes('教育经历');
    });
    
    console.log("Found", educationExperienceSections.length, "education experience sections");
    
    if (educationExperienceSections.length > 0) {
        const educationExperiences = [];
        educationExperienceSections.forEach((section, index) => {
            console.log(`Processing education experience section ${index + 1}`);
            try {
                // Extract school, degree, major, duration
                console.log(`Looking for school element in education experience ${index + 1}...`);
                const schoolEl = section.querySelector('[data-field-name="school"] .field-value') || 
                                section.querySelector('.detail-org');
                console.log(`School element found:`, schoolEl);
                
                console.log(`Looking for degree element in education experience ${index + 1}...`);
                const degreeEl = section.querySelector('[data-field-name="degree"] .field-value') || 
                                section.querySelector('.detail-title');
                console.log(`Degree element found:`, degreeEl);
                
                console.log(`Looking for major element in education experience ${index + 1}...`);
                const majorEl = section.querySelector('[data-field-name="major"] .field-value');
                console.log(`Major element found:`, majorEl);
                
                console.log(`Looking for duration element in education experience ${index + 1}...`);
                const durationEl = section.querySelector('[data-field-name="duration"] .field-value') || 
                                  section.querySelector('.detail-date');
                console.log(`Duration element found:`, durationEl);
                
                const school = schoolEl ? schoolEl.textContent.trim() : '';
                const degree = degreeEl ? degreeEl.textContent.trim() : '';
                const major = majorEl ? majorEl.textContent.trim() : '';
                const duration = durationEl ? durationEl.textContent.trim() : '';
                
                console.log(`Education experience ${index + 1} - School:`, school);
                console.log(`Education experience ${index + 1} - Degree:`, degree);
                console.log(`Education experience ${index + 1} - Major:`, major);
                console.log(`Education experience ${index + 1} - Duration:`, duration);
                
                educationExperiences.push({
                    school,
                    degree,
                    major,
                    duration
                });
            } catch (error) {
                console.error(`Error processing education experience section ${index + 1}:`, error);
            }
        });
        
        data.educationExperiences = educationExperiences;
    } else {
        console.log("Education experience section not found");
        data.educationExperiences = "教育经历 section not found";
    }
    
    console.log("Scraped candidate data:", data);
    console.log("Sending scraped data back to background script...");

    // Store data locally if manually triggered
    if (isManualTrigger) {
        // Save to localStorage
        const storedData = JSON.parse(localStorage.getItem('candidateData') || '[]');
        storedData.push(data);
        localStorage.setItem('candidateData', JSON.stringify(storedData));
        console.log("Data saved to localStorage");
        
        // Show alert to user
        alert(`候选人数据已保存到本地存储:\n姓名: ${data.name}\n公司: ${data.current_company}\n职位: ${data.current_position}\n地点: ${data.location}`);
    }

    // Send back through callback
    if (sendResponse) {
        console.log("Using sendResponse callback to send data");
        sendResponse({ action: "detail_data", data: data });
    } else {
        // Fallback to sendMessage if no callback provided
        console.log("Using chrome.runtime.sendMessage to send data");
        chrome.runtime.sendMessage({ action: "detail_data", data: data });
    }
    
    console.log("Finished scraping candidate detail page");
}
