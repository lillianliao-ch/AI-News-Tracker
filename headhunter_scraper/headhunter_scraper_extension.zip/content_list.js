// Listen for messages from background script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "scrape_list") {
        scrapeLinks(sendResponse);
        return true; // Keep message channel open for async response
    } else if (request.action === "go_next_page") {
        goToNextPage(sendResponse);
        return true;
    } else if (request.action === "check_next_page") {
        // Trigger next page logic
        chrome.runtime.sendMessage({ action: "next_page_needed" });
        sendResponse({status: "next_page_requested"});
        return true;
    }
});

function scrapeLinks(sendResponse) {
    // Select all candidate links. Based on the screenshot, it's a table.
    // We'll look for links in the "姓名" column.
    // This selector might need adjustment based on actual DOM.
    // Assuming standard table structure or specific classes.
    // Strategy: Find all 'a' tags that look like candidate links.

    const links = [];
    
    // More robust selector for candidate links in the table
    // Target specifically the candidate detail links in the table
    const candidateLinks = document.querySelectorAll('table a[href*="candidate/detail"]');
    candidateLinks.forEach(link => {
        // Ensure we're getting the full URL
        const fullUrl = link.href;
        if (fullUrl) {
            links.push(fullUrl);
        }
    });

    // Additional fallback: look for links with specific class or attributes
    if (links.length === 0) {
        const allLinks = document.querySelectorAll('a[href*="candidate/detail"]');
        allLinks.forEach(a => {
            // Additional check to ensure it's a candidate link
            if (a.textContent.trim() !== '' || a.querySelector('img')) {
                links.push(a.href);
            }
        });
    }

    // Remove duplicates
    const uniqueLinks = [...new Set(links)];

    console.log(`Found ${uniqueLinks.length} candidate links`);
    console.log('Sample links:', uniqueLinks.slice(0, 3)); // Log first 3 links for debugging
    
    // Send response through callback
    if (sendResponse) {
        sendResponse({ action: "list_data", links: uniqueLinks });
    } else {
        // Fallback to sendMessage if no callback provided
        chrome.runtime.sendMessage({ action: "list_data", links: uniqueLinks });
    }
}

function goToNextPage(sendResponse) {
    // Find the "Next Page" button.
    // Screenshot shows standard pagination: < 1/51 >
    // Look for the '>' button.
    const buttons = document.querySelectorAll('button, li, a');
    let nextBtn = null;

    for (let btn of buttons) {
        // Enhanced selector for next page button
        if (btn.textContent.trim() === '>' || 
            btn.textContent.trim() === '下一页' ||
            btn.querySelector('.anticon-right') || 
            btn.classList.contains('ant-pagination-next') ||
            (btn.getAttribute('title') && btn.getAttribute('title').includes('下一页'))) {
            nextBtn = btn;
            break;
        }
    }

    if (nextBtn) {
        console.log("Next page button found, clicking...");
        nextBtn.click();
        
        // Send response immediately
        if (sendResponse) {
            sendResponse({status: "next_page_clicked"});
        }
        
        // Wait for load then scrape again
        setTimeout(() => {
            scrapeLinks(null); // No need to send response here as it's handled by background
        }, 3000);
    } else {
        console.log("Next page button not found");
        // Send response before stopping
        if (sendResponse) {
            sendResponse({status: "no_next_page"});
        }
        chrome.runtime.sendMessage({ action: "stop_scraping" });
    }
}
