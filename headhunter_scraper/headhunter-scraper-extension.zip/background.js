let scrapingState = {
    isScraping: false,
    maxPages: 5,
    pagesScraped: 0,
    candidateQueue: [],
    currentTabId: null
};

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log("Received message:", request);
    
    if (request.action === "start_scraping") {
        chrome.storage.local.get(['maxPages'], (result) => {
            scrapingState.maxPages = result.maxPages || 5;
            scrapingState.isScraping = true;
            scrapingState.pagesScraped = 0;
            scrapingState.candidateQueue = [];

            // Get the current active tab to start scraping the list
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                if (tabs[0]) {
                    scrapingState.listTabId = tabs[0].id;
                    console.log("Starting scraping on tab:", scrapingState.listTabId);
                    
                    // Using scripting API for Manifest V3 compatibility
                    chrome.scripting.executeScript({
                        target: { tabId: tabs[0].id },
                        files: ['content_list.js']
                    }, () => {
                        if (chrome.runtime.lastError) {
                            const errorMsg = "Script injection error: " + chrome.runtime.lastError.message;
                            console.error(errorMsg);
                            scrapingState.isScraping = false;
                            chrome.storage.local.set({ isScraping: false });
                            console.log("Please refresh the target page and reload the extension.");
                        } else {
                            console.log("Successfully injected content_list.js");
                            
                            // Send message after successful script injection
                            chrome.tabs.sendMessage(tabs[0].id, { action: "scrape_list" }, (response) => {
                                if (chrome.runtime.lastError) {
                                    const errorMsg = "Connection error: " + chrome.runtime.lastError.message;
                                    console.error(errorMsg);
                                    scrapingState.isScraping = false;
                                    chrome.storage.local.set({ isScraping: false });
                                    console.log("Please refresh the target page and reload the extension.");
                                } else if (response && response.action === "list_data") {
                                    // Handle the response directly here
                                    const newLinks = response.links || [];
                                    console.log("Received links from content script:", newLinks.length);
                                    
                                    if (newLinks.length > 0) {
                                        scrapingState.candidateQueue.push(...newLinks);
                                        console.log(`Added ${newLinks.length} candidates. Queue size: ${scrapingState.candidateQueue.length}`);
                                        
                                        // If we have candidates, start processing them
                                        processNextCandidate();
                                    } else {
                                        console.log("No candidate links found on this page");
                                        // Check if we should go to next page
                                        chrome.tabs.sendMessage(scrapingState.listTabId, { action: "check_next_page" });
                                    }
                                } else {
                                    console.log("Unexpected response from content script:", response);
                                }
                            });
                        }
                    });
                } else {
                    console.error("No active tab found");
                }
            });
        });
    } else if (request.action === "stop_scraping") {
        console.log("Stopping scraping process");
        scrapingState.isScraping = false;
        chrome.storage.local.set({ isScraping: false });
    } else if (request.action === "list_data") {
        // Received links from list page
        console.log("Received list_data message directly:", request);
        
        if (!scrapingState.isScraping) {
            console.log("Scraping is not active, ignoring list_data");
            return;
        }

        const newLinks = request.links || [];
        if (newLinks.length > 0) {
            scrapingState.candidateQueue.push(...newLinks);
            console.log(`Added ${newLinks.length} candidates. Queue size: ${scrapingState.candidateQueue.length}`);
            
            // If we have candidates, start processing them
            processNextCandidate();
        } else {
            console.log("No candidate links received");
            // Check if we should go to next page
            chrome.tabs.sendMessage(scrapingState.listTabId, { action: "check_next_page" });
        }
    
    } else if (request.action === "next_page_needed") {
        console.log("Next page needed, pages scraped:", scrapingState.pagesScraped, "max pages:", scrapingState.maxPages);
        
        if (scrapingState.pagesScraped < scrapingState.maxPages) {
            scrapingState.pagesScraped++;
            console.log("Going to next page, page count:", scrapingState.pagesScraped);
            
            chrome.tabs.sendMessage(scrapingState.listTabId, { action: "go_next_page" }, (response) => {
                if (chrome.runtime.lastError) {
                    const errorMsg = "Connection error for next page: " + chrome.runtime.lastError.message;
                    console.error(errorMsg);
                    scrapingState.isScraping = false;
                    chrome.storage.local.set({ isScraping: false });
                } else {
                    console.log("Next page request sent successfully, response:", response);
                }
            });
        } else {
            console.log("Max pages reached. Stopping scraping.");
            scrapingState.isScraping = false;
            chrome.storage.local.set({ isScraping: false });
        }
    }
});

function processNextCandidate() {
    console.log("Processing next candidate, queue size:", scrapingState.candidateQueue.length);
    
    if (!scrapingState.isScraping) {
        console.log("Scraping is not active, stopping process");
        return;
    }

    if (scrapingState.candidateQueue.length > 0) {
        const nextUrl = scrapingState.candidateQueue.shift();
        console.log("Opening candidate detail page:", nextUrl);
        
        chrome.tabs.create({ url: nextUrl, active: false }, (tab) => {
            if (chrome.runtime.lastError) {
                console.error("Error creating tab for candidate:", chrome.runtime.lastError.message);
                // Continue with next candidate
                setTimeout(processNextCandidate, 1000);
                return;
            }
            
            console.log("Created tab for candidate:", tab.id);
            
            // Inject content script for detail page
            chrome.scripting.executeScript({
                target: { tabId: tab.id },
                files: ['content_detail.js']
            }, () => {
                if (chrome.runtime.lastError) {
                    console.error("Script injection error for detail page:", chrome.runtime.lastError.message);
                    // Close the tab and continue with next candidate
                    chrome.tabs.remove(tab.id);
                    setTimeout(processNextCandidate, 1000);
                } else {
                    console.log("Successfully injected content_detail.js");
                    
                    // Send message to trigger scraping after successful script injection
                    console.log("Waiting 2 seconds before sending scrape_detail message to tab", tab.id);
                    setTimeout(() => {
                        console.log("Sending scrape_detail message to tab", tab.id);
                        chrome.tabs.sendMessage(tab.id, { action: "scrape_detail" }, (response) => {
                            if (chrome.runtime.lastError) {
                                const errorMsg = "Connection error for detail page: " + chrome.runtime.lastError.message;
                                console.error(errorMsg);
                                
                                // Close the tab and continue with next candidate
                                console.log("Closing tab due to connection error and continuing with next candidate");
                                chrome.tabs.remove(tab.id);
                                setTimeout(processNextCandidate, 1000);
                            } else if (response && response.action === "detail_data") {
                                // Handle the response directly here
                                const candidateData = response.data || {};
                                console.log("Scraped candidate:", candidateData.name || "Unknown");
                                console.log("Full candidate data:", candidateData);

                                // Send to backend
                                console.log("Sending candidate data to backend API at http://localhost:5001/api/save_candidate");
                                fetch('http://localhost:5001/api/save_candidate', {
                                    method: 'POST',
                                    headers: { 'Content-Type': 'application/json' },
                                    body: JSON.stringify(candidateData)
                                }).then(response => {
                                    console.log("Backend API response status:", response.status);
                                    if (!response.ok) {
                                        throw new Error(`HTTP error! status: ${response.status}`);
                                    }
                                    console.log("Successfully sent candidate data to backend");
                                    return response.json();
                                }).then(data => {
                                    console.log("Backend API response data:", data);
                                }).catch(err => {
                                    console.error("Error sending to backend:", err);
                                }).finally(() => {
                                    // Close the detail tab if it's not the list tab
                                    console.log("Closing detail tab and processing next candidate");
                                    if (tab.id !== scrapingState.listTabId) {
                                        chrome.tabs.remove(tab.id);
                                    }

                                    // Process next
                                    setTimeout(processNextCandidate, 1000); // Small delay
                                });
                            } else {
                                console.log("Unexpected response from detail page:", response);
                                
                                // Close the tab and continue with next candidate
                                console.log("Closing tab due to unexpected response and continuing with next candidate");
                                chrome.tabs.remove(tab.id);
                                setTimeout(processNextCandidate, 1000);
                            }
                        });
                    }, 2000); // Wait for page to load
                }
            });
        });
    } else {
        console.log("Candidate queue is empty, checking if we need to scrape more pages");
        // Queue empty, check if we need to scrape more pages
        // Ask list tab to go to next page
        chrome.tabs.sendMessage(scrapingState.listTabId, { action: "check_next_page" }, (response) => {
            if (chrome.runtime.lastError) {
                console.error("Error checking for next page:", chrome.runtime.lastError.message);
            } else {
                console.log("Check next page response:", response);
            }
        });
    }
}
