// Run automatically when page loads
window.addEventListener('load', () => {
    console.log("Page loaded, waiting 2 seconds before scraping...");
    setTimeout(scrapeDetail, 2000); // Wait for dynamic content
});

// Listen for messages from background script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "scrape_detail") {
        scrapeDetail(sendResponse);
        return true; // Keep message channel open for async response
    }
});

function scrapeDetail(sendResponse) {
    console.log("Starting to scrape candidate detail page...");
    console.log("Current page URL:", window.location.href);
    const data = {};
    
    // Add URL to data for debugging
    data.url = window.location.href;

    // Helper to extract text safely
    const getText = (selector) => {
        const el = document.querySelector(selector);
        return el ? el.innerText.trim() : '';
    };

    // Basic Info
    // Based on the provided HTML structure:
    // span (姓名) - 候选人姓名
    // span (城市) - 城市信息
    // a (当前公司) - 当前公司
    // span (当前职位) - 当前职位

    console.log("Attempting to extract basic info...");
    
    // Extract name - look for span with title attribute matching the name
    // Based on the provided structure: <span _ngcontent-ng-c3704861777="" title="汪羽萌">汪羽萌</span>
    let nameEl = document.querySelector('span[title]'); 
    
    // If not found, try other common selectors
    if (!nameEl) {
        nameEl = document.querySelector('.candidate-name') || 
                 document.querySelector('h1') || 
                 document.querySelector('[class*="name"]') ||
                 document.querySelector('title');
    }
    
    // Extract name from title attribute or text content
    if (nameEl) {
        data.name = nameEl.getAttribute('title') || nameEl.innerText.trim();
        // Clean up the name by removing extra info like ID
        if (data.name.includes('(ID:')) {
            data.name = data.name.split('(ID:')[0].trim();
        }
    } else {
        data.name = document.title ? document.title.split('(ID:')[0].trim() : '未知';
    }
    
    console.log("Candidate name element found:", nameEl);
    console.log("Candidate name:", data.name);

    // Extract current company and position
    console.log("Attempting to extract current company and position...");
    // Based on the provided structure: <a _ngcontent-ng-c3704861777="" data-sref="client.detail({id:155})" title="上海睿璞人才服务有限公司" href="#/client/detail?id=155">上海睿璞人才服务有限公司</a>
    const currentCompanyEl = document.querySelector('a[data-sref*="client"], a[href*="client"]') || 
                             document.querySelector('a[title]');
    data.current_company = currentCompanyEl ? (currentCompanyEl.getAttribute('title') || currentCompanyEl.innerText.trim()) : "";
    console.log("Current company element found:", currentCompanyEl);
    console.log("Current company:", data.current_company);

    // Based on the provided structure: <span _ngcontent-ng-c3704861777="" data-toggle="tooltip" title="猎头顾问">猎头顾问</span>
    const currentPositionEl = document.querySelector('span[data-toggle="tooltip"][title]') ||
                              document.querySelector('span[title*="顾问"], span[title*="经理"], span[title*="总监"]');
    data.current_position = currentPositionEl ? (currentPositionEl.getAttribute('title') || currentPositionEl.innerText.trim()) : "";
    console.log("Current position element found:", currentPositionEl);
    console.log("Current position:", data.current_position);

    // Extract location/city
    console.log("Attempting to extract location...");
    // Based on the provided structure, location seems to be in a span with class 'label label-default'
    let locationElements = Array.from(document.querySelectorAll('span.label.label-default'));
    console.log("Found", locationElements.length, "span elements to search for location");
    
    // If not found, fall back to all spans
    if (locationElements.length === 0) {
        locationElements = Array.from(document.querySelectorAll('span'));
    }
    
    // Find location element - look for one containing city names
    const cities = ['北京', '上海', '深圳', '广州', '杭州', '南京', '苏州', '无锡', '成都', '武汉', '西安', '长沙'];
    let locationEl = locationElements.find(el => 
        el.textContent && cities.some(city => el.textContent.includes(city))
    );
    
    // If still not found, try to find any element with location-like content
    if (!locationEl) {
        locationEl = locationElements.find(el => 
            el.textContent && (
                el.textContent.includes('市') || 
                el.textContent.includes('区') || 
                el.textContent.includes('县')
            )
        );
    }
    
    data.location = locationEl ? locationEl.textContent.trim() : "未知";
    console.log("Location element found:", locationEl);
    console.log("Location:", data.location);

    // Combine basic info for raw info
    data.raw_basic_info = `姓名: ${data.name}\n当前公司: ${data.current_company}\n当前职位: ${data.current_position}\n地点: ${data.location || '未知'}`;
    console.log("Raw basic info:", data.raw_basic_info);

    // Work Experience
    console.log("Attempting to extract work experience...");
    // Look for section headers like "工作经历"
    // Based on the provided HTML structure, work experience items are in div.detail-item elements
    let workExperiences = [];
    
    // Try to find work experience section based on the actual structure
    // Looking for div elements with class 'detail-item' that contain work experience data
    const workItems = document.querySelectorAll('div.detail-item');
    console.log("Found", workItems.length, "potential work experience items");
    
    workItems.forEach((item, index) => {
        // Look for elements that indicate this is a work experience item
        const isWorkItem = item.querySelector('[data-field-name="companyName"]') || 
                          item.querySelector('[data-field-name="position"]') ||
                          item.querySelector('[data-field-name="dateRange"]') ||
                          item.querySelector('.company-name') ||
                          item.querySelector('.position-title');
        
        if (isWorkItem) {
            console.log("Processing work experience item", index);
            
            // Extract company name
            const companyElement = item.querySelector('[data-field-name="companyName"]') || 
                                  item.querySelector('.company-name');
            const company = companyElement ? (companyElement.getAttribute('title') || companyElement.innerText.trim()) : '';
            
            // Extract position
            const positionElement = item.querySelector('[data-field-name="position"]') || 
                                   item.querySelector('.position-title');
            const position = positionElement ? (positionElement.getAttribute('title') || positionElement.innerText.trim()) : '';
            
            // Extract duration/date range
            const durationElement = item.querySelector('[data-field-name="dateRange"]') || 
                                   item.querySelector('.work-duration');
            const duration = durationElement ? durationElement.innerText.trim() : '';
            
            // Extract description
            const descriptionElement = item.querySelector('[data-field-name="description"]') || 
                                      item.querySelector('.work-description');
            const description = descriptionElement ? descriptionElement.innerText.trim() : '';
            
            console.log("Work experience item details - Company:", company, "Position:", position, "Duration:", duration);
            
            workExperiences.push({
                company: company,
                position: position,
                duration: duration,
                description: description
            });
        }
    });
    
    // Fallback to previous method if no work experiences found
    if (workExperiences.length === 0) {
        console.log("No work experiences found with new method, trying fallback approach...");
        const fallbackWorkItems = document.querySelectorAll('li.detail-fields[data-action="field/editable"][data-field-name="candidateexperience_set"]');
        console.log("Found", fallbackWorkItems.length, "work experience list items with fallback method");
        
        fallbackWorkItems.forEach((item, index) => {
            console.log("Processing fallback work experience item", index, ":", item.innerText);
            workExperiences.push({
                company: '',
                position: '',
                duration: '',
                description: item.innerText
            });
        });
    }
    
    // Format work experiences for storage
    if (workExperiences.length > 0) {
        data.work_experience = workExperiences.map(exp => 
            `${exp.company ? exp.company + ' - ' : ''}${exp.position ? exp.position + ' ' : ''}${exp.duration ? '(' + exp.duration + ')' : ''}\n${exp.description || ''}`
        ).join('\n\n').trim();
        console.log("Work experiences extracted:", workExperiences.length, "items");
    } else {
        data.work_experience = "工作经历 section not found";
        console.log("Work experience section not found");
    }

    // Education
    console.log("Attempting to extract education...");
    // Based on the provided HTML structure, education items are in div.detail-item elements
    let educations = [];
    
    // Try to find education section based on the actual structure
    // Looking for div elements with class 'detail-item' that contain education data
    const eduItems = document.querySelectorAll('div.detail-item');
    console.log("Found", eduItems.length, "potential education items");
    
    eduItems.forEach((item, index) => {
        // Look for elements that indicate this is an education item
        const isEduItem = item.querySelector('[data-field-name="school"]') || 
                         item.querySelector('[data-field-name="degree"]') ||
                         item.querySelector('[data-field-name="major"]') ||
                         item.querySelector('[data-field-name="eduDateRange"]');
        
        if (isEduItem) {
            console.log("Processing education item", index);
            
            // Extract school name
            const schoolElement = item.querySelector('[data-field-name="school"]');
            const school = schoolElement ? (schoolElement.getAttribute('title') || schoolElement.innerText.trim()) : '';
            
            // Extract degree
            const degreeElement = item.querySelector('[data-field-name="degree"]');
            const degree = degreeElement ? (degreeElement.getAttribute('title') || degreeElement.innerText.trim()) : '';
            
            // Extract major
            const majorElement = item.querySelector('[data-field-name="major"]');
            const major = majorElement ? (majorElement.getAttribute('title') || majorElement.innerText.trim()) : '';
            
            // Extract date range
            const dateRangeElement = item.querySelector('[data-field-name="eduDateRange"]');
            const dateRange = dateRangeElement ? dateRangeElement.innerText.trim() : '';
            
            console.log("Education item details - School:", school, "Degree:", degree, "Major:", major);
            
            educations.push({
                school: school,
                degree: degree,
                major: major,
                dateRange: dateRange
            });
        }
    });
    
    // Fallback to previous method if no educations found
    if (educations.length === 0) {
        console.log("No educations found with new method, trying fallback approach...");
        const fallbackEduItems = document.querySelectorAll('li.detail-fields[data-action="field/editable"][data-field-name="candidateeducation_set"]');
        console.log("Found", fallbackEduItems.length, "education list items with fallback method");
        
        fallbackEduItems.forEach((item, index) => {
            console.log("Processing fallback education item", index, ":", item.innerText);
            educations.push({
                school: '',
                degree: '',
                major: '',
                dateRange: '',
                description: item.innerText
            });
        });
    }
    
    // Format educations for storage
    if (educations.length > 0) {
        data.education = educations.map(edu => 
            `${edu.school ? edu.school + ' - ' : ''}${edu.degree ? edu.degree + ' ' : ''}${edu.major ? '(' + edu.major + ')' : ''}${edu.dateRange ? ' ' + edu.dateRange : ''}`
        ).join('\n\n').trim();
        console.log("Educations extracted:", educations.length, "items");
    } else {
        data.education = "教育经历 section not found";
        console.log("Education section not found");
    }
    
    console.log("Scraped candidate data:", data);
    console.log("Sending scraped data back to background script...");

    // Send back through callback
    if (sendResponse) {
        console.log("Using sendResponse callback to send data");
        sendResponse({ action: "detail_data", data: data });
    } else {
        // Fallback to sendMessage if no callback provided
        console.log("Using chrome.runtime.sendMessage to send data");
        chrome.runtime.sendMessage({ action: "detail_data", data: data });
    }
    
    console.log("Finished scraping candidate detail page");
}
