// 状态管理
let scrapeState = {
  isRunning: false,
  config: {},
  results: [],
  currentPage: 1,
  urlsToVisit: [], // 当前页需要抓取的详情页 URL 队列 (阿里平台)
  feishuJobs: [], // 飞书平台的职位列表
  feishuCurrentIndex: 0, // 飞书当前处理的职位索引
  bytedanceJobs: [], // ByteDance平台的职位列表
  bytedanceCurrentIndex: 0, // ByteDance当前处理的职位索引
  xiaohongshuJobs: [], // 小红书平台的职位列表
  xiaohongshuCurrentIndex: 0, // 小红书当前处理的职位索引
  deliveryUrls: [], // 投递记录详情页 URL 队列
  deliveryCurrentIndex: 0, // 当前处理索引
  deliveryDownloaded: 0, // 已下载计数
  deliveryFailed: 0, // 失败计数
  rootTabId: null,
  currentDetailTabId: null, // 跟踪当前正在抓取的详情页
  platform: 'alibaba', // 当前平台：alibaba, aliyun, feishu, bytedance, xiaohongshu
  scrapeType: 'jobs', // 抓取类型：jobs（职位）或 resumes（简历）
  feishuWaitingForDetail: false,
  bytedanceWaitingForDetail: false,
  xiaohongshuWaitingForDetail: false
};

// 只注册一次消息监听器
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  let handled = true;

  if (message.action === "START_SCRAPE") {
    startScrape(message.config);
    sendResponse({ status: "started" });
  } else if (message.action === "START_RESUME_SCRAPE") {
    startResumeScrape(message.config);
    sendResponse({ status: "started" });
  } else if (message.action === "START_XIAOHONGSHU_SCRAPE") {
    startXiaohongshuScrape(message.config);
    sendResponse({ status: "started" });
  } else if (message.action === "START_DELIVERY_SCRAPE") {
    startDeliveryScrape(message.config);
    sendResponse({ status: "started" });
  } else if (message.action === "START_RESUME_LIBRARY_SCRAPE") {
    startResumeLibraryScrape(message.config);
    sendResponse({ status: "started" });
  } else if (message.action === "DELIVERY_RECORDS_EXTRACTED") {
    handleDeliveryRecords(message.data);
    sendResponse({ received: true });
  } else if (message.action === "RESUME_LIBRARY_RECORDS_EXTRACTED") {
    handleResumeLibraryRecords(message.data);
    sendResponse({ received: true });
  } else if (message.action === "DELIVERY_DOWNLOAD_DONE") {
    // 关闭详情 tab，处理下一条
    if (scrapeState.currentDetailTabId) {
      chrome.tabs.remove(scrapeState.currentDetailTabId).catch(() => { });
      scrapeState.currentDetailTabId = null;
    }
    if (message.success) {
      scrapeState.deliveryDownloaded++;
    } else {
      scrapeState.deliveryFailed++;
    }
    console.log(`📬 下载进度: 成功 ${scrapeState.deliveryDownloaded}, 失败 ${scrapeState.deliveryFailed}`);
    setTimeout(() => processNextDeliveryRecord(), 1000);
    sendResponse({ received: true });
  } else if (message.action === "RESUME_LIBRARY_DOWNLOAD_DONE") {
    // 关闭详情 tab，处理下一条
    if (scrapeState.currentDetailTabId) {
      chrome.tabs.remove(scrapeState.currentDetailTabId).catch(() => { });
      scrapeState.currentDetailTabId = null;
    }
    if (message.success) {
      scrapeState.resumeLibraryDownloaded++;
    } else {
      scrapeState.resumeLibraryFailed++;
    }
    console.log(`📚 下载进度: 成功 ${scrapeState.resumeLibraryDownloaded}, 失败 ${scrapeState.resumeLibraryFailed}`);
    setTimeout(() => processNextResumeLibraryRecord(), 2000);
    sendResponse({ received: true });
  } else if (message.action === "LINKS_EXTRACTED") {
    // 阿里平台
    handleLinksExtracted(message.links);
    sendResponse({ received: true });
  } else if (message.action === "FEISHU_JOBS") {
    // 飞书平台：收到职位列表
    handleFeishuJobs(message.jobs);
    sendResponse({ received: true });
  } else if (message.action === "BYTEDANCE_JOBS") {
    // ByteDance平台：收到职位列表
    handleBytedanceJobs(message.jobs);
    sendResponse({ received: true });
  } else if (message.action === "XIAOHONGSHU_JOBS") {
    // 小红书平台：收到职位列表
    handleXiaohongshuJobs(message.jobs);
    sendResponse({ received: true });
  } else if (message.action === "DETAIL_SCRAPED") {
    handleDetailScraped(message.data);
    sendResponse({ received: true });
  } else if (message.action === "NEXT_PAGE_READY") {
    processNextPage();
    sendResponse({ received: true });
  } else if (message.action === "RESUME_LINKS_EXTRACTED") {
    // 简历管理页面：处理简历列表
    handleResumeLinksExtracted(message.data);
    sendResponse({ received: true });
  } else if (message.action === "RESUME_DETAIL_EXTRACTED") {
    // 简历详情抓取完成
    handleResumeDetailExtracted(message.data);
    sendResponse({ received: true });
  } else if (message.action === "RESUME_SCRAPING_ERROR") {
    // 简历抓取错误
    console.error("Resume scraping error:", message.data.error);
    handleResumeScrapingError(message.data.error);
    sendResponse({ received: true });
  } else if (message.action === "NEXT_PAGE_READY") {
    processNextPage();
    sendResponse({ received: true });
  } else if (message.action === "DETAIL_DATA") {
    // 处理详情数据
    if (scrapeState.platform === 'feishu') {
      // 飞书平台：检查是否正在等待数据
      if (!scrapeState.feishuWaitingForDetail) {
        console.warn("Feishu: Ignoring unexpected DETAIL_DATA");
        sendResponse({ ignored: true });
        return false;
      }
      scrapeState.feishuWaitingForDetail = false;

      console.log("Feishu detail scraped:", message.data);
      if (message.data) {
        scrapeState.results.push(message.data);
      }
      // 继续处理下一个职位
      setTimeout(() => processNextFeishuJob(), 1500);
      sendResponse({ received: true });
    } else if (scrapeState.platform === 'bytedance') {
      // ByteDance平台：检查是否正在等待数据
      if (!scrapeState.bytedanceWaitingForDetail) {
        console.warn("ByteDance: Ignoring unexpected DETAIL_DATA");
        sendResponse({ ignored: true });
        return false;
      }
      scrapeState.bytedanceWaitingForDetail = false;

      console.log("ByteDance detail scraped:", message.data);
      if (message.data) {
        scrapeState.results.push(message.data);
      }
      // 继续处理下一个职位（增加延迟避免反爬虫）
      setTimeout(() => processNextBytedanceJob(), 2000);
      sendResponse({ received: true });
    } else if (scrapeState.platform === 'xiaohongshu') {
      // 小红书平台：检查是否正在等待数据
      if (!scrapeState.xiaohongshuWaitingForDetail) {
        console.warn("Xiaohongshu: Ignoring unexpected DETAIL_DATA");
        sendResponse({ ignored: true });
        return false;
      }
      scrapeState.xiaohongshuWaitingForDetail = false;

      console.log("Xiaohongshu detail scraped:", message.data);
      if (message.data) {
        scrapeState.results.push(message.data);
      }
      // 继续处理下一个职位（增加延迟避免反爬虫，小红书反爬较严格）
      const delay = 2000 + Math.random() * 1000; // 2-3秒随机延迟
      setTimeout(() => processNextXiaohongshuJob(), delay);
      sendResponse({ received: true });
    } else {
      // 阿里平台
      if (sender.tab && sender.tab.id === scrapeState.currentDetailTabId) {
        if (scrapeState.currentDetailTabId === null) {
          console.warn("Ignoring duplicate DETAIL_DATA, already processed.");
          sendResponse({ ignored: true });
          return false;
        }

        console.log("Scraped detail:", message.data);
        scrapeState.results.push(message.data);

        const tabIdToClose = scrapeState.currentDetailTabId;
        scrapeState.currentDetailTabId = null;

        chrome.tabs.remove(tabIdToClose);
        setTimeout(() => processNextUrl(), 1000);
        sendResponse({ received: true });
      } else {
        console.warn("Ignoring DETAIL_DATA from unexpected tab:", sender.tab?.id, "expected:", scrapeState.currentDetailTabId);
        sendResponse({ ignored: true });
      }
    }
  } else if (message.action === "SKIP_PAGE") {
    console.warn("Skipping page:", message.url);
    if (sender.tab) {
      if (sender.tab.id === scrapeState.currentDetailTabId) {
        scrapeState.currentDetailTabId = null;
        chrome.tabs.remove(sender.tab.id);
        setTimeout(() => processNextUrl(), 500);
      } else {
        console.warn("Ignoring SKIP_PAGE from unexpected tab");
      }
    }
    sendResponse({ received: true });
  } else {
    handled = false;
  }

  // 必须返回true表示异步处理，false表示同步处理
  return handled;
});

function startScrape(config) {
  console.log("Starting scrape with config:", config);

  // 检测平台
  chrome.tabs.get(config.rootTabId, (tab) => {
    let platform = 'alibaba';
    if (tab.url.includes('hire.feishu.cn')) platform = 'feishu';
    else if (tab.url.includes('aliyun-headhunter')) platform = 'aliyun';

    console.log("Detected platform:", platform);

    scrapeState = {
      isRunning: true,
      config: config,
      results: [],
      currentPage: 1,
      urlsToVisit: [],
      feishuJobs: [],
      feishuCurrentIndex: 0,
      feishuWaitingForDetail: false, // 飞书：是否正在等待详情数据
      rootTabId: config.rootTabId,
      currentDetailTabId: null,
      platform: platform,
      scrapeType: 'jobs'
    };

    // 通知 Content Script 开始 - 先尝试注入 content script 确保连接可用
    ensureContentScriptLoaded(scrapeState.rootTabId).then(() => {
      chrome.tabs.sendMessage(scrapeState.rootTabId, {
        action: "INIT_LIST",
        tabType: config.tabType
      }).catch(err => {
        console.error("Failed to send INIT_LIST:", err);
        // 提示用户刷新页面
        chrome.tabs.reload(scrapeState.rootTabId, {}, () => {
          console.log("Reloaded tab due to connection error. Please try starting again.");
        });
      });
    }).catch(err => {
      console.error("Failed to ensure content script:", err);
      // 刷新页面以重新注入 content script
      chrome.tabs.reload(scrapeState.rootTabId, {}, () => {
        console.log("Reloaded tab to inject content script. Please try starting again.");
      });
    });
  });
}

// 确保 content script 已加载
async function ensureContentScriptLoaded(tabId) {
  try {
    // 先尝试发送一个简单的 ping 消息
    await chrome.tabs.sendMessage(tabId, { action: "PING" });
    console.log("Content script is already loaded");
    return true;
  } catch (err) {
    console.log("Content script not loaded, injecting...");
    // 如果发送失败，说明 content script 未加载，尝试注入
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tabId },
        files: ["content.js"]
      });
      // 等待脚本初始化
      await new Promise(resolve => setTimeout(resolve, 500));

      // 也注入 resume-parser.js
      await chrome.scripting.executeScript({
        target: { tabId: tabId },
        files: ["resume-parser.js"]
      });
      await new Promise(resolve => setTimeout(resolve, 300));

      console.log("Content scripts injected successfully");
      return true;
    } catch (injectErr) {
      console.error("Failed to inject content script:", injectErr);
      throw injectErr;
    }
  }
}

function handleLinksExtracted(links) {
  // 放宽背景脚本的过滤，相信 content.js 的判断
  const validLinks = links.filter(l => l.length > 20);

  console.log(`Received ${links.length} raw links, ${validLinks.length} potentially valid links.`);

  scrapeState.urlsToVisit = validLinks;

  if (scrapeState.urlsToVisit.length === 0) {
    console.warn("No links found on this page.");
    processNextUrl();
    return;
  }

  processNextUrl();
}

function processNextUrl() {
  // 如果还有正在处理的详情页，等待它完成
  if (scrapeState.currentDetailTabId !== null) {
    console.warn("Still waiting for current detail tab to finish, skipping processNextUrl");
    return;
  }

  if (scrapeState.urlsToVisit.length === 0) {
    // 当前页所有详情抓取完毕，尝试翻页
    if (scrapeState.currentPage < scrapeState.config.pageCount) {
      scrapeState.currentPage++;
      console.log(`Going to page ${scrapeState.currentPage}...`);
      chrome.tabs.sendMessage(scrapeState.rootTabId, {
        action: "GO_NEXT_PAGE"
      });
    } else {
      finishScrape();
    }
    return;
  }

  const url = scrapeState.urlsToVisit.shift();
  openDetailTab(url);
}

function openDetailTab(url) {
  // active: true 确保页面获得资源优先加载
  chrome.tabs.create({ url: url, active: true }, (tab) => {
    // 记录当前详情页 ID，防止重复处理
    scrapeState.currentDetailTabId = tab.id;

    // 使用一个一次性的监听器
    function onTabUpdated(tabId, info) {
      if (tabId === tab.id && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(onTabUpdated);
        // 发送抓取指令
        setTimeout(() => {
          chrome.tabs.sendMessage(tab.id, { action: "SCRAPE_DETAIL" }).catch(err => {
            console.error("Failed to send SCRAPE_DETAIL to tab", tab.id, err);
            // 发送失败，清除标记并继续下一个
            scrapeState.currentDetailTabId = null;
            chrome.tabs.remove(tab.id).catch(() => { });
            setTimeout(() => processNextUrl(), 500);
          });
        }, 1000);
      }
    }

    chrome.tabs.onUpdated.addListener(onTabUpdated);
  });
}

// 飞书平台：处理职位列表
function handleFeishuJobs(jobs) {
  console.log(`Received ${jobs.length} jobs from Feishu`);

  // 过滤掉 rowElement（不能序列化）
  scrapeState.feishuJobs = jobs.map(job => {
    const { rowElement, ...rest } = job;
    return rest;
  });
  scrapeState.feishuCurrentIndex = 0;

  if (scrapeState.feishuJobs.length === 0) {
    console.warn("No jobs found on Feishu page.");
    // 尝试翻页
    if (scrapeState.currentPage < scrapeState.config.pageCount) {
      scrapeState.currentPage++;
      chrome.tabs.sendMessage(scrapeState.rootTabId, { action: "GO_NEXT_PAGE" });
    } else {
      finishScrape();
    }
    return;
  }

  // 开始处理第一个职位
  processNextFeishuJob();
}

function processNextFeishuJob() {
  // 防止重复调用
  if (scrapeState.feishuWaitingForDetail) {
    console.warn("Feishu: Still waiting for detail, ignoring processNextFeishuJob call");
    return;
  }

  if (scrapeState.feishuCurrentIndex >= scrapeState.feishuJobs.length) {
    // 当前页所有职位处理完毕
    console.log(`Finished processing ${scrapeState.feishuJobs.length} jobs on page ${scrapeState.currentPage}`);

    if (scrapeState.currentPage < scrapeState.config.pageCount) {
      scrapeState.currentPage++;
      console.log(`Going to Feishu page ${scrapeState.currentPage}...`);
      chrome.tabs.sendMessage(scrapeState.rootTabId, { action: "GO_NEXT_PAGE" });
    } else {
      finishScrape();
    }
    return;
  }

  const index = scrapeState.feishuCurrentIndex;
  scrapeState.feishuCurrentIndex++;
  scrapeState.feishuWaitingForDetail = true; // 标记正在等待详情

  console.log(`Processing Feishu job ${index + 1}/${scrapeState.feishuJobs.length}`);

  // 发送消息让 content script 点击并抓取详情
  chrome.tabs.sendMessage(scrapeState.rootTabId, {
    action: "SCRAPE_FEISHU_DETAIL",
    rowIndex: index
  }).catch(err => {
    console.error("Failed to send SCRAPE_FEISHU_DETAIL:", err);
    scrapeState.feishuWaitingForDetail = false;
    // 跳过这个，继续下一个
    setTimeout(() => processNextFeishuJob(), 500);
  });
}

function finishScrape() {
  console.log("Scraping finished. Generating CSV...");
  scrapeState.isRunning = false;
  generateCSV(scrapeState.results);
}

function generateCSV(data) {
  if (!data || data.length === 0) {
    console.warn("No data to export");
    return;
  }

  // 定义标准字段顺序
  const standardHeaders = [
    '职位名称', '公司', '部门', '工作地点', '学历要求', '工作年限',
    '岗位层级', '岗位描述', '岗位要求', '招聘人数', 'HR',
    '发布日期', '更新日期', '有效日期', '职位状态', '职位链接'
  ];

  // 使用标准字段顺序，如果数据中没有某字段则留空
  // 如果数据中有额外字段（旧格式），也尝试映射
  const fieldMapping = {
    'title': '职位名称',
    'company': '公司',
    'department': '部门',
    'location': '工作地点',
    'degree': '学历要求',
    'experience': '工作年限',
    'level': '岗位层级',
    'description': '岗位描述',
    'requirements': '岗位要求',
    'headcount': '招聘人数',
    'hr': 'HR',
    'recruiter': 'HR',
    'publishDate': '发布日期',
    'updatedDate': '更新日期',
    'validDate': '有效日期',
    'status': '职位状态',
    'url': '职位链接'
  };

  // 转换数据，统一字段名
  const normalizedData = data.map(row => {
    const newRow = {};
    standardHeaders.forEach(h => newRow[h] = '');

    for (let [key, value] of Object.entries(row)) {
      // 如果已经是中文字段名
      if (standardHeaders.includes(key)) {
        newRow[key] = value || '';
      }
      // 如果是英文字段名，映射到中文
      else if (fieldMapping[key]) {
        newRow[fieldMapping[key]] = value || '';
      }
    }
    return newRow;
  });

  let csvContent = "\uFEFF" + standardHeaders.join(",") + "\n"; // BOM for Excel

  normalizedData.forEach(row => {
    let rowStr = standardHeaders.map(header => {
      let cell = row[header] || "";
      cell = String(cell).replace(/"/g, '""'); // Escape quotes
      if (cell.search(/("|,|\n)/g) >= 0) cell = `"${cell}"`;
      return cell;
    }).join(",");
    csvContent += rowStr + "\n";
  });

  // 触发下载
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const reader = new FileReader();
  reader.readAsDataURL(blob);
  reader.onload = function (e) {
    // 生成文件名：job_网页来源_日期_时间.csv
    const platformNames = {
      'alibaba': 'ali',
      'aliyun': 'aliyun',
      'feishu': 'feishu'
    };
    const platformName = platformNames[scrapeState.platform] || scrapeState.platform;
    const now = new Date();
    const date = now.toISOString().slice(0, 10); // YYYY-MM-DD
    const time = now.toTimeString().slice(0, 8).replace(/:/g, ''); // HHMMSS
    const filename = `job_${platformName}_${date}_${time}.csv`;

    console.log("Downloading file:", filename);

    chrome.downloads.download({
      url: e.target.result,
      filename: filename,
      saveAs: false
    });
  };
}

// 简历抓取相关函数

function startResumeScrape(config) {
  console.log("Starting resume scrape with config:", config);

  scrapeState = {
    isRunning: true,
    config: config,
    results: [],
    currentPage: 1,
    urlsToVisit: [],
    feishuJobs: [],
    feishuCurrentIndex: 0,
    feishuWaitingForDetail: false,
    rootTabId: config.rootTabId,
    currentDetailTabId: null,
    platform: 'alibaba', // 简历功能主要针对阿里巴巴平台
    scrapeType: 'resumes',
    resumes: [], // 简历列表
    resumeCurrentIndex: 0, // 当前处理的简历索引
    resumeWaitingForDetail: false // 是否正在等待简历详情
  };

  // 通知 Resume Parser 开始
  setTimeout(() => {
    chrome.tabs.sendMessage(scrapeState.rootTabId, {
      action: "START_RESUME_SCRAPE",
      config: {
        rootTabId: config.rootTabId,
        pageCount: config.pageCount
      }
    }).catch(err => {
      console.error("Failed to send INIT_RESUME:", err);
      chrome.tabs.reload(scrapeState.rootTabId, {}, () => {
        console.log("Reloaded tab due to connection error. Please try starting again.");
      });
    });
  }, 500);
}

function handleResumeLinksExtracted(data) {
  console.log(`Received ${data.resumes.length} resumes from page ${data.pageCount}`);

  // 存储简历列表
  scrapeState.resumes = data.resumes;
  scrapeState.resumeCurrentIndex = 0;

  if (scrapeState.resumes.length === 0) {
    console.warn("No resumes found on this page.");

    // 尝试翻页
    if (scrapeState.currentPage < scrapeState.config.pageCount) {
      scrapeState.currentPage++;
      chrome.tabs.sendMessage(scrapeState.rootTabId, {
        action: "CLICK_NEXT_RESUME_PAGE"
      });
    } else {
      finishResumeScrape();
    }
    return;
  }

  // 开始处理第一个简历
  processNextResume();
}

function processNextResume() {
  // 防止重复调用
  if (scrapeState.resumeWaitingForDetail) {
    console.warn("Resume: Still waiting for detail, ignoring processNextResume call");
    return;
  }

  if (scrapeState.resumeCurrentIndex >= scrapeState.resumes.length) {
    // 当前页所有简历处理完毕
    console.log(`Finished processing ${scrapeState.resumes.length} resumes on page ${scrapeState.currentPage}`);

    if (scrapeState.currentPage < scrapeState.config.pageCount) {
      scrapeState.currentPage++;
      console.log(`Going to resume page ${scrapeState.currentPage}...`);
      chrome.tabs.sendMessage(scrapeState.rootTabId, {
        action: "CLICK_NEXT_RESUME_PAGE"
      });
    } else {
      finishResumeScrape();
    }
    return;
  }

  const resume = scrapeState.resumes[scrapeState.resumeCurrentIndex];
  scrapeState.resumeCurrentIndex++;
  scrapeState.resumeWaitingForDetail = true; // 标记正在等待详情

  console.log(`Processing resume ${scrapeState.resumeCurrentIndex}/${scrapeState.resumes.length}: ${resume.name}`);
  console.log(`Opening resume URL: ${resume.link}`);

  // 打开新标签页加载简历详情
  chrome.tabs.create({ url: resume.link, active: true }, (tab) => {
    scrapeState.currentDetailTabId = tab.id;

    // 监听标签页更新，等待加载完成
    function onTabUpdated(tabId, info) {
      if (tabId === tab.id && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(onTabUpdated);

        // 页面加载完成后，发送抓取指令
        // DEBUG MODE: 等待时间延长到 60s
        setTimeout(() => {
          // 获取该标签页的所有 Frame，并向每个 Frame 发送指令
          chrome.webNavigation.getAllFrames({ tabId: tab.id }, (frames) => {
            if (!frames) return;

            console.log(`Broadcasting SCRAPE_RESUME_DETAIL to ${frames.length} frames in tab ${tab.id}`);

            frames.forEach(frame => {
              chrome.tabs.sendMessage(tab.id, {
                action: "SCRAPE_RESUME_DETAIL",
                data: {
                  resumeId: resume.id,
                  url: resume.link
                }
              }, { frameId: frame.frameId }).catch(err => {
                // 忽略某些 frame 发送失败
              });
            });
          });

          // DEBUG MODE: 移除自动超时关闭，改为极长超时
          // setTimeout(() => {
          //    if (scrapeState.currentDetailTabId === tab.id && scrapeState.resumeWaitingForDetail) {
          //        console.warn("Timeout waiting for resume detail, skipping...");
          //        handleResumeDetailExtracted({ resumeId: resume.id, detail: null });
          //    }
          // }, 15000); 

        }, 5000); // 保持5s启动延时
      }
    }

    chrome.tabs.onUpdated.addListener(onTabUpdated);
  });
}

function handleResumeDetailExtracted(data) {
  console.log("Resume detail extracted:", data.resumeId);

  if (data.detail) {
    // 添加简历详情到结果中
    const resumeDetail = {
      resumeId: data.resumeId,
      ...data.detail
    };

    // 保存到全局存储（合并模式）
    saveToGlobalResumeStorage(resumeDetail);

    // 保存到当前批次（兼容性）
    scrapeState.results.push(resumeDetail);
  }

  // 关闭详情页标签
  // DEBUG MODE: 强制等待 15 秒再关闭，以便用户查看 Console
  console.log("Wait 15s before closing tab...");
  setTimeout(() => {
    if (scrapeState.currentDetailTabId) {
      chrome.tabs.remove(scrapeState.currentDetailTabId).catch(() => { });
      scrapeState.currentDetailTabId = null;
    }

    scrapeState.resumeWaitingForDetail = false;

    // 继续处理下一个简历
    setTimeout(() => processNextResume(), 1000);
  }, 15000);
}

function handleResumeScrapingError(error) {
  console.error("Resume scraping error:", error);

  // 如果是页面检测错误，可能需要用户手动导航到正确的页面
  if (error.includes('resume management page')) {
    console.log("Please navigate to the resume management page first.");
    return;
  }

  // 对于其他错误，继续尝试
  scrapeState.resumeWaitingForDetail = false;
  setTimeout(() => processNextResume(), 2000);
}

function finishResumeScrape() {
  console.log("Resume scraping finished. Generating CSV...");
  scrapeState.isRunning = false;
  generateResumeCSV(scrapeState.results);
}

// 全局简历数据存储
let globalResumeStorage = {
  allResumes: [],
  lastExportTime: null
};

// 保存简历数据到全局存储
function saveToGlobalResumeStorage(resumeData) {
  // 避免重复数据（基于resumeId）
  const exists = globalResumeStorage.allResumes.find(r => r.resumeId === resumeData.resumeId);
  if (!exists) {
    globalResumeStorage.allResumes.push(resumeData);
    console.log(`📝 简历数据已保存到全局存储，总数：${globalResumeStorage.allResumes.length}`);
  } else {
    console.log(`📝 简历 ${resumeData.resumeId} 已存在，跳过保存`);
  }
}

// 手动导出所有简历数据
function exportAllResumes() {
  if (globalResumeStorage.allResumes.length === 0) {
    console.warn("没有可导出的简历数据");
    return;
  }

  console.log(`🚀 开始导出 ${globalResumeStorage.allResumes.length} 份简历数据`);
  generateResumeCSV(globalResumeStorage.allResumes);
  globalResumeStorage.lastExportTime = new Date().toISOString();
}

// 清除所有存储的简历数据
function clearGlobalResumeStorage() {
  globalResumeStorage.allResumes = [];
  globalResumeStorage.lastExportTime = null;
  console.log("🗑️ 已清除所有简历数据");
}

function generateResumeCSV(data) {
  if (!data || data.length === 0) {
    console.warn("No resume data to export");
    return;
  }

  // 简历数据标准字段
  const resumeHeaders = [
    '姓名', '电话', '邮箱', '现居地', '当前职位', '工作年限',
    '期望职位', '期望薪资', '教育经历', '工作经历', '技能标签',
    '项目经历', '自我评价', '简历链接', '提取时间'
  ];

  // 简历字段映射
  const resumeFieldMapping = {
    'name': '姓名',
    'phone': '电话',
    'email': '邮箱',
    'location': '现居地',
    'currentTitle': '当前职位',
    'yearsExp': '工作年限',
    'expectedTitle': '期望职位',
    'expectedSalary': '期望薪资',
    'education': '教育经历',
    'experience': '工作经历',
    'skills': '技能标签',
    'projects': '项目经历',
    'summary': '自我评价',
    'url': '简历链接',
    'extractedAt': '提取时间'
  };

  // 转换数据格式
  const normalizedData = data.map(row => {
    const newRow = {};
    resumeHeaders.forEach(h => newRow[h] = '');

    for (let [key, value] of Object.entries(row)) {
      if (resumeHeaders.includes(key)) {
        newRow[key] = value || '';
      } else if (resumeFieldMapping[key]) {
        newRow[resumeFieldMapping[key]] = value || '';
      }
    }
    return newRow;
  });

  let csvContent = "\uFEFF" + resumeHeaders.join(",") + "\n"; // BOM for Excel

  normalizedData.forEach(row => {
    let rowStr = resumeHeaders.map(header => {
      let cell = row[header] || "";

      // 处理复杂数据结构（转换为JSON字符串）
      if (typeof cell === 'object') {
        cell = JSON.stringify(cell);
      }

      cell = String(cell).replace(/"/g, '""'); // Escape quotes
      if (cell.search(/("|,|\n)/g) >= 0) cell = `"${cell}"`;
      return cell;
    }).join(",");
    csvContent += rowStr + "\n";
  });

  // 触发下载
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const reader = new FileReader();
  reader.readAsDataURL(blob);
  reader.onload = function (e) {
    // 生成文件名：resume_平台_日期_时间.csv
    const now = new Date();
    const date = now.toISOString().slice(0, 10); // YYYY-MM-DD
    const time = now.toTimeString().slice(0, 8).replace(/:/g, ''); // HHMMSS
    const filename = `resume_alibaba_${date}_${time}.csv`;

    console.log("Downloading resume file:", filename);
    console.log("📊 本次导出简历数量:", data.length);

    chrome.downloads.download({
      url: e.target.result,
      filename: filename,
      saveAs: false
    });
  };
}

// ============ ByteDance 平台处理函数 ============

function handleBytedanceJobs(jobs) {
  console.log(`Received ${jobs.length} ByteDance jobs`);

  if (jobs.length === 0) {
    console.log("No more jobs, finishing...");
    finishScrape();
    return;
  }

  scrapeState.bytedanceJobs = jobs;
  scrapeState.bytedanceCurrentIndex = 0;

  // 开始处理第一个职位
  processNextBytedanceJob();
}

function processNextBytedanceJob() {
  if (scrapeState.bytedanceCurrentIndex >= scrapeState.bytedanceJobs.length) {
    console.log("All ByteDance jobs processed, going to next page...");
    processNextPage();
    return;
  }

  const job = scrapeState.bytedanceJobs[scrapeState.bytedanceCurrentIndex];
  console.log(`Processing ByteDance job ${scrapeState.bytedanceCurrentIndex + 1}/${scrapeState.bytedanceJobs.length}: ${job.title}`);

  scrapeState.bytedanceWaitingForDetail = true;

  chrome.tabs.sendMessage(scrapeState.rootTabId, {
    action: "SCRAPE_BYTEDANCE_DETAIL",
    rowIndex: scrapeState.bytedanceCurrentIndex
  }, (response) => {
    if (chrome.runtime.lastError) {
      console.error("Failed to send SCRAPE_BYTEDANCE_DETAIL:", chrome.runtime.lastError);
      scrapeState.bytedanceWaitingForDetail = false;

      // 跳过当前职位，继续下一个
      scrapeState.bytedanceCurrentIndex++;
      setTimeout(() => processNextBytedanceJob(), 3000);
    }
  });

  scrapeState.bytedanceCurrentIndex++;
}

// ============ 小红书平台处理函数 ============

function startXiaohongshuScrape(config) {
  console.log("Starting Xiaohongshu scrape with config:", config);

  scrapeState = {
    isRunning: true,
    config: config,
    results: [],
    currentPage: 1,
    urlsToVisit: [],
    feishuJobs: [],
    feishuCurrentIndex: 0,
    feishuWaitingForDetail: false,
    bytedanceJobs: [],
    bytedanceCurrentIndex: 0,
    bytedanceWaitingForDetail: false,
    xiaohongshuJobs: [],
    xiaohongshuCurrentIndex: 0,
    xiaohongshuWaitingForDetail: false,
    rootTabId: config.rootTabId,
    currentDetailTabId: null,
    platform: 'xiaohongshu',
    scrapeType: 'jobs'
  };

  // 通知 Content Script 开始抓取小红书职位列表
  ensureContentScriptLoaded(scrapeState.rootTabId).then(() => {
    chrome.tabs.sendMessage(scrapeState.rootTabId, {
      action: "INIT_XIAOHONGSHU_LIST"
    }).catch(err => {
      console.error("Failed to send INIT_XIAOHONGSHU_LIST:", err);
      chrome.tabs.reload(scrapeState.rootTabId, {}, () => {
        console.log("Reloaded tab due to connection error. Please try starting again.");
      });
    });
  }).catch(err => {
    console.error("Failed to ensure content script:", err);
    chrome.tabs.reload(scrapeState.rootTabId, {}, () => {
      console.log("Reloaded tab to inject content script. Please try starting again.");
    });
  });
}

function handleXiaohongshuJobs(jobs) {
  console.log(`Received ${jobs.length} Xiaohongshu jobs`);

  if (jobs.length === 0) {
    console.log("No more Xiaohongshu jobs, finishing...");
    finishScrape();
    return;
  }

  scrapeState.xiaohongshuJobs = jobs;
  scrapeState.xiaohongshuCurrentIndex = 0;

  // 开始处理第一个职位
  processNextXiaohongshuJob();
}

function processNextXiaohongshuJob() {
  // 防止重复调用
  if (scrapeState.xiaohongshuWaitingForDetail) {
    console.warn("Xiaohongshu: Still waiting for detail, ignoring processNextXiaohongshuJob call");
    return;
  }

  if (scrapeState.xiaohongshuCurrentIndex >= scrapeState.xiaohongshuJobs.length) {
    // 当前页所有职位处理完毕
    console.log(`Finished processing ${scrapeState.xiaohongshuJobs.length} Xiaohongshu jobs on page ${scrapeState.currentPage}`);

    if (scrapeState.currentPage < scrapeState.config.pageCount) {
      scrapeState.currentPage++;
      console.log(`Going to Xiaohongshu page ${scrapeState.currentPage}...`);
      // 发送翻页命令
      chrome.tabs.sendMessage(scrapeState.rootTabId, { action: "GO_XIAOHONGSHU_NEXT_PAGE" });
    } else {
      finishScrape();
    }
    return;
  }

  const index = scrapeState.xiaohongshuCurrentIndex;
  scrapeState.xiaohongshuCurrentIndex++;
  scrapeState.xiaohongshuWaitingForDetail = true;

  console.log(`Processing Xiaohongshu job ${index + 1}/${scrapeState.xiaohongshuJobs.length}`);

  // 发送消息让 content script 点击并抓取详情
  chrome.tabs.sendMessage(scrapeState.rootTabId, {
    action: "SCRAPE_XIAOHONGSHU_DETAIL",
    rowIndex: index
  }).catch(err => {
    console.error("Failed to send SCRAPE_XIAOHONGSHU_DETAIL:", err);
    scrapeState.xiaohongshuWaitingForDetail = false;
    // 跳过这个，继续下一个
    setTimeout(() => processNextXiaohongshuJob(), 1000);
  });
}

// ============ 投递记录简历下载处理函数 ============

function startDeliveryScrape(config) {
  console.log("📬 Starting delivery record resume download with config:", config);

  scrapeState = {
    isRunning: true,
    config: config,
    results: [],
    currentPage: 1,
    urlsToVisit: [],
    feishuJobs: [],
    feishuCurrentIndex: 0,
    feishuWaitingForDetail: false,
    bytedanceJobs: [],
    bytedanceCurrentIndex: 0,
    bytedanceWaitingForDetail: false,
    xiaohongshuJobs: [],
    xiaohongshuCurrentIndex: 0,
    xiaohongshuWaitingForDetail: false,
    deliveryUrls: [],
    deliveryCurrentIndex: 0,
    deliveryDownloaded: 0,
    deliveryFailed: 0,
    rootTabId: config.rootTabId,
    currentDetailTabId: null,
    platform: 'alibaba',
    scrapeType: 'delivery'
  };

  // 确保 content script 已加载，然后发送初始化消息
  ensureContentScriptLoaded(scrapeState.rootTabId).then(() => {
    chrome.tabs.sendMessage(scrapeState.rootTabId, {
      action: "INIT_DELIVERY_LIST"
    }).catch(err => {
      console.error("Failed to send INIT_DELIVERY_LIST:", err);
      chrome.tabs.reload(scrapeState.rootTabId, {}, () => {
        console.log("Reloaded tab due to connection error. Please try starting again.");
      });
    });
  }).catch(err => {
    console.error("Failed to ensure content script:", err);
    chrome.tabs.reload(scrapeState.rootTabId, {}, () => {
      console.log("Reloaded tab to inject content script. Please try starting again.");
    });
  });
}

function handleDeliveryRecords(data) {
  const urls = data.urls || [];
  console.log(`📬 Received ${urls.length} delivery record URLs from page ${scrapeState.currentPage}`);

  scrapeState.deliveryUrls = urls;
  scrapeState.deliveryCurrentIndex = 0;

  if (urls.length === 0) {
    console.warn("📬 No delivery records found on this page.");
    // 尝试翻页
    if (scrapeState.currentPage < scrapeState.config.pageCount) {
      scrapeState.currentPage++;
      chrome.tabs.sendMessage(scrapeState.rootTabId, { action: "GO_DELIVERY_NEXT_PAGE" });
    } else {
      finishDeliveryScrape();
    }
    return;
  }

  processNextDeliveryRecord();
}

function processNextDeliveryRecord() {
  if (scrapeState.deliveryCurrentIndex >= scrapeState.deliveryUrls.length) {
    // 当前页所有记录处理完毕
    console.log(`📬 Finished page ${scrapeState.currentPage}, downloaded: ${scrapeState.deliveryDownloaded}, failed: ${scrapeState.deliveryFailed}`);

    if (scrapeState.currentPage < scrapeState.config.pageCount) {
      scrapeState.currentPage++;
      console.log(`📬 Going to delivery page ${scrapeState.currentPage}...`);
      chrome.tabs.sendMessage(scrapeState.rootTabId, { action: "GO_DELIVERY_NEXT_PAGE" });
    } else {
      finishDeliveryScrape();
    }
    return;
  }

  const url = scrapeState.deliveryUrls[scrapeState.deliveryCurrentIndex];
  scrapeState.deliveryCurrentIndex++;

  console.log(`📬 Processing delivery record ${scrapeState.deliveryCurrentIndex}/${scrapeState.deliveryUrls.length}: ${url}`);

  // 打开详情页 tab
  chrome.tabs.create({ url: url, active: true }, (tab) => {
    scrapeState.currentDetailTabId = tab.id;

    function onTabUpdated(tabId, info) {
      if (tabId === tab.id && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(onTabUpdated);

        // 页面加载完成后，等待 3s 再点击下载按钮
        setTimeout(() => {
          // 注入 content script 并发送下载指令
          ensureContentScriptLoaded(tab.id).then(() => {
            chrome.tabs.sendMessage(tab.id, {
              action: "CLICK_DELIVERY_DOWNLOAD"
            }).catch(err => {
              console.error("📬 Failed to send CLICK_DELIVERY_DOWNLOAD:", err);
              scrapeState.deliveryFailed++;
              if (scrapeState.currentDetailTabId) {
                chrome.tabs.remove(scrapeState.currentDetailTabId).catch(() => { });
                scrapeState.currentDetailTabId = null;
              }
              setTimeout(() => processNextDeliveryRecord(), 1000);
            });
          }).catch(err => {
            console.error("📬 Failed to inject content script into detail tab:", err);
            scrapeState.deliveryFailed++;
            if (scrapeState.currentDetailTabId) {
              chrome.tabs.remove(scrapeState.currentDetailTabId).catch(() => { });
              scrapeState.currentDetailTabId = null;
            }
            setTimeout(() => processNextDeliveryRecord(), 1000);
          });
        }, 3000);
      }
    }

    chrome.tabs.onUpdated.addListener(onTabUpdated);
  });
}

function finishDeliveryScrape() {
  scrapeState.isRunning = false;
  console.log("========================================");
  console.log("📬 投递记录简历下载完成!");
  console.log(`📬 成功下载: ${scrapeState.deliveryDownloaded}`);
  console.log(`📬 失败/跳过: ${scrapeState.deliveryFailed}`);
  console.log(`📬 总计处理页数: ${scrapeState.currentPage}`);
  console.log("========================================");
}

// ============ 简历库简历下载处理函数 ============

function startResumeLibraryScrape(config) {
  console.log("📚 Starting resume library download with config:", config);

  scrapeState = {
    isRunning: true,
    config: config,
    results: [],
    currentPage: 1,
    urlsToVisit: [],
    feishuJobs: [],
    feishuCurrentIndex: 0,
    feishuWaitingForDetail: false,
    bytedanceJobs: [],
    bytedanceCurrentIndex: 0,
    bytedanceWaitingForDetail: false,
    xiaohongshuJobs: [],
    xiaohongshuCurrentIndex: 0,
    xiaohongshuWaitingForDetail: false,
    resumeLibraryUrls: [],
    resumeLibraryCurrentIndex: 0,
    resumeLibraryDownloaded: 0,
    resumeLibraryFailed: 0,
    rootTabId: config.rootTabId,
    currentDetailTabId: null,
    platform: 'alibaba',
    scrapeType: 'resume_library'
  };

  // 确保 content script 已加载，然后发送初始化消息
  ensureContentScriptLoaded(scrapeState.rootTabId).then(() => {
    chrome.tabs.sendMessage(scrapeState.rootTabId, {
      action: "INIT_RESUME_LIBRARY_LIST"
    }).catch(err => {
      console.error("Failed to send INIT_RESUME_LIBRARY_LIST:", err);
      chrome.tabs.reload(scrapeState.rootTabId, {}, () => {
        console.log("Reloaded tab due to connection error. Please try starting again.");
      });
    });
  }).catch(err => {
    console.error("Failed to ensure content script:", err);
    chrome.tabs.reload(scrapeState.rootTabId, {}, () => {
      console.log("Reloaded tab to inject content script. Please try starting again.");
    });
  });
}

function handleResumeLibraryRecords(data) {
  const urls = data.urls || [];
  console.log(`📚 Received ${urls.length} resume library URLs from page ${scrapeState.currentPage}`);

  scrapeState.resumeLibraryUrls = urls;
  scrapeState.resumeLibraryCurrentIndex = 0;

  if (urls.length === 0) {
    console.warn("📚 No resume library records found on this page.");
    // 尝试翻页
    if (scrapeState.currentPage < scrapeState.config.pageCount) {
      scrapeState.currentPage++;
      chrome.tabs.sendMessage(scrapeState.rootTabId, { action: "GO_RESUME_LIBRARY_NEXT_PAGE" });
    } else {
      finishResumeLibraryScrape();
    }
    return;
  }

  processNextResumeLibraryRecord();
}

function processNextResumeLibraryRecord() {
  if (scrapeState.resumeLibraryCurrentIndex >= scrapeState.resumeLibraryUrls.length) {
    // 当前页所有记录处理完毕
    console.log(`📚 Finished page ${scrapeState.currentPage}, downloaded: ${scrapeState.resumeLibraryDownloaded}, failed: ${scrapeState.resumeLibraryFailed}`);

    if (scrapeState.currentPage < scrapeState.config.pageCount) {
      scrapeState.currentPage++;
      console.log(`📚 Going to resume library page ${scrapeState.currentPage}...`);
      console.log(`📚 Resting for 5 seconds before next page...`);

      // 每页之间休息 5 秒，避免过载
      setTimeout(() => {
        // 先切换回列表页并激活
        chrome.tabs.update(scrapeState.rootTabId, { active: true }, () => {
          // 确保 content script 已加载
          ensureContentScriptLoaded(scrapeState.rootTabId).then(() => {
            setTimeout(() => {
              chrome.tabs.sendMessage(scrapeState.rootTabId, { action: "GO_RESUME_LIBRARY_NEXT_PAGE" }).catch(err => {
                console.error("📚 Failed to send GO_RESUME_LIBRARY_NEXT_PAGE:", err);
                finishResumeLibraryScrape();
              });
            }, 500);
          }).catch(err => {
            console.error("📚 Failed to ensure content script in root tab:", err);
            finishResumeLibraryScrape();
          });
        });
      }, 5000);
    } else {
      finishResumeLibraryScrape();
    }
    return;
  }

  const url = scrapeState.resumeLibraryUrls[scrapeState.resumeLibraryCurrentIndex];
  scrapeState.resumeLibraryCurrentIndex++;

  console.log(`📚 Processing resume library record ${scrapeState.resumeLibraryCurrentIndex}/${scrapeState.resumeLibraryUrls.length}: ${url}`);

  // 打开详情页 tab
  chrome.tabs.create({ url: url, active: true }, (tab) => {
    scrapeState.currentDetailTabId = tab.id;

    let timeoutId = null;
    let hasProcessed = false;

    function onTabUpdated(tabId, info) {
      if (tabId === tab.id && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(onTabUpdated);
        if (timeoutId) clearTimeout(timeoutId);
        if (hasProcessed) return;
        hasProcessed = true;

        // 页面加载完成后，等待 3s 再点击下载按钮
        setTimeout(() => {
          // 注入 content script 并发送下载指令
          ensureContentScriptLoaded(tab.id).then(() => {
            chrome.tabs.sendMessage(tab.id, {
              action: "CLICK_RESUME_LIBRARY_DOWNLOAD"
            }).catch(err => {
              console.error("📚 Failed to send CLICK_RESUME_LIBRARY_DOWNLOAD:", err);
              scrapeState.resumeLibraryFailed++;
              if (scrapeState.currentDetailTabId) {
                chrome.tabs.remove(scrapeState.currentDetailTabId).catch(() => { });
                scrapeState.currentDetailTabId = null;
              }
              setTimeout(() => processNextResumeLibraryRecord(), 2000);
            });
          }).catch(err => {
            console.error("📚 Failed to inject content script into detail tab:", err);
            scrapeState.resumeLibraryFailed++;
            if (scrapeState.currentDetailTabId) {
              chrome.tabs.remove(scrapeState.currentDetailTabId).catch(() => { });
              scrapeState.currentDetailTabId = null;
            }
            setTimeout(() => processNextResumeLibraryRecord(), 2000);
          });
        }, 3000);
      }
    }

    // 设置 30 秒超时
    timeoutId = setTimeout(() => {
      if (hasProcessed) return;
      hasProcessed = true;
      chrome.tabs.onUpdated.removeListener(onTabUpdated);
      console.warn(`📚 Tab loading timeout for: ${url}`);
      scrapeState.resumeLibraryFailed++;
      if (scrapeState.currentDetailTabId) {
        chrome.tabs.remove(scrapeState.currentDetailTabId).catch(() => { });
        scrapeState.currentDetailTabId = null;
      }
      setTimeout(() => processNextResumeLibraryRecord(), 2000);
    }, 30000);

    chrome.tabs.onUpdated.addListener(onTabUpdated);
  });
}

function finishResumeLibraryScrape() {
  scrapeState.isRunning = false;
  console.log("========================================");
  console.log("📚 简历库简历下载完成!");
  console.log(`📚 成功下载: ${scrapeState.resumeLibraryDownloaded}`);
  console.log(`📚 失败/跳过: ${scrapeState.resumeLibraryFailed}`);
  console.log(`📚 总计处理页数: ${scrapeState.currentPage}`);
  console.log("========================================");
}
