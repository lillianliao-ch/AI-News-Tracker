document.addEventListener('DOMContentLoaded', function () {
  const startBtn = document.getElementById('startScrape');
  const targetTabSelect = document.getElementById('targetTab');
  const pageCountInput = document.getElementById('pageCount');
  const statusDiv = document.getElementById('status');

  // 初始化抓取配置
  startBtn.addEventListener('click', function () {
    const selectedValue = targetTabSelect.value;
    const pageCount = parseInt(pageCountInput.value) || 1;

    // 解析选择值来确定抓取类型和具体参数
    let scrapeType, configType;

    if (selectedValue.startsWith('jobs_')) {
      scrapeType = 'job';
      configType = selectedValue.replace('jobs_', '');
    } else if (selectedValue === 'xiaohongshu_jobs') {
      scrapeType = 'xiaohongshu';
      configType = 'jobs';
    } else if (selectedValue === 'resumes') {
      scrapeType = 'resume';
      configType = 'page_based';
    } else if (selectedValue === 'delivery_records') {
      scrapeType = 'delivery';
      configType = 'delivery';
    } else if (selectedValue === 'resume_library') {
      scrapeType = 'resume_library';
      configType = 'resume_library';
    }

    const config = {
      scrapeType: scrapeType,
      configType: configType,
      pageCount: pageCount,
      resumePageCount: 0,
      filterType: null
    };

    console.log('🎯 抓取配置:', config);
    statusDiv.textContent = `准备${scrapeType === 'delivery' || scrapeType === 'resume_library' ? '下载简历' : '抓取 ' + (scrapeType === 'job' ? '职位' : '简历')}，共 ${pageCount} 页`;

    // Send message to background script to start scraping
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      const currentTabId = tabs[0].id;
      const currentUrl = tabs[0].url;
      console.log('📡 当前页面URL:', currentUrl);

      // 检测是否在详情页
      const isDetailPage = currentUrl.includes('FORM-') || currentUrl.includes('orderCode=');
      console.log('🔍 页面类型:', isDetailPage ? '详情页' : '列表页');

      if (isDetailPage) {
        // 如果是详情页，直接抓取当前页面
        chrome.tabs.sendMessage(currentTabId, {
          action: 'SCRAPE_DETAIL',
          config: config
        }, function (response) {
          if (chrome.runtime.lastError) {
            console.error('❌ 消息发送失败:', chrome.runtime.lastError.message);
            statusDiv.textContent = `❌ 发送消息失败: ${chrome.runtime.lastError.message}`;
          } else {
            console.log('✅ 消息发送成功:', response);
            statusDiv.textContent = `✅ 正在抓取详情页...`;
          }
        });
      } else {
        // 如果是列表页，发送消息给 background script 启动抓取
        if (scrapeType === 'job') {
          // 职位抓取 - 发送给 background script
          const scrapeConfig = {
            rootTabId: currentTabId,
            tabType: configType,
            pageCount: pageCount
          };

          console.log('🚀 发送抓取请求到 background:', scrapeConfig);

          chrome.runtime.sendMessage({
            action: 'START_SCRAPE',
            config: scrapeConfig
          }, function (response) {
            if (chrome.runtime.lastError) {
              console.error('❌ 启动抓取失败:', chrome.runtime.lastError.message);
              statusDiv.textContent = `❌ 启动失败: ${chrome.runtime.lastError.message}`;
            } else {
              console.log('✅ 抓取启动成功:', response);
              statusDiv.textContent = `✅ 正在启动职位抓取...`;
            }
          });
        } else if (scrapeType === 'resume') {
          // 简历抓取 - 发送请求给 background script
          const scrapeConfig = {
            rootTabId: currentTabId,
            tabType: configType,
            pageCount: pageCount
          };

          console.log('📋 发送简历抓取请求到 background:', scrapeConfig);

          chrome.runtime.sendMessage({
            action: 'START_RESUME_SCRAPE',
            config: scrapeConfig
          }, function (response) {
            if (chrome.runtime.lastError) {
              console.error('❌ 启动简历抓取失败:', chrome.runtime.lastError.message);
              statusDiv.textContent = `❌ 启动失败: ${chrome.runtime.lastError.message}`;
            } else {
              console.log('✅ 简历抓取启动成功:', response);
              statusDiv.textContent = `✅ 正在启动简历抓取...`;
            }
          });
        } else if (scrapeType === 'xiaohongshu') {
          // 小红书职位抓取
          const scrapeConfig = {
            rootTabId: currentTabId,
            tabType: configType,
            pageCount: pageCount
          };

          console.log('📕 发送小红书抓取请求到 background:', scrapeConfig);

          chrome.runtime.sendMessage({
            action: 'START_XIAOHONGSHU_SCRAPE',
            config: scrapeConfig
          }, function (response) {
            if (chrome.runtime.lastError) {
              console.error('❌ 启动小红书抓取失败:', chrome.runtime.lastError.message);
              statusDiv.textContent = `❌ 启动失败: ${chrome.runtime.lastError.message}`;
            } else {
              console.log('✅ 小红书抓取启动成功:', response);
              statusDiv.textContent = `✅ 正在启动小红书职位抓取...`;
            }
          });
        } else if (scrapeType === 'delivery') {
          // 投递记录简历下载
          const scrapeConfig = {
            rootTabId: currentTabId,
            tabType: configType,
            pageCount: pageCount
          };

          console.log('📬 发送投递记录简历下载请求到 background:', scrapeConfig);

          chrome.runtime.sendMessage({
            action: 'START_DELIVERY_SCRAPE',
            config: scrapeConfig
          }, function (response) {
            if (chrome.runtime.lastError) {
              console.error('❌ 启动投递记录简历下载失败:', chrome.runtime.lastError.message);
              statusDiv.textContent = `❌ 启动失败: ${chrome.runtime.lastError.message}`;
            } else {
              console.log('✅ 投递记录简历下载启动成功:', response);
              statusDiv.textContent = `✅ 正在启动投递记录简历下载...`;
            }
          });
        } else if (scrapeType === 'resume_library') {
          // 简历库简历下载
          const scrapeConfig = {
            rootTabId: currentTabId,
            tabType: configType,
            pageCount: pageCount
          };

          console.log('📚 发送简历库简历下载请求到 background:', scrapeConfig);

          chrome.runtime.sendMessage({
            action: 'START_RESUME_LIBRARY_SCRAPE',
            config: scrapeConfig
          }, function (response) {
            if (chrome.runtime.lastError) {
              console.error('❌ 启动简历库简历下载失败:', chrome.runtime.lastError.message);
              statusDiv.textContent = `❌ 启动失败: ${chrome.runtime.lastError.message}`;
            } else {
              console.log('✅ 简历库简历下载启动成功:', response);
              statusDiv.textContent = `✅ 正在启动简历库简历下载...`;
            }
          });
        }
      }
    });
  });

  // 批量导入人才库按钮
  const batchImportBtn = document.getElementById('batchImportTalents');
  batchImportBtn.addEventListener('click', function () {
    statusDiv.textContent = '准备批量导入人才库...';

    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      const currentTabId = tabs[0].id;
      const currentUrl = tabs[0].url;

      // 检查是否在简历列表页
      if (!currentUrl.includes('headhunter') && !currentUrl.includes('resume')) {
        statusDiv.textContent = '❌ 请在简历列表页使用此功能';
        return;
      }

      // 发送批量导入消息
      chrome.tabs.sendMessage(currentTabId, {
        action: 'BATCH_IMPORT_TALENTS'
      }, function (response) {
        if (chrome.runtime.lastError) {
          console.error('❌ 消息发送失败:', chrome.runtime.lastError.message);
          statusDiv.textContent = `❌ 发送消息失败: ${chrome.runtime.lastError.message}`;
        } else {
          console.log('✅ 批量导入启动成功:', response);
          statusDiv.textContent = `✅ 正在批量导入人才库...`;
        }
      });
    });
  });

});

