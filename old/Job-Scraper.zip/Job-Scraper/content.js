function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function waitForDetailKeywords(timeout) {
  const start = Date.now();
  while (Date.now() - start < timeout) {
    const text = document.body.innerText;
    if (text.includes("岗位描述") || text.includes("岗位要求") || text.includes("职位详情")) {
      return true;
    }
    await sleep(500);
  }
  return false;
}

// 等待元素出现
async function waitForElement(selector, timeout = 5000) {
  const start = Date.now();
  while (Date.now() - start < timeout) {
    const el = document.querySelector(selector);
    if (el) return el;
    await sleep(500);
  }
  return null;
}

// --- 列表页逻辑 ---

// 检测当前平台
function detectPlatform() {
  const url = window.location.href;
  if (url.includes('hire.feishu.cn')) return 'feishu';
  if (url.includes('aliyun-headhunter.alibaba-inc.com')) return 'aliyun';
  if (url.includes('headhunter.alibaba.com')) return 'alibaba';
  if (url.includes('jobs.bytedance.com')) return 'bytedance';
  if (url.includes('hunter.xiaohongshu.com')) return 'xiaohongshu';
  return 'unknown';
}

// 防止消息监听器重复注册
if (!window.jobScraperListenerRegistered) {
  window.jobScraperListenerRegistered = true;
  console.log("Content script ready, waiting for commands...");

  chrome.runtime.onMessage.addListener(async (message, sender, sendResponse) => {
    // PING 消息用于检测 content script 是否已加载
    if (message.action === "PING") {
      sendResponse({ status: "ready" });
      return true;
    }

    const platform = detectPlatform();
    console.log("Platform detected:", platform);

    if (message.action === "INIT_LIST") {
      console.log("Initializing list for tab:", message.tabType);

      // 清除之前的抓取状态
      clearFeishuDetailStates();

      if (platform === 'feishu') {
        // 飞书平台：直接在当前页面抓取，不需要切换 Tab
        const jobs = await scrapeFeishuList();
        chrome.runtime.sendMessage({ action: "FEISHU_JOBS", jobs: jobs });
      } else if (platform === 'bytedance') {
        // ByteDance平台：直接在当前页面抓取
        const jobs = await scrapeBytedanceList();
        chrome.runtime.sendMessage({ action: "BYTEDANCE_JOBS", jobs: jobs });
      } else if (platform === 'xiaohongshu') {
        // 小红书平台：不应该收到 INIT_LIST，忽略
        console.log("Xiaohongshu platform detected, ignoring INIT_LIST (should use INIT_XIAOHONGSHU_LIST)");
      } else {
        // 阿里平台 (alibaba/aliyun)
        await switchTab(message.tabType);
        const links = await extractLinks();
        chrome.runtime.sendMessage({ action: "LINKS_EXTRACTED", links: links });
      }
    } else if (message.action === "GO_NEXT_PAGE") {
      if (platform === 'feishu') {
        // 翻页前清除之前的抓取状态
        clearFeishuDetailStates();

        const success = await clickFeishuNextPage();
        if (success) {
          await sleep(2000);
          const jobs = await scrapeFeishuList();
          chrome.runtime.sendMessage({ action: "FEISHU_JOBS", jobs: jobs });
        } else {
          chrome.runtime.sendMessage({ action: "FEISHU_JOBS", jobs: [] });
        }
      } else if (platform === 'bytedance') {
        // ByteDance翻页
        clearFeishuDetailStates();

        const success = await clickBytedanceNextPage();
        if (success) {
          await sleep(2500);
          const jobs = await scrapeBytedanceList();
          chrome.runtime.sendMessage({ action: "BYTEDANCE_JOBS", jobs: jobs });
        } else {
          chrome.runtime.sendMessage({ action: "BYTEDANCE_JOBS", jobs: [] });
        }
      } else {
        const success = await clickNextPage();
        if (success) {
          await sleep(3000);
          const links = await extractLinks();
          chrome.runtime.sendMessage({ action: "LINKS_EXTRACTED", links: links });
        } else {
          console.error("Pagination failed");
          chrome.runtime.sendMessage({ action: "LINKS_EXTRACTED", links: [] });
        }
      }
    } else if (message.action === "SCRAPE_BYTEDANCE_DETAIL") {
      // ByteDance详情：点击职位，抓取数据
      const scrapeKey = `bytedance_detail_${message.rowIndex}`;
      if (window[scrapeKey]) {
        console.warn("SCRAPE_BYTEDANCE_DETAIL already executed for row:", message.rowIndex);
        return;
      }
      window[scrapeKey] = true;

      console.log("Scraping ByteDance detail for row:", message.rowIndex);
      const data = await scrapeBytedanceDetail(message.rowIndex);
      if (data) {
        chrome.runtime.sendMessage({ action: "DETAIL_DATA", data: data });
      } else {
        chrome.runtime.sendMessage({ action: "DETAIL_DATA", data: null });
      }
    } else if (message.action === "SCRAPE_FEISHU_DETAIL") {
      // 飞书详情：点击职位行，等待弹出层，抓取数据
      // 防止重复执行
      const scrapeKey = `feishu_detail_${message.rowIndex}`;
      if (window[scrapeKey]) {
        console.warn("SCRAPE_FEISHU_DETAIL already executed for row:", message.rowIndex);
        return;
      }
      window[scrapeKey] = true;

      console.log("Scraping Feishu detail for row:", message.rowIndex);
      const data = await scrapeFeishuDetail(message.rowIndex);
      if (data) {
        chrome.runtime.sendMessage({ action: "DETAIL_DATA", data: data });
      }
    } else if (message.action === "SCRAPE_DETAIL") {
      // 阿里详情页
      if (window.hasScrapedDetail) {
        console.warn("SCRAPE_DETAIL already executed for this page, ignoring duplicate request.");
        return;
      }
      window.hasScrapedDetail = true;

      console.log("Received SCRAPE_DETAIL command");
      const isDetail = await waitForDetailKeywords(8000);
      if (isDetail) {
        await scrapeDetailPage();
      } else {
        console.warn("Not a detail page or content did not load");
        chrome.runtime.sendMessage({ action: "SKIP_PAGE", url: window.location.href });
      }
    } else if (message.action === "LINKS_EXTRACTED") {
      // 响应列表页提取的链接，开始打开详情页
      console.log("📋 收到链接列表，开始处理:", message.links.length, "个链接");

      if (message.links && message.links.length > 0) {
        // 发送链接给 background.js 处理 - 使用正确的消息格式
        chrome.runtime.sendMessage({
          action: "LINKS_EXTRACTED",
          links: message.links
        }, function (response) {
          if (chrome.runtime.lastError) {
            console.error("❌ 发送链接处理请求失败:", chrome.runtime.lastError.message);
          } else {
            console.log("✅ 链接处理请求发送成功:", response);
          }
        });
      } else {
        console.warn("⚠️ 没有找到有效的职位链接");
        chrome.runtime.sendMessage({ action: "NO_LINKS_FOUND" });
      }
    } else if (message.action === "START_RESUME_SCRAPE") {
      // 简历抓取处理
      console.log("🏢 开始简历抓取...");
      handleResumeScrape(message.config);
    } else if (message.action === "RESUME_LINKS_EXTRACTED") {
      // 处理简历链接提取结果
      console.log("📋 收到简历链接列表:", message.data.resumes.length, "个简历");

      if (message.data.resumes && message.data.resumes.length > 0) {
        chrome.runtime.sendMessage({
          action: "RESUME_LINKS_EXTRACTED",
          data: message.data
        }, function (response) {
          if (chrome.runtime.lastError) {
            console.error("❌ 发送简历链接处理请求失败:", chrome.runtime.lastError.message);
          } else {
            console.log("✅ 简历链接处理请求发送成功:", response);
          }
        });
      } else {
        console.warn("⚠️ 没有找到有效的简历链接");
        chrome.runtime.sendMessage({ action: "NO_RESUME_LINKS_FOUND" });
      }
    } else if (message.action === "RESUME_DEBUG_INFO") {
      // 处理简历页面调试信息
      console.log("🔍 收到简历页面调试信息:", message.data.message);
      // 转发给 background.js
      chrome.runtime.sendMessage({
        action: "RESUME_DEBUG_INFO",
        data: message.data
      }, function (response) {
        if (chrome.runtime.lastError) {
          console.error("❌ 发送简历调试信息失败:", chrome.runtime.lastError.message);
        }
      });
    } else if (message.action === "SCRAPE_RESUME_DETAIL") {
      // 处理简历详情抓取
      console.log("📄 开始抓取简历详情:", message.data.resumeId);
      await scrapeResumeDetail(message.data);
    } else if (message.action === "INIT_XIAOHONGSHU_LIST") {
      // 小红书：初始化职位列表抓取
      console.log("📕 开始抓取小红书职位列表...");
      const jobs = await scrapeXiaohongshuList();
      chrome.runtime.sendMessage({ action: "XIAOHONGSHU_JOBS", jobs: jobs });
    } else if (message.action === "SCRAPE_XIAOHONGSHU_DETAIL") {
      // 小红书：抓取职位详情
      const scrapeKey = `xiaohongshu_detail_${message.rowIndex}`;
      if (window[scrapeKey]) {
        console.warn("SCRAPE_XIAOHONGSHU_DETAIL already executed for row:", message.rowIndex);
        return;
      }
      window[scrapeKey] = true;

      console.log("📕 Scraping Xiaohongshu detail for row:", message.rowIndex);
      const data = await scrapeXiaohongshuDetail(message.rowIndex);
      if (data) {
        chrome.runtime.sendMessage({ action: "DETAIL_DATA", data: data });
      } else {
        chrome.runtime.sendMessage({ action: "DETAIL_DATA", data: null });
      }
    } else if (message.action === "GO_XIAOHONGSHU_NEXT_PAGE") {
      // 小红书：翻页
      console.log("📕 小红书翻页...");
      const success = await clickXiaohongshuNextPage();
      if (success) {
        await sleep(2000);
        // 清除之前的抓取状态
        clearXiaohongshuDetailStates();
        const jobs = await scrapeXiaohongshuList();
        chrome.runtime.sendMessage({ action: "XIAOHONGSHU_JOBS", jobs: jobs });
      } else {
        console.log("Xiaohongshu pagination failed or no more pages");
        chrome.runtime.sendMessage({ action: "XIAOHONGSHU_JOBS", jobs: [] });
      }
    } else if (message.action === "INIT_DELIVERY_LIST") {
      // 投递记录：定位 section 容器 + 提取当前页所有详情页链接
      console.log("📬 开始提取投递记录列表...");
      initDeliverySectionContainer();
      const urls = await extractDeliveryRecords();
      chrome.runtime.sendMessage({
        action: "DELIVERY_RECORDS_EXTRACTED",
        data: { urls: urls }
      });
    } else if (message.action === "GO_DELIVERY_NEXT_PAGE") {
      // 投递记录：翻页后重新提取列表
      console.log("📬 投递记录翻页...");
      // 每次翻页前重新定位容器，防止 DOM 重渲染导致引用失效
      initDeliverySectionContainer();
      const success = await clickDeliveryNextPage();
      if (success) {
        await sleep(3000);
        const urls = await extractDeliveryRecords();
        chrome.runtime.sendMessage({
          action: "DELIVERY_RECORDS_EXTRACTED",
          data: { urls: urls }
        });
      } else {
        console.log("📬 翻页失败或没有更多页");
        chrome.runtime.sendMessage({
          action: "DELIVERY_RECORDS_EXTRACTED",
          data: { urls: [] }
        });
      }
    } else if (message.action === "CLICK_DELIVERY_DOWNLOAD") {
      // 投递记录详情页：点击下载简历按钮
      console.log("📬 在详情页查找并点击下载简历按钮...");
      const result = await clickDeliveryDownloadButton();
      chrome.runtime.sendMessage({
        action: "DELIVERY_DOWNLOAD_DONE",
        success: result
      });
    } else if (message.action === "INIT_RESUME_LIBRARY_LIST") {
      // 简历库：定位 section 容器 + 提取当前页所有详情页链接
      console.log("📚 开始提取简历库列表...");
      initResumeLibrarySectionContainer();
      const urls = await extractResumeLibraryRecords();
      chrome.runtime.sendMessage({
        action: "RESUME_LIBRARY_RECORDS_EXTRACTED",
        data: { urls: urls }
      });
    } else if (message.action === "GO_RESUME_LIBRARY_NEXT_PAGE") {
      // 简历库：翻页后重新提取列表
      console.log("📚 简历库翻页...");
      // 每次翻页前重新定位容器，防止 DOM 重渲染导致引用失效
      initResumeLibrarySectionContainer();
      const success = await clickResumeLibraryNextPage();
      if (success) {
        await sleep(3000);
        const urls = await extractResumeLibraryRecords();
        chrome.runtime.sendMessage({
          action: "RESUME_LIBRARY_RECORDS_EXTRACTED",
          data: { urls: urls }
        });
      } else {
        console.log("📚 翻页失败或没有更多页");
        chrome.runtime.sendMessage({
          action: "RESUME_LIBRARY_RECORDS_EXTRACTED",
          data: { urls: [] }
        });
      }
    } else if (message.action === "CLICK_RESUME_LIBRARY_DOWNLOAD") {
      // 简历库详情页：点击下载简历按钮
      console.log("📚 在详情页查找并点击下载简历按钮...");
      const result = await clickResumeLibraryDownloadButton();
      chrome.runtime.sendMessage({
        action: "RESUME_LIBRARY_DOWNLOAD_DONE",
        success: result
      });
    } else if (message.action === "BATCH_IMPORT_TALENTS") {
      // 批量导入人才库
      console.log("📥 开始批量导入人才库...");
      batchImportTalentsToAPI();
      sendResponse({ status: "started" });
      return true;
    }
  });
} // 结束 if (!window.jobScraperListenerRegistered) 块

// ============ 投递记录简历下载函数 ============

// 从投递记录列表页提取每行的详情页 URL
async function extractDeliveryRecords() {
  await sleep(1000); // 等待页面渲染

  const urls = [];

  // 策略1：查找表格行中的 <a> 标签链接
  const tableLinks = document.querySelectorAll('table a[href], .ant-table a[href], .next-table a[href]');
  for (const link of tableLinks) {
    const href = link.href || link.getAttribute('href');
    if (href && (href.includes('deliveryRecord') || href.includes('delivery') || href.includes('resumeCode') || href.includes('FORM-'))) {
      if (!urls.includes(href)) {
        urls.push(href);
      }
    }
  }

  // 策略2：如果策略1没找到，尝试从列表行中提取所有可能的详情链接
  if (urls.length === 0) {
    const allLinks = document.querySelectorAll('a[href]');
    for (const link of allLinks) {
      const href = link.href || link.getAttribute('href');
      if (href && href.includes('headhunter') && (href.includes('detail') || href.includes('resume') || href.includes('delivery') || href.includes('Record'))) {
        if (!urls.includes(href)) {
          urls.push(href);
        }
      }
    }
  }

  // 策略3：查找表格行，提取行内的链接或行点击跳转
  if (urls.length === 0) {
    const rows = document.querySelectorAll('tr[class*="row"], .ant-table-row, .next-table-row, tbody tr');
    for (const row of rows) {
      const link = row.querySelector('a[href]');
      if (link) {
        const href = link.href || link.getAttribute('href');
        if (href && href.length > 20 && !urls.includes(href)) {
          urls.push(href);
        }
      }
    }
  }

  console.log(`📬 提取到 ${urls.length} 条投递记录详情页链接`);
  urls.forEach((url, i) => console.log(`  ${i + 1}. ${url}`));
  return urls;
}

// 在详情页中查找并点击"下载简历"按钮
async function clickDeliveryDownloadButton() {
  await sleep(1000); // 等待页面渲染

  // 策略1：通过文本匹配查找按钮
  const allClickable = document.querySelectorAll('button, a, span, div[role="button"]');
  for (const el of allClickable) {
    const text = (el.innerText || el.textContent || '').trim();
    if (text.includes('下载简历') || text.includes('下载附件') || text.includes('下载 Resume') || text.includes('Download Resume')) {
      console.log("📬 找到下载按钮（文本匹配）:", text);
      el.click();
      await sleep(3000); // 等待下载触发
      return true;
    }
  }

  // 策略2：查找包含 download 相关属性的链接
  const downloadLinks = document.querySelectorAll('a[download], a[href*="download"], a[href*="resume"][href*=".pdf"], a[href*="resume"][href*=".doc"]');
  if (downloadLinks.length > 0) {
    console.log("📬 找到下载链接（属性匹配）:", downloadLinks[0].href);
    downloadLinks[0].click();
    await sleep(3000);
    return true;
  }

  // 策略3：查找图标按钮（下载图标 + 简历相关上下文）
  const iconButtons = document.querySelectorAll('[class*="download"], [class*="Download"], [aria-label*="下载"], [title*="下载简历"]');
  if (iconButtons.length > 0) {
    console.log("📬 找到下载按钮（图标/属性匹配）");
    iconButtons[0].click();
    await sleep(3000);
    return true;
  }

  console.warn("📬 未找到下载简历按钮，跳过此记录");
  return false;
}

// 定位投递记录所在的 section 容器（与 switchTab 类似的逻辑）
function initDeliverySectionContainer() {
  console.log("📬 [DEBUG] 开始定位投递记录 section 容器...");

  // 检查现有容器是否仍在 DOM 中
  if (window.deliverySectionContainer && document.contains(window.deliverySectionContainer)) {
    console.log("📬 [DEBUG] 现有容器仍有效，复用");
    return;
  }

  // 查找所有分页组件，选择可见的那个
  const allPaginations = document.querySelectorAll('.kuma-page, .ant-pagination, [class*="pagination"]');
  console.log("📬 [DEBUG] 找到", allPaginations.length, "个分页组件");

  for (const paginationEl of allPaginations) {
    // 跳过不可见的
    if (paginationEl.offsetParent === null && paginationEl.offsetHeight === 0) continue;

    console.log("📬 [DEBUG] 检查分页组件:", paginationEl.tagName, paginationEl.className);
    let parent = paginationEl.parentElement;
    for (let i = 0; i < 10 && parent; i++) {
      const hasTable = parent.querySelector('table, .ant-table, .kuma-table, .kuma-uxtable, .next-table, [class*="uxtable"]');
      if (hasTable) {
        window.deliverySectionContainer = parent;
        console.log("📬 定位到投递记录 section 容器:", parent.tagName, parent.className?.substring(0, 80));
        return;
      }
      parent = parent.parentElement;
    }
  }

  // 兜底：使用整个 document
  window.deliverySectionContainer = null;
  console.log("📬 未找到投递记录 section 容器，使用 document");
}

// 投递记录专用翻页函数 — 与 clickNextPage 保持一致的简单逻辑
async function clickDeliveryNextPage() {
  // 直接用 document 搜索，与 clickNextPage 一致
  let searchScope = window.deliverySectionContainer || document;
  console.log("📬 投递记录翻页，搜索范围:", searchScope === document ? "document" : searchScope.tagName);

  // 尝试多种分页按钮选择器（与 clickNextPage 完全一致）
  const selectors = [
    '.ant-pagination-next:not(.ant-pagination-disabled)',
    '.kuma-page-next:not(.kuma-page-disabled)',
    '.next-pagination-item.next-next:not(.next-disabled)',
    'li.next:not(.disabled) a',
    'button[aria-label="下一页"]:not([disabled])',
    '.pagination-next:not(.disabled)'
  ];

  for (let selector of selectors) {
    const nextBtn = searchScope.querySelector(selector);
    if (nextBtn) {
      console.log("📬 Found next page button:", selector);
      nextBtn.click();
      return true;
    }
  }

  // 备选：查找包含 ">" 或 "下一页" 文本的按钮
  const allButtons = searchScope.querySelectorAll('button, a, li');
  for (let btn of allButtons) {
    const text = btn.innerText.trim();
    if ((text === '>' || text === '下一页' || text === 'Next') && !btn.classList.contains('disabled')) {
      console.log("📬 Found next page button by text:", text);
      btn.click();
      return true;
    }
  }

  console.warn("📬 未找到翻页按钮，或已是最后一页");
  return false;
}

// 简历详情抓取函数
async function scrapeResumeDetail(data) {
  try {
    console.log("📄 简历详情抓取开始:", data.resumeId);
    console.log("📄 简历链接:", data.url);

    // 检查是否已经在简历详情页
    if (window.location.href.includes('resumeCode') ||
      window.location.href.includes('FORM-') ||
      window.location.href.includes('resume') ||
      await waitForDetailKeywords(2000)) {

      console.log("✅ 已在简历详情页，开始抓取数据");
      const resumeData = await extractResumeDetail();

      if (resumeData) {
        chrome.runtime.sendMessage({
          action: "RESUME_DETAIL_EXTRACTED",
          data: {
            resumeId: data.resumeId,
            detail: resumeData
          }
        });
      } else {
        console.error("❌ 简历详情抓取失败");
        chrome.runtime.sendMessage({
          action: "RESUME_SCRAPING_ERROR",
          data: { error: `简历 ${data.resumeId} 详情抓取失败` }
        });
      }

    } else {
      // 不在详情页，需要点击打开
      console.log("🔗 需要点击打开简历详情页");

      // 查找并点击简历链接
      const resumeLink = await findAndClickResumeLink(data.url);

      if (resumeLink) {
        console.log("✅ 成功点击简历链接，等待页面加载...");

        // 等待页面加载
        const loaded = await waitForDetailKeywords(8000);

        if (loaded) {
          console.log("✅ 简历详情页加载完成，开始抓取");
          const resumeData = await extractResumeDetail();

          if (resumeData) {
            chrome.runtime.sendMessage({
              action: "RESUME_DETAIL_EXTRACTED",
              data: {
                resumeId: data.resumeId,
                detail: resumeData
              }
            });
          }
        } else {
          console.error("❌ 简历详情页加载超时");
          chrome.runtime.sendMessage({
            action: "RESUME_SCRAPING_ERROR",
            data: { error: `简历 ${data.resumeId} 页面加载超时` }
          });
        }

      } else {
        console.error("❌ 未找到简历链接:", data.url);
        chrome.runtime.sendMessage({
          action: "RESUME_SCRAPING_ERROR",
          data: { error: `简历 ${data.resumeId} 链接未找到` }
        });
      }
    }

  } catch (error) {
    console.error("❌ 简历详情抓取异常:", error);
    chrome.runtime.sendMessage({
      action: "RESUME_SCRAPING_ERROR",
      data: { error: error.message }
    });
  }
}

// 检测页面类型（列表页 vs 详情页）
function detectPageType() {
  const pageText = document.body.innerText || '';
  const url = window.location.href;

  console.log("🔍 检测页面类型...");
  console.log("当前URL:", url);
  console.log("页面文本预览:", pageText.substring(0, 200));

  // 检查是否是详情页的特征
  const detailPageIndicators = [
    '个人信息',
    '联系方式',
    '教育背景',
    '工作经历',
    '项目经验',
    '姓名：',
    '手机：',
    '邮箱：',
    '居住地：',
    '期望职位：'
  ];

  // 检查是否是列表页的特征
  const listPageIndicators = [
    '候选人列表',
    '简历库',
    '猎头系统',
    '任务管理',
    '候选人投递职位',
    '操作',
    '更新人',
    '更新时间'
  ];

  let detailScore = 0;
  let listScore = 0;

  detailPageIndicators.forEach(indicator => {
    if (pageText.includes(indicator)) detailScore++;
  });

  listPageIndicators.forEach(indicator => {
    if (pageText.includes(indicator)) listScore++;
  });

  console.log(`详情页指标得分: ${detailScore}`);
  console.log(`列表页指标得分: ${listScore}`);

  if (detailScore > listScore) {
    console.log("✅ 检测为详情页");
    return 'detail';
  } else if (listScore > detailScore) {
    console.log("⚠️  检测为列表页");
    return 'list';
  } else {
    console.log("❓ 页面类型不确定");
    return 'unknown';
  }
}

// 查找并点击简历链接 - 改进版本
async function findAndClickResumeLink(targetUrl) {
  console.log("🔍 查找简历链接:", targetUrl);

  // 首先检测当前页面类型
  const pageType = detectPageType();

  if (pageType === 'detail') {
    console.log("✅ 已在详情页，无需点击链接");
    return true;
  }

  if (pageType === 'unknown') {
    console.log("❓ 页面类型不确定，尝试继续查找链接");
  }

  // 改进的链接选择器 - 优先查找候选人姓名链接
  const linkSelectors = [
    // 优先：包含候选人姓名的链接
    'a[href*="resumeCode"]',
    'a[href*="FORM-"]',
    'a[href*="resume"]',
    'a[href*="candidate"]',
    'a[href*="detail"]',
    // 备用：表格中的链接
    'td a[href]',
    'tr a[href]',
    '.candidate-name a',
    '.resume-link'
  ];

  let foundLinks = [];

  // 收集所有候选链接
  for (const selector of linkSelectors) {
    const links = document.querySelectorAll(selector);
    console.log(`选择器 "${selector}" 找到 ${links.length} 个链接`);

    for (const link of links) {
      const href = link.href || link.getAttribute('href');
      const text = link.innerText || link.textContent || '';

      if (href) {
        foundLinks.push({
          href: href,
          text: text.trim(),
          element: link
        });
      }
    }
  }

  console.log(`总共找到 ${foundLinks.length} 个候选链接`);

  // 过滤出最有可能的简历详情链接
  const candidateLinks = foundLinks.filter(link => {
    const href = link.href;
    const text = link.text;

    // 排除明显的系统链接
    const systemKeywords = ['猎头系统', '任务管理', '简历库', '登录', '首页', '操作', '管理'];
    const hasSystemKeyword = systemKeywords.some(keyword =>
      text.includes(keyword) || href.includes(keyword.toLowerCase())
    );

    if (hasSystemKeyword) {
      console.log(`排除系统链接: ${text} (${href})`);
      return false;
    }

    // 检查是否是简历详情链接
    const isResumeLink = href.includes('resumeCode') ||
      href.includes('FORM-') ||
      href.includes('resume') ||
      href.includes('candidate') ||
      href.includes('detail') ||
      text.length > 0; // 有文本内容的链接

    return isResumeLink;
  });

  console.log(`过滤后剩余 ${candidateLinks.length} 个候选链接`);

  // 按可信度排序
  candidateLinks.sort((a, b) => {
    const aScore = (a.href.includes('resumeCode') ? 10 : 0) +
      (a.href.includes('FORM-') ? 8 : 0) +
      (a.href.includes('resume') ? 6 : 0) +
      (a.text.length > 0 ? 2 : 0);
    const bScore = (b.href.includes('resumeCode') ? 10 : 0) +
      (b.href.includes('FORM-') ? 8 : 0) +
      (b.href.includes('resume') ? 6 : 0) +
      (b.text.length > 0 ? 2 : 0);
    return bScore - aScore;
  });

  // 尝试点击最有希望的链接
  for (let i = 0; i < Math.min(candidateLinks.length, 3); i++) {
    const link = candidateLinks[i];
    console.log(`尝试点击链接 ${i + 1}: ${link.text} (${link.href})`);

    try {
      // 模拟点击
      const clickEvent = new MouseEvent('click', {
        view: window,
        bubbles: true,
        cancelable: true
      });

      link.element.dispatchEvent(clickEvent);

      // 等待页面响应
      await sleep(1000);

      // 检查是否成功导航到详情页
      const newPageType = detectPageType();
      if (newPageType === 'detail') {
        console.log("✅ 成功导航到详情页");
        return true;
      }

    } catch (error) {
      console.error("点击链接时出错:", error);
    }
  }

  // 如果还是没有找到，尝试模糊匹配
  console.log("🔍 尝试模糊匹配任何包含resume或candidate的链接...");
  const allLinks = document.querySelectorAll('a[href]');
  for (const link of allLinks) {
    const href = link.href || link.getAttribute('href');
    const text = link.innerText || link.textContent || '';

    if (href && (href.includes('resume') || href.includes('candidate') || href.includes('detail'))) {
      console.log(`✅ 找到候选链接: ${text} (${href})`);

      // 跳过明显的系统链接
      const systemKeywords = ['猎头系统', '任务管理', '简历库'];
      const isSystemLink = systemKeywords.some(keyword =>
        text.includes(keyword) || href.includes(keyword.toLowerCase())
      );

      if (!isSystemLink) {
        const clickEvent = new MouseEvent('click', {
          view: window,
          bubbles: true,
          cancelable: true
        });
        link.dispatchEvent(clickEvent);

        await sleep(1500); // 等待更长时间

        const pageTypeAfter = detectPageType();
        if (pageTypeAfter === 'detail') {
          console.log("✅ 模糊匹配成功导航到详情页");
          return true;
        }
      }
    }
  }

  console.error("❌ 未找到有效的简历详情链接");
  return false;
}

// 提取简历详情数据 - 优化阿里巴巴平台
async function extractResumeDetail() {
  try {
    console.log("📄 开始提取阿里巴巴简历详情数据...");

    // 等待页面完全加载
    await sleep(2000);

    // 首先检测页面类型
    const pageType = detectPageType();

    if (pageType === 'list') {
      console.error("❌ 当前在列表页，无法提取简历详情数据");
      throw new Error("当前页面是列表页，不是简历详情页");
    }

    if (pageType === 'unknown') {
      console.log("⚠️  页面类型不确定，尝试继续提取但可能结果不准确");
    }

    console.log("✅ 确认在详情页，开始提取简历数据...");

    // 初始化简历数据
    const resumeData = {
      name: '',
      phone: '',
      email: '',
      location: '',
      currentTitle: '',
      yearsExp: '',
      expectedTitle: '',
      expectedSalary: '',
      education: '',
      experience: '',
      skills: '',
      projects: '',
      summary: '',
      url: window.location.href,
      extractedAt: new Date().toISOString()
    };

    // 1. 获取页面完整文本内容用于分析
    const fullText = document.body.innerText || '';
    console.log("页面文本预览:", fullText.substring(0, 500));

    // 2. 优先从表格结构提取数据 - 阿里巴巴通常使用表格展示简历信息
    const tableData = extractFieldsFromTable();
    console.log("表格提取的数据:", tableData);

    // 3. 如果表格提取失败，使用增强的文本提取
    if (!tableData.name || tableData.name === '未知') {
      const enhancedData = extractFromContent(fullText);
      Object.assign(tableData, enhancedData);
    }

    // 4. 合并所有提取的数据
    Object.assign(resumeData, tableData);

    // 5. 数据验证和清理
    resumeData.name = validateAndCleanName(resumeData.name, fullText);
    resumeData.phone = cleanPhoneNumber(resumeData.phone);
    resumeData.email = cleanEmail(resumeData.email);

    // 6. 提取详细信息段落
    resumeData.education = extractSectionByKeyword('教育', '学习', '学历');
    resumeData.experience = extractSectionByKeyword('工作', '经历', '经验');
    resumeData.projects = extractSectionByKeyword('项目', '作品');
    resumeData.skills = extractSectionByKeyword('技能', '特长', '专长');
    resumeData.summary = extractSectionByKeyword('自我', '简介', '评价');

    console.log("✅ 阿里巴巴简历详情提取完成:", resumeData.name);
    console.log("📊 最终提取的数据:", resumeData);

    return resumeData;

  } catch (error) {
    console.error("❌ 简历详情提取错误:", error);
    return null;
  }
}

// 从内容中提取数据 - 增强版本
function extractFromContent(fullText) {
  const data = {
    name: '',
    phone: '',
    email: '',
    location: '',
    currentTitle: '',
    yearsExp: '',
    expectedTitle: '',
    expectedSalary: ''
  };

  // 1. 提取姓名 - 跳过系统相关文本
  data.name = extractNameFromContentSmart(fullText);

  // 2. 提取联系方式 - 改进的正则表达式
  const phonePattern = /(?:电话[:：]\s*|手机[:：]\s*|联系电话[:：]\s*|联系电话[:： ]*)(\d{11})/;
  const phoneMatch = fullText.match(phonePattern);
  if (phoneMatch) {
    data.phone = phoneMatch[1];
  } else {
    // 备用模式：查找包含"电话"或"手机"后的数字
    const phoneAltPattern = /[电话手机][:： ]+(\d{11})/;
    const phoneAltMatch = fullText.match(phoneAltPattern);
    if (phoneAltMatch) data.phone = phoneAltMatch[1];
  }

  // 3. 提取邮箱 - 改进的正则表达式
  const emailPattern = /([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/;
  const emailMatch = fullText.match(emailPattern);
  if (emailMatch) {
    data.email = emailMatch[1];
  }

  // 4. 从表格行中提取结构化数据
  const tableRows = extractStructuredDataFromTable(fullText);
  Object.assign(data, tableRows);

  return data;
}

// 智能姓名提取 - 避免系统文本
function extractNameFromContentSmart(text) {
  console.log("🔍 开始智能姓名提取...");

  // 首先尝试从表格数据中提取
  const tableName = extractNameFromTable(text);
  if (tableName && tableName !== '未知') {
    console.log("从表格获取到姓名:", tableName);
    return tableName;
  }

  // 姓名模式匹配 - 排除系统相关文本
  const namePatterns = [
    /(?:姓名|候选人)[:：]\s*([^\n\r]{2,15})/,
    /(?:称呼|姓名)\s+([^\n\r]{2,15})/,
    // 查找中文姓名模式
    /([一-龯]{2,4})\s*(?:先生|女士|女士们|先生们|先生\/女士)/,
    // 查找类似姓名的文本
    /^([一-龯]{2,4})\s*[\r\n]/m
  ];

  for (const pattern of namePatterns) {
    const match = text.match(pattern);
    if (match) {
      const name = match[1].trim();
      console.log("模式匹配找到候选姓名:", name);
      if (isValidPersonName(name)) {
        console.log("姓名验证通过:", name);
        return name;
      } else {
        console.log("姓名验证失败:", name);
      }
    }
  }

  // 回退：查找第一个合理的中文名
  const lines = text.split('\n').map(line => line.trim()).filter(line => line.length > 0);
  console.log("扫描所有文本行，寻找有效姓名...");

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    console.log(`检查行 ${i}: "${line}"`);

    // 严格排除系统相关文本
    if (line.includes('猎头系统') || line.includes('系统') || line.includes('管理') ||
      line.includes('猎头') || line.includes('平台') || line.includes('页面') ||
      line.includes('列表') || line.includes('详情') || line.includes('操作') ||
      line.includes('登录') || line.includes('首页') || line.includes('任务')) {
      console.log("跳过系统相关文本:", line);
      continue;
    }

    if (isValidPersonName(line)) {
      console.log("找到有效姓名:", line);
      return line;
    } else {
      console.log("验证失败的候选:", line);
    }
  }

  console.log("未找到有效姓名，返回'未知'");
  return '未知';
}

// 验证是否为有效的个人姓名
function isValidPersonName(name) {
  if (!name || name.length < 2 || name.length > 6) return false;

  // 排除系统相关文本
  const systemKeywords = ['系统', '管理', '猎头', '平台', '页面', '列表', '详情', '操作', '登录', '首页'];
  for (const keyword of systemKeywords) {
    if (name.includes(keyword)) return false;
  }

  // 检查是否包含特殊字符
  if (/[0-9@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(name)) return false;

  // 检查是否都是中文或中文+英文字母
  if (/^[一-龯]{2,4}$/.test(name) || /^[一-龯]{2,4}[a-zA-Z]*$/.test(name)) {
    return true;
  }

  return false;
}

// 从表格数据中提取姓名
function extractNameFromTable(text) {
  // 查找表格行中的姓名
  const lines = text.split('\n');
  for (const line of lines) {
    if (line.includes('姓名') || line.includes('候选人')) {
      const match = line.match(/(?:姓名|候选人)[:：]\s*([^\n\r]+)/);
      if (match) {
        const name = match[1].trim();
        if (isValidPersonName(name)) {
          return name;
        }
      }
    }
  }

  return null;
}

// 提取结构化数据从表格
function extractStructuredDataFromTable(text) {
  const data = {};
  const lines = text.split('\n');

  // 字段映射
  const fieldMappings = {
    '现居地': 'location',
    '所在地': 'location',
    '居住地': 'location',
    '当前职位': 'currentTitle',
    '当前岗位': 'currentTitle',
    '现任职位': 'currentTitle',
    '工作年限': 'yearsExp',
    '工作经验': 'yearsExp',
    '工作年数': 'yearsExp',
    '期望职位': 'expectedTitle',
    '期望岗位': 'expectedTitle',
    '意向职位': 'expectedTitle',
    '期望薪资': 'expectedSalary',
    '期望薪酬': 'expectedSalary',
    '意向薪资': 'expectedSalary'
  };

  for (const line of lines) {
    for (const [chineseField, englishField] of Object.entries(fieldMappings)) {
      if (line.includes(chineseField)) {
        // 提取字段值
        const value = line.replace(new RegExp(`.*${chineseField}[:：]\\s*`), '').trim();
        if (value && value.length < 50 && !value.includes('系统') && !value.includes('管理')) {
          data[englishField] = value;
        }
        break;
      }
    }
  }

  return data;
}

// 验证和清理姓名
function validateAndCleanName(name, fullText) {
  console.log(`🔍 验证姓名: "${name}"`);

  // 如果名字为空或为'未知'，从内容中重新提取
  if (!name || name === '未知') {
    console.log("名字为空或未知，重新从内容中提取...");
    const lines = fullText.split('\n').map(l => l.trim()).filter(l => l.length > 0);

    for (const line of lines) {
      if (isValidPersonName(line) &&
        !line.includes('系统') &&
        !line.includes('管理') &&
        !line.includes('猎头') &&
        line.length >= 2 &&
        line.length <= 6) {
        console.log(`重新提取到有效姓名: "${line}"`);
        return line;
      }
    }

    console.log("未找到有效姓名");
    return '未知';
  }

  // 即使名字不为空，也要进行二次验证
  if (name.includes('猎头系统') || name.includes('系统') || name.includes('管理') ||
    name.includes('猎头') || name.includes('平台') || name.includes('页面') ||
    name.includes('列表') || name.includes('详情') || name.includes('操作') ||
    name.includes('登录') || name.includes('首页') || name.includes('任务')) {
    console.log(`姓名包含系统关键词，拒绝: "${name}"`);
    return '未知';
  }

  if (isValidPersonName(name) && name.length >= 2 && name.length <= 6) {
    console.log(`姓名验证通过: "${name}"`);
    return name;
  } else {
    console.log(`姓名验证失败: "${name}"`);
    return '未知';
  }
}

// 清理电话号码
function cleanPhoneNumber(phone) {
  if (!phone) return '';

  // 移除非数字字符
  const cleanPhone = phone.replace(/\D/g, '');

  // 验证电话号码长度
  if (cleanPhone.length === 11 && cleanPhone.startsWith('1')) {
    return cleanPhone;
  }

  return phone;
}

// 清理邮箱地址
function cleanEmail(email) {
  if (!email) return '';

  // 基本邮箱格式验证
  const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  if (emailPattern.test(email)) {
    return email;
  }

  return '';
}

// 从多个选择器中提取文本
function extractTextFromSelectors(selectors) {
  for (const selector of selectors) {
    try {
      const element = document.querySelector(selector);
      if (element && element.textContent.trim()) {
        return element.textContent.trim();
      }
    } catch (e) {
      // 忽略无效选择器
    }
  }
  return null;
}

// 从表格结构中提取字段
function extractFieldsFromTable() {
  const fields = {};
  const cells = document.querySelectorAll('td, th');

  for (let i = 0; i < cells.length; i++) {
    const cell = cells[i];
    const text = cell.textContent.trim();

    if (text.length < 2 || text.length > 50) continue;

    // 特殊处理姓名字段 - 使用严格的验证
    if (text.includes('姓名') || text.includes('候选人')) {
      const match = text.match(/(?:姓名|候选人)[:：]\s*([^\n\r]+)/);
      if (match) {
        const candidateName = match[1].trim();
        if (isValidPersonName(candidateName) && !candidateName.includes('系统')) {
          fields.name = candidateName;
        }
      }
      continue;
    }

    // 检查字段名
    const fieldPatterns = {
      '现居地': ['location', '现居地'],
      '当前职位': ['currentTitle', 'currentTitle'],
      '工作年限': ['yearsExp', 'yearsExp'],
      '期望职位': ['expectedTitle', 'expectedTitle'],
      '期望薪资': ['expectedSalary', 'expectedSalary'],
      '学历': ['education', 'education'],
      '教育': ['education', 'education']
    };

    for (const [key, pattern] of Object.entries(fieldPatterns)) {
      if (text.includes(key)) {
        // 查找对应的值
        let value = '';

        // 方案1：当前单元格包含 "key: value"
        const match = text.match(new RegExp(key + '[:：]\\s*(.+)'));
        if (match) {
          value = match[1].trim();
        } else {
          // 方案2：下一个单元格是值
          const nextCell = cells[i + 1];
          if (nextCell) {
            const nextText = nextCell.textContent.trim();
            if (nextText.length > 0 && nextText.length < 100 && !nextText.includes('系统')) {
              value = nextText;
            }
          }
        }

        if (value && !value.includes('系统')) {
          fields[pattern[0]] = value;
          break;
        }
      }
    }
  }

  return fields;
}

// 通过关键词提取文本段落
function extractSectionByKeyword(...keywords) {
  const fullText = document.body.innerText || '';

  for (const keyword of keywords) {
    // 查找关键词
    const keywordIndex = fullText.indexOf(keyword);
    if (keywordIndex !== -1) {
      // 提取关键词后的内容
      const afterKeyword = fullText.substring(keywordIndex);

      // 查找段落结束位置
      const lines = afterKeyword.split('\n');
      let content = '';
      let isInSection = false;

      for (const line of lines) {
        const trimmedLine = line.trim();

        if (trimmedLine.includes(keyword)) {
          isInSection = true;
          continue;
        }

        if (isInSection) {
          // 如果遇到新的字段标记，停止提取
          if (trimmedLine.match(/^[^\w]*[^\w]*$/) || trimmedLine.includes('：') || trimmedLine.includes(':')) {
            break;
          }

          if (trimmedLine.length > 0) {
            content += trimmedLine + '\n';
          }

          // 限制内容长度
          if (content.length > 1000) break;
        }
      }

      return content.trim();
    }
  }

  return '';
}

// 从内容中智能提取姓名
function extractNameFromContent(text) {
  // 姓名通常在页面前1000字符中
  const firstPart = text.substring(0, 1000);

  // 查找姓名模式
  const namePatterns = [
    /姓名[:：]\s*([^\n\r]+)/,
    /候选人[:：]\s*([^\n\r]+)/,
    /姓名\s+([^\n\r]{2,10})/
  ];

  for (const pattern of namePatterns) {
    const match = firstPart.match(pattern);
    if (match) {
      return match[1].trim();
    }
  }

  // 回退：查找第一个比较短的非空行
  const lines = firstPart.split('\n').map(line => line.trim()).filter(line => line.length > 0);
  if (lines.length > 0) {
    for (const line of lines) {
      if (line.length > 1 && line.length < 10 && !line.includes('：') && !line.includes(':')) {
        return line;
      }
    }
  }

  return '未知';
}

// 从内容中提取现居地
function extractLocationFromContent(text) {
  const locationPatterns = [
    /现居地[:：]\s*([^\n\r]+)/,
    /所在地[:：]\s*([^\n\r]+)/,
    /居住地[:：]\s*([^\n\r]+)/
  ];

  for (const pattern of locationPatterns) {
    const match = text.match(pattern);
    if (match) {
      return match[1].trim();
    }
  }

  return '';
}

// 从内容中提取期望职位
function extractExpectedTitleFromContent(text) {
  const titlePatterns = [
    /期望职位[:：]\s*([^\n\r]+)/,
    /意向职位[:：]\s*([^\n\r]+)/,
    /期望岗位[:：]\s*([^\n\r]+)/
  ];

  for (const pattern of titlePatterns) {
    const match = text.match(pattern);
    if (match) {
      return match[1].trim();
    }
  }

  return '';
}

// 辅助函数：提取文本
function extractText(selector) {
  try {
    const element = document.querySelector(selector);
    return element ? element.textContent.trim() : null;
  } catch (e) {
    return null;
  }
}

// 简历抓取处理函数
async function handleResumeScrape(config) {
  try {
    console.log("🏢 处理简历抓取配置:", config);

    // 检查简历解析器是否加载 - 先检查实例，再检查类
    if (typeof window.smartResumeParser === 'undefined' && typeof SmartResumeParser === 'undefined') {
      console.log("📄 简历解析器未加载，尝试动态加载...");
      await loadResumeParser();
    }

    // 获取解析器实例
    const parser = window.smartResumeParser || new SmartResumeParser();
    console.log("✅ 简历解析器可用:", parser.constructor.name);

    // 检测平台
    const platform = detectPlatform();
    console.log("简历抓取平台检测:", platform);

    if (platform !== 'alibaba') {
      console.warn("当前只支持阿里平台简历抓取");
      return;
    }

    // 创建简历解析器实例
    if (typeof SmartResumeParser !== 'undefined') {
      const resumeParser = new SmartResumeParser();

      // 开始简历抓取
      await resumeParser.initResumeScraping(config);
    } else {
      console.error("简历解析器未正确加载");
      chrome.runtime.sendMessage({
        action: "RESUME_SCRAPING_ERROR",
        data: { error: "简历解析器加载失败" }
      });
    }
  } catch (error) {
    console.error("简历抓取处理错误:", error);
    chrome.runtime.sendMessage({
      action: "RESUME_SCRAPING_ERROR",
      data: { error: error.message }
    });
  }
}

// 清除飞书详情抓取状态（翻页或开始新一轮抓取时调用）
function clearFeishuDetailStates() {
  // 清除所有 feishu_detail_X 状态
  for (let key in window) {
    if (key.startsWith('feishu_detail_')) {
      delete window[key];
    }
  }
  window.feishuWaitingForDetail = false;
  console.log("Cleared Feishu detail states");
}

// 全局变量（使用 window 避免重复声明错误）
if (typeof window.currentSectionContainer === 'undefined') {
  window.currentSectionContainer = null;
}
if (typeof window.currentTabType === 'undefined') {
  window.currentTabType = null;
}

async function switchTab(tabType) {
  // 保存当前选择的类型
  window.currentTabType = tabType;

  // 根据 tabType 确定要查找的区域标题
  let sectionKeyword = "";
  if (tabType === 'pending') {
    sectionKeyword = "待分配";
  } else if (tabType === 'allocated') {
    sectionKeyword = "已分配";
  } else if (tabType === 'myorders') {
    sectionKeyword = "我的订单";
  }

  console.log(`=== switchTab called with tabType: ${tabType} ===`);
  console.log(`Looking for section containing: "${sectionKeyword}"`);

  // 重置容器
  window.currentSectionContainer = null;

  // 策略：找到所有区域标题，然后定位到对应区域的表格
  // 区域标题通常是带有竖线装饰的文本，如 "| 待分配的订单"

  // 找到所有可能的区域标题
  const sectionTitles = [];
  const candidates = document.querySelectorAll('div, span, h1, h2, h3, h4, h5, p');

  for (let el of candidates) {
    if (el.offsetParent === null) continue;

    const text = el.innerText.trim();
    // 区域标题通常较短
    if (text.length < 3 || text.length > 20) continue;

    // 检查是否包含区域关键词
    if (text.includes("待分配") || text.includes("已分配") || text.includes("我的订单")) {
      // 确保这是一个叶子节点或接近叶子节点（不包含太多子元素）
      const childElements = el.querySelectorAll('*');
      if (childElements.length < 5) {
        sectionTitles.push({
          element: el,
          text: text,
          rect: el.getBoundingClientRect()
        });
        console.log(`Found section title: "${text}" at y=${el.getBoundingClientRect().top}`);
      }
    }
  }

  console.log(`Found ${sectionTitles.length} section titles total`);

  // 找到目标区域的标题
  let targetTitle = null;
  for (let title of sectionTitles) {
    if (title.text.includes(sectionKeyword)) {
      targetTitle = title;
      console.log(`Target section title: "${title.text}"`);
      break;
    }
  }

  if (!targetTitle) {
    console.warn(`Section title containing "${sectionKeyword}" not found.`);
    // 回退策略：使用表格索引
    await fallbackToTableIndex(tabType);
    return;
  }

  // 找到该标题对应的表格或列表容器
  // 策略：找到标题下方最近的表格或类似表格的容器

  // 支持多种表格选择器：标准 table、ant-design table、div 模拟的表格
  const tableSelectors = [
    'table',
    '.ant-table',
    '.ant-table-wrapper',
    '.kuma-table',
    '.next-table',
    '[class*="table"]',
    '[class*="list"]'
  ];

  let allTableLikeElements = [];
  for (let selector of tableSelectors) {
    const elements = document.querySelectorAll(selector);
    for (let el of elements) {
      // 确保元素可见且有一定大小
      const rect = el.getBoundingClientRect();
      if (rect.height > 100 && rect.width > 200) {
        allTableLikeElements.push({ element: el, rect: rect });
      }
    }
  }

  console.log(`Found ${allTableLikeElements.length} table-like elements on page`);

  let targetContainer = null;
  let minDistance = Infinity;

  for (let item of allTableLikeElements) {
    // 容器必须在标题下方
    if (item.rect.top > targetTitle.rect.top) {
      const distance = item.rect.top - targetTitle.rect.bottom;
      if (distance < minDistance && distance < 500) { // 限制最大距离
        minDistance = distance;
        targetContainer = item.element;
      }
    }
  }

  if (targetContainer) {
    window.currentSectionContainer = targetContainer;
    console.log(`Found target container ${minDistance}px below title`);
    console.log(`Container:`, window.currentSectionContainer.tagName, window.currentSectionContainer.className);
  } else {
    console.warn("No table/list container found below the section title.");
    // 备选：使用标题的父容器
    let parent = targetTitle.element.parentElement;
    let attempts = 0;
    while (parent && attempts < 5) {
      const links = parent.querySelectorAll('a');
      if (links.length >= 3) { // 至少有3个链接才算是列表区域
        window.currentSectionContainer = parent;
        console.log("Using parent container with links:", parent.tagName, parent.className);
        break;
      }
      parent = parent.parentElement;
      attempts++;
    }

    if (!window.currentSectionContainer) {
      await fallbackToTableIndex(tabType);
    }
  }

  // 输出容器信息
  if (window.currentSectionContainer) {
    const links = window.currentSectionContainer.querySelectorAll('a');
    const rows = window.currentSectionContainer.querySelectorAll('tr');
    console.log(`Container has ${links.length} links, ${rows.length} rows`);
  }

  await sleep(500);
}

async function fallbackToTableIndex(tabType) {
  console.log("Using fallback: finding list containers by structure");

  // 查找所有可能包含职位列表的容器
  // 特征：包含多个链接，且链接文本较长（职位名称）
  const allDivs = document.querySelectorAll('div');
  const listContainers = [];

  for (let div of allDivs) {
    const rect = div.getBoundingClientRect();
    // 容器必须可见且有一定大小
    if (rect.height < 200 || rect.width < 300) continue;

    const links = div.querySelectorAll('a');
    // 统计有效的职位链接（链接文本较长，且包含详情页特征）
    let validLinks = 0;
    for (let link of links) {
      const text = link.innerText.trim();
      const href = link.href || '';
      if (text.length > 10 && (href.includes('orderCode') || href.includes('FORM-'))) {
        validLinks++;
      }
    }

    if (validLinks >= 3) {
      listContainers.push({
        element: div,
        rect: rect,
        linkCount: validLinks
      });
    }
  }

  console.log(`Found ${listContainers.length} potential list containers`);

  if (listContainers.length === 0) {
    console.error("No list containers found on page!");
    window.currentSectionContainer = document.body;
    return;
  }

  // 按 Y 坐标排序（从上到下）
  listContainers.sort((a, b) => a.rect.top - b.rect.top);

  // 根据 tabType 选择第几个容器
  let containerIndex = 0;
  if (tabType === 'allocated') containerIndex = 1;
  if (tabType === 'myorders') containerIndex = 2;

  // 确保索引有效
  containerIndex = Math.min(containerIndex, listContainers.length - 1);

  window.currentSectionContainer = listContainers[containerIndex].element;
  console.log(`Using container #${containerIndex + 1} with ${listContainers[containerIndex].linkCount} job links`);
}

async function extractLinks() {
  // 提取当前区域的详情链接
  console.log("Extracting links from section...");

  // 确定搜索范围
  let searchScope = window.currentSectionContainer || document.body;

  if (searchScope === document.body) {
    console.warn("WARNING: No section container found, searching entire page.");
    console.log("This may include jobs from multiple sections.");
  }
  console.log("Search scope: section container", searchScope.tagName, searchScope.className);

  // 1. 等待数据行出现 (最多等 10秒)
  let attempts = 0;
  let rows = [];

  while (attempts < 20) {
    rows = searchScope.querySelectorAll('.ant-table-row, tr[data-row-key], tbody tr, .kuma-table-tbody tr, .next-table-row');
    if (rows.length > 0) break;
    await sleep(500);
    attempts++;
  }

  console.log(`Found ${rows.length} rows in section after waiting.`);

  let links = [];

  if (rows.length > 0) {
    // 从行里提取链接
    for (let row of rows) {
      const anchors = Array.from(row.querySelectorAll('a'));
      for (let anchor of anchors) {
        if (anchor.href) links.push(anchor.href);
      }
    }
    console.log(`Extracted ${links.length} raw links from table rows`);
  }

  // 如果标准方法没找到链接，使用 heuristic 但限定在区域内
  if (links.length < 2) {
    console.log("Standard extraction yielded few links, running heuristic in section...");
    const heuristicLinks = extractLinksFromScope(searchScope);
    links = [...links, ...heuristicLinks];
  }

  // 统一去重和清洗
  const uniqueLinks = new Set();
  const finalLinks = [];

  // 支持的域名
  const supportedDomains = [
    'headhunter.alibaba.com',
    'aliyun-headhunter.alibaba-inc.com'
  ];

  for (let href of links) {
    if (!href || href.includes('javascript') || href === '' || href === '#') continue;
    if (href.includes('dingtalk:')) continue;

    // 检查是否是支持的域名
    const isSupportedDomain = supportedDomains.some(domain => href.includes(domain));
    if (!isSupportedDomain) continue;

    // 详情页特征：包含 FORM- 或 orderCode=
    const hasDetailFeature = href.includes('FORM-') || href.includes('orderCode=');

    // 列表页特征
    const isListPage = (href.includes('task_management') || href.includes('is_manager=true'))
      && !hasDetailFeature;

    if (!hasDetailFeature) continue;
    if (isListPage) continue;
    if (href.replace(/\/$/, '') === window.location.origin) continue;

    if (!uniqueLinks.has(href)) {
      uniqueLinks.add(href);
      finalLinks.push(href);
    }
  }

  console.log(`Final links from section: ${finalLinks.length}`, finalLinks);
  return finalLinks;
}

// 从指定范围提取链接
function extractLinksFromScope(scope) {
  const links = [];
  const seenUrls = new Set();

  const allLinks = Array.from(scope.querySelectorAll('a'));

  for (let a of allLinks) {
    const href = a.href;
    const text = a.innerText.trim();

    if (!href || href.includes('javascript') || href === '' || href === '#') continue;
    // 排除首页链接
    if (href === 'https://headhunter.alibaba.com/' || href === 'https://headhunter.alibaba.com') continue;
    if (href === 'https://aliyun-headhunter.alibaba-inc.com/' || href === 'https://aliyun-headhunter.alibaba-inc.com') continue;
    if (text.length < 4) continue;
    if (['批量分配订单', '首页', '退出', '帮助', '意见反馈', '招聘职位', '工作地点', '更新日期', '职位发布人', 'DingTalk', 'dingtalk', '分配订单', '投递简历'].includes(text)) continue;
    if (href.includes('dingtalk:')) continue;
    // 排除列表页链接
    if ((href.includes('__navId=task_management') || href.includes('is_manager=true')) && !href.includes('orderCode') && !href.includes('FORM-')) continue;

    if (!seenUrls.has(href)) {
      links.push(href);
      seenUrls.add(href);
    }
  }

  console.log(`Heuristic found ${links.length} links in scope`);
  return links;
}


async function clickNextPage() {
  // 在当前区域内查找"下一页"按钮
  let searchScope = window.currentSectionContainer || document;

  // 尝试多种分页按钮选择器
  const selectors = [
    '.ant-pagination-next:not(.ant-pagination-disabled)',
    '.kuma-page-next:not(.kuma-page-disabled)',
    '.next-pagination-item.next-next:not(.next-disabled)',
    'li.next:not(.disabled) a',
    'button[aria-label="下一页"]:not([disabled])',
    '.pagination-next:not(.disabled)'
  ];

  for (let selector of selectors) {
    const nextBtn = searchScope.querySelector(selector);
    if (nextBtn) {
      console.log("Found next page button:", selector);
      nextBtn.click();
      return true;
    }
  }

  // 备选：查找包含 ">" 或 "下一页" 文本的按钮
  const allButtons = searchScope.querySelectorAll('button, a, li');
  for (let btn of allButtons) {
    const text = btn.innerText.trim();
    if ((text === '>' || text === '下一页' || text === 'Next') && !btn.classList.contains('disabled')) {
      console.log("Found next page button by text:", text);
      btn.click();
      return true;
    }
  }

  console.warn("Next page button not found in section");
  return false;
}

// --- 详情页逻辑 ---

async function scrapeDetailPage() {
  console.log("Scraping detail page...");
  await sleep(2000); // 等待渲染

  // 定义数据结构 - 使用标准化中文字段名
  const data = {
    职位名称: "",
    公司: "",
    部门: "",
    工作地点: "",
    学历要求: "",
    工作年限: "",
    岗位层级: "",
    岗位描述: "",
    岗位要求: "",
    招聘人数: "",
    HR: "",
    发布日期: "",
    更新日期: "",
    有效日期: "",
    职位状态: "",
    职位链接: window.location.href
  };

  // 新策略：先把整个页面的"标签-值"对全部提取出来，构建一个 Map
  const fieldMap = new Map();

  // 寻找所有 Table/Grid 单元格
  const cells = Array.from(document.querySelectorAll('td, th, div'));

  for (let i = 0; i < cells.length; i++) {
    const cell = cells[i];
    if (cell.offsetParent === null) continue;

    // 只看子元素少的（可能是单元格）
    if (cell.children.length > 3) continue;

    const text = cell.innerText.trim();

    // 跳过太长或太短的
    if (text.length < 2 || text.length > 100) continue;

    // 跳过包含代码的
    if (text.includes('window.') || text.includes('function') || text.includes('=')) continue;

    // 检查是否包含常见的标签关键词（带冒号）
    const labelPatterns = [
      '部门:', '部门：',
      '工作地点:', '工作地点：',
      '学历要求:', '学历要求：',
      '工作年限要求:', '工作年限要求：',
      '工作年限:', '工作年限：',
      '岗位层级:', '岗位层级：',
      '招聘人数:', '招聘人数：',
      '职位状态:', '职位状态：', '岗位状态:', '岗位状态：',
      '发布日期:', '发布日期：',
      '更新日期:', '更新日期：',
      '有效日期:', '有效日期：'
    ];

    for (let pattern of labelPatterns) {
      if (text.includes(pattern)) {
        // 提取 label (去掉冒号)
        const labelKey = pattern.replace(/[:：]/g, '');

        // 提取 value
        // Case 1: "Label: Value" 在同一单元格
        let value = text.replace(pattern, '').trim();

        // Case 2: Label 独立，Value 在下一个单元格
        if (value.length === 0 || value.includes(pattern.replace(/[:：]/g, ''))) {
          // 尝试下一个兄弟
          let nextCell = cell.nextElementSibling;
          if (nextCell) {
            value = nextCell.innerText.trim();
          }
        }

        if (value.length > 0 && value.length < 100) {
          fieldMap.set(labelKey, value);
        }
        break; // 找到一个 pattern 就跳出
      }
    }
  }

  console.log("Field map extracted:", Object.fromEntries(fieldMap));

  // 映射到 data 对象 - 使用标准化中文字段名
  data.部门 = fieldMap.get('部门') || '';
  data.工作地点 = fieldMap.get('工作地点') || '';
  data.学历要求 = fieldMap.get('学历要求') || '';
  data.工作年限 = fieldMap.get('工作年限要求') || fieldMap.get('工作年限') || '';
  data.岗位层级 = fieldMap.get('岗位层级') || '';
  data.招聘人数 = fieldMap.get('招聘人数') || '';
  data.职位状态 = fieldMap.get('职位状态') || fieldMap.get('岗位状态') || '';
  data.发布日期 = fieldMap.get('发布日期') || '';
  data.更新日期 = fieldMap.get('更新日期') || '';
  data.有效日期 = fieldMap.get('有效日期') || '';

  // 标题：避免抓到页面顶部的"猎头系统"
  // 详情页标题通常在页面内容区，且有特定的 class 或者是页面主标题
  // 策略：找第一个足够长的标题（职位名称通常很长）
  let titleCandidates = Array.from(document.querySelectorAll('h1, h2, h3, .title, .job-title, .vc-job-title'));
  for (let t of titleCandidates) {
    const text = t.innerText.trim();
    // 职位标题通常很长（10 字以上），排除"猎头系统"这种短标题
    if (text.length > 10 && !text.includes('猎头系统') && !text.includes('任务管理')) {
      data.职位名称 = text;
      break;
    }
  }

  // 如果还没找到，尝试从 URL 或其他位置找
  if (!data.职位名称) {
    // 有些页面标题在顶部的橙色 badge 旁边
    const badge = document.querySelector('.vc-text');
    if (badge && badge.innerText.length > 10) {
      data.职位名称 = badge.innerText.trim();
    }
  }

  // 招聘负责人/招聘责任人/HR：使用正则更精准地提取
  const pageText = document.body.innerText;
  const recruiterMatch = pageText.match(/招聘(?:负责人|责任人)[\s\n]*([^\n]+)/);
  if (recruiterMatch) {
    let recruiterText = recruiterMatch[1].trim();
    // 可能包含链接，去掉多余空格
    data.HR = recruiterText.split('\n')[0].trim();
  }

  // 岗位描述和要求
  const headings = Array.from(document.querySelectorAll('h3, h4, h5, div, span, strong, b'));
  for (let h of headings) {
    const text = h.innerText.trim();
    if (text.length > 20 || text.length < 2) continue;
    if (h.children.length > 0) continue;
    if (h.offsetParent === null) continue;

    let targetKey = null;
    if (text === "岗位描述" || text === "职位描述") targetKey = "岗位描述";
    if (text === "岗位要求" || text === "任职要求") targetKey = "岗位要求";

    if (targetKey && !data[targetKey]) {
      // 尝试找内容
      let content = h.nextElementSibling;

      if (!content && h.parentElement) {
        content = h.parentElement.nextElementSibling;
      }

      if (!content && h.parentElement && h.parentElement.parentElement) {
        if (h.parentElement.children.length === 1) {
          content = h.parentElement.parentElement.nextElementSibling;
        }
      }

      if (content && content.innerText.length > 10) {
        data[targetKey] = content.innerText.trim();
      }
    }
  }

  console.log("Scraped data:", data);

  // 发送回 Background
  chrome.runtime.sendMessage({ action: "DETAIL_DATA", data: data });
}

// ============ 飞书平台专用函数 ============

async function scrapeFeishuList() {
  console.log("Scraping Feishu job list...");
  await sleep(1000);

  const jobs = [];

  // 飞书页面结构：左侧是导航，右侧是职位列表
  // 需要找到右侧的主内容区域，通常包含 "全部职位" 标题和表格

  // 策略1：查找包含职位表格的主内容区域
  // 表格列：职位、客户、工作地点、职位类型、月薪范围、操作

  // 飞书使用分离式表格：固定列和滚动列分开渲染
  // 需要在整个页面范围内查找职位链接，而不是只在 table 内

  console.log("=== Feishu: Searching for clickable job rows ===");

  // 飞书页面职位列表不是用 <a> 标签，而是用可点击的 div/tr 行
  // 需要找到表格行或列表项

  const navKeywords = ['全部职位', '我收藏的职位', '推荐记录', '服务费申请', '客户公告', '人员管理', '推荐候选人', '猎头账号管理', '飞书招聘猎头端'];

  // 策略1: 查找表格行 (Arco Design / Semi Design 表格)
  let tableRows = document.querySelectorAll('.arco-table-tr, .semi-table-row, tr[data-row-key], [class*="table-row"]');
  console.log(`Found ${tableRows.length} table rows with specific selectors`);

  // 策略2: 如果没找到，查找通用表格行
  if (tableRows.length === 0) {
    tableRows = document.querySelectorAll('tbody tr');
    console.log(`Found ${tableRows.length} tbody tr rows`);
  }

  // 策略3: 查找 div 实现的虚拟列表
  if (tableRows.length === 0) {
    // 查找右侧内容区域
    const contentArea = document.querySelector('[class*="content"], [class*="main"], main');
    if (contentArea) {
      // 在内容区域查找可能的列表项
      tableRows = contentArea.querySelectorAll('[class*="row"], [class*="item"], [class*="list-item"]');
      console.log(`Found ${tableRows.length} list items in content area`);
    }
  }

  // 调试：输出页面结构
  console.log("=== DEBUG: Page structure analysis ===");

  // 策略改进：直接从表格行获取职位，不依赖关键词
  // 飞书的职位名称在第一列，通常有特定的 class
  let jobElements = [];
  const seenTexts = new Set();

  // 方法1：查找职位名称元素（通过 class 名）
  const positionNameElements = document.querySelectorAll('.position-name__3QXeW, [class*="position-name"], [class*="job-name"], .throne-biz-clamp-content');
  console.log(`Found ${positionNameElements.length} position name elements by class`);

  for (let el of positionNameElements) {
    const text = el.innerText?.trim() || '';
    const rect = el.getBoundingClientRect();

    // 基本过滤
    if (rect.left < 200 || rect.width < 50) continue;
    if (!text || text.length < 5 || text.length > 100) continue;
    if (navKeywords.some(kw => text.includes(kw))) continue;

    const firstLine = text.split('\n')[0].trim();
    if (!seenTexts.has(firstLine)) {
      console.log(`Position by class: "${firstLine}"`);
      jobElements.push({ element: el, text: firstLine });
      seenTexts.add(firstLine);
    }
  }

  // 方法2：如果方法1没找到足够的职位，从表格行的第一个单元格获取
  if (jobElements.length < 5 && tableRows.length > 0) {
    console.log("Trying to extract from table rows...");

    for (let row of tableRows) {
      // 跳过表头
      if (row.querySelector('th')) continue;

      const firstCell = row.querySelector('td');
      if (!firstCell) continue;

      const text = firstCell.innerText?.trim() || '';
      const firstLine = text.split('\n')[0].trim();

      if (firstLine.length < 5 || firstLine.length > 100) continue;
      if (navKeywords.some(kw => firstLine.includes(kw))) continue;

      if (!seenTexts.has(firstLine)) {
        console.log(`Position from row: "${firstLine}"`);
        jobElements.push({ element: firstCell, text: firstLine });
        seenTexts.add(firstLine);
      }
    }
  }

  console.log(`Found ${jobElements.length} job positions total`);

  // 如果找到了职位元素，使用它们
  let potentialJobLinks = [];

  if (jobElements.length > 0) {
    // 使用找到的职位元素
    for (let { element, text } of jobElements) {
      // 找到可点击的父元素（通常是行）
      let clickableRow = element;
      let parent = element.parentElement;
      let attempts = 0;
      while (parent && attempts < 8) {
        const parentRect = parent.getBoundingClientRect();
        // 行元素通常宽度较大
        if (parentRect.width > 500 && parentRect.height < 150) {
          clickableRow = parent;
        }
        parent = parent.parentElement;
        attempts++;
      }

      potentialJobLinks.push({
        element: clickableRow,
        text: text,
        href: window.location.href
      });
    }
  } else if (tableRows.length > 0) {
    // 使用表格行
    console.log("Using table rows...");
    tableRows.forEach((row, i) => {
      const text = row.innerText?.trim() || '';
      const firstLine = text.split('\n')[0].trim();
      const rect = row.getBoundingClientRect();

      // 跳过表头和空行
      if (rect.height < 30 || firstLine.length < 5) return;
      if (navKeywords.some(kw => firstLine.includes(kw))) return;

      console.log(`Row ${i}: "${firstLine.substring(0, 40)}" | height=${Math.round(rect.height)}`);

      potentialJobLinks.push({
        element: row,
        text: firstLine,
        href: window.location.href
      });
    });
  }

  console.log(`Found ${potentialJobLinks.length} potential job rows`);

  // 为每个职位行提取相关信息
  for (let { element, text, href } of potentialJobLinks) {
    const job = {
      title: text,
      url: href || window.location.href,
      client: '',
      location: '',
      jobType: '',
      salary: '',
      rowIndex: jobs.length
    };

    // 从行元素提取其他信息
    let rowContainer = element;
    const rowText = rowContainer?.innerText || '';

    if (rowText) {

      // 提取薪资
      const salaryMatch = rowText.match(/(\d+-\d+K?\s*CNY|\d+K\s*CNY)/i);
      if (salaryMatch) job.salary = salaryMatch[0];

      // 提取公司/客户
      const companies = ['ByteDance', 'MiniMax', '上海人工智能创新中心', '上海识装信息科技有限公司'];
      for (let company of companies) {
        if (rowText.includes(company)) {
          job.client = company;
          break;
        }
      }

      // 提取城市
      const cities = ['北京', '上海', '杭州', '深圳', '广州', '成都'];
      for (let city of cities) {
        if (rowText.includes(city) && !job.location) {
          job.location = city;
        }
      }

      // 提取职位类型
      const types = ['产品', '算法', '运营', '研发', '设计', '互联网', '网游', '电子'];
      for (let type of types) {
        if (rowText.includes(type) && !job.jobType) {
          job.jobType = type;
        }
      }
    }

    // 存储元素引用以便后续点击
    job.element = element;

    // 避免重复
    if (!jobs.some(j => j.title === job.title)) {
      console.log("Found job:", job.title, "| Client:", job.client, "| Salary:", job.salary);
      jobs.push(job);
    }
  }


  console.log(`Found ${jobs.length} jobs on Feishu page`);
  return jobs;
}

async function scrapeFeishuDetail(rowIndex) {
  console.log(`Scraping Feishu detail for row ${rowIndex}...`);

  // 使用和 scrapeFeishuList 相同的逻辑查找职位元素
  const navKeywords = ['全部职位', '我收藏的职位', '推荐记录', '服务费申请', '客户公告', '人员管理', '推荐候选人'];

  let jobElements = [];
  const seenTexts = new Set();

  // 方法1：查找职位名称元素（通过 class 名）
  const positionNameElements = document.querySelectorAll('.position-name__3QXeW, [class*="position-name"], [class*="job-name"], .throne-biz-clamp-content');

  for (let el of positionNameElements) {
    const text = el.innerText?.trim() || '';
    const rect = el.getBoundingClientRect();

    // 基本过滤
    if (rect.left < 200 || rect.width < 50) continue;
    if (!text || text.length < 5 || text.length > 100) continue;
    if (navKeywords.some(kw => text.includes(kw))) continue;

    const firstLine = text.split('\n')[0].trim();
    if (!seenTexts.has(firstLine)) {
      // 找到可点击的父元素（通常是行）
      let clickableRow = el;
      let parent = el.parentElement;
      let attempts = 0;
      while (parent && attempts < 8) {
        const parentRect = parent.getBoundingClientRect();
        if (parentRect.width > 500 && parentRect.height < 150) {
          clickableRow = parent;
        }
        parent = parent.parentElement;
        attempts++;
      }

      jobElements.push({ element: clickableRow, titleElement: el, text: firstLine });
      seenTexts.add(firstLine);
    }
  }

  console.log(`Found ${jobElements.length} job elements for detail scraping`);

  if (rowIndex >= jobElements.length) {
    console.error("Row index out of range:", rowIndex, "total jobs:", jobElements.length);
    return null;
  }

  const { element: clickableRow, titleElement, text: jobTitle } = jobElements[rowIndex];

  // 点击职位元素，触发弹出层
  console.log("Clicking job element:", jobTitle);
  titleElement.click();

  // 等待弹出层出现
  await sleep(2000);

  // 查找弹出层/详情面板（飞书通常在右侧显示详情）
  // 尝试多种选择器
  let detailPanel = null;
  const panelSelectors = [
    '[class*="detail"]',
    '[class*="drawer"]',
    '[class*="modal"]',
    '[class*="panel"]',
    '[class*="sidebar"]',
    '[class*="slide"]'
  ];

  for (let selector of panelSelectors) {
    const panels = document.querySelectorAll(selector);
    for (let panel of panels) {
      const rect = panel.getBoundingClientRect();
      // 详情面板通常在右侧，宽度适中
      if (rect.width > 300 && rect.right > window.innerWidth - 100) {
        const text = panel.innerText;
        if (text.includes('职位描述') || text.includes('基本信息') || text.includes('职位详情')) {
          detailPanel = panel;
          console.log("Found detail panel:", selector);
          break;
        }
      }
    }
    if (detailPanel) break;
  }

  // 按照指定顺序定义字段
  const data = {
    职位名称: jobTitle,
    公司: '',
    部门: '',
    工作地点: '',
    学历要求: '',
    工作年限: '',
    岗位层级: '',
    岗位描述: '',
    岗位要求: '',
    招聘人数: '',
    HR: '',
    发布日期: '',
    更新日期: '',
    有效日期: '',
    职位状态: '',
    职位链接: window.location.href
  };

  if (detailPanel) {
    console.log("Extracting from detail panel...");
    const panelText = detailPanel.innerText;

    // 提取标题（可能在面板顶部）
    const titleEl = detailPanel.querySelector('h1, h2, h3, [class*="title"]');
    if (titleEl && titleEl.innerText.trim().length > 5) {
      data.职位名称 = titleEl.innerText.trim();
    }

    // 使用正则提取各字段
    const extractField = (patterns) => {
      for (let pattern of patterns) {
        const match = panelText.match(pattern);
        if (match) return match[1].trim();
      }
      return '';
    };

    data.公司 = extractField([/公司[\s\n:：]*([^\n]+)/, /客户[\s\n:：]*([^\n]+)/]);
    // 飞书页面没有"部门"字段，保持为空
    data.工作地点 = extractField([/职位地点[\s\n:：]*([^\n]+)/, /工作地点[\s\n:：]*([^\n]+)/, /地点[\s\n:：]*([^\n]+)/]);
    data.学历要求 = extractField([/学历要求[\s\n:：]*([^\n]+)/, /学历[\s\n:：]*([^\n]+)/]);
    data.工作年限 = extractField([/工作年限要求[\s\n:：]*([^\n]+)/, /工作年限[\s\n:：]*([^\n]+)/, /经验[\s\n:：]*([^\n]+)/]);
    data.岗位层级 = extractField([/岗位层级[\s\n:：]*([^\n]+)/, /职级[\s\n:：]*([^\n]+)/]);
    data.招聘人数 = extractField([/招聘人数[\s\n:：]*([^\n]+)/, /人数[\s\n:：]*(\d+)/]);
    data.HR = extractField([/HR[\s\n:：]*([^\n]+)/, /招聘负责人[\s\n:：]*([^\n]+)/]);
    data.发布日期 = extractField([/发布时间[\s\n:：]*([^\n]+)/, /发布日期[\s\n:：]*([^\n]+)/]);
    data.更新日期 = extractField([/更新时间[\s\n:：]*([^\n]+)/, /更新日期[\s\n:：]*([^\n]+)/]);
    data.有效日期 = extractField([/有效日期[\s\n:：]*([^\n]+)/, /截止日期[\s\n:：]*([^\n]+)/]);
    data.职位状态 = extractField([/职位状态[\s\n:：]*([^\n]+)/, /状态[\s\n:：]*([^\n]+)/]);

    // 岗位描述
    const descMatch = panelText.match(/(?:职位描述|岗位描述|工作职责)[\s\n:：]*([\s\S]*?)(?=职位要求|任职要求|岗位要求|任职资格|$)/);
    if (descMatch) data.岗位描述 = descMatch[1].trim().substring(0, 2000);

    // 岗位要求
    const reqMatch = panelText.match(/(?:职位要求|任职要求|岗位要求|任职资格)[\s\n:：]*([\s\S]*?)(?=推荐候选人|$)/);
    if (reqMatch) data.岗位要求 = reqMatch[1].trim().substring(0, 2000);

  } else {
    console.warn("Detail panel not found, extracting from row only");
    // 从表格行提取基本信息
    const cells = clickableRow.querySelectorAll('td');
    if (cells.length >= 2) data.公司 = cells[1]?.innerText?.trim() || '';
    if (cells.length >= 3) data.工作地点 = cells[2]?.innerText?.trim() || '';
    if (cells.length >= 5) {
      // 尝试从最后一列获取薪资信息（飞书列表页显示月薪范围）
      const lastCell = cells[cells.length - 1];
      if (lastCell && lastCell.innerText.includes('CNY')) {
        // 薪资不在标准字段中，可以放到备注或忽略
      }
    }
  }

  // 尝试关闭弹出层
  const closeSelectors = [
    '[class*="close"]',
    '[aria-label="close"]',
    '[aria-label="关闭"]',
    'button[class*="close"]',
    '[class*="icon-close"]'
  ];

  for (let selector of closeSelectors) {
    const closeBtn = document.querySelector(selector);
    if (closeBtn && closeBtn.offsetParent !== null) {
      console.log("Closing detail panel with:", selector);
      closeBtn.click();
      await sleep(500);
      break;
    }
  }

  console.log("Feishu detail scraped:", data);
  return data;
}

async function clickFeishuNextPage() {
  // 飞书的分页按钮
  const nextBtn = document.querySelector('[class*="next"]:not([disabled]), [aria-label="下一页"]:not([disabled])');
  if (nextBtn) {
    nextBtn.click();
    return true;
  }

  // 备选：查找 ">" 按钮
  const allBtns = document.querySelectorAll('button, a, span');
  for (let btn of allBtns) {
    if (btn.innerText.trim() === '>' || btn.innerText.trim() === '下一页') {
      if (!btn.disabled && !btn.classList.contains('disabled')) {
        btn.click();
        return true;
      }
    }
  }

  return false;
}

// ============ ByteDance 平台专用函数 ============

async function scrapeBytedanceList() {
  console.log("Scraping ByteDance job list...");
  await sleep(1500); // 等待页面加载

  const jobs = [];
  const seenTitles = new Set();

  // 策略1: 查找职位卡片/列表项（常见React组件类名模式）
  const selectors = [
    '[class*="position-item"]',
    '[class*="job-card"]',
    '[class*="job-item"]',
    '[data-testid*="job"]',
    '[data-job-id]',
    '[class*="PositionCard"]',
    '[class*="JobCard"]',
    'a[href*="/experienced/position/"]',
    'a[href*="/campus/position/"]'
  ];

  let jobElements = [];

  // 尝试所有选择器
  for (let selector of selectors) {
    const elements = document.querySelectorAll(selector);
    if (elements.length > 0) {
      console.log(`Found ${elements.length} elements with selector: ${selector}`);
      jobElements = Array.from(elements);
      break;
    }
  }

  // 策略2: 如果没找到，尝试查找链接
  if (jobElements.length === 0) {
    const allLinks = document.querySelectorAll('a[href]');
    for (let link of allLinks) {
      if (link.href.includes('/position/') && link.href.includes('bytedance.com')) {
        jobElements.push(link);
      }
    }
    console.log(`Found ${jobElements.length} job links via fallback method`);
  }

  // 提取职位信息
  for (let el of jobElements) {
    const rect = el.getBoundingClientRect();

    // 过滤不可见元素
    if (rect.width === 0 || rect.height === 0) continue;
    if (rect.left < 0 || rect.top < 0) continue;

    // 提取职位标题
    let title = '';
    const titleSelectors = ['h1', 'h2', 'h3', '[class*="title"]', '[class*="name"]'];
    for (let selector of titleSelectors) {
      const titleEl = el.querySelector(selector);
      if (titleEl) {
        title = titleEl.innerText?.trim();
        break;
      }
    }

    // 如果没找到标题元素，使用元素本身的文本
    if (!title) {
      title = el.innerText?.trim()?.split('\n')[0];
    }

    // 过滤无效标题
    if (!title || title.length < 5 || title.length > 100) continue;
    if (seenTitles.has(title)) continue;

    // 提取职位链接
    let url = el.href || el.querySelector('a')?.href || window.location.href;

    seenTitles.add(title);
    jobs.push({
      title: title,
      element: el,
      url: url
    });
  }

  console.log(`Found ${jobs.length} ByteDance jobs`);
  return jobs;
}

async function scrapeBytedanceDetail(rowIndex) {
  console.log(`Scraping ByteDance detail for row ${rowIndex}...`);

  const jobs = await scrapeBytedanceList();
  if (rowIndex >= jobs.length) {
    console.error('Invalid row index:', rowIndex);
    return null;
  }

  const { element: jobElement, title: jobTitle, url } = jobs[rowIndex];

  // 点击职位元素
  jobElement.click();
  await sleep(2500); // 等待详情页加载

  // 检测是否跳转到新页面（SPA路由变化）
  const currentUrl = window.location.href;
  const isPageNavigation = currentUrl !== url && currentUrl.includes('/position/');

  let detailPanel = null;

  if (isPageNavigation) {
    // 详情页模式：从整个页面提取
    detailPanel = document.body;
  } else {
    // 弹窗模式：查找drawer/modal/panel
    const panelSelectors = [
      '[class*="detail"]',
      '[class*="drawer"]',
      '[class*="modal"]',
      '[class*="panel"]',
      '[class*="dialog"]'
    ];

    for (let selector of panelSelectors) {
      const panels = document.querySelectorAll(selector);
      for (let panel of panels) {
        const rect = panel.getBoundingClientRect();
        if (rect.width > 400 && rect.height > 400) {
          detailPanel = panel;
          break;
        }
      }
      if (detailPanel) break;
    }
  }

  // 结构化数据提取
  const data = {
    职位名称: jobTitle || '',
    公司: 'ByteDance',
    部门: '',
    工作地点: '',
    学历要求: '',
    工作年限: '',
    岗位描述: '',
    岗位要求: '',
    薪资范围: '',
    职位类别: '',
    发布日期: '',
    职位链接: currentUrl
  };

  if (detailPanel) {
    const panelText = detailPanel.innerText;

    // 使用正则表达式提取各字段
    const extractField = (patterns) => {
      for (let pattern of patterns) {
        const match = panelText.match(pattern);
        if (match && match[1]) {
          return match[1].trim();
        }
      }
      return '';
    };

    // 提取基本信息
    data.工作地点 = extractField([
      /城市[\s\n:：]*([^\n]+)/,
      /工作地点[\s\n:：]*([^\n]+)/,
      /地点[\s\n:：]*([^\n]+)/
    ]);

    data.学历要求 = extractField([
      /学历[\s\n:：]*([^\n]+)/,
      /学历要求[\s\n:：]*([^\n]+)/
    ]);

    data.工作年限 = extractField([
      /经验[\s\n:：]*([^\n]+)/,
      /工作年限[\s\n:：]*([^\n]+)/,
      /年限[\s\n:：]*([^\n]+)/
    ]);

    data.薪资范围 = extractField([
      /薪资[\s\n:：]*([^\n]+)/,
      /月薪[\s\n:：]*([^\n]+)/,
      /(\d+-\d+K?\s*CNY|\d+K\s*CNY)/i
    ]);

    data.部门 = extractField([
      /部门[\s\n:：]*([^\n]+)/,
      /团队[\s\n:：]*([^\n]+)/
    ]);

    data.职位类别 = extractField([
      /类别[\s\n:：]*([^\n]+)/,
      /职能[\s\n:：]*([^\n]+)/
    ]);

    // 提取描述和要求（多行文本）
    const descMatch = panelText.match(/(?:职位描述|岗位描述|描述)[\s\n:：]*([\s\S]*?)(?=职位要求|任职要求|$)/);
    if (descMatch && descMatch[1]) {
      data.岗位描述 = descMatch[1].trim().substring(0, 3000);
    }

    const reqMatch = panelText.match(/(?:职位要求|任职要求|要求)[\s\n:：]*([\s\S]*?)(?=职位描述|$)/);
    if (reqMatch && reqMatch[1]) {
      data.岗位要求 = reqMatch[1].trim().substring(0, 3000);
    }
  }

  // 如果是弹窗模式，关闭弹窗
  if (!isPageNavigation) {
    const closeSelectors = [
      '[class*="close"]',
      '[aria-label="close"]',
      '[aria-label="关闭"]',
      'button[icon="close"]'
    ];

    for (let selector of closeSelectors) {
      const closeBtn = document.querySelector(selector);
      if (closeBtn && closeBtn.offsetParent !== null) {
        closeBtn.click();
        await sleep(500);
        break;
      }
    }
  } else {
    // 如果是页面跳转，返回上一页
    window.history.back();
    await sleep(1500);
  }

  console.log("ByteDance detail scraped:", data);
  return data;
}

async function clickBytedanceNextPage() {
  console.log("Clicking ByteDance next page...");

  // 策略1: 查找下一页按钮（常见模式）
  const nextBtnSelectors = [
    '[class*="next"]:not([disabled])',
    '[aria-label="next"]:not([disabled])',
    '[aria-label="下一页"]:not([disabled])',
    'button[class*="pagination"]:not(:disabled)',
    'li.next:not(.disabled) button'
  ];

  for (let selector of nextBtnSelectors) {
    const btn = document.querySelector(selector);
    if (btn && btn.offsetParent !== null) {
      btn.click();
      await sleep(2000);
      return true;
    }
  }

  // 策略2: 查找文本为 ">" 或 "下一页" 的按钮
  const allBtns = document.querySelectorAll('button, a, span[role="button"]');
  for (let btn of allBtns) {
    const text = btn.innerText?.trim();
    if ((text === '>' || text === '下一页' || text === 'Next') && !btn.disabled) {
      btn.click();
      await sleep(2000);
      return true;
    }
  }

  // 策略3: 检测无限滚动
  const scrollHeight = document.documentElement.scrollHeight;
  const beforeScroll = window.scrollY;
  window.scrollTo(0, document.body.scrollHeight);
  await sleep(3000);

  const afterScroll = window.scrollY;
  if (afterScroll > beforeScroll) {
    return true; // 触发了滚动加载
  }

  console.log("No next page found");
  return false;
}

// 反爬虫检测
function isBlocked() {
  const bodyText = document.body.innerText.toLowerCase();

  const blockedKeywords = [
    '访问频繁',
    '验证码',
    'captcha',
    'rate limit',
    'too many requests',
    '检测到异常',
    '请稍后再试'
  ];

  return blockedKeywords.some(keyword => bodyText.includes(keyword));
}

// 随机延迟（模拟人类行为）
function randomDelay(min = 1000, max = 3000) {
  const delay = Math.floor(Math.random() * (max - min + 1)) + min;
  return sleep(delay);
}

// 初始化
if (!window.hasRun) {
  window.hasRun = true;
  window.hasScrapedDetail = false;
  console.log("Content script ready, waiting for commands...");
}

// ============ 小红书平台抓取函数 ============

// 清除小红书详情抓取状态
function clearXiaohongshuDetailStates() {
  for (let key in window) {
    if (key.startsWith('xiaohongshu_detail_')) {
      delete window[key];
    }
  }
  console.log("Cleared Xiaohongshu detail states");
}

// 全局变量存储当前职位列表
if (typeof window.xiaohongshuJobLinks === 'undefined') {
  window.xiaohongshuJobLinks = [];
}

// 抓取小红书职位列表
async function scrapeXiaohongshuList() {
  console.log("📕 Scraping Xiaohongshu job list...");
  await sleep(1000);

  const jobs = [];
  const seenTitles = new Set();

  // 查找职位链接：a[href^='/position-detail/']
  const jobLinks = document.querySelectorAll("a[href^='/position-detail/']");
  console.log(`Found ${jobLinks.length} job links`);

  // 保存到全局，供详情抓取时使用
  window.xiaohongshuJobLinks = Array.from(jobLinks);

  for (let link of jobLinks) {
    const title = link.innerText?.trim();
    const href = link.getAttribute('href');

    if (!title || title.length < 2) continue;
    if (seenTitles.has(title)) continue;

    seenTitles.add(title);

    // 尝试从行中提取更多信息
    const row = link.closest('tr');
    let location = '';
    let hr = '';
    let publishDate = '';
    let status = '';

    if (row) {
      const cells = row.querySelectorAll('td');
      // 根据表格结构，列顺序大致是：复选框、职位名称、猎聘人数、工作地点、猎聘HR、发布时间、招聘状态
      if (cells.length >= 7) {
        location = cells[3]?.innerText?.trim() || '';
        hr = cells[4]?.innerText?.trim() || '';
        publishDate = cells[5]?.innerText?.trim() || '';
        status = cells[6]?.innerText?.trim() || '';
      }
    }

    jobs.push({
      title: title,
      href: href,
      location: location,
      hr: hr,
      publishDate: publishDate,
      status: status
    });
  }

  console.log(`📕 Found ${jobs.length} Xiaohongshu jobs`);
  return jobs;
}

// 抓取小红书职位详情
async function scrapeXiaohongshuDetail(rowIndex) {
  console.log(`📕 Scraping Xiaohongshu detail for row ${rowIndex}...`);

  // 获取保存的职位链接
  const jobLinks = window.xiaohongshuJobLinks || [];
  if (rowIndex >= jobLinks.length) {
    console.error('Invalid row index:', rowIndex);
    return null;
  }

  const jobLink = jobLinks[rowIndex];
  const jobTitle = jobLink.innerText?.trim() || '';

  // 添加随机延迟，模拟人类行为
  await randomDelay(500, 1500);

  // 点击职位链接进入详情页
  jobLink.click();
  console.log(`📕 Clicked job: "${jobTitle}"`);

  // 等待详情页加载
  await sleep(2000);

  // 等待详情页元素出现
  let detailLoaded = false;
  for (let i = 0; i < 10; i++) {
    // 检查是否有详情页的标志性元素
    const formItems = document.querySelectorAll('.red-form-item, .red-form-item-label');
    if (formItems.length > 5) {
      detailLoaded = true;
      break;
    }
    await sleep(500);
  }

  if (!detailLoaded) {
    console.warn("Detail page did not load properly");
  }

  // 等待额外时间确保内容完全加载
  await sleep(1000);

  // 提取详情数据
  const data = extractXiaohongshuDetailData();
  data.职位名称 = data.职位名称 || jobTitle;
  data.职位链接 = window.location.href;

  console.log("📕 Extracted Xiaohongshu detail:", data);

  // 点击返回按钮回到列表页
  await clickXiaohongshuBackButton();

  // 等待列表页加载
  await sleep(1500);

  return data;
}

// 提取小红书详情页数据
function extractXiaohongshuDetailData() {
  const data = {
    职位名称: '',
    公司: '小红书',
    部门: '',
    工作地点: '',
    学历要求: '',
    工作年限: '',
    岗位层级: '',
    岗位描述: '',
    岗位要求: '',
    招聘人数: '',
    HR: '',
    HR电话: '',
    发布日期: '',
    更新日期: '',
    有效日期: '',
    职位状态: '',
    职位类别: '',
    员工类型: '',
    招聘类型: '',
    薪资范围: '',
    职位链接: ''
  };

  // 方法1：使用 .red-form-item 结构提取
  const formItems = document.querySelectorAll('.red-form-item');

  for (let item of formItems) {
    const labelEl = item.querySelector('.red-form-item-label, label');
    const valueEl = item.querySelector('.txt-content, .red-form-item-content');

    if (!labelEl) continue;

    const label = labelEl.innerText?.trim().replace(/[:：]/g, '') || '';
    let value = valueEl?.innerText?.trim() || '';

    // 如果 valueEl 内容和 labelEl 内容相同，尝试获取父元素的其他文本
    if (value === label || !value) {
      const itemText = item.innerText || '';
      const labelText = labelEl.innerText || '';
      value = itemText.replace(labelText, '').trim();
    }

    // 映射字段
    const fieldMapping = {
      '职位名称': '职位名称',
      '招聘人数': '招聘人数',
      '职位类别': '职位类别',
      '员工类别': '员工类型',
      '员工类型': '员工类型',
      '招聘类型': '招聘类型',
      '工作地点': '工作地点',
      '工作经验': '工作年限',
      '学历要求': '学历要求',
      '薪资范围': '薪资范围',
      '工作职责': '岗位描述',
      '任职资格': '岗位要求',
      '任职要求': '岗位要求',
      '招聘HR': 'HR',
      '猎聘HR': 'HR',
      'HR联系电话': 'HR电话'
    };

    if (fieldMapping[label] && value) {
      data[fieldMapping[label]] = value;
    }
  }

  // 方法2：如果方法1没有获取到足够数据，尝试从页面文本中提取
  if (!data.岗位描述 || !data.岗位要求) {
    const pageText = document.body.innerText;

    // 提取工作职责
    const dutyMatch = pageText.match(/工作职责[：:]\s*([\s\S]*?)(?=任职(?:资格|要求)|$)/);
    if (dutyMatch && dutyMatch[1] && !data.岗位描述) {
      data.岗位描述 = dutyMatch[1].trim().substring(0, 3000);
    }

    // 提取任职要求
    const reqMatch = pageText.match(/任职(?:资格|要求)[：:]\s*([\s\S]*?)(?=招聘HR|猎聘HR|$)/);
    if (reqMatch && reqMatch[1] && !data.岗位要求) {
      data.岗位要求 = reqMatch[1].trim().substring(0, 3000);
    }
  }

  return data;
}

// 点击小红书返回按钮
async function clickXiaohongshuBackButton() {
  console.log("📕 Looking for back button...");

  // 策略1：查找文本为"返回"的按钮
  const allButtons = document.querySelectorAll('button, a, span[role="button"]');
  for (let btn of allButtons) {
    const text = btn.innerText?.trim();
    if (text === '返回') {
      console.log("Found '返回' button, clicking...");
      btn.click();
      return true;
    }
  }

  // 策略2：查找特定 class 的返回按钮
  const backBtnSelectors = [
    'button.yam-btn.--default',
    '.red-form-btn',
    'button[class*="default"]'
  ];

  for (let selector of backBtnSelectors) {
    const btns = document.querySelectorAll(selector);
    for (let btn of btns) {
      if (btn.innerText?.includes('返回')) {
        console.log("Found back button via selector:", selector);
        btn.click();
        return true;
      }
    }
  }

  // 策略3：使用浏览器后退
  console.log("No back button found, using history.back()");
  window.history.back();
  return true;
}

// 小红书翻页
async function clickXiaohongshuNextPage() {
  console.log("📕 Clicking Xiaohongshu next page...");

  // 查找分页组件
  const pagination = document.querySelector('.yam-pagination, .red-pagination, [class*="pagination"]');

  if (!pagination) {
    console.log("No pagination found");
    return false;
  }

  // 策略1：查找下一页按钮 (右箭头)
  const nextBtns = pagination.querySelectorAll('a, button, li');
  for (let btn of nextBtns) {
    const text = btn.innerText?.trim();
    const className = btn.className || '';

    // 检查是否是下一页按钮
    if (text === '>' || text === '»' || text === '下一页' ||
      className.includes('next') || btn.querySelector('[class*="right"]')) {
      // 检查是否禁用
      if (btn.classList.contains('disabled') || btn.hasAttribute('disabled')) {
        console.log("Next page button is disabled, no more pages");
        return false;
      }

      console.log("Found next page button, clicking...");
      btn.click();
      await sleep(2000);
      return true;
    }
  }

  console.log("No next page button found");
  return false;
}

// ============ 批量导入人才库功能 ============

// 批量导入人才库主函数
async function batchImportTalentsToAPI() {
  console.log("📥 开始批量导入人才库...");

  try {
    // 1. 提取当前页所有简历链接
    const resumeLinks = await extractResumeLinksFromList();

    if (!resumeLinks || resumeLinks.length === 0) {
      console.warn("⚠️ 未找到简历链接");
      alert("未找到简历链接，请确认在简历列表页");
      return;
    }

    console.log(`📋 找到 ${resumeLinks.length} 个简历，开始逐个导入...`);

    let successCount = 0;
    let failCount = 0;
    let skipCount = 0;

    // 2. 遍历每个简历
    for (let i = 0; i < resumeLinks.length; i++) {
      const link = resumeLinks[i];
      console.log(`\n📄 [${i + 1}/${resumeLinks.length}] 处理简历: ${link.text || link.url}`);

      try {
        // 3. 点击进入详情页
        await clickResumeLink(link);
        await sleep(3000); // 等待详情页加载

        // 4. 提取简历数据
        const resumeData = await extractResumeDetail();

        if (!resumeData || !resumeData.name) {
          console.warn(`⚠️ 简历数据提取失败，跳过`);
          skipCount++;
          await goBackToList();
          continue;
        }

        // 5. 调用 API 导入
        const result = await syncCandidateToAPI(resumeData);

        if (result.success) {
          successCount++;
          console.log(`✅ [${i + 1}/${resumeLinks.length}] 导入成功: ${resumeData.name} (${result.action})`);
        } else {
          failCount++;
          console.error(`❌ [${i + 1}/${resumeLinks.length}] 导入失败: ${result.message}`);
        }

        // 6. 返回列表页
        await goBackToList();
        await sleep(1000); // 等待列表页加载

      } catch (error) {
        console.error(`❌ 处理简历时出错:`, error);
        failCount++;
        await goBackToList();
      }
    }

    // 7. 显示结果
    const summary = `批量导入完成！\n成功: ${successCount}\n失败: ${failCount}\n跳过: ${skipCount}\n总计: ${resumeLinks.length}`;
    console.log(`\n📊 ${summary}`);
    alert(summary);

  } catch (error) {
    console.error("❌ 批量导入出错:", error);
    alert(`批量导入出错: ${error.message}`);
  }
}

// 从列表页提取所有简历链接
async function extractResumeLinksFromList() {
  console.log("🔍 提取简历列表链接...");

  const links = [];

  // 策略1: 查找表格中的简历链接
  const tableLinks = document.querySelectorAll('table a[href*="resume"], table a[href*="FORM-"], table a[href*="candidate"]');
  for (const link of tableLinks) {
    const href = link.href;
    const text = link.innerText?.trim() || '';

    // 过滤掉非简历链接
    if (href && !href.includes('javascript') && text.length > 1) {
      links.push({ url: href, text: text, element: link });
    }
  }

  // 策略2: 如果策略1没找到，尝试查找所有可能的简历链接
  if (links.length === 0) {
    const allLinks = document.querySelectorAll('a[href]');
    for (const link of allLinks) {
      const href = link.href;
      const text = link.innerText?.trim() || '';

      // 判断是否是简历链接
      if (href && (href.includes('resume') || href.includes('FORM-') || href.includes('candidate'))
          && !href.includes('javascript') && text.length > 1) {
        links.push({ url: href, text: text, element: link });
      }
    }
  }

  // 去重
  const uniqueLinks = [];
  const seenUrls = new Set();
  for (const link of links) {
    if (!seenUrls.has(link.url)) {
      uniqueLinks.push(link);
      seenUrls.add(link.url);
    }
  }

  console.log(`📋 找到 ${uniqueLinks.length} 个简历链接`);
  return uniqueLinks;
}

// 点击简历链接进入详情页
async function clickResumeLink(link) {
  console.log(`🖱️ 点击简历链接: ${link.text}`);

  if (link.element && document.contains(link.element)) {
    // 如果元素还在 DOM 中，直接点击
    link.element.click();
  } else {
    // 否则通过 URL 导航
    window.location.href = link.url;
  }
}

// 返回列表页
async function goBackToList() {
  console.log("🔙 返回列表页...");
  window.history.back();
  await sleep(2000); // 等待页面加载
}

// 同步候选人数据到 API
async function syncCandidateToAPI(resumeData) {
  console.log("📡 同步数据到 API:", resumeData.name);

  try {
    // 解析工作年限（从字符串中提取数字）
    let experienceYears = 0;
    const yearsMatch = String(resumeData.yearsExp || '').match(/(\d+)/);
    if (yearsMatch) {
      experienceYears = parseInt(yearsMatch[1], 10);
    }

    // 解析技能为数组
    let skillsArray = [];
    if (resumeData.skills && typeof resumeData.skills === 'string') {
      // 支持多种分隔符：逗号、顿号、空格、竖线
      skillsArray = resumeData.skills
        .split(/[,，、| |]/)
        .map(s => s.trim())
        .filter(s => s.length > 0);
    } else if (Array.isArray(resumeData.skills)) {
      skillsArray = resumeData.skills;
    }

    // 解析教育经历为数组
    let educationsArray = [];
    if (resumeData.education && typeof resumeData.education === 'string') {
      // 尝试解析教育经历字符串为结构化数据
      const educationText = resumeData.education.trim();
      // 常见格式：本科 | 清华大学 | 计算机科学
      if (educationText.includes('|')) {
        const parts = educationText.split('|').map(p => p.trim());
        if (parts.length >= 2) {
          educationsArray.push({
            degree: parts[0] || '',
            school: parts[1] || '',
            major: parts[2] || ''
          });
        }
      } else {
        // 如果无法结构化，放入 school 字段
        educationsArray.push({
          degree: '',
          school: educationText,
          major: ''
        });
      }
    } else if (Array.isArray(resumeData.education)) {
      educationsArray = resumeData.education;
    }

    // 解析工作经历为数组（简化版本）
    let workExperiencesArray = [];
    if (resumeData.experience && typeof resumeData.experience === 'string') {
      // 尝试从文本中提取工作经历
      const expLines = resumeData.experience.split('\n').filter(line => line.trim());
      expLines.forEach(line => {
        if (line.trim().length > 5) {
          workExperiencesArray.push({
            company: '',
            position: '',
            description: line.trim()
          });
        }
      });
    } else if (Array.isArray(resumeData.experience)) {
      workExperiencesArray = resumeData.experience;
    }

    // 解析项目经历为数组
    let projectsArray = [];
    if (resumeData.projects && typeof resumeData.projects === 'string') {
      const projectLines = resumeData.projects.split('\n').filter(line => line.trim());
      projectLines.forEach(line => {
        if (line.trim().length > 5) {
          projectsArray.push({
            name: '',
            time: '',
            description: line.trim()
          });
        }
      });
    } else if (Array.isArray(resumeData.projects)) {
      projectsArray = resumeData.projects;
    }

    // 构建 API 请求数据（符合 CandidateImportRequest 格式）
    const payload = {
      name: resumeData.name || '',
      phone: resumeData.phone || '',
      email: resumeData.email || '',
      location: resumeData.location || '',
      currentCompany: '',  // 从 experience 中解析
      currentPosition: resumeData.currentTitle || '',
      experienceYears: experienceYears,
      education: resumeData.education || '',  // 保留原始文本作为 education 字段
      workExperiences: workExperiencesArray,
      educations: educationsArray,
      projects: projectsArray,
      skills: skillsArray,
      source: 'alibaba_headhunter',
      sourceUrl: resumeData.url || window.location.href,
      extractedAt: resumeData.extractedAt || new Date().toISOString()
    };

    console.log("📦 构建的 API Payload:", payload);

    // 从 storage 获取 API 地址
    const result = await chrome.storage.local.get(['apiBaseUrl']);
    const apiBaseUrl = result.apiBaseUrl || 'http://localhost:8502';

    // 调用 API
    const response = await fetch(`${apiBaseUrl}/api/candidate/maimai-sync`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`API 请求失败: ${response.status} ${response.statusText} - ${errorText}`);
    }

    const apiResult = await response.json();
    console.log("✅ API 响应:", apiResult);

    return {
      success: apiResult.success || false,
      action: apiResult.action || 'unknown',
      candidateId: apiResult.candidateId || null,
      message: apiResult.message || ''
    };

  } catch (error) {
    console.error("❌ API 同步失败:", error);
    return {
      success: false,
      message: error.message
    };
  }
}

// ============ 简历库简历下载函数 ============

// 从简历库列表页提取每行的详情页 URL
async function extractResumeLibraryRecords() {
  await sleep(1000);

  const urls = [];

  // 策略1：查找表格行中的 <a> 标签链接
  const tableLinks = document.querySelectorAll('table a[href], .ant-table a[href], .next-table a[href]');
  for (const link of tableLinks) {
    const href = link.href || link.getAttribute('href');

    // 排除职位链接（包含 orderCode 的是职位详情页）
    if (href && href.includes('orderCode=')) {
      continue;
    }

    if (href && (href.includes('resumeManagement') || href.includes('resumeCode') || href.includes('FORM-'))) {
      if (!urls.includes(href)) {
        urls.push(href);
      }
    }
  }

  // 策略2：如果策略1没找到，尝试从列表行中提取所有可能的详情链接
  if (urls.length === 0) {
    const allLinks = document.querySelectorAll('a[href]');
    for (const link of allLinks) {
      const href = link.href || link.getAttribute('href');

      // 排除职位链接
      if (href && href.includes('orderCode=')) {
        continue;
      }

      if (href && href.includes('headhunter') && (href.includes('detail') || href.includes('resume') || href.includes('FORM-'))) {
        if (!urls.includes(href)) {
          urls.push(href);
        }
      }
    }
  }

  // 策略3：查找表格行，提取行内的链接或行点击跳转
  if (urls.length === 0) {
    const rows = document.querySelectorAll('tr[class*="row"], .ant-table-row, .next-table-row, tbody tr');
    for (const row of rows) {
      const link = row.querySelector('a[href]');
      if (link) {
        const href = link.href || link.getAttribute('href');

        // 排除职位链接
        if (href && href.includes('orderCode=')) {
          continue;
        }

        if (href && href.length > 20 && !urls.includes(href)) {
          urls.push(href);
        }
      }
    }
  }

  console.log(`📚 提取到 ${urls.length} 条简历库详情页链接`);
  urls.forEach((url, i) => console.log(`  ${i + 1}. ${url}`));
  return urls;
}

async function clickResumeLibraryDownloadButton() {
  await sleep(1000);

  const allClickable = document.querySelectorAll('button, a, span, div[role="button"]');
  for (const el of allClickable) {
    const text = (el.innerText || el.textContent || '').trim();
    if (text.includes('下载简历') || text.includes('下载附件') || text.includes('下载 Resume') || text.includes('Download Resume') || text.includes('下载')) {
      console.log("📚 找到下载按钮（文本匹配）:", text);
      el.click();
      await sleep(3000);
      return true;
    }
  }

  const downloadLinks = document.querySelectorAll('a[download], a[href*="download"], a[href*="resume"][href*=".pdf"], a[href*="resume"][href*=".doc"]');
  if (downloadLinks.length > 0) {
    console.log("📚 找到下载链接（属性匹配）:", downloadLinks[0].href);
    downloadLinks[0].click();
    await sleep(3000);
    return true;
  }

  const iconButtons = document.querySelectorAll('[class*="download"], [class*="Download"], [aria-label*="下载"], [title*="下载简历"]');
  if (iconButtons.length > 0) {
    console.log("📚 找到下载按钮（图标/属性匹配）");
    iconButtons[0].click();
    await sleep(3000);
    return true;
  }

  console.warn("📚 未找到下载简历按钮，跳过此记录");
  return false;
}

function initResumeLibrarySectionContainer() {
  console.log("📚 [DEBUG] 开始定位简历库 section 容器...");

  if (window.resumeLibrarySectionContainer && document.contains(window.resumeLibrarySectionContainer)) {
    console.log("📚 [DEBUG] 现有容器仍有效，复用");
    return;
  }

  const allPaginations = document.querySelectorAll('.kuma-page, .ant-pagination, [class*="pagination"]');
  console.log("📚 [DEBUG] 找到", allPaginations.length, "个分页组件");

  for (const paginationEl of allPaginations) {
    if (paginationEl.offsetParent === null && paginationEl.offsetHeight === 0) continue;

    console.log("📚 [DEBUG] 检查分页组件:", paginationEl.tagName, paginationEl.className);
    let parent = paginationEl.parentElement;
    for (let i = 0; i < 10 && parent; i++) {
      const hasTable = parent.querySelector('table, .ant-table, .kuma-table, .kuma-uxtable, .next-table, [class*="uxtable"]');
      if (hasTable) {
        window.resumeLibrarySectionContainer = parent;
        console.log("📚 定位到简历库 section 容器:", parent.tagName, parent.className?.substring(0, 80));
        return;
      }
      parent = parent.parentElement;
    }
  }

  window.resumeLibrarySectionContainer = null;
  console.log("📚 未找到简历库 section 容器，使用 document");
}

async function clickResumeLibraryNextPage() {
  let searchScope = window.resumeLibrarySectionContainer || document;
  console.log("📚 简历库翻页，搜索范围:", searchScope === document ? "document" : searchScope.tagName);

  const nextButtonSelectors = [
    'button.next-next:not([disabled])',
    'li.next-next:not(.next-disabled) button',
    'button[aria-label="Next Page"]:not([disabled])',
    'button:not([disabled])[class*="next"]',
    '.kuma-page-next:not(.kuma-page-disabled)',
    '.ant-pagination-next:not(.ant-pagination-disabled)',
    'button.kuma-page-item-next:not([disabled])'
  ];

  for (const selector of nextButtonSelectors) {
    const btn = searchScope.querySelector(selector);
    if (btn) {
      console.log(`📚 找到翻页按钮 (${selector}):`, btn.tagName, btn.className);
      btn.click();
      await sleep(2000);
      return true;
    }
  }

  console.warn("📚 未找到可用的翻页按钮");
  return false;
}
