# TOOLS.md

> Lumi 的工具环境速查表。事实，不是说明书。

---

## 系统运行状态

| 服务 | 地址 | 启动方式 |
|------|------|---------|
| FastAPI 后端 | http://localhost:8502 | `bash start_dev.sh` |
| React 前端 | http://localhost:5173 | 同上 |
| SQLite 数据库 | `data/headhunter_dev.db` | 直连 |

**工作目录**：`/Users/lillianliao/notion_rag/personal-ai-headhunter/`

---

## 数据库

```bash
sqlite3 /Users/lillianliao/notion_rag/personal-ai-headhunter/data/headhunter_dev.db
```

**核心表**：candidates / jobs / outreach_records / batch_runs

默认只读，写操作需 Telegram 确认。

---

## 浏览器自动化（Playwright + Chrome Profile）

```python
# 挂载已登录的 Chrome（保留 Cookie + 扩展）
from playwright.sync_api import sync_playwright

CHROME_PATH = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
USER_DATA = "/Users/lillianliao/Library/Application Support/Google/Chrome"

with sync_playwright() as p:
    browser = p.chromium.launch_persistent_context(
        user_data_dir=USER_DATA,
        executable_path=CHROME_PATH,
        headless=False,  # 有头模式，可观察
        args=["--disable-blink-features=AutomationControlled"]
    )
    page = browser.new_page()
```

> 这样打开的浏览器带有 Lilian 的登录状态 + 已安装插件（包括脉脉插件）

---

## Telegram 通知与确认

```python
from telegram_notifier import notify, notify_error, notify_progress
```

确认流程（候选人沟通 / 写操作）：
1. Lumi 生成内容 → `notify()` 推送草稿到 Telegram
2. Lilian 回复"确认" / "ok" / "y" → 执行
3. 其他回复 → 修改重来

---

## Telegram Bot 工具集（10 个）

`search_candidates` / `get_candidate_detail` / `get_daily_stats` / `search_jobs` / `semantic_search_jobs` / `semantic_search_candidates` / `get_outreach_history` / `count_candidates` / `draft_outreach_message` / `send_email`

---

## LinkedIn 发布

**方式 A（推荐）**：LinkedIn API + Buffer / n8n 调度
- LinkedIn 有官方 Posts API（需 OAuth）
- Buffer 支持定时发布，合规

**方式 B**：Playwright 操控浏览器（已登录 Chrome）

---

## 小红书发布

**当前路径（半自动）**：
1. Lumi 生成图文文案
2. Playwright 打开小红书创作者后台（已登录）
3. 自动填写文案，截图预览推给 Lilian 确认
4. 确认后自动点击发布

---

## n8n 工作流（可选，待配置）

本地运行：`docker run -p 5678:5678 n8nio/n8n`  
用于：定时触发任务（每天早报 / 内容发布调度 / ArXiv 监控）

---

## 批量操作脚本（常用）

```bash
python3 batch_match_urgent_jobs.py   # 匹配
python3 batch_linkedin_outreach.py   # LinkedIn 触达
python3 batch_email_outreach.py      # Email 触达
python3 batch_update_tiers.py all    # 评级重跑
python3 daily_planner.py             # 日报
```

---

## AI 服务

```python
# ai_service.py + prompts.py
# 支持 Qwen / DeepSeek / Claude（IMDS.ai / z.ai）
```

---

## 相关项目路径

- GitHub Mining：`/Users/lillianliao/notion_rag/github_mining/`
- AI News Tracker：`/Users/lillianliao/notion_rag/ai_news_tracker/`
- 本 Workspace：`/Users/lillianliao/notion_rag/openclaw-partner/`

---

## ClawHub（Skills 市场）

URL：https://clawhub.ai  
Lumi 每周主动查阅，发现有价值的 skill 推荐安装。
