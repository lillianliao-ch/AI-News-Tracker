(function () {
  'use strict';

  // ==================== 配置区域 ====================
  // 在这里修改配置，然后刷新扩展即可生效
  const CONFIG = {
    MAX_SCROLLS: 12,           // 最大滚动次数 (1-30)
    INTERVAL_SECONDS: 10,      // 查询间隔时间（秒）
    ADD_FRIEND_DEFAULT: false, // 默认是否添加好友
    DEFAULT_MODE: 'first'      // 默认模式: 'first' 或 'all'
  };
  // =================================================

  console.log('[脉脉助手] 加载');
  console.log('[脉脉助手] 📝 配置: 最大滚动次数 =', CONFIG.MAX_SCROLLS);

  let state = {
    list: [],
    index: 0,
    running: false,
    results: [],
    currentDetailUrl: null,  // 记录当前详情页URL
    mode: 'first',  // 'first' = 首个结果, 'all' = 所有结果
    currentQueryResults: [],  // 当前查询的多个结果（用于"所有结果"模式）
    addFriend: false,  // 是否同时添加好友
    intervalSeconds: 10,  // 查询间隔时间（秒）
    lastProcessedQuery: null,  // 记录上次处理的查询词，用于检测查询变化
    currentProcessingId: null  // 🔥 当前处理的唯一ID，防止多标签页并发
  };

  // 从 localStorage 恢复状态
  function loadState() {
    try {
      const saved = localStorage.getItem('mm_state');
      if (saved) {
        const savedState = JSON.parse(saved);
        Object.assign(state, savedState);
        console.log('[脉脉助手] 恢复状态', state);
      }
    } catch (e) {
      console.error('[脉脉助手] 恢复失败', e);
    }
  }

  // 保存状态
  function saveState() {
    try {
      localStorage.setItem('mm_state', JSON.stringify(state));
    } catch (e) {
      console.error('[脉脉助手] 保存失败', e);
    }
  }

  // 滚动获取所有搜索结果
  async function getAllResultsWithScroll() {
    console.log('[脉脉助手] 开始无限滚动获取所有结果...');

    let previousHeight = 0;
    let scrollCount = 0;
    const maxScrolls = CONFIG.MAX_SCROLLS; // 从配置读取

    while (scrollCount < maxScrolls) {
      // 滚动到页面底部
      window.scrollTo(0, document.body.scrollHeight);
      console.log('[脉脉助手] 第', (scrollCount + 1), '次滚动');

      // 等待加载
      await new Promise(resolve => setTimeout(resolve, 3000));

      // 检查页面高度是否有变化
      const currentHeight = document.body.scrollHeight;
      if (currentHeight === previousHeight) {
        console.log('[脉脉助手] 页面高度无变化，停止滚动');
        break;
      }

      previousHeight = currentHeight;
      scrollCount++;
    }

    console.log('[脉脉助手] 滚动完成，共滚动', scrollCount, '次');

    // 获取所有搜索结果卡片
    const listItems = document.querySelectorAll('.list-group-item');
    const validCards = [];
    const seenTexts = new Set(); // 用于去重

    for (let item of listItems) {
      const text = item.textContent || '';
      const shortText = text.substring(0, 50).trim(); // 前50字符用于标识

      // 跳过包含当前用户名的卡片
      if (text.includes('李睿智') || text.includes('Michael')) {
        console.log('[脉脉助手] 跳过李睿智的卡片');
        continue;
      }

      // 跳过重复的卡片
      if (seenTexts.has(shortText)) {
        console.log('[脉脉助手] 跳过重复卡片:', shortText);
        continue;
      }

      seenTexts.add(shortText);

      // 提取活跃状态
      const activeStatusEl = item.querySelector('.sc-fHxwqH.iAGemZ, span[class*="iAGemZ"]');
      const activeStatus = activeStatusEl?.textContent?.trim() || '';

      validCards.push({
        element: item,
        text: shortText,
        activeStatus: activeStatus
      });
    }

    console.log('[脉脉助手] 滚动后获取到', validCards.length, '个有效结果');
    return validCards;
  }

  // 创建面板
  function createPanel() {
    if (document.getElementById('mm-panel')) return;

    const panel = document.createElement('div');
    panel.id = 'mm-panel';
    panel.style.cssText = `
      position: fixed;
      bottom: 20px;
      left: 20px;
      width: 300px;
      background: white;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.2);
      z-index: 999999;
      font-family: sans-serif;
      font-size: 13px;
    `;

    panel.innerHTML = `
      <div style="background: linear-gradient(135deg, #00b96b, #009959); color: white; padding: 10px; border-radius: 8px 8px 0 0; font-weight: bold; display: flex; justify-content: space-between; align-items: center;">
        <span>🔍 脉脉助手</span>
        <span style="cursor: pointer; font-size: 16px;" id="mm-minimize">−</span>
      </div>
      <div id="mm-body" style="padding: 12px;">
        <textarea id="mm-input" placeholder="每行一个关键词&#10;廖娅伶&#10;张三" style="width: 100%; height: 70px; padding: 6px; border: 1px solid #ddd; border-radius: 4px; font-size: 12px; box-sizing: border-box; margin-bottom: 8px;"></textarea>
        <div style="margin-bottom: 8px; font-size: 12px;">
          <label style="display: block; margin-bottom: 4px; color: #666;">结果模式：</label>
          <select id="mm-mode" style="width: 100%; padding: 6px; border: 1px solid #ddd; border-radius: 4px; font-size: 12px; box-sizing: border-box;">
            <option value="first">首个结果（默认）</option>
            <option value="all">所有结果</option>
          </select>
        </div>
        <div style="margin-bottom: 8px; font-size: 12px;">
          <label style="display: flex; align-items: center; cursor: pointer;">
            <input type="checkbox" id="mm-add-friend" style="margin-right: 6px;">
            <span>同时添加好友</span>
          </label>
        </div>
        <button id="mm-start" style="width: 100%; padding: 8px; background: #00b96b; color: white; border: none; border-radius: 4px; font-weight: 600; cursor: pointer; margin-bottom: 5px;">开始</button>
        <button id="mm-stop" style="width: 100%; padding: 8px; background: #ff4d4f; color: white; border: none; border-radius: 4px; font-weight: 600; cursor: pointer; margin-bottom: 5px;">停止</button>
        <button id="mm-export" style="width: 100%; padding: 8px; background: #1890ff; color: white; border: none; border-radius: 4px; font-weight: 600; cursor: pointer; margin-bottom: 5px;">导出结果</button>
        <button id="mm-clear" style="width: 100%; padding: 8px; background: #888; color: white; border: none; border-radius: 4px; font-weight: 600; cursor: pointer;">清空数据</button>
        <div id="mm-status" style="margin-top: 8px; padding: 8px; background: #f5f5f5; border-radius: 4px; font-size: 11px;">就绪</div>
      </div>
    `;

    document.body.appendChild(panel);

    // 最小化功能
    document.getElementById('mm-minimize').onclick = function () {
      const body = document.getElementById('mm-body');
      const isHidden = body.style.display === 'none';
      body.style.display = isHidden ? 'block' : 'none';
      document.getElementById('mm-minimize').textContent = isHidden ? '−' : '+';
      panel.style.width = isHidden ? '300px' : '150px';
    };

    // 绑定事件
    document.getElementById('mm-start').onclick = start;
    document.getElementById('mm-stop').onclick = stop;
    document.getElementById('mm-export').onclick = exportResults;
    document.getElementById('mm-clear').onclick = clearData;

    // 监听模式切换
    document.getElementById('mm-mode').onchange = function () {
      state.mode = this.value;
      saveState();
      console.log('[脉脉助手] 切换模式:', state.mode === 'first' ? '首个结果' : '所有结果');
    };

    // 监听添加好友选项
    document.getElementById('mm-add-friend').onchange = function () {
      state.addFriend = this.checked;
      saveState();
      console.log('[脉脉助手] 添加好友:', state.addFriend ? '开启' : '关闭');
    };

    // 恢复界面状态
    if (state.list.length > 0) {
      document.getElementById('mm-input').value = state.list.join('\n');
      updateStatus('已加载 ' + state.list.length + ' 条');
    }

    // 恢复模式选择
    if (state.mode) {
      document.getElementById('mm-mode').value = state.mode;
    }

    // 恢复添加好友选项
    if (state.addFriend !== undefined) {
      document.getElementById('mm-add-friend').checked = state.addFriend;
    }

    if (state.running) {
      updateStatus('进行中 ' + (state.index + 1) + '/' + state.list.length);
    }
  }

  function start() {
    const input = document.getElementById('mm-input').value;
    const list = input.split('\n').map(s => s.trim()).filter(s => s);
    const mode = document.getElementById('mm-mode').value;
    const addFriend = document.getElementById('mm-add-friend').checked;

    if (list.length === 0) {
      updateStatus('请输入关键词');
      return;
    }

    // 先彻底清空旧数据
    localStorage.removeItem('mm_state');

    // 完全重置状态
    state = {
      list: list,
      index: 0,
      running: true,
      results: [],
      currentDetailUrl: null,
      mode: mode,
      currentQueryResults: [],
      addFriend: addFriend,
      addFriendAttemptedUsers: {},  // 清空之前的尝试记录
      intervalSeconds: 10,
      searchCache: {},  // 清空搜索缓存
      scrolledQueries: new Set(),  // 清空滚动记录
      currentProcessingId: null  // 🔥 清空处理ID
    };

    // 立即保存新状态
    saveState();

    updateStatus('开始 (共 ' + list.length + ' 条)');
    console.log('[脉脉助手] 开始搜索，已清空旧数据');
    console.log('[脉脉助手] 新状态:', state);
    console.log('[脉脉助手] 当前页面:', window.location.href);

    // 如果当前在详情页，需要先跳转到搜索页
    if (window.location.href.includes('/profile/detail') ||
      window.location.href.includes('/contact/') ||
      window.location.href.includes('/card/')) {
      console.log('[脉脉助手] 当前在详情页，需要先跳转到搜索页');
      processNext();
    } else {
      // 否则直接开始
      processNext();
    }
  }

  function stop() {
    state.running = false;
    state.currentDetailUrl = null;
    saveState();
    updateStatus('已停止');
    console.log('[脉脉助手] 停止');
  }

  function clearData() {
    state = {
      list: [],
      index: 0,
      running: false,
      results: [],
      currentDetailUrl: null
    };

    // 立即保存并清除 localStorage
    localStorage.removeItem('mm_state');
    saveState();

    document.getElementById('mm-input').value = '';
    updateStatus('已清空');
    console.log('[脉脉助手] 已清空所有数据和缓存');
  }

  function processNext() {
    if (!state.running || state.index >= state.list.length) {
      if (state.index >= state.list.length) {
        finish();
      }
      return;
    }

    // 🔥 生成新的处理ID，防止多标签页并发
    const processingId = Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
    state.currentProcessingId = processingId;
    console.log('[脉脉助手] 生成新的 processingId:', processingId);

    const query = state.list[state.index];
    console.log('[脉脉助手] 搜索', query, '(' + (state.index + 1) + '/' + state.list.length + ')');

    updateStatus('搜索中 ' + (state.index + 1) + '/' + state.list.length + ': ' + query);
    saveState();

    // 跳转到搜索页
    setTimeout(() => {
      window.location.href = 'https://maimai.cn/web/search_center?type=contact&query=' + encodeURIComponent(query);
    }, 100);
  }

  function finish() {
    state.running = false;
    state.currentDetailUrl = null;
    saveState();

    const found = state.results.filter(r => r.found === 1).length;
    updateStatus('✅ 完成！' + state.list.length + '条，找到' + found + '条');
    console.log('[脉脉助手] 完成', state.results);
  }

  function exportResults() {
    if (state.results.length === 0) {
      updateStatus('暂无结果');
      return;
    }

    // 使用引号包裹，并转义内部的引号
    const escapeCSV = (str) => {
      if (!str) return '""';
      return '"' + String(str).replace(/"/g, '""') + '"';
    };

    // 计算工作年限（基于最晚的毕业年份）
    const calculateWorkYears = (parsedEdu) => {
      if (!parsedEdu || parsedEdu.length === 0) {
        return '';  // 无教育经历
      }

      let latestGraduationYear = 0;

      // 遍历所有教育经历，找出最晚的毕业年份
      parsedEdu.forEach(edu => {
        if (edu.time_range) {
          // time_range 格式: "2012-2016" 或 "2012至2016"
          // 提取结束年份（毕业年份）
          const match = edu.time_range.match(/(\d{4})\s*$/);
          if (match) {
            const endYear = parseInt(match[1]);
            if (endYear > latestGraduationYear) {
              latestGraduationYear = endYear;
            }
          }
        }
      });

      if (latestGraduationYear === 0) {
        return '';  // 未找到有效的毕业年份
      }

      const currentYear = new Date().getFullYear();
      const workYears = currentYear - latestGraduationYear;

      return workYears > 0 ? workYears : 0;  // 确保不为负数（应届生显示0）
    };

    // 解析所有结果的工作和教育经历
    const parsedResults = state.results.map(r => {
      const parsed = { ...r };

      // 解析工作经历
      if (r.workHistory && Array.isArray(r.workHistory)) {
        parsed.parsedWork = r.workHistory.map(w => parseWorkExperience(w));
      } else {
        parsed.parsedWork = [];
      }

      // 解析教育经历
      if (r.education && Array.isArray(r.education)) {
        parsed.parsedEdu = r.education.map(e => parseEducation(e));
      } else {
        parsed.parsedEdu = [];
      }

      return parsed;
    });

    // 找出最多的工作经历和教育经历数量
    let maxWork = 0;
    let maxEdu = 0;
    parsedResults.forEach(r => {
      maxWork = Math.max(maxWork, r.parsedWork.length);
      maxEdu = Math.max(maxEdu, r.parsedEdu.length);
    });

    // 生成表头
    let csv = '姓名,活跃状态,工作年限';

    // 添加工作经历列（只保留核心字段）
    for (let i = 0; i < maxWork; i++) {
      const idx = i + 1;
      csv += `,工作${idx}-title,工作${idx}-time_range,工作${idx}-position,工作${idx}-project_name`;
    }

    // 添加教育经历列（学校、时间、专业）
    for (let i = 0; i < maxEdu; i++) {
      const idx = i + 1;
      csv += `,教育${idx}-school,教育${idx}-time_range,教育${idx}-major`;
    }

    // 添加教育经历、工作经历、简历链接、简历来源
    csv += ',教育经历,工作经历,简历链接,简历来源\n';

    // 生成数据行
    parsedResults.forEach(r => {
      // 基本信息（姓名、活跃状态、工作年限）
      const workYears = calculateWorkYears(r.parsedEdu);
      let row = escapeCSV(r.name || '') + ',' +
        escapeCSV(r.activeStatus || '') + ',' +  // 活跃状态
        escapeCSV(workYears);  // 工作年限

      // 工作经历 - 只保留核心字段
      for (let i = 0; i < maxWork; i++) {
        const work = r.parsedWork[i] || {};
        row += ',' + escapeCSV(work.title || '');
        row += ',' + escapeCSV(work.time_range || '');
        row += ',' + escapeCSV(work.position || '');
        row += ',' + escapeCSV(work.project_name || '');
      }

      // 教育经历 - 学校、时间、专业
      for (let i = 0; i < maxEdu; i++) {
        const edu = r.parsedEdu[i] || {};
        row += ',' + escapeCSV(edu.school || '');
        row += ',' + escapeCSV(edu.time_range || '');
        row += ',' + escapeCSV(edu.major || '');
      }

      // 教育经历（完整内容，所有教育经历合并）
      const allEduContent = r.parsedEdu.map(e => e.content || '').filter(c => c).join(' | ');
      row += ',' + escapeCSV(allEduContent);

      // 工作经历（完整内容，所有工作经历合并）
      const allWorkContent = r.parsedWork.map(w => w.content).filter(c => c).join('\n\n---\n\n');
      row += ',' + escapeCSV(allWorkContent);

      // 简历链接（使用当前详情页URL，如果有的话）
      const resumeLink = r.profileUrl || '';
      row += ',' + escapeCSV(resumeLink);

      // 简历来源（固定为maimai）
      row += ',' + escapeCSV('maimai') + '\n';

      csv += row;
    });

    // 添加 BOM 以支持 Excel 正确显示中文
    const BOM = '\uFEFF';
    const csvContent = BOM + csv;

    // 创建下载链接
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;

    // 生成文件名（包含时间戳）
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').substring(0, 19);
    link.download = `脉脉搜索结果_${timestamp}.csv`;

    // 触发下载
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    updateStatus('✅ 已下载 ' + state.results.length + ' 条结果');
    console.log('[脉脉助手] 已导出', state.results.length, '条结果');
  }

  function updateStatus(msg) {
    const status = document.getElementById('mm-status');
    if (status) {
      status.textContent = msg;
    }
  }

  // 提取详情页信息
  function extractDetailInfo() {
    const info = {
      name: '',
      company: '',
      position: '',
      workHistory: [],
      education: []
    };

    try {
      console.log('[脉脉助手] 开始提取信息...');

      // 获取页面所有文本
      const bodyText = document.body.textContent;

      // 提取姓名 - 尝试多个选择器
      const nameCandidates = [
        document.querySelector('h1'),
        document.querySelector('[class*="name"]'),
        document.querySelector('[class*="title"]'),
        ...Array.from(document.querySelectorAll('*')).filter(el => {
          const text = el.textContent?.trim() || '';
          return text.length > 2 && text.length < 30 &&
            el.children.length === 0 &&
            !text.includes('工作') && !text.includes('教育');
        }).slice(0, 5)
      ];

      for (let el of nameCandidates) {
        if (el && el.textContent) {
          const text = el.textContent.trim();
          if (text && text.length > 1 && text.length < 50) {
            info.name = text;
            break;
          }
        }
      }

      // 提取工作经历 - 查找包含"工作经历"的标题元素
      // 只查找常见的标题标签和短文本元素
      const workHeaders = Array.from(document.querySelectorAll('h1, h2, h3, h4, h5, h6, div, span, p')).filter(el => {
        const text = el.textContent?.trim() || '';
        // 必须是精确匹配或很短的文本（避免匹配到父容器）
        return (text === '工作经历' || text === '工作经历：') && text.length < 20;
      });

      if (workHeaders.length > 0) {
        // 找到"工作经历"后面的兄弟元素
        const workHeader = workHeaders[0];
        const option1 = workHeader.nextElementSibling;

        // 使用选项1（标题本身的兄弟元素）
        let currentEl = option1;

        // 检查是否是列表元素（ul/ol），如果是则提取其子元素
        if (currentEl && (currentEl.tagName === 'UL' || currentEl.tagName === 'OL')) {
          let listItems = currentEl.querySelectorAll('li');

          if (listItems.length === 0) {
            listItems = Array.from(currentEl.children);
          }

          if (listItems.length > 0) {
            listItems.forEach((item, idx) => {
              const text = item.textContent?.trim() || '';

              if (text.length > 15 && text.length < 2000 &&
                (text.includes('公司') || text.includes('有限') || text.includes('科技') ||
                  text.includes('至今') || text.match(/\d{4}/))) {

                const isDuplicate = info.workHistory.some(existing =>
                  existing.substring(0, 30) === text.substring(0, 30)
                );

                if (!isDuplicate) {
                  info.workHistory.push(text);
                }
              }
            });
          } else {
            currentEl = currentEl.nextElementSibling;
            let iterations = 0;
            while (currentEl && iterations < 10) {
              iterations++;
              const text = currentEl.textContent?.trim() || '';

              if (text === '教育经历' || text === '自我介绍' || text === '个人信息') break;

              const hasKeyword = text.includes('公司') || text.includes('有限') || text.includes('科技') ||
                text.includes('至今') || text.match(/\d{4}/);

              if (text.length > 15 && text.length < 800 && !text.startsWith('工作经历') && hasKeyword) {
                const isDuplicate = info.workHistory.some(existing =>
                  existing.substring(0, 30) === text.substring(0, 30)
                );

                if (!isDuplicate) info.workHistory.push(text);
              }

              currentEl = currentEl.nextElementSibling;
            }
          }
        } else {
          let iterations = 0;
          while (currentEl && iterations < 10) {
            iterations++;
            const text = currentEl.textContent?.trim() || '';

            if (text === '教育经历' || text === '自我介绍' || text === '个人信息') break;

            const hasKeyword = text.includes('公司') || text.includes('有限') || text.includes('科技') ||
              text.includes('至今') || text.match(/\d{4}/);

            if (text.length > 15 && text.length < 800 && !text.startsWith('工作经历') && hasKeyword) {
              const isDuplicate = info.workHistory.some(existing =>
                existing.substring(0, 30) === text.substring(0, 30)
              );

              if (!isDuplicate) info.workHistory.push(text);
            }

            currentEl = currentEl.nextElementSibling;
          }
        }
      }

      // 提取教育经历 - 只查找标题元素
      const eduHeaders = Array.from(document.querySelectorAll('h1, h2, h3, h4, h5, h6, div, span, p')).filter(el => {
        const text = el.textContent?.trim() || '';
        return (text === '教育经历' || text === '教育经历：') && text.length < 20;
      });

      if (eduHeaders.length > 0) {
        const eduHeader = eduHeaders[0];
        let currentEl = eduHeader.nextElementSibling;

        // 检查是否是列表元素（ul/ol），如果是则提取其子元素
        if (currentEl && (currentEl.tagName === 'UL' || currentEl.tagName === 'OL')) {
          let listItems = currentEl.querySelectorAll('li');

          if (listItems.length === 0) {
            listItems = Array.from(currentEl.children);
          }

          if (listItems.length > 0) {
            listItems.forEach((item, idx) => {
              const text = item.textContent?.trim() || '';

              if (text.length > 10 && text.length < 500 &&
                (text.includes('大学') || text.includes('学院') || text.includes('本科') ||
                  text.includes('硕士') || text.includes('博士') || text.includes('学位') ||
                  text.match(/\d{4}年/))) {

                const isDuplicate = info.education.some(existing =>
                  existing.substring(0, 20) === text.substring(0, 20)
                );

                if (!isDuplicate) {
                  info.education.push(text);
                }
              }
            });
          } else {
            currentEl = currentEl.nextElementSibling;
            let iterations = 0;
            while (currentEl && iterations < 10) {
              iterations++;
              const text = currentEl.textContent?.trim() || '';

              if (text === '自我介绍' || text === '个人信息' || text === '技能特长') break;

              const hasKeyword = text.includes('大学') || text.includes('学院') || text.includes('本科') ||
                text.includes('硕士') || text.includes('博士') || text.includes('学位') ||
                text.match(/\d{4}年/);

              if (text.length > 10 && text.length < 500 && !text.startsWith('教育经历') && hasKeyword) {
                const isDuplicate = info.education.some(existing =>
                  existing.substring(0, 20) === text.substring(0, 20)
                );

                if (!isDuplicate) info.education.push(text);
              }

              currentEl = currentEl.nextElementSibling;
            }
          }
        } else {
          let iterations = 0;
          while (currentEl && iterations < 10) {
            iterations++;
            const text = currentEl.textContent?.trim() || '';

            if (text === '自我介绍' || text === '个人信息' || text === '技能特长') break;

            const hasKeyword = text.includes('大学') || text.includes('学院') || text.includes('本科') ||
              text.includes('硕士') || text.includes('博士') || text.includes('学位') ||
              text.match(/\d{4}年/);

            if (text.length > 10 && text.length < 500 && !text.startsWith('教育经历') && hasKeyword) {
              const isDuplicate = info.education.some(existing =>
                existing.substring(0, 20) === text.substring(0, 20)
              );

              if (!isDuplicate) info.education.push(text);
            }

            currentEl = currentEl.nextElementSibling;
          }
        }
      }

      // 从工作经历中提取当前公司和职位（第一条通常是当前的）
      if (info.workHistory.length > 0) {
        const current = info.workHistory[0];
        const companyMatch = current.match(/([^\s]{2,}公司|[^\s]{2,}有限|[^\s]{2,}科技)/);
        if (companyMatch) {
          info.company = companyMatch[0];
        }
      }

      console.log('[脉脉助手] ✅ 提取完成:', info.name, '| 工作', info.workHistory.length, '条 | 教育', info.education.length, '条');

    } catch (e) {
      console.error('[脉脉助手] 提取失败', e);
    }

    return info;
  }

  // 解析工作经历文本，提取结构化信息
  function parseWorkExperience(text) {
    const work = {
      title: '',
      company: '',
      time_range: '',
      position: '',
      subtitle: '',
      content: text,
      role: '',
      project_name: ''
    };

    try {
      // 提取公司名
      // 常见模式：XX公司、XX有限公司、XX科技
      const companyMatch = text.match(/([^\s\n]{2,}(?:公司|有限|科技|集团|企业|机构|银行|基金|投资))/);
      if (companyMatch) {
        work.company = companyMatch[1];
      }

      // 提取时间范围
      // 常见模式：2017.11-至今、2015.9-2017.11、2013.5-2015.7
      const timeMatch = text.match(/(\d{4}[.\-年]\d{1,2}[.\-月]?\s*[-至~]\s*(?:至今|\d{4}[.\-年]\d{1,2}[.\-月]?))/);
      if (timeMatch) {
        work.time_range = timeMatch[1].replace(/年|月/g, '').trim();
      }

      // 提取职位
      // 通常在公司名之前或时间之前
      const positionPatterns = [
        /(?:Head of|Director|Manager|Engineer|Designer|PM|产品|技术|总监|经理|主管|专家|工程师|架构师)/gi
      ];

      for (let pattern of positionPatterns) {
        const matches = text.match(pattern);
        if (matches && matches.length > 0) {
          work.position = matches[0];
          break;
        }
      }

      // 提取标题（通常是第一行或开头部分）
      const lines = text.split('\n').filter(l => l.trim());
      if (lines.length > 0) {
        work.title = lines[0].substring(0, 100);
      }

      // 提取副标题（如果有多行，第二行可能是副标题）
      if (lines.length > 1) {
        work.subtitle = lines[1].substring(0, 100);
      }

    } catch (e) {
      console.error('[脉脉助手] 解析工作经历失败', e);
    }

    return work;
  }

  // 解析教育经历文本，提取结构化信息
  function parseEducation(text) {
    const edu = {
      school: '',
      time_range: '',
      major: '',
      content: text
    };

    try {
      // 提取学校名
      // 常见模式：XX大学、XX学院
      const schoolMatch = text.match(/([^\s\n]{2,}(?:大学|学院|University|College))/i);
      if (schoolMatch) {
        edu.school = schoolMatch[1];
      }

      // 提取时间范围
      const timeMatch = text.match(/(\d{4}\s*年?\s*[-至~]\s*\d{4}\s*年?)/);
      if (timeMatch) {
        edu.time_range = timeMatch[1].replace(/年/g, '').trim();
      }

      // 提取专业
      // 常见关键词：专业、学士、硕士、博士、本科、研究生
      const majorPatterns = [
        /专业[：:]\s*([^\n\s，,。.]{2,20})/,
        /([^\n\s，,。.]{2,20})(?:专业|学士|硕士|博士)/,
        /(?:本科|硕士|博士|研究生)[：:]\s*([^\n\s，,。.]{2,20})/
      ];

      for (let pattern of majorPatterns) {
        const match = text.match(pattern);
        if (match && match[1]) {
          edu.major = match[1].trim();
          break;
        }
      }

      // 如果没有找到专业，尝试从内容中提取常见专业名词
      if (!edu.major) {
        const commonMajors = [
          '计算机', '软件工程', '信息', '通信', '电子', '自动化',
          '机械', '土木', '建筑', '化学', '生物', '物理', '数学',
          '经济', '金融', '会计', '管理', '市场营销', '人力资源',
          '法律', '新闻', '广告', '设计', '艺术', '教育', '医学', '护理'
        ];

        for (let major of commonMajors) {
          if (text.includes(major)) {
            edu.major = major;
            break;
          }
        }
      }

    } catch (e) {
      console.error('[脉脉助手] 解析教育经历失败', e);
    }

    return edu;
  }

  // 尝试添加好友
  function tryAddFriend() {
    try {
      console.log('[脉脉助手] ========== 开始添加好友流程 ==========');
      console.log('[脉脉助手] 当前页面URL:', window.location.href);
      console.log('[脉脉助手] 当前时间:', new Date().toLocaleTimeString());

      let addFriendButton = null;

      // 策略1: 精确查找"加好友"相关文本（支持全角和半角符号）
      console.log('[脉脉助手] 策略1: 查找包含"加好友"的元素...');

      // 首先尝试更精确的查询
      const buttonSelectors = [
        'button',
        '[role="button"]',
        '.btn',
        '.button',
        'div[class*="btn"]',
        'div[class*="button"]',
        'a[class*="btn"]',
        'a[class*="button"]'
      ];

      let candidates = [];

      // 先从按钮类元素中查找
      for (const selector of buttonSelectors) {
        const buttons = Array.from(document.querySelectorAll(selector));
        const matchingButtons = buttons.filter(btn => {
          const text = btn.textContent?.trim() || '';
          const innerText = btn.innerText?.trim() || '';

          return (text.length < 30 && text.length > 0) &&
            (text.includes('加好友') || text.includes('添加好友') ||
              text.includes('加为好友') || text.includes('关注') ||
              text === '+ 加好友' || text === '＋加好友' ||
              innerText.includes('加好友') || innerText.includes('添加好友'));
        });
        candidates.push(...matchingButtons);
      }

      // 如果没找到，再从所有元素中查找
      if (candidates.length === 0) {
        console.log('[脉脉助手] 按钮选择器未找到，扩大搜索范围...');
        const allElements = Array.from(document.querySelectorAll('*'));
        candidates = allElements.filter(el => {
          const text = el.textContent?.trim() || '';
          const innerText = el.innerText?.trim() || '';

          return (text.length < 20 && text.length > 0) &&
            (text.includes('加好友') || text.includes('添加好友') ||
              text.includes('加为好友') ||
              text === '+ 加好友' || text === '＋加好友' ||
              innerText.includes('加好友') || innerText.includes('添加好友'));
        });
      }

      console.log('[脉脉助手] 找到', candidates.length, '个包含"加好友"的元素');

      candidates.forEach((el, idx) => {
        const text = el.textContent?.trim() || '';
        const style = window.getComputedStyle(el);
        const isClickable = style.cursor === 'pointer' || el.onclick !== null || el.tagName === 'BUTTON' || el.tagName === 'A';
        console.log('  候选', idx + 1, ':', text, '|', el.tagName, '|', el.className.substring(0, 50), '| 可点击:', isClickable);
      });

      // 智能选择最可能的按钮
      function getButtonPriority(el) {
        const text = el.textContent?.trim() || '';
        const className = el.className || '';
        const style = window.getComputedStyle(el);
        const tagName = el.tagName;

        let priority = 0;

        // 文本匹配优先级
        if (text === '＋加好友') priority += 100;
        else if (text === '+加好友') priority += 90;
        else if (text.includes('加好友')) priority += 80;
        else if (text.includes('添加好友')) priority += 70;
        else if (text.includes('关注')) priority += 50;

        // 标签类型优先级
        if (tagName === 'BUTTON') priority += 50;
        else if (tagName === 'A') priority += 30;
        else if (el.getAttribute('role') === 'button') priority += 40;

        // 样式和交互性优先级
        if (style.cursor === 'pointer') priority += 30;
        if (el.onclick !== null) priority += 20;
        if (className.includes('btn')) priority += 20;
        if (className.includes('button')) priority += 15;

        // 可见性检查
        const rect = el.getBoundingClientRect();
        if (rect.width > 0 && rect.height > 0) priority += 10;

        return priority;
      }

      // 对候选按钮按优先级排序
      const sortedCandidates = candidates.sort((a, b) => getButtonPriority(b) - getButtonPriority(a));

      console.log('[脉脉助手] 候选按钮优先级排序:');
      sortedCandidates.forEach((el, idx) => {
        const text = el.textContent?.trim() || '';
        const priority = getButtonPriority(el);
        const rect = el.getBoundingClientRect();
        console.log(`  ${idx + 1}. "${text}" | ${el.tagName} | 优先级:${priority} | 尺寸:${Math.round(rect.width)}x${Math.round(rect.height)}`);
      });

      // 选择优先级最高的按钮
      if (sortedCandidates.length > 0) {
        addFriendButton = sortedCandidates[0];
        const text = addFriendButton.textContent?.trim() || '';
        console.log('[脉脉助手] ✅ 选择优先级最高的按钮:', text, '标签:', addFriendButton.tagName);
      }


      // 策略2: 如果策略1失败，查找包含"加"字的短文本按钮
      if (!addFriendButton) {
        console.log('[脉脉助手] 策略2: 查找包含"加"字的按钮...');

        const buttons = Array.from(document.querySelectorAll('button, a, div[role="button"], [class*="btn"], [class*="button"]'));
        const shortTextButtons = buttons.filter(btn => {
          const text = btn.textContent?.trim() || '';
          return text.length > 0 && text.length < 20 && text.includes('加');
        });

        console.log('[脉脉助手] 找到', shortTextButtons.length, '个包含"加"的按钮类元素');

        shortTextButtons.forEach((btn, idx) => {
          const text = btn.textContent?.trim() || '';
          console.log('  按钮', idx + 1, ':', text, '|', btn.tagName, '|', btn.className.substring(0, 50));
        });

        if (shortTextButtons.length > 0) {
          addFriendButton = shortTextButtons[0];
          console.log('[脉脉助手] ✅ 选中第一个"加"字按钮:', addFriendButton.textContent?.trim());
        }
      }

      // 策略3: 如果还是找不到，打印所有可能的操作按钮供调试
      if (!addFriendButton) {
        console.log('[脉脉助手] 策略3: 打印所有短文本可点击元素供调试...');

        const clickables = Array.from(document.querySelectorAll('button, a, [onclick], div[role="button"], span[role="button"]'));
        const shortClickables = clickables.filter(el => {
          const text = el.textContent?.trim() || '';
          return text.length > 0 && text.length < 30;
        });

        console.log('[脉脉助手] 找到', shortClickables.length, '个短文本可点击元素:');
        shortClickables.forEach((el, idx) => {
          const text = el.textContent?.trim() || '';
          const classList = el.className || '';
          console.log('  元素', idx + 1, ':', text, '|', el.tagName, '|', classList.substring(0, 50));
        });
      }

      if (addFriendButton) {
        console.log('[脉脉助手] 准备点击按钮:', addFriendButton.textContent?.trim());
        console.log('[脉脉助手] 按钮信息:', {
          tagName: addFriendButton.tagName,
          className: addFriendButton.className,
          id: addFriendButton.id,
          coordinates: addFriendButton.getBoundingClientRect()
        });

        // 增强的点击方法：模拟真实用户点击
        function triggerRealClick(element) {
          // 确保元素可见并可点击
          element.scrollIntoView({ behavior: 'smooth', block: 'center' });

          // 等待一小段时间让滚动完成
          setTimeout(() => {
            const rect = element.getBoundingClientRect();
            const x = rect.left + rect.width / 2;
            const y = rect.top + rect.height / 2;

            // 创建鼠标事件序列
            const mouseDownEvent = new MouseEvent('mousedown', {
              view: window,
              bubbles: true,
              cancelable: true,
              clientX: x,
              clientY: y,
              button: 0
            });

            const mouseUpEvent = new MouseEvent('mouseup', {
              view: window,
              bubbles: true,
              cancelable: true,
              clientX: x,
              clientY: y,
              button: 0
            });

            const clickEvent = new MouseEvent('click', {
              view: window,
              bubbles: true,
              cancelable: true,
              clientX: x,
              clientY: y,
              button: 0
            });

            // 依次触发事件
            element.dispatchEvent(mouseDownEvent);
            setTimeout(() => {
              element.dispatchEvent(mouseUpEvent);
              setTimeout(() => {
                element.dispatchEvent(clickEvent);
                console.log('[脉脉助手] ✅ 已使用增强点击方法点击按钮');

                // 作为备选，也尝试原生点击
                setTimeout(() => {
                  element.click();
                  console.log('[脉脉助手] ✅ 已使用原生方法点击按钮');
                }, 100);
              }, 50);
            }, 50);
          }, 200);
        }

        triggerRealClick(addFriendButton);

        console.log('[脉脉助手] ✅ 已点击加好友按钮，等待页面跳转到验证页面...');
        console.log('[脉脉助手] 注意：发送按钮的查找将在验证页面加载时自动执行');


        // 点击发送按钮后，等待一段时间再关闭弹窗
        setTimeout(() => {
          console.log('[脉脉助手] ========== 添加好友流程结束 ==========');
        }, 5000);
      } else {
        console.log('[脉脉助手] ❌ 所有策略都失败，无法找到添加好友按钮');
        console.log('[脉脉助手] 请检查上面的调试信息，看看实际的按钮文本是什么');
      }
    } catch (e) {
      console.error('[脉脉助手] 添加好友失败', e);
    }
  }

  // 在搜索结果页
  if (window.location.href.includes('search_center')) {
    loadState();

    console.log('[脉脉助手] 当前URL:', window.location.href);
    console.log('[脉脉助手] 当前状态:', {
      running: state.running,
      index: state.index,
      listLength: state.list.length,
      currentQuery: state.list[state.index],
      currentDetailUrl: state.currentDetailUrl
    });

    if (state.running && state.index < state.list.length) {
      // 保存当前的processingId用于后续验证
      const expectedProcessingId = state.currentProcessingId;
      console.log('[脉脉助手] 在搜索页，等待结果... (processingId:', expectedProcessingId, ')');

      setTimeout(async () => {
        // 🔥 重新加载状态并验证processingId
        loadState();

        if (state.currentProcessingId !== expectedProcessingId) {
          console.log('[脉脉助手] ⚠️ processingId 不匹配，跳过处理');
          console.log('[脉脉助手] 期望:', expectedProcessingId, '实际:', state.currentProcessingId);
          return;
        }

        const query = new URLSearchParams(window.location.search).get('query') || '';
        const expectedQuery = state.list[state.index];

        console.log('[脉脉助手] URL中的查询词:', decodeURIComponent(query));
        console.log('[脉脉助手] 期望的查询词:', expectedQuery);

        // 检查是否匹配
        if (decodeURIComponent(query) !== expectedQuery) {
          console.error('[脉脉助手] ⚠️ 查询词不匹配！URL中是"' + decodeURIComponent(query) + '"，期望是"' + expectedQuery + '"');
        }

        // 检测是否有结果
        const noResult = document.body.textContent.includes('暂无搜索结果') ||
          document.body.textContent.includes('没有找到');

        if (noResult) {
          // 没有结果，直接记录并继续
          const result = {
            query: decodeURIComponent(query),
            found: 0,
            time: new Date().toLocaleString()
          };

          console.log('[脉脉助手] 无结果', result);
          state.results.push(result);
          state.index++;
          saveState();

          setTimeout(() => {
            processNext();
          }, 2000);
        } else {
          // 有结果，查找搜索结果卡片
          const query = state.list[state.index];
          const mode = state.mode || 'first';

          console.log('[脉脉助手] 页面有结果，模式:', mode === 'first' ? '首个结果' : '所有结果');

          // 简化的结果获取逻辑
          let validCards = [];

          // 每次都执行滚动获取完整结果（因为网页重新访问会重置）
          console.log('[脉脉助手] 执行滚动获取完整结果...');
          validCards = await getAllResultsWithScroll();
          console.log('[脉脉助手] 滚动完成，获取了', validCards.length, '个结果');

          console.log('[脉脉助手] 有效卡片数量:', validCards.length);

          let resultCard = null;

          if (mode === 'first') {
            // 首个结果模式：只选第一个
            if (validCards.length > 0) {
              resultCard = validCards[0].element;
              // 保存活跃状态到 state (持久化)
              state.currentActiveStatus = validCards[0].activeStatus || '';
              saveState();
              console.log('[脉脉助手] ✅ 选择首个结果');
              console.log('[脉脉助手] 📊 活跃状态:', state.currentActiveStatus);
            }
          } else if (mode === 'all') {
            // 所有结果模式：保存所有卡片，逐个处理
            if (validCards.length > 0) {
              // 检查是否是新查询（查询词改变时重置）
              const isNewQuery = !state.lastProcessedQuery || state.lastProcessedQuery !== query;

              if (isNewQuery || state.currentQueryResults.length === 0) {
                // 新查询或第一次：重新初始化索引列表，同时保存活跃状态
                state.currentQueryResults = validCards.map((card, i) => ({
                  index: i,
                  activeStatus: card.activeStatus || ''
                }));
                state.lastProcessedQuery = query;
                saveState();
                console.log('[脉脉助手] 所有结果模式：找到', validCards.length, '个结果，重新初始化索引');
              }

              // 取当前要处理的卡片
              if (state.currentQueryResults.length > 0) {
                const currentResult = state.currentQueryResults[0];
                // 兼容处理：支持对象格式和旧的数字格式
                const cardIndex = typeof currentResult === 'object' ? currentResult.index : currentResult;
                const currentActiveStatus = typeof currentResult === 'object' ? currentResult.activeStatus : '';

                // 安全检查：确保索引不越界
                if (cardIndex < validCards.length && validCards[cardIndex] && validCards[cardIndex].element) {
                  resultCard = validCards[cardIndex].element;
                  // 保存活跃状态到 state (持久化)
                  state.currentActiveStatus = currentActiveStatus || validCards[cardIndex].activeStatus || '';
                  saveState();
                  console.log('[脉脉助手] ✅ 处理第', (cardIndex + 1), '/', validCards.length, '个结果');
                  console.log('[脉脉助手] 📊 活跃状态:', state.currentActiveStatus);
                } else {
                  console.error('[脉脉助手] ❌ 索引越界或元素不存在:', cardIndex, '/', validCards.length);
                  // 跳过无效的索引
                  state.currentQueryResults.shift();
                  saveState();
                  setTimeout(() => {
                    processNext();
                  }, 1000);
                  return;
                }
              }
            }
          }

          if (resultCard && resultCard.querySelectorAll) {
            // 找到卡片后，尝试从卡片中提取 dstu 参数并直接跳转
            console.log('[脉脉助手] 准备从卡片提取 dstu 参数...');
            console.log('[脉脉助手] resultCard 类型:', typeof resultCard, 'tagName:', resultCard.tagName);

            // 策略1: 查找卡片内所有元素的属性，寻找 dstu
            let dstu = null;

            // 检查所有子元素的 data-* 属性
            const allElements = resultCard.querySelectorAll('*');
            for (let el of allElements) {
              // 检查所有属性
              for (let attr of el.attributes || []) {
                if (attr.value && attr.value.includes('dstu=')) {
                  const match = attr.value.match(/dstu=(\d+)/);
                  if (match) {
                    dstu = match[1];
                    console.log('[脉脉助手] ✅ 从属性中找到 dstu:', dstu);
                    break;
                  }
                }
              }
              if (dstu) break;

              // 检查 onclick 等事件属性
              if (el.onclick && el.onclick.toString().includes('dstu')) {
                const match = el.onclick.toString().match(/dstu['":\s=]+(\d+)/);
                if (match) {
                  dstu = match[1];
                  console.log('[脉脉助手] ✅ 从 onclick 找到 dstu:', dstu);
                  break;
                }
              }
            }

            // 策略2: 如果找不到 dstu，尝试在 React 属性中查找
            if (!dstu) {
              console.log('[脉脉助手] 未找到 dstu，尝试查找 React 数据...');

              // 查找 __reactProps 或类似的 React 内部属性
              for (let el of allElements) {
                for (let key in el) {
                  if (key.startsWith('__react')) {
                    try {
                      const props = el[key];
                      const propsStr = JSON.stringify(props);
                      if (propsStr.includes('dstu')) {
                        const match = propsStr.match(/dstu['":\s]+(\d+)/);
                        if (match) {
                          dstu = match[1];
                          console.log('[脉脉助手] ✅ 从 React props 找到 dstu:', dstu);
                          break;
                        }
                      }
                    } catch (e) {
                      // 忽略循环引用等错误
                    }
                  }
                }
                if (dstu) break;
              }
            }

            if (dstu) {
              // 找到 dstu，构建 URL 并跳转
              const detailUrl = `https://maimai.cn/profile/detail?dstu=${dstu}&from=pc_web_search`;
              console.log('[脉脉助手] ✅ 构建详情页URL:', detailUrl);

              state.currentDetailUrl = detailUrl;
              saveState();

              setTimeout(() => {
                window.location.href = detailUrl;
              }, 1000);
            } else {
              // 找不到 dstu，尝试点击
              console.log('[脉脉助手] ⚠️ 未找到 dstu，尝试点击卡片...');

              // 按优先级顺序尝试点击元素
              // .media-left 是最可靠的（测试验证通过）
              const clickableElements = [
                resultCard.querySelector('.media-left'),  // 最优先
                resultCard.querySelector('.cursor-pointer'),
                resultCard.querySelector('.media-body'),
                resultCard
              ];

              let clicked = false;
              for (let el of clickableElements) {
                if (el) {
                  console.log('[脉脉助手] 点击元素:', el.className || el.tagName);
                  el.click();
                  clicked = true;

                  state.currentDetailUrl = 'CLICKED_CARD';
                  saveState();

                  // 🔥 保存当前的processingId用于超时验证
                  const timeoutProcessingId = state.currentProcessingId;

                  // 添加超时检测：等待5秒检查是否跳转成功
                  setTimeout(() => {
                    // 🔥 重新加载状态并验证processingId
                    loadState();

                    // 如果processingId已变化，说明已经在其他地方处理了，跳过
                    if (state.currentProcessingId !== timeoutProcessingId) {
                      console.log('[脉脉助手] processingId已变化，跳过超时处理');
                      return;
                    }

                    // 检查是否还在搜索页面（说明跳转失败）
                    if (window.location.href.includes('/web/search_center')) {
                      console.log('[脉脉助手] ⚠️ 点击后5秒未跳转，跳过此结果');

                      // "所有结果"模式：移除当前处理的卡片索引，继续处理下一个
                      if (state.mode === 'all' && state.currentQueryResults && state.currentQueryResults.length > 1) {
                        state.currentQueryResults.shift(); // 移除第一个（当前的）
                        console.log('[脉脉助手] 继续处理剩余', state.currentQueryResults.length, '个结果');

                        // 直接调用搜索页面处理逻辑，继续下一个结果
                        setTimeout(() => {
                          handleSearchPage();
                        }, 1000);
                      } else {
                        // 首个结果模式或最后一个结果：跳过到下一个查询
                        console.log('[脉脉助手] 跳过到下一个查询');
                        const result = {
                          query: state.list[state.index],
                          found: 0,
                          time: new Date().toLocaleString(),
                          note: '点击后未能跳转'
                        };
                        state.results.push(result);
                        state.index++;
                        state.currentQueryResults = []; // 重置结果数组
                        saveState();

                        setTimeout(() => {
                          processNext();
                        }, 1000);
                      }
                    }
                  }, 5000);

                  break;
                }
              }

              if (!clicked) {
                console.log('[脉脉助手] ❌ 未能点击卡片');
                const result = {
                  query: query,
                  found: 0,
                  time: new Date().toLocaleString()
                };
                state.results.push(result);
                state.index++;
                saveState();

                setTimeout(() => {
                  processNext();
                }, 2000);
              }
            }
          } else {
            // 找不到结果卡片
            console.log('[脉脉助手] ❌ 未找到结果卡片');
            const result = {
              query: query,
              found: 0,
              time: new Date().toLocaleString()
            };
            state.results.push(result);
            state.index++;
            saveState();

            setTimeout(() => {
              processNext();
            }, 2000);
          }
        }
      }, 2000);
    } else {
      createPanel();
    }
  }
  // 在详情页或验证页
  else if (window.location.href.includes('/profile/detail') ||
    window.location.href.includes('/contact/') ||
    window.location.href.includes('/card/')) {
    loadState();

    // 更精确的验证页面检测（避免误判详情页）
    console.log('[脉脉助手] 详情页分支 - 检查是否为验证页面...');
    console.log('[脉脉助手] 当前URL:', window.location.href);

    const pageText = document.body.textContent || '';
    const currentUrl = window.location.href;

    // 只有同时满足多个条件才认为是验证页面
    const hasVerificationInput = document.querySelector('input[placeholder*="验证"]') ||
      document.querySelector('textarea[placeholder*="验证"]') ||
      document.querySelector('input[placeholder*="申请理由"]') ||
      document.querySelector('textarea[placeholder*="申请理由"]');

    const hasVerificationText = pageText.includes('验证信息') ||
      pageText.includes('申请理由') ||
      pageText.includes('好友申请');

    const hasVerificationUrl = currentUrl.includes('verification') ||
      currentUrl.includes('add_friend') ||
      currentUrl.includes('friend_tag');

    // 必须同时有输入框和相关文本，或者URL明确包含验证相关路径
    const isVerificationPage = (hasVerificationInput && hasVerificationText) || hasVerificationUrl;

    console.log('[脉脉助手] 验证页面检测:', {
      hasVerificationInput,
      hasVerificationText,
      hasVerificationUrl,
      isVerificationPage
    });

    if (isVerificationPage) {
      console.log('[脉脉助手] ✅ 检测到验证页面，调用验证页面处理逻辑...');
      createPanel();
      checkIfVerificationPageAndHandleSend();
      return;
    }

    // 如果没有 currentDetailUrl，说明不是通过搜索跳转来的
    if (!state.currentDetailUrl) {
      // 🔥 但如果正在运行，可能是添加好友流程中的异常页面，继续下一个
      if (state.running && state.index < state.list.length) {
        console.log('[脉脉助手] ⚠️ currentDetailUrl为空但正在运行，可能是添加好友异常');
        console.log('[脉脉助手] 5秒后继续下一个查询...');
        createPanel();
        setTimeout(() => {
          console.log('[脉脉助手] 继续下一个查询...');
          loadState();
          state.index++;
          state.currentQueryResults = [];
          saveState();
          processNext();
        }, 5000);
        return;
      }
      createPanel();
      return;
    }

    if (state.running && state.currentDetailUrl) {
      console.log('[脉脉助手] 📄 详情页 - 查询:', state.list[state.index]);
      console.log('[脉脉助手] 当前URL:', window.location.href);

      // 如果是通过点击卡片进入的（标记为 CLICKED_CARD），则直接提取信息
      // 不需要做URL匹配检查，因为我们没有预知的URL
      if (state.currentDetailUrl !== 'CLICKED_CARD') {
        // 如果有具体的URL，则检查是否匹配
        const currentUrlBase = window.location.href.split('?')[0] + '?' + window.location.href.split('?')[1]?.split('&')[0];
        const expectedUrlBase = state.currentDetailUrl.split('?')[0] + '?' + state.currentDetailUrl.split('?')[1]?.split('&')[0];

        if (currentUrlBase !== expectedUrlBase) {
          console.error('[脉脉助手] ⚠️ URL不匹配！跳过提取');
          console.error('[脉脉助手] 期望的URL:', state.currentDetailUrl);
          console.error('[脉脉助手] 实际的URL:', window.location.href);

          // URL不匹配，清除状态并跳转到正确的搜索页
          state.currentDetailUrl = null;
          saveState();

          setTimeout(() => {
            processNext();
          }, 1000);

          return;
        }
      }

      // 定义继续下一个查询的函数
      const continueNextQuery = () => {
        // 检查是否是"所有结果"模式
        const mode = state.mode || 'first';

        if (mode === 'all' && state.currentQueryResults.length > 0) {
          // 所有结果模式：移除刚处理的卡片索引
          state.currentQueryResults.shift();
          saveState();

          if (state.currentQueryResults.length > 0) {
            // 还有更多结果要处理，回到搜索页继续
            console.log('[脉脉助手] 所有结果模式：还有', state.currentQueryResults.length, '个结果待处理');
            updateStatus('处理中 ' + (state.index + 1) + '/' + state.list.length + ' (多结果)');

            const delay = (state.intervalSeconds || 10) * 1000;
            console.log('[脉脉助手] 等待', state.intervalSeconds, '秒后继续...');
            setTimeout(() => {
              // 回到搜索页处理下一个结果
              const query = state.list[state.index];
              window.location.href = 'https://maimai.cn/web/search_center?type=contact&query=' + encodeURIComponent(query);
            }, delay);

            return;
          } else {
            // 当前查询的所有结果都处理完了，继续下一个查询
            console.log('[脉脉助手] 所有结果模式：当前查询完成');
            state.index++;
            saveState();
          }
        } else {
          // 首个结果模式：直接进入下一个查询
          state.index++;
          state.currentQueryResults = [];
          saveState();
        }

        updateStatus('已完成 ' + state.index + '/' + state.list.length);

        // 等待指定时间后继续下一个查询（防止反爬）
        const delay = (state.intervalSeconds || 10) * 1000;
        console.log('[脉脉助手] 等待', state.intervalSeconds, '秒后继续下一个查询...');
        setTimeout(() => {
          processNext();
        }, delay);
      };

      // 检查是否已经尝试过添加这个用户为好友
      const currentDstu = new URLSearchParams(window.location.search).get('dstu');
      const attemptedKey = `attempted_${currentDstu}`;

      if (!state.addFriendAttemptedUsers) {
        state.addFriendAttemptedUsers = {};
      }

      const alreadyAttempted = state.addFriendAttemptedUsers[attemptedKey];
      console.log(`[脉脉助手] 用户 ${currentDstu} 是否已尝试添加好友:`, alreadyAttempted);

      saveState();

      // 等待2秒让页面加载完成
      setTimeout(() => {
        // 如果开启了添加好友，先执行添加好友流程
        if (state.addFriend && !alreadyAttempted) {
          console.log('[脉脉助手] ========== 开启了添加好友功能 ==========');
          console.log('[脉脉助手] 首次尝试添加好友...');

          // 🔥 先提取并保存数据，防止添加好友失败导致数据丢失
          console.log('[脉脉助手] 先提取数据再添加好友...');
          const info = extractDetailInfo();
          const query = state.list[state.index] || '';

          console.log('[脉脉助手] 当前应该查询的关键词:', query);
          console.log('[脉脉助手] 提取到的姓名:', info.name);

          const result = {
            query: query,
            found: 1,
            name: info.name,
            company: info.company,
            position: info.position,
            workHistory: info.workHistory,
            education: info.education,
            profileUrl: window.location.href.split('?')[0] + '?dstu=' + new URLSearchParams(window.location.search).get('dstu'),
            time: new Date().toLocaleString(),
            addFriendStatus: 'attempting',
            activeStatus: state.currentActiveStatus || ''
          };

          console.log('[脉脉助手] 详情结果 (添加好友前)', result);

          state.results.push(result);
          state.currentDetailUrl = null;

          // 🔥 立即生成新的processingId使5秒超时失效
          state.currentProcessingId = Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
          console.log('[脉脉助手] 数据已保存，生成新的 processingId:', state.currentProcessingId);

          // 标记已经尝试过添加好友
          state.addFriendAttemptedUsers[attemptedKey] = true;
          saveState();

          // 数据已保存，现在尝试添加好友
          tryAddFriend();

          // 等待添加好友流程完成后继续下一个
          setTimeout(() => {
            console.log('[脉脉助手] 添加好友流程完成，继续下一个查询...');
            // 重新加载状态
            loadState();
            // 继续下一个查询
            continueNextQuery();
          }, 9000);
        } else if (state.addFriend && alreadyAttempted) {
          console.log('[脉脉助手] 已经尝试过添加好友，跳过，直接提取数据...');

          // 提取信息并保存
          const info = extractDetailInfo();
          const query = state.list[state.index] || '';

          const result = {
            query: query,
            found: 1,
            name: info.name,
            company: info.company,
            position: info.position,
            workHistory: info.workHistory,
            education: info.education,
            profileUrl: window.location.href.split('?')[0] + '?dstu=' + new URLSearchParams(window.location.search).get('dstu'),
            time: new Date().toLocaleString(),
            addFriendStatus: 'attempted_already',
            activeStatus: state.currentActiveStatus || ''  // 从 state 读取
          };

          console.log('[脉脉助手] 详情结果（已尝试加好友）', result);

          state.results.push(result);
          state.currentDetailUrl = null;

          // 🔥 立即生成新的processingId使5秒超时失效
          state.currentProcessingId = Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
          console.log('[脉脉助手] 数据已保存，生成新的 processingId:', state.currentProcessingId);

          saveState();

          // 继续下一个查询
          continueNextQuery();
        } else {
          // 没有开启添加好友，直接提取数据
          console.log('[脉脉助手] 未开启添加好友，直接提取数据...');

          const info = extractDetailInfo();
          const query = state.list[state.index] || '';

          console.log('[脉脉助手] 当前应该查询的关键词:', query);
          console.log('[脉脉助手] 提取到的姓名:', info.name);

          const result = {
            query: query,
            found: 1,
            name: info.name,
            company: info.company,
            position: info.position,
            workHistory: info.workHistory,
            education: info.education,
            profileUrl: window.location.href.split('?')[0] + '?dstu=' + new URLSearchParams(window.location.search).get('dstu'),
            time: new Date().toLocaleString(),
            activeStatus: state.currentActiveStatus || ''  // 从 state 读取
          };

          console.log('[脉脉助手] 详情结果', result);

          state.results.push(result);
          state.currentDetailUrl = null;

          // 🔥 立即生成新的processingId使5秒超时失效
          state.currentProcessingId = Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
          console.log('[脉脉助手] 数据已保存，生成新的 processingId:', state.currentProcessingId);

          saveState();

          // 继续下一个查询
          continueNextQuery();
        }
      }, 2000);
    }

    createPanel();
  }
  // 其他页面
  else {
    console.log('[脉脉助手] 🔍 进入"其他页面"分支');
    console.log('[脉脉助手] 当前URL:', window.location.href);
    loadState();
    console.log('[脉脉助手] state.running:', state.running, 'state.index:', state.index);
    createPanel();

    // 检查是否是验证页面，如果是则自动查找发送按钮
    checkIfVerificationPageAndHandleSend();

    // 额外的延迟检查，以防页面加载较慢
    setTimeout(() => {
      console.log('[脉脉助手] 执行延迟页面检测...');
      checkIfVerificationPageAndHandleSend();
    }, 3000);
  }

  // 检查页面类型并处理相应逻辑
  function checkIfVerificationPageAndHandleSend() {
    const currentUrl = window.location.href;
    console.log('[脉脉助手] ========== 开始页面检测 ==========');
    console.log('[脉脉助手] 当前URL:', currentUrl);
    console.log('[脉脉助手] 页面标题:', document.title);
    console.log('[脉脉助手] 页面文本内容（前500字符）:', document.body.textContent.substring(0, 500));

    // 首先检查是否是发送成功页面
    const bodyText = document.body.textContent;
    const isSuccessPage = bodyText.includes('已发送') ||
      bodyText.includes('等待对方通过') ||
      bodyText.includes('好友申请已发送') ||
      bodyText.includes('申请已发送') ||
      bodyText.includes('发送成功') ||
      currentUrl.includes('success') ||
      currentUrl.includes('sent');

    if (isSuccessPage) {
      console.log('[脉脉助手] ✅ 检测到发送成功页面，准备关闭并继续下一个...');
      handleSuccessPage();
      return;
    }

    // 更宽泛的验证页面检测
    console.log('[脉脉助手] 检查验证页面特征...');

    // 检查URL特征（移除太宽泛的contact，避免误判详情页）
    const urlHasFeature = currentUrl.includes('add_friend') ||
      currentUrl.includes('verification') ||
      currentUrl.includes('verify') ||
      currentUrl.includes('friend_tag');

    console.log('[脉脉助手] URL包含好友相关关键词:', urlHasFeature);

    // 检查页面内容特征
    const hasAddFriendText = bodyText.includes('添加好友') ||
      bodyText.includes('加好友') ||
      bodyText.includes('验证信息') ||
      bodyText.includes('验证消息') ||
      bodyText.includes('发送验证');

    console.log('[脉脉助手] 页面包含好友相关文本:', hasAddFriendText);

    // 检查输入框
    const inputs = document.querySelectorAll('input, textarea');
    const hasVerificationInput = Array.from(inputs).some(input => {
      const placeholder = input.placeholder || '';
      const name = input.name || '';
      const id = input.id || '';
      return placeholder.includes('验证') ||
        placeholder.includes('消息') ||
        name.includes('verify') ||
        name.includes('message') ||
        id.includes('verify') ||
        id.includes('message');
    });

    console.log('[脉脉助手] 找到验证相关输入框:', hasVerificationInput);
    console.log('[脉脉助手] 输入框详情:');
    inputs.forEach((input, idx) => {
      console.log(`  输入框${idx + 1}: placeholder="${input.placeholder}" name="${input.name}" id="${input.id}"`);
    });

    // 检查发送按钮
    const sendButtons = Array.from(document.querySelectorAll('button, [role="button"], .btn')).filter(btn => {
      const text = btn.textContent?.trim() || '';
      return text === '发送' || text.includes('发送') || text === 'Send' || text === '提交';
    });

    console.log('[脉脉助手] 找到发送相关按钮数量:', sendButtons.length);
    sendButtons.forEach((btn, idx) => {
      console.log(`  发送按钮${idx + 1}: "${btn.textContent?.trim()}" | ${btn.tagName} | ${btn.className}`);
    });

    // 更精确的验证页面判断（避免误判详情页）
    const isVerificationPage = urlHasFeature ||
      (hasVerificationInput && (hasAddFriendText || sendButtons.length > 0));

    console.log('[脉脉助手] 综合判断 - 是否为验证页面:', isVerificationPage);

    if (isVerificationPage) {
      console.log('[脉脉助手] ✅ 检测到验证页面，准备查找发送按钮...');

      // 等待页面完全加载后再查找发送按钮
      setTimeout(() => {
        findAndClickSendButton();
      }, 2000);
    } else {
      // 🔥 不是验证页面也不是成功页面 → 可能是无法添加好友的页面
      // 等待一段时间后继续下一个查询，避免卡住
      console.log('[脉脉助手] ⚠️ 当前不是验证页面或成功页面，可能无法添加好友');
      console.log('[脉脉助手] DEBUG: state.running =', state.running);
      console.log('[脉脉助手] DEBUG: state.index =', state.index);
      console.log('[脉脉助手] DEBUG: state.list.length =', state.list.length);
      console.log('[脉脉助手] 5秒后将继续下一个查询...');

      // 如果正在运行，等待5秒后继续下一个
      if (state.running && state.index < state.list.length) {
        console.log('[脉脉助手] ✅ 条件满足，5秒后继续');
        setTimeout(() => {
          console.log('[脉脉助手] 页面异常，继续下一个查询...');
          loadState();
          // 增加索引并继续下一个
          state.index++;
          state.currentDetailUrl = null;
          state.currentQueryResults = [];
          saveState();
          processNext();
        }, 5000);
      } else {
        console.log('[脉脉助手] ❌ 条件不满足，不继续');
      }
    }

    console.log('[脉脉助手] ========== 页面检测结束 ==========');
  }

  // 处理发送成功页面
  function handleSuccessPage() {
    console.log('[脉脉助手] ========== 处理发送成功页面 ==========');
    console.log('[脉脉助手] 好友申请已发送，准备关闭页面...');

    // 尝试关闭页面的多种方法
    setTimeout(() => {
      // 方法1: 查找关闭或返回按钮
      const closeButtons = Array.from(document.querySelectorAll('button, a, div, span'));
      let closed = false;

      for (let btn of closeButtons) {
        const text = btn.textContent?.trim() || '';
        const className = btn.className || '';

        // 查找关闭、返回、完成等按钮
        if (text === '×' || text === 'X' || text === '关闭' || text === '返回' ||
          text === '取消' || text === '完成' || text === '确定' ||
          className.includes('close') || className.includes('modal-close') ||
          className.includes('back') || className.includes('return') ||
          className.includes('finish')) {
          console.log('[脉脉助手] 找到关闭按钮:', text || className.substring(0, 30));
          btn.click();
          console.log('[脉脉助手] ✅ 已点击关闭按钮');
          closed = true;
          break;
        }
      }

      // 方法2: 如果没找到关闭按钮，直接跳转到搜索页面继续下一个查询
      if (!closed) {
        console.log('[脉脉助手] 未找到关闭按钮，直接跳转到搜索页面继续下一个查询...');

        // 清理当前详情页状态
        state.currentDetailUrl = null;
        saveState();

        // 继续下一个查询
        setTimeout(() => {
          const nextQuery = state.list[state.index + 1];
          if (nextQuery) {
            state.index++;
            saveState();
            const searchUrl = 'https://maimai.cn/web/search_center?type=contact&query=' + encodeURIComponent(nextQuery);
            console.log('[脉脉助手] ✅ 跳转到下一个查询:', nextQuery);
            window.location.href = searchUrl;
          } else {
            console.log('[脉脉助手] 所有查询已完成！');
            window.location.href = 'https://maimai.cn';
          }
        }, 1000);

        closed = true;
      }

      // 最终兜底：直接跳转到下一个查询
      setTimeout(() => {
        if (!closed) {
          console.log('[脉脉助手] 所有关闭方法都失败，直接强制跳转到下一个查询...');

          // 清理状态
          state.currentDetailUrl = null;
          saveState();

          // 继续下一个查询
          const nextQuery = state.list[state.index + 1];
          if (nextQuery) {
            state.index++;
            saveState();
            const searchUrl = 'https://maimai.cn/web/search_center?type=contact&query=' + encodeURIComponent(nextQuery);
            console.log('[脉脉助手] ✅ 强制跳转到下一个查询:', nextQuery);
            window.location.href = searchUrl;
          } else {
            console.log('[脉脉助手] 所有查询已完成！');
            window.location.href = 'https://maimai.cn';
          }
        }

        console.log('[脉脉助手] ========== 添加好友流程完全结束 ==========');
      }, 1000);
    }, 1000);
  }

  // 在验证页面查找并点击发送按钮
  function findAndClickSendButton() {
    console.log('[脉脉助手] ========== 在验证页面查找"发送"按钮 ==========');
    console.log('[脉脉助手] 当前页面URL:', window.location.href);
    console.log('[脉脉助手] 页面标题:', document.title);

    let sendButton = null;

    // 策略1: 查找BUTTON标签且文本为"发送"的元素
    console.log('[脉脉助手] 策略1: 查找BUTTON标签...');
    const allElements = Array.from(document.querySelectorAll('*'));
    for (let el of allElements) {
      const text = el.textContent?.trim() || '';

      if (el.tagName === 'BUTTON' && text === '发送') {
        sendButton = el;
        console.log('[脉脉助手] ✅ 找到BUTTON标签的"发送"按钮');
        console.log('[脉脉助手] 按钮class:', el.className);
        console.log('[脉脉助手] 按钮位置:', el.getBoundingClientRect());
        break;
      }
    }

    // 策略2: 如果没找到BUTTON，查找包含"发送"的其他可点击元素
    if (!sendButton) {
      console.log('[脉脉助手] 策略2: 查找其他可点击元素...');

      const buttonSelectors = [
        'button',
        '[role="button"]',
        '.btn',
        '.button',
        'div[class*="button"]',
        'div[class*="btn"]',
        'a[class*="btn"]',
        'span[class*="btn"]'
      ];

      for (const selector of buttonSelectors) {
        const elements = Array.from(document.querySelectorAll(selector));
        console.log(`[脉脉助手] 查找 ${selector}: 找到 ${elements.length} 个元素`);

        for (let btn of elements) {
          const text = btn.textContent?.trim() || '';

          if (text === '发送' || text.includes('发送') || text === 'Send' || text === '提交') {
            sendButton = btn;
            console.log('[脉脉助手] ✅ 找到包含"发送"的元素:',
              'text="' + text + '"',
              '选择器:', selector,
              '标签:', btn.tagName,
              'class:', btn.className.substring(0, 40));
            break;
          }
        }

        if (sendButton) break;
      }
    }

    // 策略3: 如果还没找到，搜索所有可能的提交按钮
    if (!sendButton) {
      console.log('[脉脉助手] 策略3: 搜索所有可能的提交按钮...');

      // 打印页面上所有短文本的可点击元素
      const allClickable = Array.from(document.querySelectorAll('button, [role="button"], .btn, .button, div[class*="btn"], a, span'));
      const candidates = allClickable.filter(el => {
        const text = el.textContent?.trim() || '';
        return text.length > 0 && text.length < 20;
      });

      console.log('[脉脉助手] 页面上所有短文本可点击元素:');
      candidates.forEach((el, idx) => {
        const text = el.textContent?.trim() || '';
        const rect = el.getBoundingClientRect();
        const visible = rect.width > 0 && rect.height > 0;
        console.log(`  ${idx + 1}. "${text}" | ${el.tagName} | ${el.className.substring(0, 30)} | 可见:${visible}`);

        // 尝试匹配更广泛的发送相关文本
        if ((text.includes('送') || text.includes('发') || text.includes('确') || text.includes('提交') ||
          text === '确定' || text === '确认' || text === 'OK' || text === '好的') && visible) {
          if (!sendButton) {
            sendButton = el;
            console.log('[脉脉助手] ✅ 策略3匹配到按钮:', text);
          }
        }
      });
    }

    if (sendButton) {
      console.log('[脉脉助手] 准备点击"发送"按钮...');
      console.log('[脉脉助手] 发送按钮信息:', {
        tagName: sendButton.tagName,
        className: sendButton.className,
        text: sendButton.textContent?.trim(),
        coordinates: sendButton.getBoundingClientRect()
      });

      // 使用增强点击方法
      function triggerSendClick(element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'center' });

        setTimeout(() => {
          const rect = element.getBoundingClientRect();
          const x = rect.left + rect.width / 2;
          const y = rect.top + rect.height / 2;

          // 创建鼠标事件序列
          const events = ['mousedown', 'mouseup', 'click'].map(type =>
            new MouseEvent(type, {
              view: window,
              bubbles: true,
              cancelable: true,
              clientX: x,
              clientY: y,
              button: 0
            })
          );

          // 依次触发事件
          let delay = 0;
          events.forEach((event, index) => {
            setTimeout(() => {
              element.dispatchEvent(event);
              if (index === events.length - 1) {
                console.log('[脉脉助手] ✅ 已使用增强方法点击发送按钮');
                // 备选原生点击
                setTimeout(() => {
                  element.click();
                  console.log('[脉脉助手] ✅ 已使用原生方法点击发送按钮');
                }, 100);
              }
            }, delay);
            delay += 50;
          });
        }, 200);
      }

      triggerSendClick(sendButton);

      console.log('[脉脉助手] 发送按钮已点击，等待跳转到成功页面...');

      // 设置超时监控，检查发送是否成功
      setTimeout(() => {
        const currentUrl = window.location.href;
        const pageText = document.body.textContent || '';

        // 检查是否成功发送
        const isSuccessPage = pageText.includes('发送成功') ||
          pageText.includes('申请已发送') ||
          pageText.includes('好友申请成功') ||
          currentUrl.includes('success');

        // 检查是否又回到了详情页（有加好友按钮）
        const backToDetailPage = pageText.includes('加好友') ||
          pageText.includes('添加好友') ||
          currentUrl.includes('/profile/detail');

        if (isSuccessPage) {
          console.log('[脉脉助手] ✅ 检测到发送成功，调用成功页面处理...');
          handleSuccessPage();
        } else if (backToDetailPage) {
          console.log('[脉脉助手] ❌ 发送后又回到了详情页，说明发送失败');
          console.log('[脉脉助手] 停止尝试添加好友，直接进入下一个查询');

          // 记录失败结果
          const query = state.list[state.index] || '';
          const result = {
            query: query,
            found: 1,
            name: '发送失败',
            company: '加好友发送失败',
            position: '',
            workHistory: [],
            education: [],
            time: new Date().toLocaleString(),
            addFriendStatus: 'send_failed'
          };

          state.results.push(result);
          state.currentDetailUrl = null;
          saveState();

          // 跳转到下一个查询
          const nextQuery = state.list[state.index + 1];
          if (nextQuery) {
            state.index++;
            saveState();
            const searchUrl = 'https://maimai.cn/web/search_center?type=contact&query=' + encodeURIComponent(nextQuery);
            console.log('[脉脉助手] ✅ 跳转到下一个查询:', nextQuery);
            window.location.href = searchUrl;
          } else {
            console.log('[脉脉助手] 所有查询已完成！');
            window.location.href = 'https://maimai.cn';
          }
        } else {
          console.log('[脉脉助手] ⚠️ 5秒内未检测到成功页面，也没有回到详情页');
          console.log('[脉脉助手] 当前URL:', currentUrl);
          console.log('[脉脉助手] 页面文本片段:', pageText.substring(0, 200));
          console.log('[脉脉助手] 可能页面卡住了，强制跳转到下一个查询...');

          // 清理状态并跳转到下一个查询
          state.currentDetailUrl = null;
          saveState();

          const nextQuery = state.list[state.index + 1];
          if (nextQuery) {
            state.index++;
            saveState();
            const searchUrl = 'https://maimai.cn/web/search_center?type=contact&query=' + encodeURIComponent(nextQuery);
            console.log('[脉脉助手] ✅ 跳转到下一个查询:', nextQuery);
            window.location.href = searchUrl;
          } else {
            console.log('[脉脉助手] 所有查询已完成！');
            window.location.href = 'https://maimai.cn';
          }
        }
      }, 5000);

    } else {
      console.log('[脉脉助手] ⚠️ 未找到"发送"按钮');
      console.log('[脉脉助手] 调试：打印所有短文本按钮');

      // 重新定义 debugButtons 进行调试
      const debugButtons = Array.from(document.querySelectorAll('button, [role="button"], .btn, .button, div[class*="button"]'));
      debugButtons.forEach((btn, idx) => {
        const text = btn.textContent?.trim() || '';
        if (text.length > 0 && text.length < 15) {
          const rect = btn.getBoundingClientRect();
          const visible = rect.width > 0 && rect.height > 0;
          console.log(`  按钮 ${idx + 1}: "${text}" | ${btn.tagName} | ${btn.className.substring(0, 30)} | 可见:${visible}`);
        }
      });
    }
  }

})();
