# 脉脉助手 - 问题与解决方案汇总

## 项目概述
Chrome 扩展插件，用于批量搜索脉脉用户并自动提取个人信息（工作经历、教育经历等），支持添加好友功能。

---

## 问题 1: 添加 10 秒查询间隔

### 需求
为了避免触发反爬机制，需要在每次查询完一个人后，等待 10 秒再继续下一个查询。

### 解决方案
在 `state` 对象中添加 `intervalSeconds` 字段，默认值为 10：

```javascript
let state = {
  // ... 其他字段
  intervalSeconds: 10
};
```

在两处地方修改延迟时间：
1. 详情页提取完信息后，继续下一个查询前（约 1160 行）
2. "所有结果"模式下，回到搜索页处理下一个结果前（约 1136 行）

```javascript
const delay = (state.intervalSeconds || 10) * 1000;
setTimeout(() => {
  processNext();
}, delay);
```

### 状态
✅ 已解决 - 用户确认 10 秒间隔正常工作

---

## 问题 2: 添加"同时添加好友"功能

### 需求
提供一个复选框选项"同时添加好友"，勾选后自动点击详情页上的"＋加好友"按钮。

### 遇到的问题

#### 问题 2.1: 找不到"加好友"按钮

**原因分析：**
- 按钮文本使用的是**全角符号"＋"**（不是半角"+"）
- 按钮不是 `<button>` 标签，而是 `<div class="btn btn-xsm btn-secondary btn-block">`
- 初始代码只搜索了半角符号和 button/a 标签

**调试过程：**
运行以下命令找到实际的按钮元素：
```javascript
const all = document.querySelectorAll('*');
for(let i=0; i<all.length; i++) {
  const text = all[i].textContent;
  if(text && text.trim().length < 20 && (text.includes('加') || text.includes('添加'))) {
    console.log(text.trim(), all[i].tagName, all[i]);
  }
}
```

**输出结果：**
```
＋加好友 DIV <div class="btn btn-xsm btn-secondary btn-block" ...>＋加好友</div>
```

**解决方案：**
在 `tryAddFriend()` 函数中：
1. 添加全角符号"＋"的匹配：`text === '＋加好友'`
2. 优先匹配 `text === '＋加好友' && el.tagName === 'DIV' && className.includes('btn')`
3. 搜索所有元素类型（不限于 button/a）

```javascript
// 策略1: 精确查找"加好友"相关文本（支持全角和半角符号）
const candidates = allElements.filter(el => {
  const text = el.textContent?.trim() || '';
  return (text.length < 20 && text.length > 0) &&
         (text.includes('加好友') || text === '＋加好友' || text === '+ 加好友');
});

// 优先选择有 btn class 的 div
for (let el of candidates) {
  const text = el.textContent?.trim() || '';
  const className = el.className || '';
  
  if (text === '＋加好友' && el.tagName === 'DIV' && className.includes('btn')) {
    addFriendButton = el;
    break;
  }
}
```

**状态：** ✅ 已解决 - 能成功找到并点击"＋加好友"按钮

---

#### 问题 2.2: 找不到"发送"按钮

**问题描述：**
点击"＋加好友"后，会跳转到一个验证信息页面，需要点击"发送"按钮来确认添加。但代码找不到这个"发送"按钮。

**原因分析：**
页面上有多个元素的 `textContent` 都包含"发送"文本：
- 父容器 `<div>` 的 textContent 也包含子元素的"发送"文本
- 需要精确匹配 `<button>` 标签

**调试过程：**
运行以下命令找到"发送"按钮：
```javascript
const btns = document.querySelectorAll('*');
for(let btn of btns) {
  if(btn.textContent?.trim() === '发送') {
    console.log('找到发送按钮:', btn, '标签:', btn.tagName, 'class:', btn.className);
  }
}
```

**输出结果：**
```
找到发送按钮: <div class="sc-dEoRIm ePaAOT">...</div> 标签: DIV class: sc-dEoRIm ePaAOT
找到发送按钮: <div style="...">...</div> 标签: DIV class: 
找到发送按钮: <div class="sc-jtggT LWScX">...</div> 标签: DIV class: sc-jtggT LWScX
找到发送按钮: <button type="button" class="mui-mobile-web-button ...">发送</button> 标签: BUTTON class: mui-mobile-web-button ...
```

**解决方案：**
精确匹配 `<button>` 标签且文本为"发送"的元素：

```javascript
// 精确查找 button 标签且文本为"发送"的元素
const allElements = Array.from(document.querySelectorAll('*'));
let sendButton = null;

for (let el of allElements) {
  const text = el.textContent?.trim() || '';
  
  // 必须是 BUTTON 标签，且文本精确为"发送"
  if (el.tagName === 'BUTTON' && text === '发送') {
    sendButton = el;
    break;
  }
}
```

**状态：** ✅ 已解决 - 能准确找到并点击"发送"按钮

---

#### 问题 2.3: 关闭验证信息弹窗

**问题描述：**
点击"发送"按钮后，需要关闭验证信息页面，返回详情页继续下一个查询。

**解决方案：**
点击"发送"后，延迟 1 秒执行关闭操作：

```javascript
setTimeout(() => {
  console.log('[脉脉助手] 尝试关闭弹窗...');
  
  // 方法1: 查找关闭按钮
  const closeButtons = Array.from(document.querySelectorAll('button, a, div, span, [class*="close"]'));
  for (let btn of closeButtons) {
    const text = btn.textContent?.trim() || '';
    const className = btn.className || '';
    
    if (text === '×' || text === 'X' || text === '关闭' || 
        className.includes('close') || className.includes('modal-close')) {
      btn.click();
      break;
    }
  }
  
  // 方法2: 如果找不到关闭按钮，发送 ESC 键事件
  setTimeout(() => {
    const escEvent = new KeyboardEvent('keydown', {
      key: 'Escape',
      code: 'Escape',
      keyCode: 27,
      which: 27,
      bubbles: true
    });
    document.dispatchEvent(escEvent);
  }, 500);
}, 1000);
```

**状态：** 🔄 待用户测试验证

---

## 问题 3: JavaScript 控制台语法错误

### 问题描述
用户在控制台粘贴调试代码时，多次遇到 `SyntaxError: Invalid or unexpected token` 错误。

### 原因
1. **中文引号问题**：中文引号（''）vs 英文引号（''）
2. **多行代码换行**：直接粘贴多行代码导致解析错误
3. **模板字符串**：反引号（\`）在控制台中可能有问题

### 解决方案
提供单行版本的调试代码：

```javascript
// 不推荐（多行，可能出错）
const all = document.querySelectorAll('*'); 
for(let i=0; i<all.length; i++) {
  const text = all[i].textContent;
  if(text && text.includes('加')) console.log(text);
}

// 推荐（单行，更可靠）
const all = document.querySelectorAll('*'); for(let i=0; i<all.length; i++) { const text = all[i].textContent; if(text && text.trim().length < 20 && text.includes('加')) { console.log(text.trim(), all[i].tagName, all[i].className); } }
```

**状态：** ✅ 已解决

---

## 调试技巧总结

### 1. 查找包含特定文本的元素
```javascript
const all = document.querySelectorAll('*');
for(let i=0; i<all.length; i++) {
  const text = all[i].textContent?.trim();
  if(text && text.length < 20 && text.includes('关键词')) {
    console.log(text, '|', all[i].tagName, '|', all[i].className);
  }
}
```

### 2. 精确查找特定文本的元素
```javascript
const btns = document.querySelectorAll('*');
for(let btn of btns) {
  if(btn.textContent?.trim() === '精确文本') {
    console.log('找到:', btn, '标签:', btn.tagName, 'class:', btn.className);
  }
}
```

### 3. 查找所有短文本可点击元素
```javascript
const clickables = document.querySelectorAll('button, a, [onclick], div[role="button"]');
clickables.forEach(el => {
  const text = el.textContent?.trim();
  if(text && text.length < 20) {
    console.log(text, '|', el.tagName, '|', el.className.substring(0, 50));
  }
});
```

---

## 当前状态

### ✅ 已完成
1. 10 秒查询间隔功能
2. UI 复选框"同时添加好友"
3. 智能按钮检测和优先级排序系统
4. 增强的鼠标事件点击方法
5. 找到并点击"＋加好友"按钮（大幅改进）
6. 找到并点击"发送"按钮
7. JavaScript错误修复（allButtons未定义）

### 🔄 待测试
1. 关闭验证信息弹窗功能
2. 完整的添加好友流程在不同用户场景下的稳定性
3. 批量操作时的性能表现

### ❓ 待确认
- 验证信息页面的 URL 格式（需要确认是否是新页面还是弹窗）
- 是否需要在验证信息页面填写验证消息（目前假设默认消息已存在）
- 不同类型按钮（关注、加好友、已关注等）的处理策略

---

## 代码文件

### 主要文件
- `content.js` - 内容脚本，包含所有主要逻辑
- `manifest.json` - Chrome 扩展配置
- `README.md` - 使用说明
- `TEST_GUIDE.md` - 测试指南

### 关键函数
- `tryAddFriend()` - 添加好友功能（728行起，含智能检测和增强点击）
- `extractDetailInfo()` - 提取详情页信息（375行起）
- `processNext()` - 处理下一个查询（212-230行）
- `exportResults()` - 导出结果到CSV（242行起）
- `getButtonPriority()` - 按钮优先级评分（795-825行）
- `triggerRealClick()` - 增强点击方法（854-908行）

---

## 注意事项

1. **全角 vs 半角符号**：脉脉页面使用全角符号"＋"，需要同时匹配全角和半角
2. **元素类型不确定**：按钮可能是 `<button>`、`<div>`、`<a>` 等，需要遍历所有元素
3. **父容器文本问题**：父容器的 `textContent` 包含所有子元素文本，需要精确匹配标签类型
4. **时间延迟**：页面加载、弹窗出现都需要合适的延迟时间（1-2 秒）
5. **反爬策略**：10 秒间隔是必要的，避免过快导致账号被限制

---

#### 问题 2.4: 点击按钮无效（找到但不响应）

**问题描述：**
控制台显示已找到"＋加好友"按钮并执行了点击操作，但实际页面上按钮没有被真正点击，添加好友功能不生效。

**现象：**
```
[脉脉助手] ✅ 找到"＋加好友"按钮
[脉脉助手] ✅ 已点击添加好友按钮
```
但页面上的"＋加好友"按钮状态未改变，没有弹出验证信息页面。

**原因分析：**
1. **简单click()方法不足**：现代Web应用（特别是React/Vue等SPA）可能需要更完整的事件序列
2. **元素遮挡问题**：真正的可点击区域可能被其他透明元素覆盖
3. **事件冒泡问题**：点击事件可能没有正确冒泡到事件监听器
4. **坐标问题**：某些按钮需要在特定坐标位置点击才有效

**解决方案：**

1. **增强点击方法**：实现完整的鼠标事件序列
```javascript
function triggerRealClick(element) {
  // 确保元素可见
  element.scrollIntoView({ behavior: 'smooth', block: 'center' });
  
  setTimeout(() => {
    const rect = element.getBoundingClientRect();
    const x = rect.left + rect.width / 2;
    const y = rect.top + rect.height / 2;
    
    // 创建完整的鼠标事件序列：mousedown → mouseup → click
    const mouseDownEvent = new MouseEvent('mousedown', {
      view: window, bubbles: true, cancelable: true,
      clientX: x, clientY: y, button: 0
    });
    
    const mouseUpEvent = new MouseEvent('mouseup', {
      view: window, bubbles: true, cancelable: true,
      clientX: x, clientY: y, button: 0
    });
    
    const clickEvent = new MouseEvent('click', {
      view: window, bubbles: true, cancelable: true,
      clientX: x, clientY: y, button: 0
    });
    
    // 依次触发事件
    element.dispatchEvent(mouseDownEvent);
    setTimeout(() => {
      element.dispatchEvent(mouseUpEvent);
      setTimeout(() => {
        element.dispatchEvent(clickEvent);
        // 备选：同时尝试原生点击
        setTimeout(() => element.click(), 100);
      }, 50);
    }, 50);
  }, 200);
}
```

2. **智能按钮检测和优先级排序**：
```javascript
function getButtonPriority(el) {
  const text = el.textContent?.trim() || '';
  const className = el.className || '';
  const style = window.getComputedStyle(el);
  const tagName = el.tagName;
  
  let priority = 0;
  
  // 文本匹配优先级
  if (text === '＋加好友') priority += 100;
  else if (text === '+加好友') priority += 90;
  else if (text.includes('加好友')) priority += 80;
  
  // 标签类型优先级
  if (tagName === 'BUTTON') priority += 50;
  else if (tagName === 'A') priority += 30;
  else if (el.getAttribute('role') === 'button') priority += 40;
  
  // 样式和交互性优先级
  if (style.cursor === 'pointer') priority += 30;
  if (el.onclick !== null) priority += 20;
  if (className.includes('btn')) priority += 20;
  
  // 可见性检查
  const rect = el.getBoundingClientRect();
  if (rect.width > 0 && rect.height > 0) priority += 10;
  
  return priority;
}

// 按优先级排序并选择最佳按钮
const sortedCandidates = candidates.sort((a, b) => 
  getButtonPriority(b) - getButtonPriority(a)
);
```

3. **精确选择器策略**：
```javascript
const buttonSelectors = [
  'button',
  '[role="button"]',
  '.btn',
  '.button',
  'div[class*="btn"]',
  'div[class*="button"]',
  'a[class*="btn"]',
  'a[class*="button"]'
];
```

4. **详细调试信息**：
```javascript
console.log('[脉脉助手] 按钮信息:', {
  tagName: addFriendButton.tagName,
  className: addFriendButton.className,
  id: addFriendButton.id,
  coordinates: addFriendButton.getBoundingClientRect()
});

console.log('[脉脉助手] 候选按钮优先级排序:');
sortedCandidates.forEach((el, idx) => {
  const text = el.textContent?.trim() || '';
  const priority = getButtonPriority(el);
  const rect = el.getBoundingClientRect();
  console.log(`  ${idx + 1}. "${text}" | ${el.tagName} | 优先级:${priority} | 尺寸:${Math.round(rect.width)}x${Math.round(rect.height)}`);
});
```

**测试步骤：**
1. 重新加载Chrome扩展
2. 在脉脉个人详情页勾选"同时添加好友"
3. 执行搜索，观察控制台输出的详细调试信息
4. 验证按钮是否真正被点击（页面状态变化）

**状态：** ✅ 已解决 - 增强点击方法和智能检测大幅提升了点击成功率

---

## 问题 2.5: 页面循环跳转问题

### 问题描述
点击"发送"按钮后，页面会返回到上一页，上一页又出现"加好友"按钮，导致无限循环：
1. 详情页 → 点击"加好友" → 验证页面 
2. 验证页面 → 点击"发送" → **返回详情页** ❌
3. 详情页 → 再次点击"加好友" → 验证页面... **无限循环**

### 根本原因分析
通过代码审查发现多个导致循环的问题：

#### 1. **验证页面检测过于宽泛**
```javascript
// 问题代码：
const isVerificationPage = pageText.includes('发送') || pageText.includes('验证')...
```
- `pageText.includes('发送')` 会误判详情页为验证页面
- 详情页中也可能包含"发送"等文字

#### 2. **重复的检测逻辑冲突**
- 详情页分支中有验证页面检测 (1225-1242行)
- "其他页面"分支中也有 `checkIfVerificationPageAndHandleSend()` (1445行)
- 两套逻辑相互冲突，导致重复处理

#### 3. **URL条件错误**
```javascript
// 问题代码：
const urlHasFeature = currentUrl.includes('contact')...
```
- 所有详情页URL都包含 `/contact/`
- 导致详情页被误判为验证页面

#### 4. **状态标记重置错误**
```javascript
// 问题代码：每次进入详情页都重置
state.addFriendAttempted = false;
```
- 如果发送失败返回详情页，标记被重置
- 导致再次尝试添加好友，形成循环

#### 5. **页面关闭使用 history.back()**
```javascript
// 问题代码：
window.history.back(); // 返回上一页，形成循环
```

### 彻底解决方案

#### 1. **精确的验证页面检测** (`content.js:1228-1250`)
```javascript
// 必须同时满足多个条件
const hasVerificationInput = document.querySelector('input[placeholder*="验证"]') ||
                            document.querySelector('textarea[placeholder*="申请理由"]');
                            
const hasVerificationText = pageText.includes('验证信息') ||
                           pageText.includes('申请理由') ||
                           pageText.includes('好友申请');
                           
const hasVerificationUrl = currentUrl.includes('verification') ||
                          currentUrl.includes('add_friend') ||
                          currentUrl.includes('friend_tag');

// 严格条件：必须有输入框+文本 或 明确的验证URL
const isVerificationPage = (hasVerificationInput && hasVerificationText) || hasVerificationUrl;
```

#### 2. **移除错误的URL条件** (`content.js:1496-1500`)
```javascript
// 修复前：
const urlHasFeature = currentUrl.includes('contact'); // ❌ 误判详情页

// 修复后：
const urlHasFeature = currentUrl.includes('add_friend') || 
                     currentUrl.includes('verification') ||
                     currentUrl.includes('verify') ||
                     currentUrl.includes('friend_tag'); // ✅ 只检测明确的验证URL
```

#### 3. **按用户记录尝试状态** (`content.js:1340-1365`)
```javascript
// 按具体用户URL记录，避免重复尝试
const currentDstu = new URLSearchParams(window.location.search).get('dstu');
const attemptedKey = `attempted_${currentDstu}`;

if (!state.addFriendAttemptedUsers) {
  state.addFriendAttemptedUsers = {};
}

const alreadyAttempted = state.addFriendAttemptedUsers[attemptedKey];

// 只有没尝试过的用户才添加好友
if (state.addFriend && !alreadyAttempted) {
  state.addFriendAttemptedUsers[attemptedKey] = true;
  tryAddFriend();
}
```

#### 4. **发送失败检测与断路** (`content.js:1750-1792`)
```javascript
setTimeout(() => {
  const backToDetailPage = pageText.includes('加好友') || 
                           pageText.includes('添加好友') ||
                           currentUrl.includes('/profile/detail');
                           
  if (backToDetailPage) {
    console.log('[脉脉助手] ❌ 发送后又回到了详情页，说明发送失败');
    console.log('[脉脉助手] 停止尝试添加好友，直接进入下一个查询');
    
    // 记录失败并强制跳转下一个查询，断开循环
    window.location.href = searchUrl; // 直接跳转，不使用 history.back()
  }
}, 5000);
```

#### 5. **移除导致循环的 history.back()** (`content.js:1548-1567`)
```javascript
// 修复前：
window.history.back(); // ❌ 返回上一页，形成循环

// 修复后：
window.location.href = searchUrl; // ✅ 直接跳转下一个查询
```

### 新的正确流程
1. 详情页 → 点击"加好友" → 标记用户已尝试 → 验证页面
2. 验证页面 → 点击"发送" → **监控5秒**：
   - ✅ 成功页面 → 正常关闭，跳转下一个查询
   - ❌ 回到详情页 → **检测到循环** → 记录失败，强制跳转下一个查询  
   - ⚠️ 其他情况 → 超时，强制跳转下一个查询
3. 如果再次进入同一详情页 → 检测到 `alreadyAttempted = true` → 跳过加好友，直接提取数据

### 关键改进点
- **消除误判**: 多重条件确保只有真正的验证页面才被处理
- **防止重复**: 同一用户只尝试一次加好友，即使返回详情页  
- **循环断路**: 检测到返回详情页立即停止循环
- **超时保护**: 5秒未成功自动跳转下一个查询
- **强制跳转**: 使用直接跳转替代可能导致循环的 history.back()

### 修改文件
- `content.js`: 1228-1250, 1340-1365, 1496-1500, 1544-1567, 1750-1792 行

**状态：** ✅ 已解决 - 彻底消除页面循环跳转，用户确认问题已修复

---

## 未来优化建议

1. **可配置间隔时间**：允许用户在 UI 中设置查询间隔（目前固定 10 秒）
2. **验证消息模板**：允许用户自定义添加好友时的验证消息
3. **错误重试机制**：如果添加好友失败，可以记录并在最后重试
4. **进度持久化**：即使浏览器关闭，也能从上次中断的地方继续
5. **批量导入优化**：支持更大批量（当前建议 < 50 条）
