# 测试指南

## 重新加载插件

1. 打开 `chrome://extensions/`
2. 找到 "Maimai Search Helper"
3. 点击刷新图标 🔄

## 测试步骤

### 1. 清空旧数据
- 访问 https://maimai.cn
- 左下角绿色面板 → 点击 **"清空数据"**

### 2. 单条测试
- 在文本框输入一个测试关键词（如：廖娅伶）
- 点击 **"开始"**
- 观察控制台输出

### 3. 观察日志

打开浏览器控制台（F12），你应该看到：

**在搜索结果页：**
```
[脉脉助手] 在搜索页，等待结果...
[脉脉助手] 页面有结果，查找详情链接...
[脉脉助手] 找到 profile 链接数量: X
[脉脉助手] 找到详情页链接: https://maimai.cn/profile/detail?dstu=...
```

**在详情页：**
```
[脉脉助手] 在详情页，提取信息...
[脉脉助手] 开始提取信息...
[脉脉助手] 找到姓名: XXX
[脉脉助手] 找到工作经历标题数量: X
[脉脉助手] 找到工作经历: XXXX...
[脉脉助手] 找到教育经历标题数量: X
[脉脉助手] 找到教育经历: XXXX...
[脉脉助手] 提取完成: {name: "XXX", company: "XXX", workCount: X, eduCount: X}
[脉脉助手] 详情结果 {query: "...", found: 1, name: "...", ...}
```

### 4. 导出结果
- 搜索完成后，点击 **"复制结果"**
- 粘贴到 Excel 查看结果

## 预期结果格式

```
关键词    结果      姓名    公司    职位    工作经历              教育经历
廖娅伶    找到     XXX    XXX公司  XXX   公司1; 公司2; ...    大学1; 大学2; ...
```

## 如果提取失败

在详情页控制台运行：
```javascript
// 检查标题是否能找到
console.log('工作经历标题:', Array.from(document.querySelectorAll('*')).filter(el => el.textContent?.includes('工作经历')).length);
console.log('教育经历标题:', Array.from(document.querySelectorAll('*')).filter(el => el.textContent?.includes('教育经历')).length);

// 手动测试提取逻辑
const workHeaders = Array.from(document.querySelectorAll('*')).filter(el => el.textContent?.trim() === '工作经历');
console.log('找到的工作经历元素:', workHeaders);
if (workHeaders.length > 0) {
  const section = workHeaders[0].closest('div');
  console.log('工作经历区域:', section);
}
```

把结果截图发给我，我会帮你优化选择器。
