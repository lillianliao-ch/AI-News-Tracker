# 批量导入人才库功能设计文档

## 1. 需求背景

### 1.1 现有功能
- **job-scraper**: 阿里猎头平台职位和简历抓取，导出为 CSV 文件
- **maimai-assistant**: 脉脉招聘平台人才抓取，支持单个导入和批量导入到人才库 API

### 1.2 用户需求
在阿里猎头平台的简历列表页，实现类似 maimai-assistant 的批量导入功能：
- 点击一个按钮，自动遍历当前页所有简历
- 逐个点击进入详情页，提取数据
- 调用 API 导入到人才库系统（而不是导出 CSV）
- 自动返回列表页继续下一个

### 1.3 技术挑战
1. **页面结构复杂**: 阿里猎头平台的简历列表页结构可能比较复杂
2. **交互繁琐**: 需要自动化点击、等待、提取、返回的完整流程
3. **容错处理**: 需要处理各种异常情况（链接失效、页面加载失败等）
4. **API 兼容**: 需要将阿里平台的简历数据格式转换为 API 接受的格式

## 2. 设计方案

### 2.1 整体架构

```
用户点击按钮 (popup.html)
    ↓
发送消息 (popup.js)
    ↓
接收消息 (content.js)
    ↓
批量导入主流程 (batchImportTalentsToAPI)
    ↓
    ├─ 提取简历链接 (extractResumeLinksFromList)
    ├─ 遍历每个简历
    │   ├─ 点击链接 (clickResumeLink)
    │   ├─ 提取数据 (extractResumeDetail) [复用现有]
    │   ├─ 同步 API (syncCandidateToAPI)
    │   └─ 返回列表 (goBackToList)
    └─ 显示结果统计
```

### 2.2 核心设计思路

#### 2.2.1 复用现有功能
- **简历提取**: 复用 `extractResumeDetail()` 函数，已经实现了完整的简历数据提取逻辑
- **页面检测**: 复用 `detectPageType()` 函数，判断当前是列表页还是详情页
- **工具函数**: 复用 `sleep()` 等辅助函数

#### 2.2.2 参考 maimai-assistant 的实现
- **API 接口**: 使用相同的 `/api/candidate/maimai-sync` 接口
- **数据格式**: 参考 maimai-assistant 的数据结构
- **批量逻辑**: 参考 `batchImportTalents()` 的遍历和导入流程

#### 2.2.3 自动化交互流程
```
列表页 → 点击简历 → 详情页 → 提取数据 → 调用 API → 返回列表页 → 下一个
```

关键点：
- 使用 `window.history.back()` 返回列表页
- 每步之间添加适当的 `sleep()` 等待页面加载
- 记录成功/失败/跳过的数量

## 3. 实现细节

### 3.1 前端界面 (popup.html)

```html
<!-- 批量导入人才库按钮 -->
<button id="batchImportTalents" style="margin-top: 10px; background-color: #28a745;">
  📥 批量导入人才库
</button>
```

**设计考虑**：
- 使用绿色背景区分于其他按钮（抓取按钮是橙色）
- 添加 📥 图标增强视觉识别
- 独立按钮，不依赖"抓取目标"下拉框

### 3.2 交互逻辑 (popup.js)

```javascript
// 批量导入人才库按钮
const batchImportBtn = document.getElementById('batchImportTalents');
batchImportBtn.addEventListener('click', function () {
  statusDiv.textContent = '准备批量导入人才库...';

  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    const currentTabId = tabs[0].id;
    const currentUrl = tabs[0].url;

    // 检查是否在简历列表页
    if (!currentUrl.includes('headhunter') && !currentUrl.includes('resume')) {
      statusDiv.textContent = '❌ 请在简历列表页使用此功能';
      return;
    }

    // 发送批量导入消息
    chrome.tabs.sendMessage(currentTabId, {
      action: 'BATCH_IMPORT_TALENTS'
    }, function (response) {
      if (chrome.runtime.lastError) {
        console.error('❌ 消息发送失败:', chrome.runtime.lastError.message);
        statusDiv.textContent = `❌ 发送消息失败: ${chrome.runtime.lastError.message}`;
      } else {
        console.log('✅ 批量导入启动成功:', response);
        statusDiv.textContent = `✅ 正在批量导入人才库...`;
      }
    });
  });
});
```

**设计考虑**：
- URL 检查：确保在正确的页面使用此功能
- 错误处理：捕获消息发送失败的情况
- 用户反馈：实时更新状态显示

### 3.3 消息监听 (content.js)

```javascript
} else if (message.action === "BATCH_IMPORT_TALENTS") {
  // 批量导入人才库
  console.log("📥 开始批量导入人才库...");
  batchImportTalentsToAPI();
  sendResponse({ status: "started" });
  return true;
}
```

**设计考虑**：
- 异步执行：不阻塞消息响应
- 立即返回：告知 popup 已启动
- 独立函数：将主逻辑封装在 `batchImportTalentsToAPI()`

### 3.4 核心函数实现

#### 3.4.1 主流程函数

```javascript
async function batchImportTalentsToAPI() {
  console.log("📥 开始批量导入人才库...");

  try {
    // 1. 提取当前页所有简历链接
    const resumeLinks = await extractResumeLinksFromList();

    if (!resumeLinks || resumeLinks.length === 0) {
      console.warn("⚠️ 未找到简历链接");
      alert("未找到简历链接，请确认在简历列表页");
      return;
    }

    console.log(`📋 找到 ${resumeLinks.length} 个简历，开始逐个导入...`);

    let successCount = 0;
    let failCount = 0;
    let skipCount = 0;

    // 2. 遍历每个简历
    for (let i = 0; i < resumeLinks.length; i++) {
      const link = resumeLinks[i];
      console.log(`\n📄 [${i + 1}/${resumeLinks.length}] 处理简历: ${link.text || link.url}`);

      try {
        // 3. 点击进入详情页
        await clickResumeLink(link);
        await sleep(3000); // 等待详情页加载

        // 4. 提取简历数据
        const resumeData = await extractResumeDetail();

        if (!resumeData || !resumeData.name) {
          console.warn(`⚠️ 简历数据提取失败，跳过`);
          skipCount++;
          await goBackToList();
          continue;
        }

        // 5. 调用 API 导入
        const result = await syncCandidateToAPI(resumeData);

        if (result.success) {
          successCount++;
          console.log(`✅ [${i + 1}/${resumeLinks.length}] 导入成功: ${resumeData.name} (${result.action})`);
        } else {
          failCount++;
          console.error(`❌ [${i + 1}/${resumeLinks.length}] 导入失败: ${result.message}`);
        }

        // 6. 返回列表页
        await goBackToList();
        await sleep(1000); // 等待列表页加载

      } catch (error) {
        console.error(`❌ 处理简历时出错:`, error);
        failCount++;
        aToList();
      }
    }

    // 7. 显示结果
    const summary = `批量导入完成！\n成功: ${successCount}\n失败: ${failCount}\n跳过: ${skipCount}\n总计: ${resumeLinks.length}`;
    console.log(`\n📊 ${summary}`);
    alert(summary);

  } catch (error) {
    console.error("❌ 批量导入出错:", error);
    alert(`批量导入出错: ${error.message}`);
  }
}
```

**设计考虑**：
- **统计信息**: 记录成功、失败、跳过的数量
- **进度显示**: 在控制台显示 `[当前/总数]` 进度
- **错误处理**: 每个简历的处理都包裹在 try-catch 中，单个失败不影响整体
- **用户反馈**: 完成后弹出统计结果

#### 3.4.2 提取简历链接

```javascript
async function extractResumeLinksFromList() {
  console.log("🔍 提取简历列表链接...");

  const links = [/ 策略1: 查找表格中的简历链接
  const tableLinks = document.querySelectorAll('table a[href*="resume"], table a[href*="FORM-"], table a[href*="candidate"]');
  for (const link of tableLinks) {
    const href = link.href;
    const text = link.innerText?.trim() || '';

    // 过滤掉非简历链接
    if (href && !href.includes('javascript') && text.length > 1) {
      links.push({ url: href, text: text, element: link });
    }
  }

  // 策略2: 如果策略1没找到，尝试查找所有可能的简历链接
  if (links.length === 0) {
    const allLinks = document.querySelectorAll('a[href]');
    for (const link of allLinks) {
      const href = link.href;
      const text = link.innerText?.trim() || '';

      // 判断是否是简历链接
      if (href && (href.includes('resume') || href.includes('FORM-') || href.includes('candidate'))
          && !href.includes('javascript') && text.length > 1) {
        links.push({ url: href, text: text, element: link });
      }
    }
  }

  // 去重
  const uniqueLinks = [];
  const seenUrls = new Set();
  for (const link of links) {
    if (!seenUrls.has(link.url)) {
      uniqueLinks.push(link);
      seenUrls.add(link.url);
    }
  }

  console.log(`📋 找到 ${uniqueLinks.length} 个简历链接`);
  return uniqueLinks;
}
```

**设计考虑**：
- **多策略**: 先尝试表格内查找（更精确），失败后全局查找
- **URL 特征**: 通过 URL 包含 `resume`、`FORM-`、`candidate` 等关键词判断
- **去重**: 使用 Set 去除重复链接
- **保存元素**: 保存 DOM 元素引用，方便后续点击

#### 3.4.3 点击简历链接

```javascript
async function clickResumeLink(link) {
  console.log(`🖱️ 点击简历链接: ${link.text}`);

  if (link.element && document.contains(link.element)) {
    // 如果元素还在 DOM 中，直接点击
    link.element.click();
  } else {
    // 否则通过 URL 导航
    window.location.href = link.url;
  }
}
```

**设计考虑**：
- **DOM 检查**: 检查元素是否还在 DOM 中（可能被重新渲染）
- **降级方案**: 如果元素失效，使用 URL 导航

#### 3.4.4 返回列表页

```javascript
async function goBackToList() {
  console.log("🔙 返回列表页...");
  window.history.back();
  await sleep(2000);待页面加载
}
```

**设计考虑**：
- **浏览器历史**: 使用 `history.back()` 返回上一页
- **等待加载**: 返回后等待 2 秒确保页面加载完成

#### 3.4.5 同步到 API

```javascript
async function syncCandidateToAPI(resumeData) {
  console.log("📡 同步数据到 API:", resumeData.name);

  try {
    // 构建 API 请求数据（参考 maimai-assistant 的格式）
    const payload = {
      name: resumeData.name || '',
      phone: resumeData.phone || '',
      email: resumeData.email || '',
      location: resumeData.location || '',
      currentTitle: resumeData.currentTitle || '',
      experienceYears: resumeData.yearsExp || '',
      education: resumeData.education || '',
      expectedTitle: resumeData.expectedTitle || '',
      expectedSalary: resumeData.expectedSalary || '',
      workExperiences: resumeData.experience || '',
      projects: resumeData.projects || '',
      skills: resumeData.skills || '',
      summary: resumeData.summary || '',
      source: 'alibaba_headhunter',
      sourceUrl: resumeData.url || window.location.href,
      extractedAt: resumeData.extractedAt || new Date().toISOString()
    };

    // 调用 API
    const response = await fetch('http://localhost:8502/api/candidate/maimai-sync', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      throw new Error(`API 请求失败: ${response.status} ${response.statusText}`);
    }

    const result = await response.json();
    console.log("✅ API 响应:", result);

    return {
      success: result.success || false,
      action: result.action || 'unknown',
      candidateId: result.candidateId || null,
      message: result.message || ''
    };

  } catch (error) {
    console.error("❌ API 同步失败:", error);
    return {
      success: false,
      message: error.message
    };
  }
}
```

**设计考虑**：
- **字段映射**: 将阿里平台的字段名映射到 API 接受的字段名
  - `yearsExp` → `experienceYears`
  - `experience` → `workExperiences`
- **来源标识**: 设置 `source: 'alibaba_headhunter'` 区分数据来源
- **容错处理**: 所有字段都使用 `|| ''` 提供默认值
- **错误捕获**: 捕获网络错误和 API 错误

## 4. 数据流转

### 4.1 数据提取流程

```
阿里猎头平台简历详情页
    ↓
extractResumeDetail() [现有函数]
    ↓
{
  name: '张三',
  phone: '13800138000',
  email: 'zhangsan@example.com',
  location: '北京',
  currentTitle: '高级工程师',
  yearsExp: '5年',
  expectedTitle: '技术专家',
  expectedSalary: '30-40K',
  education: '本科 | 清华大学 | 计算机科学',
  experience: '2018-2023 阿里巴巴 高级工程师...',
  skills: 'Python, Java, AI, LLM',
  projects: '项目A: ...',
  summary: '5年互联网经验...',
  url: 'https://...',
  extractedAt: '2024-01-01T00:00:00.000Z'
}
```

### 4.2 数据转换流程

```
阿里平台数据格式
    ↓
syncCandidateToAPI() 字段映射
    ↓
API 接受的格式
{
  name: '张三',
  phone: '13800138000',
  email: 'zhangsan@example.com',
  location: '北京',
  currentTitle: '高级工程师',
  experienceYears: '5年',           // yearsExp → experienceYears
  education: '本科 | 清华大学 | 计算机科学',
  expectedTitle: '技术专家',
  expectedSalary: '30-40K',
  workExperiences: '2018-2023...',  // experience → workExperiences
  projects: '项目A: ...',
  skills: 'Python, LLM',
  summary: '5年互联网经验...',
  source: 'alibaba_headhunter',     // 新增：数据来源
  sourceUrl: 'https://...',         // url → sourceUrl
  extractedAt: '2024-01-01T00:00:00.000Z'
}
    ↓
POST /api/candidate/maimai-sync
    ↓
API 响应
{
  success: true,
  action: 'created' | 'updated' | 'unchanged',
  candidateId: 123,
  message: '...'
}
```

## 5. 错误处理

### 5.1 错误类型

| 错误类型 | 处理方式 | 用户反馈 |
|---------|---------|---------|
| 未找到简历链接 | 提前返回 | Alert 提示 |
| 简历数据提取失败 | 跳过该简历，继续下一个 | 计入 skipCount |
| API 调用失败 | 记录失败，继续下一个 | 计入 failCount |
| 网络错误 | 捕获异常，继续下一个 | 计入 failCount |
| 页面加载超时 | 等待固定时间后继续 | 可能导致数据不完整 |

### 5.2 容错机制

```javascript
// 每个简历的处理都包裹在 try-catch 中
try {
  await clickResumeLink(link);
  await sleep(3000);

  const resumeData = await extractResumeDetail();

  if (!resumeData || !resumeData.name) {
    skipCount++;
    await goBackToList();
    continue;  // 跳过，不影响后续
  }

  const result = await syncCandidateToAPI(resumeData);

  if (result.success) {
    successCount++;
  } else {
    failCount++;
  }

  await goBackToList();

} catch (error) {
  console.error(`❌ 处理简历时出错:`, error);
  failCount++;
  await goBackToList();  // 确列表页
}
```

## 6. 性能优化

### 6.1 等待时间设置

| 操作 | 等待时间 | 原因 |
|-----|---------|------|
| 点击链接后 | 3000ms | 详情页加载需要时间 |
| 返回列表页后 | 2000ms | 列表页重新渲染 |
| 每个简历之间 | 1000ms | 避免请求过快 |

### 6.2 优化建议

1. **并发处理**: 当前是串行处理，可以考虑并发处理多个简历（需要打开多个标签页）
2. **智能等待**: 使用 `MutationObserver` 监听 DOM 变化，而不是固定等待时间
3. **断点续传**: 记录已处理的简历，支持中断后继续
4. **批量 API**: 如果 API 支持批量导入，可以一次性提交多个简历

## 7. 使用说明

### 7.1 前置条件

1. 确保后端 API 服务运行在 `http://localhost:8502`
2. 确保 API 接口 `/api/candidate/maimai-sync` 可用
3. Chrome 扩展已加载并启用

### 7.2 使用步骤

1. 打开阿里猎头平台的简历列表页
2. 点击 Chrome 扩展图标
3. 点击"📥 批量导入人才库"按钮
4. 等待自动导入完成（不要关闭或切换标签页）
5. 查看弹出的结果统计

### 7.3 注意事项

- ⚠️ 导入过程中不要手动操作浏览器
- ⚠️ 确保网络连接稳定
- ⚠️ 如果中途失败，可以重新点击按钮继续（已导入的会被标记为 'unchanged'）
- ⚠️ 建议先在小范围测试（1-2 页）

## 8. 测试建议

### 8.1 单元测试

- [ ] `extractResumeLinksFromList()` - 测试不同页面结构的链接提取
- [ ] `clickResumeLink()` - 测试元素失效时的降级方案
- [ ] `syncCandidateToAPI()` - 测试 API 调用和错误处理
- [ ] `goBackToList()` - 测试返回列表页的可靠性

### 8.2 集成测试

- [ ] 完整流程测试：列表页 → 详情页 → API → 返回
- [ ] 异常情况测试：网络断开、API 错误、页面加载失败
- [ ] 边界测试：空列表、单个简历、大量简历

### 8.3 用户测试

- [ ] 不同浏览器兼容性（Chrome, Edge）
- [ ] 不同页面结构（待分配、已分配、我的订单）
- [ ] 不同网络环境（快速、慢速、不稳定）

## 9. 未来改进

### 9.1 功能增强

1. **选择性导入**: 支持勾选要导入的简历，而不是全部导入
2. **翻页支持**: 自动翻页并导入多页简历
3. **去重检测**: 导入前检查是否已存在，避免重复
4. **数据预览**: 导入前预览提取的数据，确认无误后再提交

### 9.2 用户体验

1. **进度条**: 在 popup 中显示实时进度条
2. **暂停/继续**: 支持暂停和继续导入
3. **导入历史**: 记录每次导入的结果，支持查看历史
4. **错误详情**: 显示失败简历的详细错误信息

### 9.3 性能优化

1. **并发导入**: 同时处理多个简历（需要多标签页支持）
2. **智能等待**: 使用 DOM 监听代替固定等待时间
3. **缓存机制**: 缓存已提取的数据，避免重复提取
4. **增量导入**: 只导入新增或更新的简历

## 10. 参考资料

### 10.1 相关文件

- `popup.html` - 前端界面
- `popup.js` - 交互逻辑
- `content.js` - 核心功能实现
- `RESUME_IMPLEMENTATION_SUMMARY.md` - 简历抓取功能总结
- `maimai-assistant/extension/content/talent-extractor.js` - 脉脉助手参考实现

### 10.2 API 文档

- **接口**: `POST /api/candidate/maimai-sync`
- **请求格式**: JSON
- **响应格式**: `{ success, action, candidateId, message }`
- **action 类型**: `created` | `updated` | `unchanged`

### 10.3 技术栈

- Chrome Extension Manifest V2
- Vanilla JavaScript (ES6+)
- Fetch API
- Chrome Extension APIs (tabs, runtime, storage)

## 11. 版本历史

| 版本 | 日期 | 更新内容 |
|-----|------|---------|
| v1.0 | 2024-02-27 | 初始版本，实现基础批量导入功能 |

## 12. 贡献者

- Claude Opus 4.6 - 设计与实现
- Lillian Liao - 需求提出与测试

---

**文档维护**: 请在功能更新时同步更新本文档
**最后更新**: 2024-02-27
