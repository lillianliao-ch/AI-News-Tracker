document.addEventListener('DOMContentLoaded', function () {
  const startBtn = document.getElementById('startScrape');
  const targetTabSelect = document.getElementById('targetTab');
  const pageCountInput = document.getElementById('pageCount');
  const exportModeSelect = document.getElementById('exportMode');
  const apiBaseUrlInput = document.getElementById('apiBaseUrl');
  const statusDiv = document.getElementById('status');
  const batchModeCheckbox = document.getElementById('batchMode');

  // ========== 状态持久化 ==========

  // 从 storage 加载所有保存的状态
  function loadPopupState() {
    chrome.storage.local.get(['popupState', 'apiBaseUrl'], function (result) {
      // 1. 加载 API 地址 (独立于状态对象，保持兼容)
      if (result.apiBaseUrl) {
        apiBaseUrlInput.value = result.apiBaseUrl;
      }

      const state = result.popupState || {};
      console.log('📂 加载保存的状态:', state);

      // 2. 加载导出模式
      if (state.exportMode) {
        exportModeSelect.value = state.exportMode;
      }

      // 3. 加载单平台选择和页数
      if (state.targetTab) {
        targetTabSelect.value = state.targetTab;
        // 触发 change 事件以同步 batchMode 状态
        targetTabSelect.dispatchEvent(new Event('change'));
      }
      if (state.pageCount) {
        pageCountInput.value = state.pageCount;
      }

      // 4. 加载批量任务复选框和页数
      if (state.batchTasks) {
        Object.keys(state.batchTasks).forEach(taskVal => {
          const taskData = state.batchTasks[taskVal];
          const checkbox = document.querySelector(`.batch-task[value="${taskVal}"]`);
          const pageInput = document.querySelector(`.batch-task-pages[data-task="${taskVal}"]`);

          if (checkbox) checkbox.checked = taskData.checked;
          if (pageInput) pageInput.value = taskData.pages;
        });
      }
    });
  }

  // 保存所有当前状态到 storage
  function savePopupState() {
    const state = {
      batchMode: batchModeCheckbox.checked, // 这里也保存一下
      exportMode: exportModeSelect.value,
      targetTab: targetTabSelect.value,
      pageCount: pageCountInput.value,
      batchTasks: {}
    };

    // 收集所有批量任务的状态
    document.querySelectorAll('.batch-task').forEach(checkbox => {
      const taskVal = checkbox.value;
      const pageInput = document.querySelector(`.batch-task-pages[data-task="${taskVal}"]`);
      state.batchTasks[taskVal] = {
        checked: checkbox.checked,
        pages: pageInput ? pageInput.value : 1
      };
    });

    console.log('💾 保存状态:', state);
    chrome.storage.local.set({ popupState: state });
    // API 地址依然单独保存，方便测试连接脚本使用
    chrome.storage.local.set({ apiBaseUrl: apiBaseUrlInput.value.trim() });
  }

  // 为所有输入元素添加自动保存监听器
  function attachAutoSaveListeners() {
    const inputs = document.querySelectorAll('select, input[type="text"], input[type="number"], input[type="checkbox"]');
    inputs.forEach(input => {
      input.addEventListener('change', savePopupState);
      if (input.type === 'number' || input.type === 'text') {
        input.addEventListener('input', savePopupState);
      }
    });
  }

  // 初始化加载
  loadPopupState();
  attachAutoSaveListeners();

  // ========== 逻辑处理 ==========

  // 当选择了单平台任务时，自动取消批量模式，反之亦然
  targetTabSelect.addEventListener('change', function () {
    if (this.value !== "") {
      batchModeCheckbox.checked = false;
      console.log("🎯 切换模式: 单平台任务 (" + this.value + ")");
    } else {
      batchModeCheckbox.checked = true;
      console.log("🚀 切换模式: 批量模式");
    }
  });

  // 测试连接逻辑
  const testConnBtn = document.getElementById('testConnection');
  testConnBtn.addEventListener('click', async function () {
    let apiBaseUrl = apiBaseUrlInput.value.trim();
    console.log("🧪 测试连接:", apiBaseUrl);
    if (!apiBaseUrl) {
      alert('请先输入 API 地址');
      return;
    }

    // 自动去掉末尾斜杠
    apiBaseUrl = apiBaseUrl.replace(/\/+$/, '');
    apiBaseUrlInput.value = apiBaseUrl;

    testConnBtn.disabled = true;
    testConnBtn.textContent = '测试中...';
    statusDiv.textContent = '⏳ 正在测试连接...';

    try {
      // 优先尝试访问 /health 接口
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 5000); // 5秒超时

      const response = await fetch(`${apiBaseUrl}/health`, {
        method: 'GET',
        signal: controller.signal
      }).catch(err => {
        // 如果 /health 失败，回退到 OPTIONS 探测
        return fetch(`${apiBaseUrl}/api/jobs/sync`, { method: 'OPTIONS', signal: controller.signal });
      });

      if (response.ok || response.status === 405) {
        statusDiv.textContent = '✅ 连接成功！服务器已响应。';
        statusDiv.style.color = 'green';
      } else {
        statusDiv.textContent = `❌ 连接失败 (状态码: ${response.status})`;
        statusDiv.style.color = 'red';
      }
    } catch (err) {
      console.error('Connection test failed:', err);
      statusDiv.textContent = `❌ 无法连接到服务器: ${err.message}`;
      statusDiv.style.color = 'red';
      alert(`连接失败！\n1. 请检查 IP (${apiBaseUrl}) 是否正确\n2. 请确保 Machine B 服务器正在运行\n3. 请确保 Machine B 防火墙允许入站连接`);
    } finally {
      testConnBtn.disabled = false;
      testConnBtn.textContent = '测试连接';
    }
  });

  // 初始化抓取配置
  startBtn.addEventListener('click', function () {
    const selectedValue = targetTabSelect.value;
    const pageCount = parseInt(pageCountInput.value) || 1;
    const exportMode = exportModeSelect.value;
    const apiBaseUrl = apiBaseUrlInput.value.trim() || 'http://localhost:8502';

    // 保存 API 地址到 storage
    chrome.storage.local.set({ apiBaseUrl: apiBaseUrl });

    // 检查是否为批量模式
    console.log("🟢 点击开始按钮. 批量模式:", batchModeCheckbox.checked);

    if (batchModeCheckbox.checked) {
      const selectedTasks = Array.from(document.querySelectorAll('.batch-task:checked')).map(el => el.value);
      console.log("📋 已选批量任务:", selectedTasks);

      if (selectedTasks.length === 0) {
        alert('请至少选择一个批量任务 (请勾选上方的复选框)');
        return;
      }

      const batchConfig = {
        tasks: selectedTasks.map(taskVal => {
          let scrapeType, configType, platform;

          if (taskVal.includes('pending') || taskVal.includes('allocated')) {
            scrapeType = 'job';
            // taskVal 格式: alibaba_pending, aliyun_allocated, feishu_pending
            const parts = taskVal.split('_');
            platform = parts[0];
            configType = parts[1];
          } else if (taskVal === 'xiaohongshu_jobs') {
            scrapeType = 'xiaohongshu';
            configType = 'jobs';
            platform = 'xiaohongshu';
          }

          // 获取该任务对应的页数
          const pageInput = document.querySelector(`.batch-task-pages[data-task="${taskVal}"]`);
          const taskPageCount = pageInput ? (parseInt(pageInput.value) || 1) : 1;

          return {
            scrapeType: scrapeType,
            configType: configType,
            platform: platform,
            pageCount: taskPageCount
          };
        }),
        exportMode: exportMode,
        apiBaseUrl: apiBaseUrl
      };

      console.log('🚀 启动批量抓取:', batchConfig);
      statusDiv.textContent = `🚀 启动批量模式: ${selectedTasks.length} 个任务...`;

      chrome.runtime.sendMessage({
        action: 'START_BATCH_SCRAPE',
        config: batchConfig
      }, function (response) {
        if (chrome.runtime.lastError) {
          statusDiv.textContent = `❌ 启动失败: ${chrome.runtime.lastError.message}`;
        } else {
          statusDiv.textContent = `✅ 批量任务已启动，请监控后台 console`;
        }
      });
      return;
    }

    // 解析选择值来确定抓取类型和具体参数
    let scrapeType, configType;

    if (selectedValue.startsWith('jobs_')) {
      scrapeType = 'job';
      configType = selectedValue.replace('jobs_', '');
    } else if (selectedValue === 'xiaohongshu_jobs') {
      scrapeType = 'xiaohongshu';
      configType = 'jobs';
    } else if (selectedValue === 'resumes') {
      scrapeType = 'resume';
      configType = 'page_based';
    } else if (selectedValue === 'delivery_records') {
      scrapeType = 'delivery';
      configType = 'delivery';
    } else if (selectedValue === 'resume_library') {
      scrapeType = 'resume_library';
      configType = 'resume_library';
    }

    const config = {
      scrapeType: scrapeType,
      configType: configType,
      pageCount: pageCount,
      resumePageCount: 0,
      filterType: null,
      exportMode: exportMode,
      apiBaseUrl: apiBaseUrl
    };

    console.log('🎯 抓取配置:', config);
    statusDiv.textContent = `准备${scrapeType === 'delivery' || scrapeType === 'resume_library' ? '下载简历' : '抓取 ' + (scrapeType === 'job' ? '职位' : '简历')}，共 ${pageCount} 页，导出模式: ${exportMode === 'csv' ? 'CSV 文件' : '数据库'}`;

    // Send message to background script to start scraping
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      const currentTabId = tabs[0].id;
      const currentUrl = tabs[0].url;
      console.log('📡 当前页面URL:', currentUrl);

      // 检测是否在详情页
      const isDetailPage = currentUrl.includes('FORM-') || currentUrl.includes('orderCode=');
      console.log('🔍 页面类型:', isDetailPage ? '详情页' : '列表页');

      if (isDetailPage) {
        // 如果是详情页，直接抓取当前页面
        chrome.tabs.sendMessage(currentTabId, {
          action: 'SCRAPE_DETAIL',
          config: config
        }, function (response) {
          if (chrome.runtime.lastError) {
            console.error('❌ 消息发送失败:', chrome.runtime.lastError.message);
            statusDiv.textContent = `❌ 发送消息失败: ${chrome.runtime.lastError.message}`;
          } else {
            console.log('✅ 消息发送成功:', response);
            statusDiv.textContent = `✅ 正在抓取详情页...`;
          }
        });
      } else {
        // 如果是列表页，发送消息给 background script 启动抓取
        if (scrapeType === 'job') {
          // 职位抓取 - 发送给 background script
          const scrapeConfig = {
            rootTabId: currentTabId,
            tabType: configType,
            pageCount: pageCount,
            exportMode: exportMode,
            apiBaseUrl: apiBaseUrl
          };

          console.log('🚀 发送抓取请求到 background:', scrapeConfig);

          chrome.runtime.sendMessage({
            action: 'START_SCRAPE',
            config: scrapeConfig
          }, function (response) {
            if (chrome.runtime.lastError) {
              console.error('❌ 启动抓取失败:', chrome.runtime.lastError.message);
              statusDiv.textContent = `❌ 启动失败: ${chrome.runtime.lastError.message}`;
            } else {
              console.log('✅ 抓取启动成功:', response);
              statusDiv.textContent = `✅ 正在启动职位抓取...`;
            }
          });
        } else if (scrapeType === 'resume') {
          // 简历抓取 - 不支持数据库同步
          if (exportMode === 'database') {
            statusDiv.textContent = '❌ 简历抓取暂不支持数据库同步，请选择 CSV 导出';
            return;
          }
          const scrapeConfig = {
            rootTabId: currentTabId,
            tabType: configType,
            pageCount: pageCount
          };

          console.log('📋 发送简历抓取请求到 background:', scrapeConfig);

          chrome.runtime.sendMessage({
            action: 'START_RESUME_SCRAPE',
            config: scrapeConfig
          }, function (response) {
            if (chrome.runtime.lastError) {
              console.error('❌ 启动简历抓取失败:', chrome.runtime.lastError.message);
              statusDiv.textContent = `❌ 启动失败: ${chrome.runtime.lastError.message}`;
            } else {
              console.log('✅ 简历抓取启动成功:', response);
              statusDiv.textContent = `✅ 正在启动简历抓取...`;
            }
          });
        } else if (scrapeType === 'xiaohongshu') {
          // 小红书职位抓取
          const scrapeConfig = {
            rootTabId: currentTabId,
            tabType: configType,
            pageCount: pageCount,
            exportMode: exportMode,
            apiBaseUrl: apiBaseUrl
          };

          console.log('📕 发送小红书抓取请求到 background:', scrapeConfig);

          chrome.runtime.sendMessage({
            action: 'START_XIAOHONGSHU_SCRAPE',
            config: scrapeConfig
          }, function (response) {
            if (chrome.runtime.lastError) {
              console.error('❌ 启动小红书抓取失败:', chrome.runtime.lastError.message);
              statusDiv.textContent = `❌ 启动失败: ${chrome.runtime.lastError.message}`;
            } else {
              console.log('✅ 小红书抓取启动成功:', response);
              statusDiv.textContent = `✅ 正在启动小红书职位抓取...`;
            }
          });
        } else if (scrapeType === 'delivery') {
          // 投递记录简历下载 - 不支持数据库同步
          if (exportMode === 'database') {
            statusDiv.textContent = '❌ 投递记录简历下载暂不支持数据库同步，请选择 CSV 导出';
            return;
          }
          const scrapeConfig = {
            rootTabId: currentTabId,
            tabType: configType,
            pageCount: pageCount
          };

          console.log('📬 发送投递记录简历下载请求到 background:', scrapeConfig);

          chrome.runtime.sendMessage({
            action: 'START_DELIVERY_SCRAPE',
            config: scrapeConfig
          }, function (response) {
            if (chrome.runtime.lastError) {
              console.error('❌ 启动投递记录简历下载失败:', chrome.runtime.lastError.message);
              statusDiv.textContent = `❌ 启动失败: ${chrome.runtime.lastError.message}`;
            } else {
              console.log('✅ 投递记录简历下载启动成功:', response);
              statusDiv.textContent = `✅ 正在启动投递记录简历下载...`;
            }
          });
        } else if (scrapeType === 'resume_library') {
          // 简历库简历下载 - 不支持数据库同步
          if (exportMode === 'database') {
            statusDiv.textContent = '❌ 简历库简历下载暂不支持数据库同步，请选择 CSV 导出';
            return;
          }
          const scrapeConfig = {
            rootTabId: currentTabId,
            tabType: configType,
            pageCount: pageCount
          };

          console.log('📚 发送简历库简历下载请求到 background:', scrapeConfig);

          chrome.runtime.sendMessage({
            action: 'START_RESUME_LIBRARY_SCRAPE',
            config: scrapeConfig
          }, function (response) {
            if (chrome.runtime.lastError) {
              console.error('❌ 启动简历库简历下载失败:', chrome.runtime.lastError.message);
              statusDiv.textContent = `❌ 启动失败: ${chrome.runtime.lastError.message}`;
            } else {
              console.log('✅ 简历库简历下载启动成功:', response);
              statusDiv.textContent = `✅ 正在启动简历库简历下载...`;
            }
          });
        }
      }
    });
  });

});

