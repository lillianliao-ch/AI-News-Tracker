// 深度页面链接分析脚本
// 用于找到真正的简历详情页链接

console.log("🔍 开始深度页面链接分析...");

// 1. 查找所有可能的候选人姓名链接
function findCandidateNameLinks() {
  console.log("\n=== 1. 查找候选人姓名链接 ===");
  
  const allLinks = document.querySelectorAll('a[href]');
  console.log(`总共找到 ${allLinks.length} 个链接`);
  
  const candidateLinks = [];
  
  allLinks.forEach((link, index) => {
    const href = link.href || link.getAttribute('href');
    const text = link.innerText || link.textContent || '';
    const parentElement = link.parentElement;
    const parentText = parentElement ? parentElement.innerText || '' : '';
    
    // 检查是否是候选人相关链接
    const isCandidateLink = (
      href.includes('resume') || 
      href.includes('candidate') || 
      href.includes('FORM-') ||
      text.includes('孔令美') ||
      text.includes('刘舒悦') ||
      text.includes('JINGBOWANG') ||
      text.length > 0 && !text.includes('猎头系统') && !text.includes('任务管理')
    );
    
    if (isCandidateLink) {
      candidateLinks.push({
        index: index,
        href: href,
        text: text.trim(),
        parentTag: parentElement ? parentElement.tagName : 'unknown',
        parentText: parentText.substring(0, 100),
        element: link
      });
    }
  });
  
  console.log(`\n找到 ${candidateLinks.length} 个候选链接:`);
  candidateLinks.forEach((link, i) => {
    console.log(`${i + 1}. 文本: "${link.text}"`);
    console.log(`   链接: ${link.href}`);
    console.log(`   父元素: ${link.parentTag}`);
    console.log(`   父文本: ${link.parentText}`);
    console.log(`   ---`);
  });
  
  return candidateLinks;
}

// 2. 分析表格结构中的链接
function analyzeTableLinks() {
  console.log("\n=== 2. 分析表格结构中的链接 ===");
  
  const tables = document.querySelectorAll('table');
  console.log(`找到 ${tables.length} 个表格`);
  
  const tableLinks = [];
  
  tables.forEach((table, tableIndex) => {
    const rows = table.querySelectorAll('tr');
    console.log(`表格 ${tableIndex + 1}: ${rows.length} 行`);
    
    rows.forEach((row, rowIndex) => {
      const cells = row.querySelectorAll('td');
      const links = row.querySelectorAll('a[href]');
      
      if (links.length > 0) {
        console.log(`  行 ${rowIndex + 1}: ${links.length} 个链接`);
        
        links.forEach((link, linkIndex) => {
          const href = link.href || link.getAttribute('href');
          const text = link.innerText || link.textContent || '';
          
          // 检查是否包含候选人姓名
          const candidateNames = ['孔令美', '刘舒悦', 'JINGBOWANG', '张华', '陈屹'];
          const hasCandidateName = candidateNames.some(name => text.includes(name));
          
          if (hasCandidateName || href.includes('resume') || href.includes('candidate')) {
            tableLinks.push({
              tableIndex: tableIndex + 1,
              rowIndex: rowIndex + 1,
              linkIndex: linkIndex + 1,
              href: href,
              text: text.trim(),
              isCandidateName: hasCandidateName
            });
            
            console.log(`    候选人链接: "${text}" -> ${href}`);
          }
        });
      }
    });
  });
  
  return tableLinks;
}

// 3. 查找动态加载的链接
function findDynamicLinks() {
  console.log("\n=== 3. 查找动态加载的链接 ===");
  
  // 检查页面源码中的链接模式
  const pageSource = document.documentElement.outerHTML;
  
  const linkPatterns = [
    /href=["']([^"']*resume[^"']*)["']/gi,
    /href=["']([^"']*candidate[^"']*)["']/gi,
    /href=["']([^"']*FORM-[^"']*)["']/gi,
    /href=["']([^"']*\d{6,}[^"']*)["']/gi
  ];
  
  let foundPatterns = [];
  
  linkPatterns.forEach((pattern, index) => {
    const matches = pageSource.match(pattern);
    if (matches) {
      console.log(`模式 ${index + 1} 匹配到 ${matches.length} 个链接:`);
      matches.forEach(match => {
        const href = match.replace(/href=["']/gi, '').replace(/["']$/, '');
        console.log(`  - ${href}`);
        foundPatterns.push(href);
      });
    }
  });
  
  return [...new Set(foundPatterns)]; // 去重
}

// 4. 检查页面特定的链接选择器
function testSpecificSelectors() {
  console.log("\n=== 4. 测试特定链接选择器 ===");
  
  const selectors = [
    'a[href*="resumeCode"]',
    'a[href*="FORM-"]',
    'a[href*="resume"]',
    'a[href*="candidate"]',
    'a[href*="detail"]',
    'a[href*="孔令美"]',
    'a[href*="刘舒悦"]',
    'a[href*="JINGBOWANG"]',
    'table a[href]',
    'tr a[href]',
    'td a[href]',
    '.candidate-name a',
    '.resume-link',
    '[data-resume-id] a',
    '[data-candidate-id] a'
  ];
  
  let totalMatches = 0;
  
  selectors.forEach(selector => {
    try {
      const elements = document.querySelectorAll(selector);
      console.log(`选择器 "${selector}": 找到 ${elements.length} 个元素`);
      
      if (elements.length > 0) {
        totalMatches += elements.length;
        
        elements.forEach((element, index) => {
          const href = element.href || element.getAttribute('href');
          const text = element.innerText || element.textContent || '';
          console.log(`  ${index + 1}. "${text}" -> ${href}`);
        });
      }
    } catch (error) {
      console.log(`选择器 "${selector}" 出错: ${error.message}`);
    }
  });
  
  console.log(`总计匹配 ${totalMatches} 个链接`);
  return totalMatches;
}

// 5. 获取页面URL信息
function analyzePageURL() {
  console.log("\n=== 5. 分析页面URL信息 ===");
  
  const currentURL = window.location.href;
  const urlParams = new URLSearchParams(window.location.search);
  
  console.log(`当前URL: ${currentURL}`);
  console.log(`URL参数数量: ${urlParams.size}`);
  
  if (urlParams.size > 0) {
    console.log("URL参数:");
    urlParams.forEach((value, key) => {
      console.log(`  ${key}: ${value}`);
    });
  }
  
  // 检查是否已经包含简历详情页的参数
  const resumeIndicators = ['resumeCode', 'candidate', 'FORM-', 'resume', 'detail'];
  const hasResumeParam = Array.from(urlParams.keys()).some(key => 
    resumeIndicators.some(indicator => key.includes(indicator))
  );
  
  console.log(`包含简历参数: ${hasResumeParam ? '是' : '否'}`);
  
  return { currentURL, urlParams, hasResumeParam };
}

// 6. 模拟点击测试链接
function simulateClickTest(links) {
  console.log("\n=== 6. 模拟点击测试 ===");
  
  if (links.length === 0) {
    console.log("没有找到可测试的链接");
    return;
  }
  
  // 选择最有希望的链接进行测试
  const candidateLinks = links.filter(link => {
    const text = link.text || '';
    const href = link.href || '';
    
    // 过滤出可能是候选人姓名的链接
    const isNameLink = (
      text.includes('孔令美') ||
      text.includes('刘舒悦') ||
      text.includes('JINGBOWANG') ||
      text.match(/[一-龯]{2,4}/) // 中文姓名模式
    );
    
    // 或者包含resume相关关键词的链接
    const isResumeLink = href.includes('resume') || href.includes('candidate') || href.includes('FORM-');
    
    return isNameLink || isResumeLink;
  });
  
  console.log(`找到 ${candidateLinks.length} 个最可能的链接进行测试`);
  
  if (candidateLinks.length > 0) {
    const testLink = candidateLinks[0];
    console.log(`准备测试链接: "${testLink.text}" -> ${testLink.href}`);
    
    // 询问用户是否要点击测试
    if (confirm(`准备点击链接: "${testLink.text}"\n确认要导航到详情页进行测试吗？`)) {
      console.log("🚀 开始点击测试...");
      
      try {
        const clickEvent = new MouseEvent('click', {
          view: window,
          bubbles: true,
          cancelable: true
        });
        
        testLink.element.dispatchEvent(clickEvent);
        
        // 等待页面响应
        setTimeout(() => {
          console.log("⏱️  等待页面加载...");
          const newPageType = detectPageType();
          console.log(`新页面类型: ${newPageType}`);
          
          if (newPageType === 'detail') {
            console.log("✅ 成功导航到详情页！");
          } else {
            console.log("❌ 导航失败或仍在列表页");
          }
        }, 2000);
        
      } catch (error) {
        console.error("点击测试失败:", error);
      }
    }
  }
}

// 主函数：运行所有分析
function runDeepLinkAnalysis() {
  console.log("🎯 开始深度链接分析...");
  
  const pageURL = analyzePageURL();
  const candidateLinks = findCandidateNameLinks();
  const tableLinks = analyzeTableLinks();
  const dynamicLinks = findDynamicLinks();
  const selectorMatches = testSpecificSelectors();
  
  // 合并所有找到的链接
  const allFoundLinks = [...candidateLinks];
  
  console.log("\n=== 分析结果汇总 ===");
  console.log(`页面URL分析: ${JSON.stringify(pageURL, null, 2)}`);
  console.log(`候选人链接: ${candidateLinks.length} 个`);
  console.log(`表格链接: ${tableLinks.length} 个`);
  console.log(`动态链接模式: ${dynamicLinks.length} 个`);
  console.log(`选择器匹配: ${selectorMatches} 个`);
  
  // 询问是否进行点击测试
  if (allFoundLinks.length > 0) {
    simulateClickTest(allFoundLinks);
  } else {
    console.log("❌ 没有找到合适的链接进行测试");
  }
  
  return {
    candidateLinks,
    tableLinks,
    dynamicLinks,
    pageURL,
    allFoundLinks
  };
}

// 导出函数供手动调用
window.deepLinkAnalysis = {
  runDeepLinkAnalysis,
  findCandidateNameLinks,
  analyzeTableLinks,
  findDynamicLinks,
  testSpecificSelectors,
  analyzePageURL,
  simulateClickTest
};

// 自动运行分析
runDeepLinkAnalysis();