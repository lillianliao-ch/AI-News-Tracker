/**
 * Optimized Resume Parser for JobScraper Extension
 * Based on comprehensive page screenshot analysis and intelligent element detection
 * Enhanced version with smart extraction strategies and debug capabilities
 */

class SmartResumeParser {
  constructor() {
    this.resumeData = null;
    this.isProcessing = false;
    this.config = null;
    this.pageType = null;
    this.debugMode = false;
    this.extractionStrategies = [];
    this.performanceMetrics = {};
    
    this.initStrategies();
  }

  /**
   * Initialize extraction strategies based on screenshot analysis
   */
  initStrategies() {
    this.extractionStrategies = [
      {
        name: 'AntTableStrategy',
        priority: 1,
        test: () => document.querySelector('.ant-table'),
        extract: () => this.extractViaAntTable()
      },
      {
        name: 'CardStrategy', 
        priority: 2,
        test: () => document.querySelector('.resume-card, .candidate-card'),
        extract: () => this.extractViaCardLayout()
      },
      {
        name: 'TableStrategy',
        priority: 3,
        test: () => document.querySelector('table tbody tr'),
        extract: () => this.extractViaTableStructure()
      },
      {
        name: 'ListStrategy',
        priority: 4,
        test: () => document.querySelector('ul li, ol li'),
        extract: () => this.extractViaListItems()
      },
      {
        name: 'DivStrategy',
        priority: 5,
        test: () => document.querySelector('[class*="row"], [class*="item"]'),
        extract: () => this.extractViaDivs()
      }
    ];
  }

  /**
   * Initialize parser
   */
  init() {
    // Enable debug mode for development
    this.debugMode = window.location.hostname.includes('headhunter') || 
                    window.location.search.includes('debug=true');
    
    if (this.debugMode) {
      console.log('🚀 Smart Resume Parser initialized with debug mode');
    }

    // Listen for messages from background script
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      this.handleMessage(message, sender, sendResponse);
    });

    // Initialize performance monitoring
    this.performanceMetrics = {
      startTime: Date.now(),
      extractionCount: 0,
      errors: [],
      strategies: {}
    };
  }

  /**
   * Handle messages from background script
   */
  handleMessage(message, sender, sendResponse) {
    const startTime = performance.now();
    
    switch (message.action) {
      case 'INIT_RESUME':
        this.initResumeScraping(message.data);
        break;
      case 'SCRAPE_RESUME_LIST':
        this.scrapeResumeList(message.data);
        break;
      case 'SCRAPE_RESUME_DETAIL':
        this.scrapeResumeDetail(message.data);
        break;
      case 'CLICK_NEXT_RESUME_PAGE':
        this.clickNextResumePage(message.data);
        break;
      case 'DEBUG_PAGE':
        this.debugPageStructure();
        break;
      case 'GET_PERFORMANCE_STATS':
        this.getPerformanceStats();
        break;
      default:
        break;
    }
    
    // Track performance
    if (this.debugMode) {
      const endTime = performance.now();
      console.log(`Action ${message.action} completed in ${endTime - startTime}ms`);
    }
  }

  /**
   * Intelligent page type detection based on comprehensive analysis
   */
  async detectPageType() {
    const url = window.location.href;
    const docTitle = document.title.toLowerCase();
    const bodyClasses = document.body.className.toLowerCase();
    const metaContent = document.querySelector('meta[name="description"]')?.content || '';
    
    // 简历管理页面检测指标
    const listPageIndicators = [
      // URL特征
      url.includes('resumeManagement') || url.includes('resume-management'),
      url.includes('resume-list') || url.includes('candidate-list'),
      
      // DOM结构特征
      document.querySelector('.ant-table') !== null,
      document.querySelector('.resume-list') !== null,
      document.querySelector('.candidate-list') !== null,
      document.querySelector('.table-resume') !== null,
      
      // 内容特征
      docTitle.includes('简历') && docTitle.includes('列表'),
      docTitle.includes('候选人') && docTitle.includes('管理'),
      bodyClasses.includes('list') || bodyClasses.includes('table'),
      
      // 数据结构特征
      document.querySelectorAll('tbody tr').length > 3,
      document.querySelectorAll('.resume-card, .candidate-card').length > 2,
      
      // 页面功能特征
      document.querySelector('.pagination') !== null,
      document.querySelector('.filter-bar') !== null,
      document.querySelector('.search-bar') !== null
    ];

    // 简历详情页面检测指标
    const detailPageIndicators = [
      // URL特征
      url.includes('resume-detail') || url.includes('resumeDetail'),
      url.includes('candidate-detail') || url.includes('candidateDetail'),
      
      // DOM结构特征
      document.querySelector('.resume-detail') !== null,
      document.querySelector('.candidate-detail') !== null,
      document.querySelector('.detail-container') !== null,
      document.querySelector('.profile-container') !== null,
      
      // 内容特征
      docTitle.includes('简历详情') || docTitle.includes('个人简历'),
      docTitle.includes('候选人') && docTitle.includes('详情'),
      
      // 页面结构特征
      document.querySelector('h1') !== null,
      document.querySelector('.profile') !== null,
      document.querySelector('.info-section') !== null
    ];

    const listScore = listPageIndicators.filter(Boolean).length;
    const detailScore = detailPageIndicators.filter(Boolean).length;

    if (detailScore >= 3) {
      this.pageType = 'detail';
    } else if (listScore >= 3) {
      this.pageType = 'list';
    } else {
      this.pageType = 'unknown';
    }

    if (this.debugMode) {
      console.log('📊 Page Type Detection:', {
        listScore,
        detailScore,
        detected: this.pageType,
        url,
        title: document.title
      });
    }

    return this.pageType;
  }

  /**
   * Enhanced page detection with multiple validation strategies
   */
  async isResumeManagementPage() {
    const pageType = await this.detectPageType();
    return pageType === 'list';
  }

  /**
   * Initialize resume scraping with enhanced error handling
   */
  async initResumeScraping(config) {
    try {
      this.isProcessing = true;
      this.config = config;
      
      if (this.debugMode) {
        console.log('🔄 Initializing resume scraping with config:', config);
      }

      // Validate page type before starting
      const isResumePage = await this.isResumeManagementPage();
      
      if (isResumePage) {
        console.log('✅ Resume management page detected');
        await this.scrapeResumeList(config);
      } else {
        console.log('❌ Not a resume management page');
        this.sendMessageToBackground({
          action: 'RESUME_PAGE_NOT_DETECTED',
          data: { 
            currentUrl: window.location.href,
            pageType: this.pageType,
            detectedAt: new Date().toISOString()
          }
        });
      }
    } catch (error) {
      console.error('💥 Error initializing resume scraping:', error);
      this.recordError('INIT_ERROR', error);
      this.sendMessageToBackground({
        action: 'RESUME_SCRAPING_ERROR',
        data: { error: error.message, stack: error.stack }
      });
    } finally {
      this.isProcessing = false;
    }
  }

  /**
   * Smart resume list extraction with intelligent strategy selection
   */
  async scrapeResumeList(config) {
    try {
      const startTime = performance.now();
      
      // Wait for content to be fully loaded
      await this.waitForContentLoad();
      
      // Re-detect page type (might have changed)
      const pageType = await this.detectPageType();
      
      if (pageType !== 'list') {
        throw new Error(`Expected list page, but detected: ${pageType}`);
      }

      // Use intelligent extraction strategies
      const resumes = await this.extractWithStrategies();
      
      const extractionTime = performance.now() - startTime;
      this.performanceMetrics.extractionCount++;
      this.performanceMetrics.lastExtractionTime = extractionTime;

      if (this.debugMode) {
        console.log(`⚡ Extracted ${resumes.length} resumes in ${extractionTime.toFixed(2)}ms`);
      }
      
      this.sendMessageToBackground({
        action: 'RESUME_LINKS_EXTRACTED',
        data: {
          resumes: resumes,
          pageCount: this.getCurrentPageNumber(),
          hasNextPage: this.hasNextPage(),
          pageType: 'list',
          extractionTime: extractionTime,
          strategy: this.performanceMetrics.lastStrategy,
          timestamp: new Date().toISOString()
        }
      });
    } catch (error) {
      console.error('💥 Error scraping resume list:', error);
      this.recordError('SCRAPE_ERROR', error);
      this.sendMessageToBackground({
        action: 'RESUME_SCRAPING_ERROR',
        data: { 
          error: error.message,
          stack: error.stack,
          timestamp: new Date().toISOString()
        }
      });
    }
  }

  /**
   * Extract resumes using intelligent strategy selection
   */
  async extractWithStrategies() {
    const strategies = this.extractionStrategies
      .filter(strategy => strategy.test())
      .sort((a, b) => a.priority - b.priority);

    if (strategies.length === 0) {
      throw new Error('No suitable extraction strategy found');
    }

    for (const strategy of strategies) {
      try {
        const startTime = performance.now();
        const result = await strategy.extract();
        const extractionTime = performance.now() - startTime;
        
        if (result && result.length > 0) {
          // Track successful strategy
          this.performanceMetrics.strategies[strategy.name] = {
            count: (this.performanceMetrics.strategies[strategy.name]?.count || 0) + 1,
            avgTime: extractionTime,
            lastUsed: new Date().toISOString()
          };
          
          this.performanceMetrics.lastStrategy = strategy.name;
          
          if (this.debugMode) {
            console.log(`🎯 Success: ${strategy.name} extracted ${result.length} resumes`);
          }
          
          return result;
        }
      } catch (error) {
        console.warn(`⚠️ Strategy ${strategy.name} failed:`, error.message);
        continue;
      }
    }

    throw new Error('All extraction strategies failed');
  }

  /**
   * Extract via Ant Design table (highest priority)
   */
  async extractViaAntTable() {
    const table = document.querySelector('.ant-table');
    if (!table) return [];

    const tbody = table.querySelector('tbody');
    if (!tbody) return [];

    const rows = tbody.querySelectorAll('tr');
    const resumes = [];

    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      const resumeData = this.extractResumeFromRow(row, i, 'ant-table');
      
      if (resumeData && this.isValidResumeData(resumeData)) {
        resumes.push(resumeData);
      }
    }

    return resumes;
  }

  /**
   * Extract via card layout
   */
  async extractViaCardLayout() {
    const cardSelectors = [
      '.resume-card',
      '.candidate-card', 
      '[class*="resume"]',
      '[class*="candidate"]',
      '.profile-card'
    ];

    for (const selector of cardSelectors) {
      const cards = document.querySelectorAll(selector);
      if (cards.length >= 2) {
        const resumes = [];
        
        for (let i = 0; i < cards.length; i++) {
          const card = cards[i];
          const resumeData = this.extractResumeFromCard(card, i, selector);
          
          if (resumeData && this.isValidResumeData(resumeData)) {
            resumes.push(resumeData);
          }
        }
        
        return resumes;
      }
    }

    return [];
  }

  /**
   * Extract via generic table structure
   */
  async extractViaTableStructure() {
    const tables = document.querySelectorAll('table');
    const resumes = [];

    for (const table of tables) {
      const rows = table.querySelectorAll('tbody tr');
      if (rows.length < 3) continue; // Skip small tables

      for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const resumeData = this.extractResumeFromRow(row, i, 'table');
        
        if (resumeData && this.isValidResumeData(resumeData)) {
          resumes.push(resumeData);
        }
      }
    }

    return resumes;
  }

  /**
   * Extract via list items
   */
  async extractViaListItems() {
    const listSelectors = [
      'ul.resume-list li',
      'ul.candidate-list li',
      'ol.resume-list li',
      '[class*="list"] li'
    ];

    for (const selector of listSelectors) {
      const items = document.querySelectorAll(selector);
      if (items.length >= 3) {
        const resumes = [];
        
        for (let i = 0; i < items.length; i++) {
          const item = items[i];
          const resumeData = this.extractResumeFromItem(item, i, selector);
          
          if (resumeData && this.isValidResumeData(resumeData)) {
            resumes.push(resumeData);
          }
        }
        
        return resumes;
      }
    }

    return [];
  }

  /**
   * Extract via div-based layout
   */
  async extractViaDivs() {
    const divSelectors = [
      '[role="table-row"]',
      '[data-testid*="resume"]',
      '[data-testid*="candidate"]',
      '[class*="row"]',
      '[class*="item"]'
    ];

    for (const selector of divSelectors) {
      const divs = document.querySelectorAll(selector);
      if (divs.length >= 3) {
        const resumes = [];
        
        for (let i = 0; i < divs.length; i++) {
          const div = divs[i];
          const resumeData = this.extractResumeFromDiv(div, i, selector);
          
          if (resumeData && this.isValidResumeData(resumeData)) {
            resumes.push(resumeData);
          }
        }
        
        return resumes;
      }
    }

    return [];
  }

  /**
   * Extract resume data from table row with enhanced validation
   */
  extractResumeFromRow(row, index, strategy) {
    const cells = row.querySelectorAll('td');
    if (cells.length < 1) return null;

    const name = this.extractCandidateName(cells[0]);
    if (!name || !this.isValidName(name)) return null;

    const link = this.extractResumeLink(cells[0] || row);
    
    return {
      id: this.extractResumeId(row) || `resume_${index + 1}`,
      name: name,
      link: link,
      phone: this.extractPhoneFromElement(cells[1] || row),
      email: this.extractEmailFromElement(cells[2] || cells[1] || row),
      index: index,
      strategy: strategy,
      element: row,
      extractedAt: new Date().toISOString()
    };
  }

  /**
   * Extract resume data from card element
   */
  extractResumeFromCard(card, index, strategy) {
    const name = this.extractCandidateName(card);
    if (!name || !this.isValidName(name)) return null;

    const link = this.extractResumeLink(card);

    return {
      id: this.extractResumeId(card) || `resume_${index + 1}`,
      name: name,
      link: link,
      phone: this.extractPhoneFromElement(card),
      email: this.extractEmailFromElement(card),
      index: index,
      strategy: strategy,
      element: card,
      extractedAt: new Date().toISOString()
    };
  }

  /**
   * Extract resume data from list item
   */
  extractResumeFromItem(item, index, strategy) {
    const name = this.extractCandidateName(item);
    if (!name || !this.isValidName(name)) return null;

    const link = this.extractResumeLink(item);

    return {
      id: this.extractResumeId(item) || `resume_${index + 1}`,
      name: name,
      link: link,
      phone: this.extractPhoneFromElement(item),
      email: this.extractEmailFromElement(item),
      index: index,
      strategy: strategy,
      element: item,
      extractedAt: new Date().toISOString()
    };
  }

  /**
   * Extract resume data from div element
   */
  extractResumeFromDiv(div, index, strategy) {
    const name = this.extractCandidateName(div);
    if (!name || !this.isValidName(name)) return null;

    const link = this.extractResumeLink(div);

    return {
      id: this.extractResumeId(div) || `resume_${index + 1}`,
      name: name,
      link: link,
      phone: this.extractPhoneFromElement(div),
      email: this.extractEmailFromElement(div),
      index: index,
      strategy: strategy,
      element: div,
      extractedAt: new Date().toISOString()
    };
  }

  /**
   * Extract resume link with comprehensive validation
   */
  extractResumeLink(element) {
    const linkSelectors = [
      'a[href*="resume"]',
      'a[href*="candidate"]',
      'a[href*="detail"]',
      'a[href*="/"]',
      '.name a',
      '.candidate-name a',
      '.resume-name a',
      'td:first-child a',
      '.ant-table-cell:first-child a',
      'a[href]',
      'a' // fallback
    ];

    for (const selector of linkSelectors) {
      const link = element.querySelector(selector);
      if (link && link.href && link.href !== window.location.href) {
        const url = new URL(link.href, window.location.href);
        if (url.pathname !== '/' && !link.href.includes('#')) {
          return link.href;
        }
      }
    }

    return null;
  }

  /**
   * Extract candidate name with enhanced detection
   */
  extractCandidateName(element) {
    const nameSelectors = [
      '.name',
      '.candidate-name',
      '.resume-name',
      '.real-name',
      '.user-name',
      'td:first-child',
      'td:nth-child(1)',
      '.ant-table-cell:first-child',
      '[data-field="name"]',
      'h1',
      'h2',
      '.title',
      '.heading',
      '.profile-name'
    ];

    for (const selector of nameSelectors) {
      const nameElement = element.querySelector(selector);
      if (nameElement) {
        const name = nameElement.textContent.trim();
        if (this.isValidName(name)) {
          return name;
        }
      }
    }

    // Fallback to element's text content
    const text = element.textContent.trim();
    if (this.isValidName(text)) {
      const lines = text.split('\n');
      const firstLine = lines[0].trim();
      if (firstLine.length > 0 && firstLine.length < 50) {
        return firstLine;
      }
    }

    return null;
  }

  /**
   * Enhanced name validation
   */
  isValidName(text) {
    return text && 
           text.length > 0 && 
           text.length < 50 &&
           !text.includes('操作') && 
           !text.includes('编辑') &&
           !text.includes('查看') &&
           !text.includes('删除') &&
           !text.includes('暂无') &&
           !text.includes('加载中') &&
           !/^\d+$/.test(text) && // Not just numbers
           !/^[\s\W]*$/.test(text); // Not just special characters
  }

  /**
   * Validate resume data completeness
   */
  isValidResumeData(resumeData) {
    return resumeData &&
           resumeData.name &&
           resumeData.name !== '未知' &&
           resumeData.id &&
           this.isValidName(resumeData.name);
  }

  /**
   * Extract resume ID with multiple strategies
   */
  extractResumeId(element) {
    // Check data attributes
    const idAttrs = [
      'data-resume-id',
      'data-candidate-id', 
      'data-id',
      'data-key',
      'data-row-key',
      'data-testid',
      'data-cy'
    ];

    for (const attr of idAttrs) {
      const id = element.getAttribute(attr);
      if (id && /^[a-zA-Z0-9_-]+$/.test(id)) {
        return id;
      }
    }

    // Extract from link URL
    const link = element.querySelector('a[href]');
    if (link) {
      const patterns = [
        /resume[_\-]?(\d+)/i,
        /candidate[_\-]?(\d+)/i,
        /id[=:](\w+)/i,
        /\/(\w+)$/i,
        /[?&]id[=:](\w+)/i
      ];

      for (const pattern of patterns) {
        const match = link.href.match(pattern);
        if (match && match[1]) return match[1];
      }
    }

    // Generate based on index if no ID found
    return null;
  }

  /**
   * Extract phone number with comprehensive patterns
   */
  extractPhoneFromElement(element) {
    const phonePatterns = [
      /1[3-9]\d{9}/g, // 手机号
      /\d{3}[- ]?\d{4}[- ]?\d{4}/g, // 固话格式
      /\+86[ ]?1[3-9]\d{9}/g, // 国际格式
      /\(\d{3}\)[ ]?\d{4}[- ]?\d{4}/g // 带括号格式
    ];

    const text = element.textContent;
    for (const pattern of phonePatterns) {
      const matches = text.match(pattern);
      if (matches && matches.length > 0) {
        return matches[0].replace(/[^\d]/g, ''); // Clean formatting
      }
    }

    return '';
  }

  /**
   * Extract email with validation
   */
  extractEmailFromElement(element) {
    const emailPattern = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/g;
    const matches = element.textContent.match(emailPattern);
    
    if (matches && matches.length > 0) {
      const email = matches[0];
      // Basic email validation
      if (email.length > 5 && email.includes('@') && email.includes('.')) {
        return email;
      }
    }

    return '';
  }

  /**
   * Enhanced pagination detection with validation
   */
  hasNextPage() {
    const nextPageSelectors = [
      '.ant-pagination .ant-pagination-next:not(.ant-pagination-disabled)',
      '.next-page:not(.disabled)',
      '.page-next:not([disabled])',
      '[aria-label="Next Page"]:not([aria-disabled="true"])',
      '[title="下一页"]:not(.disabled)',
      'a[href*="page"]',
      '.pagination-next:not(.disabled)',
      'button[data-testid="next-page"]:not([disabled])'
    ];

    for (const selector of nextPageSelectors) {
      const element = document.querySelector(selector);
      if (element && 
          element.offsetParent !== null && 
          !element.disabled && 
          !element.classList.contains('disabled')) {
        return true;
      }
    }

    // Check for page numbers (if page 1, might have page 2)
    const pageElements = document.querySelectorAll('.ant-pagination .ant-pagination-item, .page-number');
    let currentPage = 1;
    let maxPage = 1;

    for (const pageEl of pageElements) {
      const pageText = pageEl.textContent.trim();
      const pageNum = parseInt(pageText);
      
      if (pageEl.classList.contains('active') || pageEl.classList.contains('ant-pagination-item-active')) {
        currentPage = pageNum;
      }
      if (!isNaN(pageNum) && pageNum > maxPage) {
        maxPage = pageNum;
      }
    }

    return currentPage < maxPage;
  }

  /**
   * Get current page number with multiple detection methods
   */
  getCurrentPageNumber() {
    const pageSelectors = [
      '.ant-pagination .ant-pagination-item-active',
      '.current-page',
      '.page-current',
      '.active-page',
      '[aria-current="page"]'
    ];

    for (const selector of pageSelectors) {
      const element = document.querySelector(selector);
      if (element) {
        const pageNum = parseInt(element.textContent);
        if (!isNaN(pageNum) && pageNum > 0) {
          return pageNum;
        }
      }
    }

    // Extract from URL parameters
    const urlParams = new URLSearchParams(window.location.search);
    const pageParam = urlParams.get('page') || urlParams.get('current') || urlParams.get('p');
    if (pageParam && !isNaN(parseInt(pageParam))) {
      return parseInt(pageParam);
    }

    // Extract from URL path
    const pathMatch = window.location.pathname.match(/page[_-]?(\d+)/i);
    if (pathMatch) {
      return parseInt(pathMatch[1]);
    }

    return 1; // Default to page 1
  }

  /**
   * Click next page with enhanced error handling
   */
  async clickNextResumePage(config) {
    try {
      const nextSelectors = [
        '.ant-pagination .ant-pagination-next:not(.ant-pagination-disabled)',
        '.next-page:not(.disabled)',
        '.page-next:not([disabled])',
        '[aria-label="Next Page"]',
        '[title="下一页"]',
        'a[href*="page"]'
      ];

      let clicked = false;
      for (const selector of nextSelectors) {
        const element = document.querySelector(selector);
        if (element && 
            element.offsetParent !== null && 
            !element.disabled) {
          
          if (this.debugMode) {
            console.log(`🔄 Clicking next page button: ${selector}`);
          }
          
          element.click();
          clicked = true;
          
          // Wait for page transition
          await this.waitForPageLoad();
          await this.scrapeResumeList(config);
          return;
        }
      }

      if (!clicked) {
        if (this.debugMode) {
          console.log('📄 No next page button found or already on last page');
        }
        this.sendMessageToBackground({
          action: 'RESUME_NO_MORE_PAGES',
          data: { success: false }
        });
      }
    } catch (error) {
      console.error('💥 Error clicking next page:', error);
      this.recordError('NEXT_PAGE_ERROR', error);
      this.sendMessageToBackground({
        action: 'RESUME_SCRAPING_ERROR',
        data: { error: error.message }
      });
    }
  }

  /**
   * Enhanced resume detail extraction
   */
  async scrapeResumeDetail(config) {
    try {
      const startTime = performance.now();
      
      await this.waitForContentLoad();
      
      const resumeDetail = await this.extractResumeDetail();
      
      const extractionTime = performance.now() - startTime;
      this.performanceMetrics.detailExtractionTime = extractionTime;
      
      if (this.debugMode) {
        console.log(`📄 Extracted resume detail in ${extractionTime.toFixed(2)}ms`);
      }
      
      this.sendMessageToBackground({
        action: 'RESUME_DETAIL_EXTRACTED',
        data: {
          resumeId: config.resumeId,
          detail: resumeDetail,
          extractionTime: extractionTime
        }
      });
    } catch (error) {
      console.error('💥 Error scraping resume detail:', error);
      this.recordError('DETAIL_SCRAPE_ERROR', error);
      this.sendMessageToBackground({
        action: 'RESUME_SCRAPING_ERROR',
        data: { error: error.message }
      });
    }
  }

  /**
   * Extract comprehensive resume detail
   */
  async extractResumeDetail() {
    await this.waitForContentLoad();
    
    const detail = {
      // Basic information
      name: this.extractFieldBySelectors([
        '.name', '.candidate-name', '.resume-name',
        '.real-name', '.user-name', 'h1', 'h2',
        '[data-field="name"]', '.ant-typography-title',
        '.profile-name', '.candidate-real-name'
      ], '姓名'),

      phone: this.extractFieldBySelectors([
        '.phone', '.mobile', '.telephone', 
        '[data-field="phone"]', '[data-field="mobile"]',
        'a[href^="tel:"]'
      ], '电话'),

      email: this.extractFieldBySelectors([
        '.email', '.mail', '[data-field="email"]',
        'a[href^="mailto:"]'
      ], '邮箱'),

      location: this.extractFieldBySelectors([
        '.location', '.address', '.current-location',
        '[data-field="location"]', '[data-field="address"]',
        '.city'
      ], '现居地'),

      // Professional information
      currentTitle: this.extractFieldBySelectors([
        '.current-title', '.current-position', '.job-title',
        '[data-field="currentTitle"]', '[data-field="currentPosition"]',
        '.position', '.role'
      ], '当前职位'),

      yearsExp: this.extractFieldBySelectors([
        '.years-exp', '.experience-years', '.work-years',
        '[data-field="yearsExp"]', '[data-field="experience"]',
        '.experience', '.work-exp'
      ], '工作年限'),

      expectedTitle: this.extractFieldBySelectors([
        '.expected-title', '.expected-position', '.target-position',
        '[data-field="expectedTitle"]', '[data-field="expectedPosition"]'
      ], '期望职位'),

      expectedSalary: this.extractFieldBySelectors([
        '.salary', '.expected-salary', '.expected-pay',
        '[data-field="expectedSalary"]', '[data-field="salary"]'
      ], '期望薪资'),

      // Detailed sections
      education: this.extractSectionEnhanced([
        '.education', '.educational', '.study-exp', 
        '[data-section="education"]', '#education', '.edu-list',
        '.education-background'
      ]),

      experience: this.extractSectionEnhanced([
        '.experience', '.work-exp', '.employment',
        '[data-section="experience"]', '#experience', '.work-list',
        '.work-history'
      ]),

      skills: this.extractSectionEnhanced([
        '.skills', '.skill-list', '.tags',
        '[data-section="skills"]', '#skills', '.skill-tags',
        '.skill-set'
      ]),

      projects: this.extractSectionEnhanced([
        '.projects', '.project-exp', '.project-list',
        '[data-section="projects"]', '#projects', '.project-items',
        '.portfolio'
      ]),

      summary: this.extractSectionEnhanced([
        '.summary', '.evaluation', '.self-intro',
        '[data-section="summary"]', '#summary', '.intro', 
        '.description', '.about-me'
      ]),

      // Metadata
      url: window.location.href,
      extractedAt: new Date().toISOString(),
      extractionMethod: 'smart'
    };

    return detail;
  }

  /**
   * Enhanced field extraction with fallback strategies
   */
  extractFieldBySelectors(selectors, fieldName = '') {
    for (const selector of selectors) {
      const element = document.querySelector(selector);
      if (element) {
        const text = element.textContent.trim();
        if (text && text.length > 0 && !text.includes('暂无') && !text.includes('未填写')) {
          return text;
        }
      }
    }
    return '';
  }

  /**
   * Enhanced section content extraction
   */
  extractSectionEnhanced(selectors) {
    const selectorList = Array.isArray(selectors) ? selectors : [selectors];
    
    for (const selector of selectorList) {
      const element = document.querySelector(selector);
      if (element) {
        const text = element.textContent.trim();
        if (text && text.length > 10 && !text.includes('暂无')) {
          // Clean up the text
          return text.replace(/\s+/g, ' ').trim();
        }
      }
    }

    return '';
  }

  /**
   * Wait for content to load with intelligent detection
   */
  async waitForContentLoad(timeout = 10000) {
    const startTime = Date.now();
    
    // Wait for DOM ready
    if (document.readyState === 'loading') {
      await new Promise(resolve => {
        document.addEventListener('DOMContentLoaded', resolve);
      });
    }

    // Wait for content to appear
    const contentSelectors = [
      '.ant-table',
      '.resume-list', 
      '.candidate-list',
      '.resume-card',
      '.candidate-card',
      'table tbody tr',
      'ul li',
      '[class*="resume"]',
      '[class*="candidate"]'
    ];

    while (Date.now() - startTime < timeout) {
      for (const selector of contentSelectors) {
        const element = document.querySelector(selector);
        if (element) {
          // Additional check for content
          if (element.textContent && element.textContent.trim().length > 10) {
            // Small delay to ensure rendering is complete
            await this.sleep(300);
            return;
          }
        }
      }
      await this.sleep(200);
    }

    if (this.debugMode) {
      console.warn('⚠️ Content load timeout, proceeding with available content');
    }
  }

  /**
   * Wait for page transition
   */
  async waitForPageLoad(timeout = 5000) {
    const startTime = Date.now();
    
    // Wait for network activity to settle
    while (Date.now() - startTime < timeout) {
      if (document.readyState === 'complete') {
        await this.sleep(500); // Additional buffer
        break;
      }
      await this.sleep(100);
    }
  }

  /**
   * Record error for debugging
   */
  recordError(type, error) {
    this.performanceMetrics.errors.push({
      type,
      message: error.message,
      stack: error.stack,
      timestamp: new Date().toISOString(),
      url: window.location.href
    });

    if (this.debugMode) {
      console.error(`🚨 Error recorded [${type}]:`, error);
    }
  }

  /**
   * Debug page structure
   */
  debugPageStructure() {
    console.log('🔍 === Smart Resume Parser Debug ===');
    console.log('URL:', window.location.href);
    console.log('Page Type:', this.pageType);
    console.log('Current Page:', this.getCurrentPageNumber());
    console.log('Has Next Page:', this.hasNextPage());
    console.log('Debug Mode:', this.debugMode);
    
    const structures = {
      antTable: !!document.querySelector('.ant-table'),
      resumeList: !!document.querySelector('.resume-list'),
      candidateList: !!document.querySelector('.candidate-list'),
      resumeCards: document.querySelectorAll('.resume-card, .candidate-card').length,
      tableRows: document.querySelectorAll('tbody tr').length,
      listItems: document.querySelectorAll('ul li, ol li').length,
      links: document.querySelectorAll('a').length,
      pagination: !!document.querySelector('.ant-pagination, .pagination'),
      filters: !!document.querySelector('.filter-bar, .search-bar')
    };
    
    console.log('Page Structures:', structures);
    console.log('Performance Metrics:', this.performanceMetrics);
    console.log('Active Strategies:', this.extractionStrategies.filter(s => s.test()).map(s => s.name));
    console.log('=== Debug End ===');
  }

  /**
   * Get performance statistics
   */
  getPerformanceStats() {
    const stats = {
      ...this.performanceMetrics,
      uptime: Date.now() - this.performanceMetrics.startTime,
      memory: performance.memory ? {
        used: Math.round(performance.memory.usedJSHeapSize / 1048576) + 'MB',
        total: Math.round(performance.memory.totalJSHeapSize / 1048576) + 'MB'
      } : 'N/A'
    };

    console.log('📊 Performance Statistics:', stats);
    return stats;
  }

  /**
   * Send message to background script
   */
  sendMessageToBackground(message) {
    chrome.runtime.sendMessage(message);
  }

  /**
   * Utility function to sleep
   */
  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// Initialize Smart Resume Parser
if (typeof window !== 'undefined') {
  window.smartResumeParser = new SmartResumeParser();
  window.smartResumeParser.init();
  
  // Add global debug functions for easy access
  window.debugSmartResumeParser = () => {
    window.smartResumeParser?.debugPageStructure();
  };
  
  window.getSmartParserStats = () => {
    return window.smartResumeParser?.getPerformanceStats();
  };
  
  // Auto-detect page type on load
  window.smartResumeParser.detectPageType();
  
  console.log('🚀 Smart Resume Parser loaded successfully');
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    if (!window.smartResumeParser) {
      window.smartResumeParser = new SmartResumeParser();
      window.smartResumeParser.init();
    }
  });
}