/**
 * Smart Resume Parser for JobScraper Extension
 * 基于阿里巴巴猎头平台页面截图分析的智能简历抓取引擎
 * 支持多种页面布局和智能策略选择
 */

class SmartResumeParser {
  constructor() {
    this.resumeData = null;
    this.isProcessing = false;
    this.config = null;
    
    // 智能提取策略系统
    this.strategies = {
      antTable: new AntDesignTableStrategy(),
      card: new CardLayoutStrategy(), 
      table: new GenericTableStrategy(),
      list: new ListItemStrategy(),
      div: new DivLayoutStrategy()
    };
    
    // 性能监控
    this.performance = {
      extractionTime: 0,
      strategyStats: {},
      errorLog: []
    };
    
    // 页面类型检测
    this.pageType = 'unknown';
  }

  /**
   * Initialize smart resume parser
   */
  init() {
    // Listen for messages from background script
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      this.handleMessage(message, sender, sendResponse);
    });
  }

  /**
   * Handle messages from background script
   */
  handleMessage(message, sender, sendResponse) {
    const startTime = performance.now();
    
    try {
      switch (message.action) {
        case 'INIT_RESUME':
        case 'START_RESUME_SCRAPE': // 添加对新 action 的支持
          this.initResumeScraping(message.data);
          break;
        case 'SCRAPE_RESUME_LIST':
          this.scrapeResumeList(message.data);
          break;
        case 'SCRAPE_RESUME_DETAIL':
          this.scrapeResumeDetail(message.data);
          break;
        case 'CLICK_NEXT_RESUME_PAGE':
          this.clickNextResumePage(message.data);
          break;
        default:
          break;
      }
    } catch (error) {
      this.logError('Message handling error', error);
      this.sendMessageToBackground({
        action: 'RESUME_SCRAPING_ERROR',
        data: { error: error.message }
      });
    } finally {
      this.performance.extractionTime += performance.now() - startTime;
    }
  }

  /**
   * Initialize resume scraping with intelligent page detection
   */
  async initResumeScraping(config) {
    try {
      this.isProcessing = true;
      this.config = config;

      // 智能页面类型检测 (仅作参考日志，不再阻断流程)
      const pageAnalysis = this.analyzePageType();
      console.log('Smart page analysis:', pageAnalysis);
      
      // 强制执行抓取，不再依赖置信度检查
      // 因为用户已经明确点击了"开始抓取"
      console.log('Force starting resume list scraping...');
      await this.scrapeResumeList(config);

    } catch (error) {
      this.logError('Resume scraping initialization error', error);
      this.sendMessageToBackground({
        action: 'RESUME_SCRAPING_ERROR',
        data: { error: error.message }
      });
    }
  }

  /**
   * Intelligent page type detection
   */
  analyzePageType() {
    const indicators = {
      url: {
        resumeManagement: window.location.href.includes('resumeManagement'),
        candidateList: window.location.href.includes('candidate') || window.location.href.includes('候选人'),
        resume: window.location.href.includes('resume') && !window.location.href.includes('resumeManagement'),
        detailPage: window.location.href.includes('resumeDetail') || 
                    window.location.href.includes('candidateDetail') ||
                    window.location.href.includes('/resume/') ||
                    window.location.href.includes('/candidate/')
      },
      dom: {
        antTable: document.querySelector('.ant-table') !== null,
        resumeList: document.querySelector('.resume-list') !== null,
        candidateList: document.querySelector('.candidate-list') !== null,
        tableRows: document.querySelectorAll('tbody tr').length > 5,
        pagination: document.querySelector('.ant-pagination') !== null,
        detailView: this.checkForDetailView()
      },
      content: {
        hasNameColumn: this.checkForNameColumn(),
        hasContactInfo: this.checkForContactInfo(),
        hasResumeRelatedText: this.checkForResumeText(),
        hasDetailContent: this.checkForDetailContent()
      }
    };

    // 计算页面类型置信度
    let score = 0;
    let type = 'unknown';
    
    // 列表页面检测 - 提高简历管理页面的权重
    const listScore = (
      (indicators.url.resumeManagement ? 0.5 : 0) +  // 提高权重到0.5
      (indicators.dom.antTable ? 0.2 : 0) +
      (indicators.dom.tableRows ? 0.2 : 0) +
      (indicators.content.hasNameColumn ? 0.2 : 0) +
      (indicators.dom.pagination ? 0.1 : 0)
    );

    // 详情页面检测 - 降低权重并更严格
    const detailScore = (
      (indicators.url.detailPage ? 0.4 : 0) +
      (indicators.dom.detailView ? 0.3 : 0) +
      (indicators.content.hasDetailContent ? 0.2 : 0) +
      (indicators.url.resume && !indicators.url.resumeManagement ? 0.1 : 0)
    );

    // 如果是简历管理页面，直接识别为列表页面
    if (indicators.url.resumeManagement) {
      type = 'list';
      score = Math.max(listScore, 0.8);
    } else if (listScore > detailScore && listScore > 0.4) {
      type = 'list';
      score = listScore;
    } else if (detailScore > 0.6) {
      type = 'detail';
      score = detailScore;
    }

    this.pageType = type;
    return { type, confidence: score, indicators };
  }

  checkForNameColumn() {
    const possibleSelectors = [
      'th:contains("姓名"), td:contains("姓名")',
      'th:contains("候选人"), td:contains("候选人")',
      '.ant-table th, .ant-table td'
    ];
    
    return possibleSelectors.some(selector => {
      try {
        const elements = document.querySelectorAll(selector.replace(':contains("姓名")', ''));
        return Array.from(elements).some(el => 
          el.textContent.includes('姓名') || 
          el.textContent.includes('候选人')
        );
      } catch (e) {
        return false;
      }
    });
  }

  checkForContactInfo() {
    const contactText = document.body.textContent;
    return contactText.includes('电话') || 
           contactText.includes('手机') || 
           contactText.includes('邮箱') ||
           contactText.includes('@');
  }

  checkForResumeText() {
    const resumeKeywords = ['简历', '工作经历', '教育经历', '项目经验', '技能'];
    const pageText = document.body.textContent;
    return resumeKeywords.some(keyword => pageText.includes(keyword));
  }

  checkForDetailView() {
    // 检查是否包含详情页特有元素
    const detailSelectors = [
      '.resume-detail',
      '.candidate-detail', 
      '.profile-detail',
      '.detail-header',
      '[data-testid="resume-detail"]',
      '.ant-descriptions'
    ];
    
    return detailSelectors.some(selector => 
      document.querySelector(selector) !== null
    ) || (
      // 或者包含很多文本内容且没有表格结构
      document.querySelectorAll('p, .ant-typography').length > 10 &&
      document.querySelectorAll('.ant-table tbody tr').length < 3
    );
  }

  checkForDetailContent() {
    // 检查是否包含详情页面特有的长文本内容
    const detailContentKeywords = [
      '详细描述', '工作描述', '项目描述', '职责描述',
      '教育背景', '工作履历', '职业经历',
      '个人信息', '联系方式', '基本资料'
    ];
    
    const pageText = document.body.textContent;
    return detailContentKeywords.some(keyword => pageText.includes(keyword));
  }

  /**
   * 页面结构调试分析 - 帮助诊断页面元素
   */
  async debugPageStructure() {
    const debugInfo = {
      timestamp: new Date().toISOString(),
      url: window.location.href,
      pageSize: {
        bodyText: document.body.textContent.length,
        bodyHTML: document.documentElement.outerHTML.length,
        allElements: document.querySelectorAll('*').length
      },
      tables: {
        total: document.querySelectorAll('table').length,
        withBody: document.querySelectorAll('table tbody').length,
        withRows: document.querySelectorAll('table tbody tr').length
      },
      antDesign: {
        table: !!document.querySelector('.ant-table'),
        card: !!document.querySelector('.ant-card'),
        row: document.querySelectorAll('.ant-table-row').length,
        tbody: !!document.querySelector('.ant-table-tbody')
      },
      candidateElements: {
        candidateSelector: document.querySelectorAll('[class*="candidate"]').length,
        resumeSelector: document.querySelectorAll('[class*="resume"]').length,
        nameSelectors: [
          { name: 'td', count: document.querySelectorAll('td').length },
          { name: 'th', count: document.querySelectorAll('th').length },
          { name: 'a', count: document.querySelectorAll('a').length },
          { name: 'li', count: document.querySelectorAll('li').length },
          { name: 'div', count: document.querySelectorAll('div').length }
        ]
      },
      textContent: {
        keywords: ['姓名', '候选人', '简历', '电话', '邮箱', '@'],
        matches: {}
      }
    };

    // 检查关键词匹配
    const bodyText = document.body.textContent;
    debugInfo.textContent.matches = {};
    debugInfo.textContent.keywords.forEach(keyword => {
      debugInfo.textContent.matches[keyword] = bodyText.includes(keyword);
    });

    // 保存调试信息并发送给background
    console.log('🔍 页面结构调试信息:', debugInfo);
    
    // 在控制台打印DOM元素详细信息
    await this.printDOMElements();
    
    this.sendMessageToBackground({
      action: 'RESUME_DEBUG_INFO',
      data: {
        debugInfo: debugInfo,
        message: '页面结构分析完成，请检查控制台查看详细信息'
      }
    });

    return debugInfo;
  }

  /**
   * 在控制台打印DOM元素详细信息
   */
  async printDOMElements() {
    console.log('='.repeat(80));
    console.log('🔍 页面DOM元素详细分析');
    console.log('='.repeat(80));
    
    // 1. 打印所有表格
    console.log('\n📊 所有表格元素:');
    const tables = document.querySelectorAll('table');
    tables.forEach((table, index) => {
      console.log(`\n📋 表格 ${index + 1}:`);
      console.log(`  - class: ${table.className}`);
      console.log(`  - id: ${table.id}`);
      console.log(`  - rows: ${table.rows?.length || 0}`);
      console.log(`  - tbody: ${table.querySelector('tbody') ? '有' : '无'}`);
      
      // 打印前3行的内容
      const rows = table.querySelectorAll('tr');
      for (let i = 0; i < Math.min(3, rows.length); i++) {
        const cells = rows[i].querySelectorAll('td, th');
        const rowContent = Array.from(cells).map(cell => {
          const text = cell.textContent.trim();
          return text.length > 20 ? text.substring(0, 20) + '...' : text;
        });
        console.log(`    行 ${i + 1}: ${rowContent.join(' | ')}`);
      }
    });
    
    // 2. 打印所有包含关键词的元素
    console.log('\n🔤 包含关键词的元素:');
    const keywords = ['姓名', '候选人', '简历', '电话', '邮箱'];
    keywords.forEach(keyword => {
      const elements = this.findElementsWithText(keyword);
      console.log(`\n包含"${keyword}"的元素 (${elements.length}个):`);
      elements.slice(0, 5).forEach((element, index) => {
        const path = this.getElementPath(element);
        console.log(`  ${index + 1}. ${path} -> "${element.textContent.trim().substring(0, 50)}..."`);
      });
    });
    
    // 3. 打印类名统计
    console.log('\n🎨 页面类名统计:');
    const allElements = document.querySelectorAll('*');
    const classCounts = {};
    allElements.forEach(el => {
      if (el.className && typeof el.className === 'string') {
        el.className.split(' ').forEach(className => {
          if (className.trim()) {
            classCounts[className.trim()] = (classCounts[className.trim()] || 0) + 1;
          }
        });
      }
    });
    
    const topClasses = Object.entries(classCounts)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 10);
    
    topClasses.forEach(([className, count]) => {
      console.log(`  ${className}: ${count}`);
    });
    
    // 4. 打印所有链接
    console.log('\n🔗 页面链接 (前10个):');
    const links = document.querySelectorAll('a[href]');
    links.slice(0, 10).forEach((link, index) => {
      const text = link.textContent.trim().replace(/\s+/g, ' ');
      const href = link.href;
      console.log(`  ${index + 1}. ${text.substring(0, 30)} -> ${href}`);
    });
    
    console.log('='.repeat(80));
  }

  /**
   * 查找包含特定文本的元素
   */
  findElementsWithText(text) {
    const elements = [];
    const walker = document.createTreeWalker(
      document.body,
      NodeFilter.SHOW_ELEMENT,
      {
        acceptNode: function(node) {
          if (node.textContent && node.textContent.includes(text)) {
            return NodeFilter.FILTER_ACCEPT;
          }
          return NodeFilter.FILTER_SKIP;
        }
      }
    );
    
    let node;
    while (node = walker.nextNode()) {
      elements.push(node);
    }
    
    return elements;
  }

  /**
   * 获取元素的CSS路径
   */
  getElementPath(element) {
    const path = [];
    let current = element;
    
    while (current && current !== document.body) {
      let selector = current.tagName.toLowerCase();
      
      if (current.id) {
        selector += `#${current.id}`;
        path.unshift(selector);
        break;
      } else {
        const classes = current.className.split(' ').filter(c => c.trim());
        if (classes.length > 0) {
          selector += '.' + classes.slice(0, 2).join('.');
        }
        
        const siblings = Array.from(current.parentNode.children).filter(
          sibling => sibling.tagName === current.tagName
        );
        
        if (siblings.length > 1) {
          const index = siblings.indexOf(current) + 1;
          selector += `:nth-child(${index})`;
        }
      }
      
      path.unshift(selector);
      current = current.parentNode;
    }
    
    return path.join(' > ');
  }

  /**
   * Smart resume list scraping with strategy selection
   */
  async scrapeResumeList(config) {
    const startTime = performance.now();
    
    try {
      const pageAnalysis = this.analyzePageType();
      
      // 如果既不是列表页，也没有检测到任何类似表格/列表的结构，且链接数很少，可能是不相关的 iframe
      const linkCount = document.querySelectorAll('a').length;
      if (pageAnalysis.type !== 'list' && linkCount < 5) {
          // 静默退出，不报错，可能是无关 frame
          return;
      }

      // 根据页面类型选择最佳策略
      const strategy = this.selectBestStrategy(pageAnalysis);
      console.log(`🎯 [Frame: ${window.location.href}] 选择提取策略: ${strategy.constructor.name}`);
      
      const resumes = await strategy.extract(this);
      console.log(`📋 [Frame: ${window.location.href}] 提取结果: ${resumes.length} 个简历`);

      // 如果提取结果为空，不要抛出错误，只是静默返回
      // 因为在多 frame 环境下，很多 frame 确实没有数据
      if (resumes.length === 0) {
        return;
      }

      // 记录策略性能
      this.updateStrategyStats(strategy.constructor.name, performance.now() - startTime);

      this.sendMessageToBackground({
        action: 'RESUME_LINKS_EXTRACTED',
        data: {
          resumes: resumes,
          pageCount: this.getCurrentPageNumber(),
          hasNextPage: this.hasNextPage(),
          strategy: strategy.constructor.name,
          analysis: pageAnalysis
        }
      });
    } catch (error) {
      this.logError('Resume list scraping error', error);
      this.sendMessageToBackground({
        action: 'RESUME_SCRAPING_ERROR',
        data: { error: error.message }
      });
    }
  }

  /**
   * Select best extraction strategy based on page analysis
   */
  selectBestStrategy(analysis) {
    const { indicators } = analysis;
    
    if (indicators.dom.antTable) {
      return this.strategies.antTable;
    } else if (indicators.dom.resumeList || indicators.dom.candidateList) {
      return this.strategies.card;
    } else if (indicators.dom.tableRows) {
      return this.strategies.table;
    } else {
      return this.strategies.list;
    }
  }

  /**
   * Enhanced resume detail extraction
   */
  async scrapeResumeDetail(config) {
    // 快速检查：当前 frame 是否包含简历内容？
    // 如果页面文字太少，或者不包含关键信息，很可能只是一个导航栏 iframe 或广告 iframe
    const bodyText = document.body.innerText;
    if (bodyText.length < 50 || 
        (!bodyText.includes('姓名') && !bodyText.includes('简历') && !bodyText.includes('候选人'))) {
      // 静默忽略，不报错，让其他 frame 去处理
      return;
    }

    const startTime = performance.now();
    
    try {
      // 等待页面加载完成
      await this.waitForPageLoad();

      // 额外等待关键内容出现（针对动态渲染的页面）
      console.log('等待页面内容渲染...');
      await this.waitForContent(['基本信息', '工作经历', '教育经历', '求职意向', '联系方式', '电话'], 5000);

      // 自动滚动以触发懒加载
      console.log('正在滚动页面以触发懒加载...');
      await this.autoScroll();
      
      const detail = await this.extractResumeDetail();
      
      // DEBUG: 打印抓取结果
      console.log('%c [FINAL RESULT] 抓取结果:', 'background: #222; color: #bada55; font-size: 14px', detail);

      // 检查数据质量
      if (detail.basicInfo.name === '未知姓名' && !detail.detailedInfo.experience) {
        console.warn('⚠️ 抓取到的数据似乎为空，可能页面尚未完全加载或需要登录');
        // 可以选择在这里抛出错误，或者记录警告
      }

      this.updateStrategyStats('detail', performance.now() - startTime);

      this.sendMessageToBackground({
        action: 'RESUME_DETAIL_EXTRACTED',
        data: {
          resumeId: config.resumeId,
          detail: detail,
          extractionTime: performance.now() - startTime
        }
      });
    } catch (error) {
      this.logError('Resume detail extraction error', error);
      this.sendMessageToBackground({
        action: 'RESUME_DETAIL_ERROR',
        data: { 
          resumeId: config.resumeId,
          error: error.message 
        }
      });
    }
  }

  /**
   * Wait for specific text content to appear
   */
  async waitForContent(keywords, timeout = 5000) {
    const start = Date.now();
    return new Promise((resolve) => {
      const check = () => {
        const text = document.body.textContent;
        const found = keywords.some(k => text.includes(k));
        
        if (found) {
          console.log(`✅ 发现关键内容，耗时: ${Date.now() - start}ms`);
          resolve(true);
        } else if (Date.now() - start > timeout) {
          console.warn(`⚠️ 等待内容超时 (${timeout}ms)`);
          resolve(false);
        } else {
          setTimeout(check, 200);
        }
      };
      check();
    });
  }

  /**
   * Auto scroll to bottom to trigger lazy loading
   */
  async autoScroll() {
    return new Promise((resolve) => {
      let totalHeight = 0;
      const distance = 300;
      const timer = setInterval(() => {
        const scrollHeight = document.body.scrollHeight;
        window.scrollBy(0, distance);
        totalHeight += distance;

        if (totalHeight >= scrollHeight) {
          clearInterval(timer);
          // 滚回顶部，或者就留在底部
          resolve();
        }
      }, 100);
    });
  }

  /**
   * Comprehensive resume detail extraction
   */
  async extractResumeDetail() {
    return {
      // 基础信息
      basicInfo: this.extractBasicInfo(),
      
      // 职业信息
      professionalInfo: this.extractProfessionalInfo(),
      
      // 详细信息
      detailedInfo: this.extractDetailedInfo(),
      
      // 页面信息
      pageInfo: {
        url: window.location.href,
        title: document.title,
        extractedAt: new Date().toISOString(),
        pageType: this.pageType
      }
    };
  }

    /**
     * Enhanced basic information extraction with RegExp fallback
     */
    extractBasicInfo() {
      // 1. 尝试常用选择器
      const nameSelectors = [
        '.resume-name, .candidate-name, [class*="name"]',
        'h1, h2, h3',
        '.ant-typography-title, .title',
        '[data-testid*="name"], [data-role*="name"]',
        'strong, b'
      ];
      
      let name = this.extractFieldBySelectors(nameSelectors);
  
      // 2. 尝试 TreeWalker
      if (!name || name === '未知姓名') {
        name = this.extractFieldByLabel('姓名');
      }
      
          // 3. 终极策略：全文本正则暴力提取
          if (!name || name === '未知姓名') {
            const text = document.body.innerText;
            // 针对 "姓名：\t\n王钟灵" 这种格式
            // \s 包括了 \t, \n, \r 和空格
            const nameMatch = text.match(/(?:姓名|候选人)[:：\s]+([\u4e00-\u9fa5]{2,5})(?:\s|$)/m);
            if (nameMatch) name = nameMatch[1].trim();
          }
      
          // 4. 电话暴力提取
          let phone = this.extractPhone();
          if (!phone) {
              const text = document.body.innerText;
              // 针对 "手机号码：\t\n86 - 15026993066"
              // 匹配: Label -> 空白 -> (86 -> 空白 -> - -> 空白 -> 号码)
              const pMatch = text.match(/(?:手机号码|手机|电话)[:：\s]+((?:86\s*-\s*)?1[3-9]\d{9})/);
              if (pMatch) {
                  phone = pMatch[1].replace(/\s+/g, '').replace(/-/g, '');
              } else {
                  // 尝试更宽泛的匹配，不带 Label，但在 Label 附近
                  // 查找 "手机号码" 后面 50 个字符内的数字
                  const labelIdx = text.indexOf('手机号码');
                  if (labelIdx !== -1) {
                      const subText = text.substring(labelIdx, labelIdx + 50);
                      const numMatch = subText.match(/(1[3-9]\d{9})/);
                      if (numMatch) phone = numMatch[1];
                  }
              }
          }
      
          // 5. 邮箱暴力提取
          let email = this.extractEmail();
          if (!email) {
              const text = document.body.innerText;
              const eMatch = text.match(/([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/);
              if (eMatch) email = eMatch[1];
          }
      
          const scanResult = this.scanPageForKeyValues();
          
          // 6. 现居住地暴力提取
          let location = this.extractLocation() || 
                        this.extractFieldByLabel(['现居地', '现居住地', '所在城市', '居住地']) || 
                        scanResult['现居地'] || scanResult['现居住地'] || scanResult['所在城市'];
                        
          if (!location) {
              const text = document.body.innerText;
              // "现居住地：\t\n中国-广东-广州"
              const locMatch = text.match(/(?:现居住地|现居地)[:：\s]+([^\n\r]+)/);
              if (locMatch && locMatch[1]) location = locMatch[1].trim();
          }
      
          return {
            name: name || '未知姓名',
            phone: phone,
            email: email,
            location: location
          };
        }  /**
   * Scan entire page for "Key: Value" patterns
   */
  scanPageForKeyValues() {
    const result = {};
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let node;
    
    while (node = walker.nextNode()) {
      const text = node.textContent.trim();
      // 匹配 "Key: Value" 或 "Key：Value"
      if (text.includes(':') || text.includes('：')) {
        const parts = text.split(/[:：]/);
        if (parts.length >= 2) {
          const key = parts[0].trim();
          let value = parts.slice(1).join(':').trim();
          
          if (!value && key.length < 10) {
             // 简单的向后查找逻辑，配合 TreeWalker 使用更佳，这里简化
          }
          
          if (key && value && key.length < 20 && value.length < 100) {
            result[key] = value;
          }
        }
      }
    }
    return result;
  }

  /**
   * Extract text content between two keywords (Text Slicing Strategy)
   */
  extractTextBetween(startKeywords, stopKeywords) {
    const text = document.body.innerText || document.body.textContent; // innerText retains formatting better
    let startIndex = -1;
    let matchedStartKw = '';
    
    for (const kw of startKeywords) {
      const idx = text.indexOf(kw);
      if (idx !== -1) {
        // 简单的防误判：关键词应该是独立的一行，或者前面是换行符
        // 这里简单处理，只要找到就行
        startIndex = idx;
        matchedStartKw = kw;
        break;
      }
    }
    
    if (startIndex === -1) return null;
    
    // Find the nearest stop keyword
    let bestStopIndex = text.length;
    for (const kw of stopKeywords) {
      const idx = text.indexOf(kw, startIndex + matchedStartKw.length);
      if (idx !== -1 && idx < bestStopIndex) {
        bestStopIndex = idx;
      }
    }
    
    // Extract content
    const rawContent = text.substring(startIndex + matchedStartKw.length, bestStopIndex).trim();
    
    // Split into lines and clean up
    const lines = rawContent.split('\n')
      .map(line => line.trim())
      .filter(line => line.length > 0); // 过滤空行
      
    return lines.length > 0 ? lines : null;
  }

  /**
   * Education experience extraction
   */
  extractEducation() {
    // 1. 尝试 Text Slicing
    const textData = this.extractTextBetween(
      ['教育经历', 'Education', '学历信息'], 
      ['工作经历', '工作经验', '项目经历', '项目经验', '技能', '语言', '证书', '自我评价']
    );
    if (textData) return textData;

    // 2. 尝试 DOM Section
    const educationSections = this.findSection(['教育经历', 'Education', '学历']);
    if (!educationSections.length) return null;
    
    const educationData = [];
    educationSections.forEach(section => {
      const rows = section.querySelectorAll('tr, .education-item, li');
      rows.forEach(row => {
        const text = row.textContent.trim();
        if (text.length > 10) educationData.push(text);
      });
    });
    
    return educationData.length > 0 ? educationData : null;
  }

  /**
   * Work experience extraction
   */
  extractExperience() {
    // 1. 尝试 Text Slicing
    const textData = this.extractTextBetween(
      ['工作经历', 'Experience', '工作经验'], 
      ['教育经历', '项目经历', '项目经验', '技能', 'Skills', '自我评价']
    );
    if (textData) return textData;

    // 2. 尝试 DOM Section
    const experienceSections = this.findSection(['工作经历', 'Experience', '工作经验']);
    if (!experienceSections.length) return null;
    
    const experienceData = [];
    experienceSections.forEach(section => {
      const items = section.querySelectorAll('.experience-item, .work-item, li, tr');
      items.forEach(item => {
        const text = item.textContent.trim();
        if (text.length > 15) experienceData.push(text);
      });
    });
    
    return experienceData.length > 0 ? experienceData : null;
  }

  /**
   * Skills extraction
   */
  extractSkills() {
    const textData = this.extractTextBetween(
      ['技能', 'Skills', '专业技能', '语言能力'], 
      ['工作经历', '项目经历', '教育经历', '自我评价']
    );
    if (textData) return textData;

    const skillsSections = this.findSection(['技能', 'Skills', '专业技能']);
    if (!skillsSections.length) return null;
    
    const skillsData = [];
    skillsSections.forEach(section => {
      const tags = section.querySelectorAll('.skill-tag, .tag, span, .badge');
      tags.forEach(tag => {
        const text = tag.textContent.trim();
        if (text.length > 0 && text.length < 20) skillsData.push(text);
      });
    });
    return skillsData.length > 0 ? skillsData : null;
  }

  /**
   * Projects extraction
   */
  extractProjects() {
    const textData = this.extractTextBetween(
      ['项目经历', 'Projects', '项目经验'], 
      ['工作经历', '教育经历', '技能', '自我评价']
    );
    if (textData) return textData;

    const projectSections = this.findSection(['项目经验', 'Projects', '项目']);
    if (!projectSections.length) return null;
    
    const projectData = [];
    projectSections.forEach(section => {
      const items = section.querySelectorAll('.project-item, .item, li, tr');
      items.forEach(item => {
        const text = item.textContent.trim();
        if (text.length > 20) projectData.push(text);
      });
    });
    return projectData.length > 0 ? projectData : null;
  }

  /**
   * Professional information extraction
   */
  extractProfessionalInfo() {
    return {
      currentTitle: this.extractCurrentTitle() || this.extractFieldByLabel('当前职位') || this.extractFieldByLabel('职位'),
      yearsExp: this.extractYearsOfExperience(),
      expectedTitle: this.extractExpectedTitle() || this.extractFieldByLabel('期望职位'),
      expectedSalary: this.extractExpectedSalary() || this.extractFieldByLabel('期望薪资')
    };
  }

  /**
   * Extract text content next to a specific label (e.g. "Name:")
   * Uses TreeWalker to find the next non-empty text node, handling "Label [newline] Value" layout.
   */
  extractFieldByLabel(labelKeywords) {
    if (!Array.isArray(labelKeywords)) labelKeywords = [labelKeywords];
    
    // 1. 构建关键词正则
    const patterns = labelKeywords.map(k => k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')); 
    
    // 2. 使用 TreeWalker 遍历所有文本节点
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let node;
    
    while (node = walker.nextNode()) {
      const text = node.textContent.trim();
      if (!text) continue;
      
      // 检查当前节点是否包含关键词
      const isMatch = patterns.some(pattern => {
        // 匹配 "姓名" 或 "姓名：" 或 "姓名:"
        return new RegExp(`^${pattern}[:：]?$`).test(text) || 
               (text.includes(pattern) && text.length < 10);
      });

      if (isMatch) {
        // 找到了 Label！现在找 Value。
        
        // 情况 A: Value 在同一个节点 (例如 "姓名：王守正")
        const parts = text.split(/[:：]/);
        if (parts.length > 1 && parts[1].trim()) {
          return parts[1].trim();
        }
        
        // 情况 B: Value 在下一个节点 (例如 "姓名：" [换行] "王守正")
        // 继续遍历 TreeWalker 找下一个非空文本
        // 注意：这里我们需要克隆一个 walker 或者小心操作，不要破坏外层循环
        // 简单起见，我们在外层循环里直接继续 nextNode
        
        let valueNode = walker.nextNode();
        // 跳过纯空白节点
        while (valueNode && !valueNode.textContent.trim()) {
          valueNode = walker.nextNode();
        }
        
        if (valueNode) {
          const valText = valueNode.textContent.trim();
          // 排除掉也是 Label 的情况（例如 "姓名：" 后面紧跟着 "电话："，说明姓名为空）
          const isNextLabel = patterns.some(p => valText.includes(p));
          if (!isNextLabel) {
            return valText;
          }
        }
      }
    }
    return null;
  }

  /**
   * Find the text with the largest font size (usually the name)
   */
  findLargestText() {
    let maxSize = 0;
    let maxEl = null;
    
    const elements = document.querySelectorAll('h1, h2, div, span, p, strong');
    elements.forEach(el => {
      const fontSize = parseFloat(window.getComputedStyle(el).fontSize);
      const text = el.textContent.trim();
      if (fontSize > maxSize && text.length > 1 && text.length < 10 && !text.includes('简历')) {
        maxSize = fontSize;
        maxEl = el;
      }
    });
    
    return maxEl ? maxEl.textContent.trim() : null;
  }

  /**
   * Detailed information extraction
   */
  extractDetailedInfo() {
    return {
      education: this.extractEducation(),
      experience: this.extractExperience(),
      skills: this.extractSkills(),
      projects: this.extractProjects(),
      summary: this.extractSummary()
    };
  }

  /**
   * Phone number extraction with multiple patterns
   */
  extractPhone() {
    const phonePatterns = [
      /(?:电话|手机|Phone|Tel|手机号码)[:：]?\s*([0-9+\-\s]{8,})/i, // 宽泛匹配
      /(\+?86\s*-\s*[0-9]{11})/, // 86 - 138...
      /(\+?86\s*[0-9]{11})/,     // 86 138...
      /(1[3-9]\d{9})/            // 138...
    ];
    
    const pageText = document.body.textContent;
    
    for (const pattern of phonePatterns) {
      const match = pageText.match(pattern);
      if (match) {
        // 清理号码
        let phone = match[1].trim();
        if (phone.length < 6) continue;
        return phone;
      }
    }
    
    return null;
  }

  /**
   * Email extraction with validation
   */
  extractEmail() {
    const emailPattern = /([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/;
    const match = document.body.textContent.match(emailPattern);
    return match ? match[1] : null;
  }

  /**
   * Location extraction
   */
  extractLocation() {
    const locationPatterns = [
      /(?:地址|现居地|Location)[:：]\s*([^,\n，]{2,20})/i,
      /([^,\n，]{2,10}[省市区][^,\n，]{0,10})/,
      /([^,\n，]{2,10}[市][^,\n，]{0,15})/
    ];
    
    for (const pattern of locationPatterns) {
      const match = document.body.textContent.match(pattern);
      if (match) {
        return match[1].trim();
      }
    }
    
    return null;
  }

  /**
   * Current position extraction
   */
  extractCurrentTitle() {
    const titleSelectors = [
      '[class*="position"], [class*="title"], [class*="job"]',
      'strong:contains("职位"), em:contains("职位")',
      '.ant-descriptions-item-label'
    ];
    
    return this.extractFieldBySelectors(titleSelectors);
  }

  /**
   * Years of experience extraction
   */
  extractYearsOfExperience() {
    const expPattern = /(?:经验|工作年限)[:：]\s*([0-9]+(?:\.[0-9]+)?)\s*年/i;
    const match = document.body.textContent.match(expPattern);
    return match ? `${match[1]}年` : null;
  }

  /**
   * Expected position extraction
   */
  extractExpectedTitle() {
    const expPattern = /(?:期望职位|意向职位)[:：]\s*([^,\n，]{2,20})/i;
    const match = document.body.textContent.match(expPattern);
    return match ? match[1].trim() : null;
  }

  /**
   * Expected salary extraction
   */
  extractExpectedSalary() {
    const salaryPattern = /(?:期望薪资|期望收入)[:：]\s*([^,\n，]{2,20})/i;
    const match = document.body.textContent.match(salaryPattern);
    return match ? match[1].trim() : null;
  }

  /**
   * Education experience extraction
   */
  extractEducation() {
    const educationSections = this.findSection(['教育经历', 'Education', '学历']);
    if (!educationSections.length) return null;
    
    const educationData = [];
    
    educationSections.forEach(section => {
      const rows = section.querySelectorAll('tr, .education-item, li');
      rows.forEach(row => {
        const text = row.textContent.trim();
        if (text.length > 10) {
          educationData.push(text);
        }
      });
    });
    
    return educationData.length > 0 ? educationData : null;
  }

  /**
   * Work experience extraction
   */
  extractExperience() {
    const experienceSections = this.findSection(['工作经历', 'Experience', '工作经验']);
    if (!experienceSections.length) return null;
    
    const experienceData = [];
    
    experienceSections.forEach(section => {
      const items = section.querySelectorAll('.experience-item, .work-item, li, tr');
      items.forEach(item => {
        const text = item.textContent.trim();
        if (text.length > 15) {
          experienceData.push(text);
        }
      });
    });
    
    return experienceData.length > 0 ? experienceData : null;
  }

  /**
   * Skills extraction
   */
  extractSkills() {
    const skillsSections = this.findSection(['技能', 'Skills', '专业技能']);
    if (!skillsSections.length) return null;
    
    const skillsData = [];
    
    skillsSections.forEach(section => {
      const tags = section.querySelectorAll('.skill-tag, .tag, span, .badge');
      tags.forEach(tag => {
        const text = tag.textContent.trim();
        if (text.length > 0 && text.length < 20) {
          skillsData.push(text);
        }
      });
    });
    
    return skillsData.length > 0 ? skillsData : null;
  }

  /**
   * Projects extraction
   */
  extractProjects() {
    const projectSections = this.findSection(['项目经验', 'Projects', '项目']);
    if (!projectSections.length) return null;
    
    const projectData = [];
    
    projectSections.forEach(section => {
      const items = section.querySelectorAll('.project-item, .item, li, tr');
      items.forEach(item => {
        const text = item.textContent.trim();
        if (text.length > 20) {
          projectData.push(text);
        }
      });
    });
    
    return projectData.length > 0 ? projectData : null;
  }

  /**
   * Summary extraction
   */
  extractSummary() {
    const summarySections = this.findSection(['自我评价', 'Summary', '个人简介']);
    if (!summarySections.length) return null;
    
    const summaryText = summarySections
      .map(section => section.textContent.trim())
      .filter(text => text.length > 10)
      .join('\n');
    
    return summaryText || null;
  }

  /**
   * Universal field extraction by selectors
   */
  extractFieldBySelectors(selectors) {
    for (const selector of selectors) {
      try {
        const element = document.querySelector(selector);
        if (element) {
          const text = element.textContent.trim();
          if (text && text.length > 0) {
            return text;
          }
        }
      } catch (e) {
        // 继续尝试下一个选择器
      }
    }
    return null;
  }

  /**
   * Find sections by keywords
   */
  findSection(keywords) {
    const sections = [];
    
    keywords.forEach(keyword => {
      const elements = document.querySelectorAll('*');
      elements.forEach(element => {
        if (element.textContent.includes(keyword)) {
          // 向上查找section容器
          let section = element;
          while (section && section !== document.body) {
            if (section.className.includes('section') || 
                section.className.includes('content') ||
                section.className.includes('detail') ||
                section.tagName === 'SECTION' ||
                section.tagName === 'DIV') {
              sections.push(section);
              break;
            }
            section = section.parentElement;
          }
        }
      });
    });
    
    return sections;
  }

  /**
   * Wait for page load with timeout
   */
  async waitForPageLoad(timeout = 10000) {
    return new Promise((resolve, reject) => {
      if (document.readyState === 'complete') {
        resolve();
        return;
      }

      const timeoutId = setTimeout(() => {
        reject(new Error('Page load timeout'));
      }, timeout);

      window.addEventListener('load', () => {
        clearTimeout(timeoutId);
        resolve();
      });
    });
  }

  /**
   * Check if there is a next page
   */
  hasNextPage() {
    const nextPageSelectors = [
      '.ant-pagination .ant-pagination-next:not(.ant-pagination-disabled)',
      '.pagination .next:not(.disabled)',
      'a:contains("下一页"), a:contains(">"), a[aria-label="Next"]',
      'button:contains("下一页"), button[aria-label="Next"]'
    ];

    for (const selector of nextPageSelectors) {
      try {
        const nextButton = document.querySelector(selector.replace(':contains("下一页")', '').replace(':contains(">")', ''));
        if (nextButton) {
          const text = nextButton.textContent.toLowerCase();
          const isDisabled = nextButton.classList.contains('disabled') || 
                           nextButton.classList.contains('ant-pagination-disabled');
          
          if (!isDisabled && (text.includes('下一页') || text.includes('>') || text.includes('next'))) {
            return true;
          }
        }
      } catch (e) {
        continue;
      }
    }

    // 检查URL参数中的页码
    const urlParams = new URLSearchParams(window.location.search);
    const currentPage = parseInt(urlParams.get('page') || '1');
    const totalPages = parseInt(urlParams.get('totalPage') || '0');
    
    if (totalPages > 0 && currentPage < totalPages) {
      return true;
    }

    return false;
  }

  /**
   * Click next page button
   */
  async clickNextResumePage(config) {
    try {
      const nextButtonSelectors = [
        '.ant-pagination .ant-pagination-next:not(.ant-pagination-disabled) a',
        '.pagination .next:not(.disabled) a, .pagination .next:not(.disabled) button',
        'a:contains("下一页"), a[aria-label="Next"]',
        'button:contains("下一页"), button[aria-label="Next"]'
      ];

      let nextButton = null;
      for (const selector of nextButtonSelectors) {
        try {
          nextButton = document.querySelector(selector.replace(':contains("下一页")', ''));
          if (nextButton) break;
        } catch (e) {
          continue;
        }
      }

      if (!nextButton) {
        // 尝试使用href跳转
        const currentPage = this.getCurrentPageNumber();
        const nextPage = currentPage + 1;
        const baseUrl = window.location.origin + window.location.pathname;
        const nextUrl = `${baseUrl}?page=${nextPage}`;
        
        window.location.href = nextUrl;
        return;
      }

      nextButton.click();
      
      // 等待页面加载
      await this.sleep(2000);
      await this.waitForPageLoad();

      this.sendMessageToBackground({
        action: 'NEXT_PAGE_CLICKED',
        data: {
          success: true,
          newPage: this.getCurrentPageNumber()
        }
      });
    } catch (error) {
      this.logError('Next page click error', error);
      this.sendMessageToBackground({
        action: 'NEXT_PAGE_CLICK_ERROR',
        data: { error: error.message }
      });
    }
  }

  /**
   * Get current page number
   */
  getCurrentPageNumber() {
    // 从页面元素获取
    const pageSelectors = [
      '.ant-pagination .ant-pagination-item-active',
      '.pagination .current, .pagination .active',
      '[aria-label*="页"], [aria-label*="Page"]'
    ];

    for (const selector of pageSelectors) {
      try {
        const activeElement = document.querySelector(selector);
        if (activeElement) {
          const pageText = activeElement.textContent.trim();
          const pageNum = parseInt(pageText);
          if (!isNaN(pageNum) && pageNum > 0) {
            return pageNum;
          }
        }
      } catch (e) {
        continue;
      }
    }

    // 从URL参数获取
    const urlParams = new URLSearchParams(window.location.search);
    const page = parseInt(urlParams.get('page') || '1');
    return page;
  }

  /**
   * Sleep utility
   */
  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  /**
   * Send message to background script
   */
  sendMessageToBackground(message) {
    chrome.runtime.sendMessage(message);
  }

  /**
   * Performance tracking utilities
   */
  updateStrategyStats(strategyName, time) {
    if (!this.performance.strategyStats[strategyName]) {
      this.performance.strategyStats[strategyName] = {
        count: 0,
        totalTime: 0,
        avgTime: 0
      };
    }
    
    const stats = this.performance.strategyStats[strategyName];
    stats.count++;
    stats.totalTime += time;
    stats.avgTime = stats.totalTime / stats.count;
  }

  /**
   * Error logging
   */
  logError(type, error) {
    const errorEntry = {
      type,
      message: error.message,
      timestamp: new Date().toISOString(),
      url: window.location.href,
      stack: error.stack
    };
    
    this.performance.errorLog.push(errorEntry);
    
    // 保持错误日志大小在合理范围内
    if (this.performance.errorLog.length > 100) {
      this.performance.errorLog = this.performance.errorLog.slice(-50);
    }
    
    console.error(`[SmartResumeParser] ${type}:`, error);
  }

  /**
   * Get performance statistics
   */
  getStats() {
    return {
      performance: this.performance,
      pageType: this.pageType,
      strategies: Object.keys(this.performance.strategyStats),
      uptime: Date.now() - (this.startTime || Date.now())
    };
  }

  /**
   * Debug page structure
   */
  debugPageStructure() {
    const debugInfo = {
      url: window.location.href,
      title: document.title,
      pageType: this.pageType,
      analysis: this.analyzePageType(),
      selectors: {
        antTable: !!document.querySelector('.ant-table'),
        resumeList: !!document.querySelector('.resume-list'),
        candidateList: !!document.querySelector('.candidate-list'),
        tableRows: document.querySelectorAll('tbody tr').length,
        pagination: !!document.querySelector('.ant-pagination'),
        nameColumn: this.checkForNameColumn(),
        contactInfo: this.checkForContactInfo(),
        resumeText: this.checkForResumeText()
      },
      performance: this.performance
    };
    
    console.log('[SmartResumeParser] Page Structure Debug:', debugInfo);
    return debugInfo;
  }
}

/**
 * Extraction Strategy Classes
 */

// AntDesign Table Strategy
class AntDesignTableStrategy {
  async extract(parser) {
    const resumes = [];
    const rows = document.querySelectorAll('.ant-table-tbody tr');
    
    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      const resumeData = parser.extractRowData(row, i);
      if (resumeData) {
        resumes.push(resumeData);
      }
    }
    
    return resumes;
  }
}

// Card Layout Strategy  
class CardLayoutStrategy {
  async extract(parser) {
    const resumes = [];
    const cards = document.querySelectorAll('.resume-card, .candidate-card, [class*="candidate"], [class*="resume"]');
    
    for (let i = 0; i < cards.length; i++) {
      const card = cards[i];
      const resumeData = parser.extractRowData(card, i);
      if (resumeData) {
        resumes.push(resumeData);
      }
    }
    
    return resumes;
  }
}

// Generic Table Strategy
class GenericTableStrategy {
  async extract(parser) {
    const resumes = [];
    const rows = document.querySelectorAll('tbody tr, .table-row, .list-item');
    
    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      const resumeData = parser.extractRowData(row, i);
      if (resumeData) {
        resumes.push(resumeData);
      }
    }
    
    return resumes;
  }
}

// List Item Strategy
class ListItemStrategy {
  async extract(parser) {
    const resumes = [];
    const items = document.querySelectorAll('li, .item, .list-item');
    
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      const resumeData = parser.extractRowData(item, i);
      if (resumeData) {
        resumes.push(resumeData);
      }
    }
    
    return resumes;
  }
}

// Div Layout Strategy
class DivLayoutStrategy {
  async extract(parser) {
    const resumes = [];
    const divs = document.querySelectorAll('div[class*="resume"], div[class*="candidate"], div[class*="item"]');
    
    for (let i = 0; i < divs.length; i++) {
      const div = divs[i];
      const resumeData = parser.extractRowData(div, i);
      if (resumeData) {
        resumes.push(resumeData);
      }
    }
    
    return resumes;
  }
}

// Enhanced row data extraction
SmartResumeParser.prototype.extractRowData = function(row, index) {
  try {
    let name = this.extractNameFromRow(row);
    const link = this.extractLinkFromRow(row);
    const id = this.extractIdFromRow(row);
    
    // 如果有链接但没有名字，不要直接丢弃
    if (!name && link) {
       name = `候选人_${index + 1}`;
    }

    // 只有当链接也没有时，才认为是无效数据
    if (!link) {
      return null;
    }
    
    // 过滤表头行
    if (name && (name.includes('姓名') || name.includes('操作'))) {
      return null;
    }
    
    return {
      id: id || `resume_${index + 1}`,
      name: name,
      link: link,
      index: index,
      element: row
    };
  } catch (error) {
    this.logError('Row data extraction error', error);
    return null;
  }
};

SmartResumeParser.prototype.extractNameFromRow = function(row) {
  const nameSelectors = [
    'td:first-child, .name-cell, [class*="name"]',
    'a[href*="resume"], a[href*="candidate"]',
    'strong, b, .title'
  ];
  
  for (const selector of nameSelectors) {
    try {
      const element = row.querySelector(selector);
      if (element) {
        const name = element.textContent.trim();
        if (name && name.length > 1 && name.length < 50) {
          return name;
        }
      }
    } catch (e) {
      continue;
    }
  }
  
  return null;
};

SmartResumeParser.prototype.extractLinkFromRow = function(row) {
  // 查找所有链接
  try {
    const links = row.querySelectorAll('a[href]');
    for (const link of links) {
      let href = link.getAttribute('href');
      if (!href || href.startsWith('javascript:') || href === '#' || href === '') continue;
      
      // 转换为绝对路径
      if (!href.startsWith('http')) {
        href = new URL(href, window.location.origin).href;
      }

      // 只要链接看起来像是一个详情页（有 ID 或长路径），就接受它
      // 排除掉明显的非详情链接（如 #top, /logout 等）
      if (href.length > 20 && !href.includes('logout') && !href.includes('login')) {
          return href;
      }
    }
  } catch (e) {
    // ignore
  }
  
  // 查找所有可点击元素
  const clickableSelectors = [
    '[onclick]',
    '[data-href]',
    '[data-id]',
    '[data-url]',
    'div[role="link"]'
  ];
  
  for (const selector of clickableSelectors) {
    try {
      const elements = row.querySelectorAll(selector);
      for (const element of elements) {
        let href = element.getAttribute('href') || 
                   element.getAttribute('data-href') || 
                   element.getAttribute('data-url');
                   
        if (href) {
          if (!href.startsWith('http')) {
            href = new URL(href, window.location.origin).href;
          }
          return href;
        }
        
        // 如果有 data-id，尝试构造 URL
        const id = element.getAttribute('data-id') || element.getAttribute('data-key');
        if (id && /^\d+$/.test(id)) {
            // 这里假设一个通用的 URL 结构，可能需要根据实际情况调整
            // 但这比漏掉要好
            // return window.location.origin + '/resume/detail/' + id;
        }
      }
    } catch (e) {
      continue;
    }
  }
  
  return null;
};

SmartResumeParser.prototype.extractIdFromRow = function(row) {
  const idPattern = /(?:resume|candidate|detail)[\/\-_]?(\d+)/i;
  const link = this.extractLinkFromRow(row);
  
  if (link) {
    const match = link.match(idPattern);
    if (match) {
      return match[1];
    }
  }
  
  // 尝试从data属性获取
  const dataId = row.getAttribute('data-id') || 
                row.getAttribute('data-resume-id') ||
                row.getAttribute('data-key');
  
  if (dataId) {
    return dataId;
  }
  
  return null;
};

// Initialize the smart resume parser
const smartResumeParser = new SmartResumeParser();
smartResumeParser.init();

// Export for global access
if (typeof window !== 'undefined') {
  window.smartResumeParser = smartResumeParser;
  
  // Global debugging functions
  window.debugSmartResumeParser = () => {
    return smartResumeParser.debugPageStructure();
  };
  
  window.getSmartParserStats = () => {
    return smartResumeParser.getStats();
  };
}