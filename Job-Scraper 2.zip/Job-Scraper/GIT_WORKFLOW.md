# JobScraper - Git工作流说明

## 📁 目录结构

```
d:\Myprojects\
├── JobScraper/                  # 开发环境 (Git仓库)
│   ├── .git/
│   ├── develop 分支             # 日常开发
│   ├── main 分支                # 稳定版本
│   ├── tests/                   # 测试和调试文件
│   ├── manifest.json
│   ├── background.js
│   ├── content.js
│   └── popup.html
│
└── JobScraper-prod/             # 生产环境
    └── [从main分支复制的稳定代码]
```

## 🚀 Chrome扩展加载方式

### 开发环境 (可实时修改)
1. 打开Chrome浏览器
2. 访问 `chrome://extensions/`
3. 开启"开发者模式"
4. 点击"加载已解压的扩展程序"
5. 选择 `d:\Myprojects\JobScraper`

### 生产环境 (稳定版本)
1. 打开Chrome浏览器
2. 访问 `chrome://extensions/`
3. 开启"开发者模式"
4. 点击"加载已解压的扩展程序"
5. 选择 `d:\Myprojects\JobScraper-prod`

## 📋 日常开发流程

### 开发新功能
```bash
cd d:\Myprojects\JobScraper
git checkout develop

# 修改代码...
# Chrome中点击"重新加载"扩展即可测试

git add .
git commit -m "feat: 功能描述"
```

### 发布到生产
```bash
cd d:\Myprojects\JobScraper

# 1. 确保develop分支已提交
git checkout develop
git status

# 2. 合并到main分支
git checkout main
git merge develop

# 3. 打版本标签
git tag -a v1.0 -m "版本描述"

# 4. 推送到GitHub
git push origin main --tags

# 5. 部署到生产环境
robocopy . ..\JobScraper-prod /E /XD .git tests /XF .gitignore

# 6. Chrome中重新加载生产环境扩展

# 7. 切回develop继续开发
git checkout develop
```

## 📂 项目结构说明

| 目录/文件 | 说明 |
|----------|------|
| `manifest.json` | 扩展配置文件 |
| `background.js` | 后台脚本 |
| `content.js` | 内容脚本(注入到网页) |
| `popup.html/js` | 弹出窗口 |
| `tests/` | 测试和调试文件 |
| `*.md` | 文档文件 |

## 🔄 版本管理

```bash
# 查看所有版本
git tag

# 查看提交历史
git log --oneline --graph --all

# 回退到旧版本
git checkout v1.0
robocopy . ..\JobScraper-prod /E /XD .git tests /XF .gitignore
```

## ⚠️ 注意事项

1. **开发环境**: 可以随意测试,修改后点击Chrome扩展的"重新加载"
2. **生产环境**: 稳定版本,用于日常工作
3. **测试文件**: 已移到`tests/`目录,不会部署到生产环境
4. **GitHub推送**: 推荐只推送main分支和标签

## 📝 提交规范

```bash
git commit -m "feat: 添加新功能"
git commit -m "fix: 修复bug"
git commit -m "docs: 更新文档"
git commit -m "refactor: 重构代码"
```
