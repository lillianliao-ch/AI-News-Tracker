# Smart Resume Parser 使用指南

## 概述

Smart Resume Parser 是基于阿里巴巴猎头平台页面截图分析开发的智能简历抓取引擎，提供多种提取策略和强大的错误处理能力。

## 主要特性

### 🚀 智能提取策略系统
- **Ant Design 表格策略**: 针对 Ant Design 组件的表格结构优化
- **通用表格策略**: 处理标准 HTML 表格布局
- **卡片布局策略**: 解析卡片式简历列表
- **列表项策略**: 处理传统列表格式
- **Div 布局策略**: 处理复杂 div 容器布局

### 🎯 智能页面识别
- 基于 URL 模式的页面类型检测
- DOM 结构分析
- 内容特征识别
- 多指标综合评估

### 📊 性能监控与调试
- 实时性能统计
- 错误记录与报告
- 策略使用情况跟踪
- 内存使用监控

### 🔧 增强字段提取
- **姓名**: 15种智能检测模式
- **链接**: 11种识别方法
- **ID**: 多种模式匹配
- **电话**: 格式验证
- **邮箱**: 有效性检查
- **地址**: 模糊匹配

## 快速开始

### 1. 加载解析器

```javascript
// 解析器会在页面加载时自动初始化
// 如果需要手动初始化：
const parser = new SmartResumeParser();
```

### 2. 基本使用

```javascript
// 启动简历抓取
smartResumeParser.initResumeScraping();

// 检查页面类型
const analysis = smartResumeParser.analyzePageType();
console.log('页面类型:', analysis);

// 手动选择策略
const strategy = smartResumeParser.selectBestStrategy(analysis);
console.log('选择策略:', strategy.constructor.name);
```

### 3. 数据提取

```javascript
// 提取姓名
const name = smartResumeParser.extractCandidateName(element);

// 提取联系方式
const phone = smartResumeParser.extractPhone(element);
const email = smartResumeParser.extractEmail(element);
const location = smartResumeParser.extractLocation(element);

// 提取简历链接
const links = smartResumeParser.extractResumeLinks(element);
```

### 4. 性能监控

```javascript
// 获取性能统计
const stats = getSmartParserStats();
console.log('性能统计:', stats);

// 查看调试信息
debugSmartResumeParser();
```

## 详细功能说明

### 策略选择算法

Smart Resume Parser 使用优先级策略系统：

1. **Ant Design 表格** (优先级: 1)
   - 检测 `.ant-table` 组件
   - 适用于阿里巴巴后台管理界面

2. **通用表格** (优先级: 2)
   - 标准 HTML `<table>` 结构
   - 适用于传统表格布局

3. **卡片布局** (优先级: 3)
   - `.ant-card`, `.card`, `.resume-card` 等
   - 适用于现代化卡片式设计

4. **列表项** (优先级: 4)
   - `<ul>`, `<ol>` 列表结构
   - 适用于传统列表布局

5. **Div 布局** (优先级: 5)
   - 纯 div 容器布局
   - 适用于复杂自定义布局

### 页面类型检测

```javascript
// 页面类型分析结果
{
  indicators: {
    url: {
      isResumeManagement: boolean,  // 是否为简历管理页面
      isDetailPage: boolean         // 是否为详情页
    },
    dom: {
      antTable: boolean,            // 是否存在 Ant Design 表格
      tableRows: number,            // 表格行数
      cardElements: number,         // 卡片元素数量
      listItems: number             // 列表项数量
    },
    content: {
      keywordCounts: object,        // 关键词统计
      hasFormElements: boolean      // 是否包含表单元素
    }
  },
  bestStrategy: string,             // 推荐的策略名称
  confidence: number               // 置信度 (0-1)
}
```

### 错误处理机制

- **自动重试**: 失败的提取操作会尝试备用策略
- **优雅降级**: 策略失败时自动回退到更基础的提取方法
- **错误记录**: 详细的错误信息和堆栈跟踪
- **性能保护**: 避免长时间运行导致的性能问题

## API 参考

### SmartResumeParser 类

#### 构造函数
```javascript
const parser = new SmartResumeParser();
```

#### 主要方法

##### `initResumeScraping()`
初始化简历抓取功能
- **返回**: Promise
- **功能**: 设置事件监听，启动抓取流程

##### `analyzePageType()`
分析当前页面类型
- **返回**: Object - 页面分析结果
- **功能**: 综合评估页面结构和内容特征

##### `selectBestStrategy(analysis)`
根据分析结果选择最佳策略
- **参数**: analysis - 页面分析对象
- **返回**: Strategy - 选中的策略实例

##### `scrapeResumeList()`
抓取简历列表
- **返回**: Array - 简历数据数组
- **功能**: 使用最佳策略提取简历列表

##### `extractCandidateName(element)`
提取候选人姓名
- **参数**: element - DOM 元素
- **返回**: string - 姓名或空字符串

##### `extractPhone(element)`
提取电话号码
- **参数**: element - DOM 元素
- **返回**: string - 电话号码或空字符串

##### `extractEmail(element)`
提取邮箱地址
- **参数**: element - DOM 元素
- **返回**: string - 邮箱地址或空字符串

##### `extractLocation(element)`
提取地址信息
- **参数**: element - DOM 元素
- **返回**: string - 地址或空字符串

##### `getStats()`
获取性能统计
- **返回**: Object - 性能数据

### 全局函数

#### `smartResumeParser`
解析器实例的全局引用

#### `debugSmartResumeParser()`
调试信息输出
- **功能**: 输出详细的调试信息到控制台

#### `getSmartParserStats()`
获取性能统计
- **返回**: Object - 包含以下属性：
  - `extractionCounts`: 各策略使用次数
  - `successRate`: 成功率
  - `memoryUsage`: 内存使用情况
  - `errorCount`: 错误计数
  - `lastReset`: 最后重置时间

## 最佳实践

### 1. 页面加载后等待
```javascript
// 页面加载后等待 DOM 稳定
window.addEventListener('load', () => {
  setTimeout(() => {
    const parser = new SmartResumeParser();
    parser.initResumeScraping();
  }, 1000);
});
```

### 2. 批量处理
```javascript
// 批量提取多个页面
async function processMultiplePages(pages) {
  const parser = new SmartResumeParser();
  const results = [];
  
  for (const pageUrl of pages) {
    const analysis = parser.analyzePageType();
    const strategy = parser.selectBestStrategy(analysis);
    const data = await parser.scrapeResumeList();
    results.push({ url: pageUrl, data, strategy: strategy.constructor.name });
    
    // 延迟避免频繁请求
    await new Promise(resolve => setTimeout(resolve, 500));
  }
  
  return results;
}
```

### 3. 错误处理
```javascript
// 健壮的错误处理
async function safeResumeExtraction() {
  try {
    const parser = new SmartResumeParser();
    const analysis = parser.analyzePageType();
    
    if (analysis.confidence < 0.5) {
      console.warn('页面识别置信度较低:', analysis);
    }
    
    const data = await parser.scrapeResumeList();
    return data;
  } catch (error) {
    console.error('简历提取失败:', error);
    return [];
  }
}
```

### 4. 性能监控
```javascript
// 定期检查性能
setInterval(() => {
  const stats = getSmartParserStats();
  
  if (stats.errorCount > 10) {
    console.warn('错误率较高，建议检查页面结构:', stats);
  }
  
  if (stats.memoryUsage > 50 * 1024 * 1024) { // 50MB
    console.warn('内存使用较高:', stats);
  }
}, 30000); // 每30秒检查一次
```

## 故障排除

### 常见问题

#### 1. 策略选择错误
**现象**: 选择的策略不适合当前页面
**解决**: 
- 检查页面类型分析的置信度
- 手动指定策略类型
- 更新策略检测规则

#### 2. 数据提取不准确
**现象**: 姓名、电话等信息提取错误
**解决**:
- 检查元素选择器是否正确
- 验证页面结构是否发生变化
- 使用调试功能查看提取过程

#### 3. 性能问题
**现象**: 提取速度慢或内存占用高
**解决**:
- 定期调用 `getSmartParserStats()` 检查性能
- 考虑分批处理大量数据
- 重置统计信息: `smartResumeParser.resetStats()`

### 调试工具

#### 启用详细日志
```javascript
// 开启详细调试模式
localStorage.setItem('smart_parser_debug', 'true');

// 查看调试信息
debugSmartResumeParser();
```

#### 策略性能分析
```javascript
// 分析各策略的使用效果
const stats = getSmartParserStats();
console.table(stats.extractionCounts);
```

## 更新日志

### v2.0.0 (当前版本)
- ✅ 集成智能提取策略系统
- ✅ 增强页面类型检测
- ✅ 添加性能监控功能
- ✅ 实现全局调试工具
- ✅ 优化错误处理机制

### v1.0.0 (基础版本)
- ✅ 基础简历列表抓取
- ✅ 简单的字段提取
- ✅ 基础的翻页控制

## 技术支持

如果在使用过程中遇到问题，可以：

1. **查看控制台日志**: 启用调试模式获取详细信息
2. **检查性能统计**: 使用 `getSmartParserStats()` 分析问题
3. **运行测试脚本**: 执行 `test_smart_parser.js` 验证功能
4. **查看实施文档**: 参考 `IMPLEMENTATION_ROADMAP.md`

## 扩展开发

### 添加新策略

```javascript
// 1. 创建新策略类
class CustomStrategy {
  constructor() {
    this.name = 'CustomStrategy';
    this.priority = 6;
  }
  
  canHandle(analysis) {
    // 判断是否适用于当前页面
    return analysis.indicators.dom.customElement > 0;
  }
  
  extractResumes() {
    // 实现具体的提取逻辑
    return [];
  }
}

// 2. 注册新策略
smartResumeParser.registerStrategy(new CustomStrategy());
```

### 自定义字段提取

```javascript
// 扩展姓名提取功能
const originalExtractName = smartResumeParser.extractCandidateName;
smartResumeParser.extractCandidateName = function(element) {
  // 添加自定义检测逻辑
  const customName = this.detectCustomName(element);
  return customName || originalExtractName.call(this, element);
};
```

---

*本指南涵盖了 Smart Resume Parser 的所有核心功能和使用方法。如有疑问，请参考源代码或联系技术支持。*