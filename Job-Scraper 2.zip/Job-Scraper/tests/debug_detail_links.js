// 在浏览器控制台中运行此代码来检查详情页链接打开方式
console.log('=== 简历详情页链接检查 ===');

// 1. 检查所有可能的点击元素
const clickableElements = document.querySelectorAll('a, button, [onclick], [data-href], [data-url], [data-testid*="resume"], [data-role*="resume"]');
console.log(`找到 ${clickableElements.length} 个可点击元素`);
clickableElements.forEach((el, index) => {
  if (index < 10) { // 只显示前10个
    console.log(`元素 ${index}: ${el.tagName}.${el.className}`);
    console.log('  href:', el.href || el.getAttribute('href'));
    console.log('  onclick:', el.getAttribute('onclick'));
    console.log('  data-href:', el.getAttribute('data-href'));
    console.log('  data-url:', el.getAttribute('data-url'));
  }
});

// 2. 检查表格行点击事件
const rows = document.querySelectorAll('tr, .ant-table-tbody tr, li, .item, .list-item');
console.log(`找到 ${rows.length} 行数据`);
rows.forEach((row, index) => {
  if (index < 5) {
    console.log(`行 ${index}:`);
    console.log('  class:', row.className);
    console.log('  onclick:', row.getAttribute('onclick'));
    console.log('  data-id:', row.getAttribute('data-id'));
    
    // 检查是否有嵌入式链接
    const links = row.querySelectorAll('a');
    if (links.length > 0) {
      console.log('  包含链接数:', links.length);
      links.forEach((link, linkIndex) => {
        console.log(`    链接 ${linkIndex}: ${link.href || link.getAttribute('href')}`);
      });
    }
  }
});

// 3. 检查常见的事件监听器
console.log('检查事件监听器...');
const resumeRows = document.querySelectorAll('[class*="resume"], [class*="candidate"], tr[class*="row"]');
resumeRows.forEach((row, index) => {
  if (index < 3) {
    const events = getEventListeners ? getEventListeners(row) : 'getEventListeners 不可用';
    console.log(`行 ${index} 事件监听器:`, events);
  }
});

// 4. 测试手动点击第一行看会发生什么
const firstRow = document.querySelector('tr, .ant-table-tbody tr, li, .item, .list-item');
if (firstRow) {
  console.log('=== 测试点击第一行 ===');
  console.log('第一行元素:', firstRow.tagName, firstRow.className);
  console.log('点击第一行...');
  
  // 模拟点击
  const clickEvent = new MouseEvent('click', {
    view: window,
    bubbles: true,
    cancelable: true
  });
  firstRow.dispatchEvent(clickEvent);
  
  // 等待2秒看是否有变化
  setTimeout(() => {
    console.log('点击后检查页面变化...');
    console.log('当前URL:', window.location.href);
    
    // 检查是否有弹窗或模态框出现
    const modals = document.querySelectorAll('.ant-modal, .modal, [class*="modal"], [class*="popup"]');
    console.log(`找到 ${modals.length} 个模态框`);
    
    // 检查是否有新标签页打开
    console.log('检查新标签页...');
    if (window.chrome && chrome.runtime && chrome.runtime.sendMessage) {
      chrome.runtime.sendMessage({action: "CHECK_NEW_TABS"}, (response) => {
        console.log('新标签页检查结果:', response);
      });
    }
  }, 2000);
}