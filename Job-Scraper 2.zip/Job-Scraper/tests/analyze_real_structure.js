// 深度页面结构分析脚本
// 在浏览器控制台中运行，分析真实的HTML结构

console.log("🔍 开始深度页面结构分析...");

// 分析页面的整体结构
function analyzePageStructure() {
  console.log("📄 页面基本信息:");
  console.log(`标题: ${document.title}`);
  console.log(`URL: ${window.location.href}`);
  console.log(`字符集: ${document.characterSet}`);
  
  return {
    title: document.title,
    url: window.location.href,
    characterSet: document.characterSet
  };
}

// 查找所有可能的姓名显示位置
function findCandidateNameElements() {
  console.log("👤 查找所有可能的姓名元素...");
  
  const candidates = [];
  
  // 查找所有h1-h6标题
  const headings = document.querySelectorAll('h1, h2, h3, h4, h5, h6');
  headings.forEach((h, index) => {
    const text = h.textContent.trim();
    if (text.length > 0 && text.length < 20 && !text.includes('猎头')) {
      candidates.push({
        selector: `h${h.tagName.charAt(1)}[${index}]`,
        element: h,
        text: text,
        reason: '标题元素'
      });
    }
  });
  
  // 查找所有可能的容器中的文本
  const containers = document.querySelectorAll('div, section, article, main');
  containers.forEach((div, index) => {
    const className = div.className;
    const id = div.id;
    const text = div.textContent.trim();
    
    // 检查是否包含姓名相关的class或id
    if (className || id) {
      const nameRelated = /name|candidate|person|user/i.test(className + ' ' + id);
      if (nameRelated && text.length > 0 && text.length < 30) {
        candidates.push({
          selector: `div[${className ? 'class=' + className : ''}][${id ? 'id=' + id : ''}]`,
          element: div,
          text: text.substring(0, 50),
          reason: '姓名相关容器'
        });
      }
    }
    
    // 检查文本内容是否像姓名
    if (text.length > 2 && text.length < 15 && 
        !text.includes('系统') && !text.includes('管理') && !text.includes('页面') &&
        !text.includes('导航') && !text.includes('操作')) {
      candidates.push({
        selector: `div[${index}]`,
        element: div,
        text: text.substring(0, 30),
        reason: '疑似姓名文本'
      });
    }
  });
  
  console.log(`找到 ${candidates.length} 个潜在的姓名候选元素`);
  return candidates;
}

// 查找所有表格和数据结构
function findTableStructures() {
  console.log("📊 分析表格结构...");
  
  const tables = document.querySelectorAll('table, tbody, thead');
  const structures = [];
  
  tables.forEach((table, index) => {
    const rows = table.querySelectorAll('tr');
    const cells = table.querySelectorAll('td, th');
    
    if (rows.length > 0) {
      const tableInfo = {
        selector: `table[${index}]`,
        rows: rows.length,
        cells: cells.length,
        data: []
      };
      
      // 分析前几行的数据
      for (let i = 0; i < Math.min(5, rows.length); i++) {
        const cells = rows[i].querySelectorAll('td, th');
        const rowData = Array.from(cells).map(cell => cell.textContent.trim());
        if (rowData.some(cell => cell.length > 0)) {
          tableInfo.data.push(rowData);
        }
      }
      
      structures.push(tableInfo);
    }
  });
  
  console.log(`找到 ${structures.length} 个表格结构`);
  return structures;
}

// 查找所有可能的联系方式
function findContactInfo() {
  console.log("📞 查找联系方式...");
  
  const contacts = {
    phones: [],
    emails: [],
    addresses: []
  };
  
  // 获取页面所有文本内容
  const allText = document.body.innerText || '';
  
  // 电话号码模式
  const phonePatterns = [
    /电话[:：]\s*(\d{11})/g,
    /手机[:：]\s*(\d{11})/g,
    /联系电话[:：]\s*(\d{11})/g,
    /(\d{3}[-.\s]?\d{4}[-.\s]?\d{4})/g
  ];
  
  phonePatterns.forEach(pattern => {
    let match;
    while ((match = pattern.exec(allText)) !== null) {
      contacts.phones.push(match[1]);
    }
  });
  
  // 邮箱模式
  const emailPattern = /([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/g;
  let emailMatch;
  while ((emailMatch = emailPattern.exec(allText)) !== null) {
    contacts.emails.push(emailMatch[1]);
  }
  
  console.log(`找到 ${contacts.phones.length} 个电话号码, ${contacts.emails.length} 个邮箱地址`);
  return contacts;
}

// 分析页面中的所有标签和类名
function analyzePageTags() {
  console.log("🏷️ 分析页面标签和类名...");
  
  const tags = new Set();
  const classes = new Set();
  const ids = new Set();
  
  // 分析所有元素
  const allElements = document.querySelectorAll('*');
  allElements.forEach(element => {
    if (element.tagName) tags.add(element.tagName);
    if (element.className) {
      element.className.split(' ').forEach(cls => {
        if (cls.trim()) classes.add(cls.trim());
      });
    }
    if (element.id) ids.add(element.id);
  });
  
  // 找出可能相关的类名
  const relevantClasses = Array.from(classes).filter(cls => 
    /name|candidate|person|user|profile|resume|contact|phone|email|info|detail/i.test(cls)
  );
  
  return {
    totalTags: tags.size,
    totalClasses: classes.size,
    totalIds: ids.size,
    relevantClasses: relevantClasses,
    allTags: Array.from(tags).slice(0, 50), // 限制数量
    allClasses: Array.from(classes).slice(0, 100) // 限制数量
  };
}

// 查找简历链接或相关的交互元素
function findResumeLinks() {
  console.log("🔗 查找简历相关链接...");
  
  const links = [];
  const buttons = [];
  
  // 查找所有链接
  const allLinks = document.querySelectorAll('a[href]');
  allLinks.forEach((link, index) => {
    const href = link.href;
    const text = link.textContent.trim();
    
    if (text && text.length < 50) {
      links.push({
        index,
        text,
        href,
        selector: `a[href][${index}]`
      });
    }
  });
  
  // 查找所有按钮
  const allButtons = document.querySelectorAll('button, input[type="button"], [onclick]');
  allButtons.forEach((btn, index) => {
    const text = btn.textContent || btn.value || '';
    if (text.trim()) {
      buttons.push({
        index,
        text: text.trim(),
        selector: `${btn.tagName}[${index}]`
      });
    }
  });
  
  console.log(`找到 ${links.length} 个链接, ${buttons.length} 个按钮`);
  return { links, buttons };
}

// 主分析函数
function runDeepAnalysis() {
  console.log("=".repeat(60));
  console.log("🔍 深度页面结构分析报告");
  console.log("=".repeat(60));
  
  // 1. 页面基本信息
  const pageInfo = analyzePageStructure();
  console.log();
  
  // 2. 查找姓名候选
  const nameCandidates = findCandidateNameElements();
  console.log("姓名候选元素:");
  nameCandidates.slice(0, 10).forEach((candidate, i) => {
    console.log(`  ${i + 1}. ${candidate.reason}: "${candidate.text}" (${candidate.selector})`);
  });
  console.log();
  
  // 3. 表格结构分析
  const tableStructures = findTableStructures();
  tableStructures.slice(0, 3).forEach((table, i) => {
    console.log(`表格 ${i + 1} (${table.selector}):`);
    table.data.forEach((row, j) => {
      console.log(`  行 ${j + 1}: ${row.join(' | ')}`);
    });
  });
  console.log();
  
  // 4. 联系方式
  const contactInfo = findContactInfo();
  console.log("联系方式:");
  console.log(`  电话: ${contactInfo.phones.join(', ') || '未找到'}`);
  console.log(`  邮箱: ${contactInfo.emails.join(', ') || '未找到'}`);
  console.log();
  
  // 5. 标签分析
  const tagAnalysis = analyzePageTags();
  console.log("页面标签分析:");
  console.log(`  总标签数: ${tagAnalysis.totalTags}`);
  console.log(`  总类名数: ${tagAnalysis.totalClasses}`);
  console.log(`  总ID数: ${tagAnalysis.totalIds}`);
  console.log(`  相关类名: ${tagAnalysis.relevantClasses.slice(0, 10).join(', ')}`);
  console.log();
  
  // 6. 链接和按钮
  const interactiveElements = findResumeLinks();
  console.log("交互元素 (前10个):");
  interactiveElements.links.slice(0, 5).forEach((link, i) => {
    console.log(`  链接 ${i + 1}: "${link.text}" -> ${link.href}`);
  });
  interactiveElements.buttons.slice(0, 5).forEach((btn, i) => {
    console.log(`  按钮 ${i + 1}: "${btn.text}"`);
  });
  console.log();
  
  // 7. 生成建议的提取策略
  console.log("💡 建议的提取策略:");
  if (nameCandidates.length > 0) {
    console.log("  - 姓名提取: 使用候选元素中的第1个非系统文本");
    console.log(`  - 建议选择器: ${nameCandidates[0].selector}`);
  }
  
  if (tableStructures.length > 0) {
    console.log("  - 表格数据: 优先从表格结构中提取");
  }
  
  if (contactInfo.phones.length > 0) {
    console.log("  - 电话提取: 使用文本模式匹配");
  }
  
  if (contactInfo.emails.length > 0) {
    console.log("  - 邮箱提取: 使用正则表达式");
  }
  
  console.log("=".repeat(60));
  
  return {
    pageInfo,
    nameCandidates,
    tableStructures,
    contactInfo,
    tagAnalysis,
    interactiveElements
  };
}

// 自动执行分析
if (typeof window !== 'undefined' && typeof document !== 'undefined') {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', runDeepAnalysis);
  } else {
    setTimeout(runDeepAnalysis, 1000);
  }
} else {
  // 导出函数供手动调用
  window.analyzeRealStructure = {
    analyzePageStructure,
    findCandidateNameElements,
    findTableStructures,
    findContactInfo,
    analyzePageTags,
    findResumeLinks,
    runDeepAnalysis
  };
}