// 快速测试姓名提取修复效果
// 在浏览器控制台运行此脚本进行即时验证

console.log("🔍 开始快速验证姓名提取修复...");

// 立即测试当前页面的姓名提取
async function testCurrentPage() {
  console.log("=" .repeat(40));
  console.log("🧪 测试当前页面姓名提取");
  console.log("=" .repeat(40));
  
  // 1. 检查页面文本内容
  const fullText = document.body.innerText || '';
  console.log("📄 页面文本长度:", fullText.length);
  console.log("📄 页面文本预览:", fullText.substring(0, 300));
  console.log("🔍 查找'猎头系统'位置:", fullText.indexOf('猎头系统'));
  
  // 2. 测试姓名验证函数
  console.log("\n🧪 测试姓名验证:");
  const testNames = ['张三', '猎头系统', '页面管理', '真实姓名', '系统管理员'];
  testNames.forEach(name => {
    const isValid = isValidPersonName(name);
    console.log(`  ${name}: ${isValid ? '✅ 有效' : '❌ 无效'}`);
  });
  
  // 3. 测试智能姓名提取
  console.log("\n🔍 测试智能姓名提取:");
  const extractedName = extractNameFromContentSmart(fullText);
  console.log(`提取的姓名: ${extractedName}`);
  
  // 4. 查看所有可能的姓名候选
  console.log("\n📝 查找所有可能的姓名候选:");
  const lines = fullText.split('\n').map(line => line.trim()).filter(line => line.length > 0);
  const nameCandidates = [];
  lines.forEach((line, index) => {
    if (isValidPersonName(line)) {
      nameCandidates.push({ index, line });
    }
  });
  
  if (nameCandidates.length > 0) {
    console.log("找到的姓名候选:");
    nameCandidates.forEach(candidate => {
      console.log(`  行 ${candidate.index}: ${candidate.line}`);
    });
  } else {
    console.log("未找到有效的姓名候选");
  }
  
  // 5. 实际运行提取函数
  console.log("\n🚀 运行完整的提取函数:");
  try {
    const result = await extractResumeDetail();
    if (result) {
      console.log("✅ 提取结果:");
      console.log(`  姓名: ${result.name}`);
      console.log(`  电话: ${result.phone || '未找到'}`);
      console.log(`  邮箱: ${result.email || '未找到'}`);
      console.log(`  现居地: ${result.location || '未找到'}`);
      console.log(`  当前职位: ${result.currentTitle || '未找到'}`);
    } else {
      console.log("❌ 提取失败");
    }
  } catch (error) {
    console.error("❌ 提取过程出错:", error);
  }
  
  return extractedName;
}

// 如果在当前页面，直接运行测试
if (typeof window !== 'undefined' && typeof document !== 'undefined') {
  console.log("🌐 检测到浏览器环境，开始测试...");
  
  // 检查必要的函数是否存在
  if (typeof extractResumeDetail === 'function') {
    console.log("✅ extractResumeDetail 函数已定义");
    testCurrentPage();
  } else {
    console.log("❌ extractResumeDetail 函数未定义，请确保先加载 content.js");
  }
}

// 导出函数供手动调用
window.quickTest = {
  testCurrentPage
};