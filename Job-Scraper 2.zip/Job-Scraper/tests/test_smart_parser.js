/**
 * Smart Resume Parser 功能测试脚本
 * 用于验证集成后的核心功能是否正常工作
 */

(function() {
  'use strict';
  
  console.log('=== Smart Resume Parser 功能测试 ===');
  
  // 测试1: 检查 SmartResumeParser 类是否存在
  function testParserClass() {
    console.log('\n1. 测试 SmartResumeParser 类...');
    
    try {
      if (typeof SmartResumeParser !== 'undefined') {
        console.log('✓ SmartResumeParser 类已正确加载');
        return true;
      } else {
        console.log('✗ SmartResumeParser 类未找到');
        return false;
      }
    } catch (error) {
      console.log('✗ SmartResumeParser 类加载错误:', error);
      return false;
    }
  }
  
  // 测试2: 检查策略类是否存在
  function testStrategyClasses() {
    console.log('\n2. 测试策略类...');
    
    const strategies = ['AntDesignTableStrategy', 'CardLayoutStrategy', 'GenericTableStrategy', 'ListItemStrategy', 'DivLayoutStrategy'];
    let allPass = true;
    
    strategies.forEach(strategyName => {
      try {
        if (typeof window[strategyName] !== 'undefined') {
          console.log(`✓ ${strategyName} 策略类已加载`);
        } else {
          console.log(`✗ ${strategyName} 策略类未找到`);
          allPass = false;
        }
      } catch (error) {
        console.log(`✗ ${strategyName} 策略类错误:`, error);
        allPass = false;
      }
    });
    
    return allPass;
  }
  
  // 测试3: 检查全局函数
  function testGlobalFunctions() {
    console.log('\n3. 测试全局函数...');
    
    const functions = ['smartResumeParser', 'debugSmartResumeParser', 'getSmartParserStats'];
    let allPass = true;
    
    functions.forEach(funcName => {
      try {
        if (typeof window[funcName] !== 'undefined') {
          console.log(`✓ ${funcName} 全局函数已定义`);
        } else {
          console.log(`✗ ${funcName} 全局函数未找到`);
          allPass = false;
        }
      } catch (error) {
        console.log(`✗ ${funcName} 函数错误:`, error);
        allPass = false;
      }
    });
    
    return allPass;
  }
  
  // 测试4: 页面类型检测
  function testPageTypeDetection() {
    console.log('\n4. 测试页面类型检测...');
    
    try {
      if (smartResumeParser && typeof smartResumeParser.analyzePageType === 'function') {
        const analysis = smartResumeParser.analyzePageType();
        console.log('✓ 页面类型分析功能正常');
        console.log('分析结果:', analysis);
        return true;
      } else {
        console.log('✗ 页面类型分析功能不可用');
        return false;
      }
    } catch (error) {
      console.log('✗ 页面类型分析错误:', error);
      return false;
    }
  }
  
  // 测试5: 策略选择功能
  function testStrategySelection() {
    console.log('\n5. 测试策略选择功能...');
    
    try {
      if (smartResumeParser && typeof smartResumeParser.selectBestStrategy === 'function') {
        const mockAnalysis = {
          indicators: {
            dom: {
              antTable: document.querySelector('.ant-table') !== null,
              tableRows: document.querySelectorAll('tbody tr').length > 5
            }
          }
        };
        
        const strategy = smartResumeParser.selectBestStrategy(mockAnalysis);
        console.log('✓ 策略选择功能正常');
        console.log('选择策略:', strategy ? strategy.constructor.name : 'None');
        return true;
      } else {
        console.log('✗ 策略选择功能不可用');
        return false;
      }
    } catch (error) {
      console.log('✗ 策略选择错误:', error);
      return false;
    }
  }
  
  // 测试6: 性能监控功能
  function testPerformanceMonitoring() {
    console.log('\n6. 测试性能监控功能...');
    
    try {
      if (smartResumeParser && typeof getSmartParserStats === 'function') {
        const stats = getSmartParserStats();
        console.log('✓ 性能监控功能正常');
        console.log('性能统计:', stats);
        return true;
      } else {
        console.log('✗ 性能监控功能不可用');
        return false;
      }
    } catch (error) {
      console.log('✗ 性能监控错误:', error);
      return false;
    }
  }
  
  // 测试7: 数据提取功能
  function testDataExtraction() {
    console.log('\n7. 测试数据提取功能...');
    
    try {
      const testElements = {
        phone: '13800138000',
        email: 'test@example.com',
        location: '北京市朝阳区'
      };
      
      // 测试电话提取
      if (typeof smartResumeParser.extractPhone === 'function') {
        console.log('✓ 电话提取方法存在');
      }
      
      // 测试邮箱提取
      if (typeof smartResumeParser.extractEmail === 'function') {
        console.log('✓ 邮箱提取方法存在');
      }
      
      // 测试地址提取
      if (typeof smartResumeParser.extractLocation === 'function') {
        console.log('✓ 地址提取方法存在');
      }
      
      return true;
    } catch (error) {
      console.log('✗ 数据提取错误:', error);
      return false;
    }
  }
  
  // 测试8: Chrome扩展通信
  function testChromeExtensionCommunication() {
    console.log('\n8. 测试Chrome扩展通信...');
    
    try {
      if (typeof chrome !== 'undefined' && chrome.runtime) {
        console.log('✓ Chrome扩展API可用');
        
        // 模拟消息监听
        if (smartResumeParser && typeof smartResumeParser.handleMessage === 'function') {
          console.log('✓ 消息处理方法存在');
        } else {
          console.log('✗ 消息处理方法不存在');
        }
        
        return true;
      } else {
        console.log('⚠ Chrome扩展API不可用（可能在非扩展环境中）');
        return true; // 这不是错误，只是环境问题
      }
    } catch (error) {
      console.log('✗ Chrome扩展通信错误:', error);
      return false;
    }
  }
  
  // 运行所有测试
  function runAllTests() {
    console.log('开始运行 Smart Resume Parser 功能测试...\n');
    
    const tests = [
      { name: '解析器类', test: testParserClass },
      { name: '策略类', test: testStrategyClasses },
      { name: '全局函数', test: testGlobalFunctions },
      { name: '页面类型检测', test: testPageTypeDetection },
      { name: '策略选择', test: testStrategySelection },
      { name: '性能监控', test: testPerformanceMonitoring },
      { name: '数据提取', test: testDataExtraction },
      { name: '扩展通信', test: testChromeExtensionCommunication }
    ];
    
    const results = tests.map(test => ({
      name: test.name,
      passed: test.test()
    }));
    
    // 汇总结果
    console.log('\n=== 测试结果汇总 ===');
    const passedCount = results.filter(r => r.passed).length;
    const totalCount = results.length;
    
    results.forEach(result => {
      const status = result.passed ? '✓ PASS' : '✗ FAIL';
      console.log(`${status} ${result.name}`);
    });
    
    console.log(`\n总计: ${passedCount}/${totalCount} 项测试通过`);
    
    if (passedCount === totalCount) {
      console.log('🎉 所有功能测试通过！Smart Resume Parser 已成功集成。');
    } else {
      console.log('⚠ 存在功能问题，请检查失败的测试项。');
    }
    
    return {
      passed: passedCount,
      total: totalCount,
      results: results
    };
  }
  
  // 如果在浏览器环境中运行测试
  if (typeof window !== 'undefined') {
    // 等待一段时间确保脚本已完全加载
    setTimeout(() => {
      window.smartParserTestResults = runAllTests();
    }, 1000);
    
    // 暴露测试函数到全局
    window.testSmartResumeParser = runAllTests;
    window.testSmartParserClass = testParserClass;
    window.testStrategyClasses = testStrategyClasses;
    window.testGlobalFunctions = testGlobalFunctions;
    
    console.log('Smart Resume Parser 测试脚本已加载。运行 testSmartResumeParser() 开始测试。');
  }
  
})();