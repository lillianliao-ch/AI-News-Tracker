// 页面导航和检测调试测试脚本
// 用于验证修复后的页面类型检测和链接点击功能

console.log("🚀 开始页面导航和检测调试测试...");

// 1. 测试页面类型检测
function testPageTypeDetection() {
  console.log("\n=== 1. 测试页面类型检测 ===");
  
  if (typeof detectPageType === 'function') {
    const pageType = detectPageType();
    console.log(`✅ 页面类型检测完成: ${pageType}`);
    
    // 详细分析页面内容
    const pageText = document.body.innerText || '';
    const url = window.location.href;
    
    console.log("\n📊 页面内容分析:");
    console.log(`- URL: ${url}`);
    console.log(`- 页面文本长度: ${pageText.length}`);
    console.log(`- 前200字符: ${pageText.substring(0, 200)}`);
    
    // 检查关键标识符
    const detailKeywords = ['个人信息', '联系方式', '教育背景', '工作经历', '姓名：', '手机：', '邮箱：'];
    const listKeywords = ['候选人列表', '简历库', '猎头系统', '任务管理', '候选人投递职位'];
    
    const foundDetailKeywords = detailKeywords.filter(keyword => pageText.includes(keyword));
    const foundListKeywords = listKeywords.filter(keyword => pageText.includes(keyword));
    
    console.log(`\n🔍 详情页关键词匹配: ${foundDetailKeywords.join(', ')}`);
    console.log(`🔍 列表页关键词匹配: ${foundListKeywords.join(', ')}`);
    
    return pageType;
  } else {
    console.error("❌ detectPageType 函数未定义");
    return null;
  }
}

// 2. 测试姓名验证函数
function testNameValidation() {
  console.log("\n=== 2. 测试姓名验证函数 ===");
  
  if (typeof isValidPersonName === 'function') {
    const testNames = [
      '孔令美', '刘舒悦', 'JINGBOWANG', '张华', '陈屹',
      '猎头系统', '简历库', '任务管理', '系统', '管理'
    ];
    
    testNames.forEach(name => {
      const isValid = isValidPersonName(name);
      console.log(`姓名验证 - "${name}": ${isValid ? '✅ 有效' : '❌ 无效'}`);
    });
  } else {
    console.error("❌ isValidPersonName 函数未定义");
  }
}

// 3. 测试智能姓名提取
function testSmartNameExtraction() {
  console.log("\n=== 3. 测试智能姓名提取 ===");
  
  if (typeof extractNameFromContentSmart === 'function') {
    const pageText = document.body.innerText || '';
    const extractedName = extractNameFromContentSmart(pageText);
    console.log(`✅ 智能姓名提取结果: "${extractedName}"`);
    
    // 分析提取过程
    console.log("\n📝 提取过程分析:");
    const lines = pageText.split('\n').map(line => line.trim()).filter(line => line.length > 0);
    
    lines.forEach((line, index) => {
      if (line.length <= 6 && line.match(/[一-龯]/)) { // 可能是中文姓名
        console.log(`行 ${index}: "${line}" - 可能是姓名候选`);
      }
    });
  } else {
    console.error("❌ extractNameFromContentSmart 函数未定义");
  }
}

// 4. 测试链接查找功能
function testLinkFinding() {
  console.log("\n=== 4. 测试链接查找功能 ===");
  
  if (typeof findAndClickResumeLink === 'function') {
    const linkSelectors = [
      'a[href*="resumeCode"]',
      'a[href*="FORM-"]',
      'a[href*="resume"]',
      'a[href*="candidate"]',
      'a[href*="detail"]',
      'td a[href]',
      'tr a[href]'
    ];
    
    let totalLinks = 0;
    let candidateLinks = 0;
    
    linkSelectors.forEach(selector => {
      const links = document.querySelectorAll(selector);
      totalLinks += links.length;
      
      if (links.length > 0) {
        console.log(`选择器 "${selector}": 找到 ${links.length} 个链接`);
        
        links.forEach((link, index) => {
          const href = link.href || link.getAttribute('href');
          const text = link.innerText || link.textContent || '';
          const isCandidate = !text.includes('猎头系统') && 
                             !text.includes('任务管理') && 
                             !text.includes('简历库') &&
                             href.includes('resume');
          
          if (isCandidate) {
            candidateLinks++;
            console.log(`  候选链接 ${index + 1}: ${text} (${href})`);
          }
        });
      }
    });
    
    console.log(`\n📊 链接统计:`);
    console.log(`- 总链接数: ${totalLinks}`);
    console.log(`- 候选链接数: ${candidateLinks}`);
    
    return { total: totalLinks, candidates: candidateLinks };
  } else {
    console.error("❌ findAndClickResumeLink 函数未定义");
    return null;
  }
}

// 5. 测试完整提取流程
function testCompleteExtraction() {
  console.log("\n=== 5. 测试完整提取流程 ===");
  
  const pageType = detectPageType();
  
  if (pageType === 'detail') {
    console.log("✅ 确认在详情页，执行完整提取测试...");
    
    if (typeof extractResumeDetail === 'function') {
      extractResumeDetail().then(result => {
        if (result) {
          console.log("✅ 完整提取成功:");
          console.log(JSON.stringify(result, null, 2));
        } else {
          console.log("❌ 完整提取失败");
        }
      }).catch(error => {
        console.error("❌ 完整提取异常:", error);
      });
    } else {
      console.error("❌ extractResumeDetail 函数未定义");
    }
  } else {
    console.log(`⚠️  当前在${pageType}页，跳过详情提取测试`);
    console.log("💡 请手动导航到简历详情页后再运行此测试");
  }
}

// 运行所有测试
function runAllTests() {
  console.log("🎯 开始执行所有导航和检测测试...");
  
  // 执行各个测试
  const pageType = testPageTypeDetection();
  testNameValidation();
  testSmartNameExtraction();
  const linkInfo = testLinkFinding();
  
  // 根据页面类型决定是否运行完整提取测试
  if (pageType === 'detail') {
    testCompleteExtraction();
  } else {
    console.log("\n=== 6. 导航建议 ===");
    console.log("💡 当前在列表页，建议:");
    console.log("1. 手动点击一个候选人姓名链接进入详情页");
    console.log("2. 或者调用 findAndClickResumeLink() 函数自动导航");
    console.log("3. 导航成功后重新运行此测试脚本");
  }
  
  console.log("\n🏁 导航和检测测试完成");
}

// 导出测试函数供手动调用
window.navigationTest = {
  runAllTests,
  testPageTypeDetection,
  testNameValidation,
  testSmartNameExtraction,
  testLinkFinding,
  testCompleteExtraction
};

// 自动运行所有测试
runAllTests();