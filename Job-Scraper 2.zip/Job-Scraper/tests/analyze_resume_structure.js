// 简历详情页结构分析工具
console.log("🔍 开始分析简历详情页结构...");

// 1. 分析页面基本信息
console.log("\n=== 页面基本信息 ===");
console.log("URL:", window.location.href);
console.log("标题:", document.title);
console.log("页面内容长度:", document.body.innerText.length);

// 2. 查找姓名相关元素
console.log("\n=== 姓名相关元素 ===");
const nameSelectors = ['h1', 'h2', 'h3', '[class*="name"]', '[class*="title"]', '.resume-name', '.candidate-name'];
nameSelectors.forEach(selector => {
  const elements = document.querySelectorAll(selector);
  if (elements.length > 0) {
    console.log(`${selector}:`, elements[0].textContent.trim());
  }
});

// 3. 查找联系方式
console.log("\n=== 联系方式 ===");
const contactSelectors = ['[class*="phone"]', '[class*="mobile"]', '[class*="email"]', '[class*="contact"]'];
contactSelectors.forEach(selector => {
  const elements = document.querySelectorAll(selector);
  if (elements.length > 0) {
    elements.forEach(el => {
      console.log(`${selector}:`, el.textContent.trim());
    });
  }
});

// 4. 查找教育经历和工作经历
console.log("\n=== 教育和工作经历 ===");
const expSelectors = ['[class*="education"]', '[class*="experience"]', '[class*="work"]', '[class*="history"]'];
expSelectors.forEach(selector => {
  const elements = document.querySelectorAll(selector);
  if (elements.length > 0) {
    console.log(`${selector} 元素数量:`, elements.length);
    if (elements[0].textContent.trim().length > 0) {
      console.log(`${selector} 示例:`, elements[0].textContent.trim().substring(0, 100));
    }
  }
});

// 5. 分析所有表单字段
console.log("\n=== 表单字段分析 ===");
const allText = document.body.innerText;
const lines = allText.split('\n').map(line => line.trim()).filter(line => line.length > 0);

// 查找可能的字段-值对
const fieldPatterns = [
  /姓名[:：]\s*(.+)/,
  /电话[:：]\s*(.+)/,
  /手机[:：]\s*(.+)/,
  /邮箱[:：]\s*(.+)/,
  /学历[:：]\s*(.+)/,
  /工作年限[:：]\s*(.+)/,
  /期望职位[:：]\s*(.+)/,
  /期望薪资[:：]\s*(.+)/,
  /现居地[:：]\s*(.+)/,
  /教育经历[:：]\s*(.+)/,
  /工作经历[:：]\s*(.+)/,
  /项目经历[:：]\s*(.+)/,
  /技能[:：]\s*(.+)/,
  /自我评价[:：]\s*(.+)/
];

lines.forEach(line => {
  fieldPatterns.forEach(pattern => {
    const match = line.match(pattern);
    if (match) {
      console.log(`找到字段: ${pattern.source}`, match[1].trim());
    }
  });
});

// 6. 查找所有表格和列表结构
console.log("\n=== 表格结构分析 ===");
const tables = document.querySelectorAll('table');
console.log("表格数量:", tables.length);

const lists = document.querySelectorAll('ul, ol');
console.log("列表数量:", lists.length);

// 7. 查找包含关键信息的div结构
console.log("\n=== 关键信息div结构 ===");
const infoDivs = document.querySelectorAll('div[class*="info"], div[class*="detail"], div[class*="content"]');
console.log("信息div数量:", infoDivs.length);

infoDivs.forEach((div, index) => {
  if (index < 3) { // 只显示前3个
    const text = div.textContent.trim();
    if (text.length > 20 && text.length < 500) {
      console.log(`信息div ${index}:`, text.substring(0, 150));
    }
  }
});

// 8. 提取页面所有可能的简历数据
console.log("\n=== 提取完整简历内容 ===");
const resumeContent = {
  完整内容: document.body.innerText.substring(0, 3000),
  URL: window.location.href,
  提取时间: new Date().toISOString()
};

console.log("简历内容预览:");
console.log(resumeContent.完整内容.substring(0, 500));
console.log("...");

console.log("\n✅ 页面结构分析完成！");
console.log("请查看上述输出，识别正确的字段提取策略。");