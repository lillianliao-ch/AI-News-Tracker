/**
 * Smart Resume Parser 测试版本
 * 适用于在浏览器控制台或测试页面中使用
 */

(function() {
  'use strict';

  // 检查是否在Chrome扩展环境中
  const isExtensionEnvironment = typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id;

  // 策略基类
  class Strategy {
    constructor() {
      this.name = 'BaseStrategy';
      this.priority = 999;
    }
    
    canHandle(analysis) {
      return false;
    }
    
    extract(parser) {
      return [];
    }
  }

  // Ant Design 表格策略
  class AntDesignTableStrategy extends Strategy {
    constructor() {
      super();
      this.name = 'AntDesignTableStrategy';
      this.priority = 1;
    }
    
    canHandle(analysis) {
      return analysis.indicators.dom.antTable && 
             analysis.indicators.dom.tableRows > 5;
    }
    
    extract(parser) {
      const resumes = [];
      const tableRows = document.querySelectorAll('tbody tr');
      
      tableRows.forEach(row => {
        const resume = parser.extractResumeFromRow(row);
        if (resume.name) {
          resumes.push(resume);
        }
      });
      
      return resumes;
    }
  }

  // 卡片布局策略
  class CardLayoutStrategy extends Strategy {
    constructor() {
      super();
      this.name = 'CardLayoutStrategy';
      this.priority = 3;
    }
    
    canHandle(analysis) {
      return analysis.indicators.dom.cardElements > 0;
    }
    
    extract(parser) {
      const resumes = [];
      const cards = document.querySelectorAll('.ant-card, .card, .resume-card');
      
      cards.forEach(card => {
        const resume = parser.extractResumeFromCard(card);
        if (resume.name) {
          resumes.push(resume);
        }
      });
      
      return resumes;
    }
  }

  // 通用表格策略
  class GenericTableStrategy extends Strategy {
    constructor() {
      super();
      this.name = 'GenericTableStrategy';
      this.priority = 2;
    }
    
    canHandle(analysis) {
      return analysis.indicators.dom.tableRows > 3;
    }
    
    extract(parser) {
      const resumes = [];
      const tables = document.querySelectorAll('table');
      
      tables.forEach(table => {
        const rows = table.querySelectorAll('tbody tr');
        rows.forEach(row => {
          const resume = parser.extractResumeFromGenericRow(row);
          if (resume.name) {
            resumes.push(resume);
          }
        });
      });
      
      return resumes;
    }
  }

  // 列表项策略
  class ListItemStrategy extends Strategy {
    constructor() {
      super();
      this.name = 'ListItemStrategy';
      this.priority = 4;
    }
    
    canHandle(analysis) {
      return document.querySelectorAll('ul li, ol li').length > 5;
    }
    
    extract(parser) {
      const resumes = [];
      const listItems = document.querySelectorAll('ul li, ol li');
      
      listItems.forEach(item => {
        const resume = parser.extractResumeFromListItem(item);
        if (resume.name) {
          resumes.push(resume);
        }
      });
      
      return resumes;
    }
  }

  // Div 布局策略
  class DivLayoutStrategy extends Strategy {
    constructor() {
      super();
      this.name = 'DivLayoutStrategy';
      this.priority = 5;
    }
    
    canHandle(analysis) {
      return document.querySelectorAll('div[class*="resume"], div[class*="candidate"]').length > 3;
    }
    
    extract(parser) {
      const resumes = [];
      const divs = document.querySelectorAll('div[class*="resume"], div[class*="candidate"]');
      
      divs.forEach(div => {
        const resume = parser.extractResumeFromDiv(div);
        if (resume.name) {
          resumes.push(resume);
        }
      });
      
      return resumes;
    }
  }

  // Smart Resume Parser 主类
  class SmartResumeParser {
    constructor() {
      this.isProcessing = false;
      this.config = null;
      this.pageType = 'unknown';
      this.performance = {
        extractionTime: 0,
        strategyUsage: {},
        errorCount: 0,
        lastReset: Date.now()
      };
      
      // 注册策略
      this.strategies = [
        new AntDesignTableStrategy(),
        new GenericTableStrategy(),
        new CardLayoutStrategy(),
        new ListItemStrategy(),
        new DivLayoutStrategy()
      ];
      
      // 初始化
      this.init();
    }

    /**
     * 初始化（测试友好版本）
     */
    init() {
      if (isExtensionEnvironment) {
        // 扩展环境下的正常初始化
        chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
          this.handleMessage(message, sender, sendResponse);
        });
      } else {
        // 测试环境下的简化初始化
        console.log('🔧 SmartResumeParser 测试环境初始化完成');
      }
    }

    /**
     * 处理消息（测试环境兼容）
     */
    handleMessage(message, sender, sendResponse) {
      if (!isExtensionEnvironment) {
        console.log('📨 测试环境收到消息:', message);
        return;
      }
      
      // 扩展环境的正常处理逻辑
      try {
        switch (message.action) {
          case 'INIT_RESUME':
            this.initResumeScraping(message.data);
            break;
          case 'SCRAPE_RESUME_LIST':
            this.scrapeResumeList(message.data);
            break;
          case 'SCRAPE_RESUME_DETAIL':
            this.scrapeResumeDetail(message.data);
            break;
          default:
            break;
        }
      } catch (error) {
        this.logError('消息处理错误', error);
      }
    }

    /**
     * 智能页面类型检测
     */
    analyzePageType() {
      const indicators = {
        url: {
          isResumeManagement: window.location.href.includes('resume') || 
                            window.location.href.includes('candidate') ||
                            window.location.href.includes('候选人'),
          isDetailPage: window.location.href.includes('detail') ||
                       window.location.href.includes('详情')
        },
        dom: {
          antTable: document.querySelector('.ant-table') !== null,
          tableRows: document.querySelectorAll('tbody tr').length,
          cardElements: document.querySelectorAll('.ant-card, .card, .resume-card').length,
          listItems: document.querySelectorAll('ul li, ol li').length,
          pagination: document.querySelector('.ant-pagination') !== null
        },
        content: {
          keywordCounts: this.countKeywords(),
          hasFormElements: document.querySelectorAll('input, textarea').length > 0
        }
      };

      // 计算最佳策略和置信度
      let bestStrategy = null;
      let highestConfidence = 0;
      
      for (const strategy of this.strategies) {
        const confidence = this.calculateStrategyConfidence(strategy, indicators);
        if (confidence > highestConfidence) {
          highestConfidence = confidence;
          bestStrategy = strategy;
        }
      }

      return {
        type: highestConfidence > 0.5 ? 'list' : 'unknown',
        confidence: highestConfidence,
        indicators,
        bestStrategy: bestStrategy ? bestStrategy.constructor.name : 'None'
      };
    }

    /**
     * 计算策略置信度
     */
    calculateStrategyConfidence(strategy, indicators) {
      switch (strategy.constructor.name) {
        case 'AntDesignTableStrategy':
          return (indicators.dom.antTable ? 0.8 : 0) + 
                 (indicators.dom.tableRows > 5 ? 0.2 : 0);
        
        case 'GenericTableStrategy':
          return indicators.dom.tableRows > 3 ? 0.7 : 0;
        
        case 'CardLayoutStrategy':
          return indicators.dom.cardElements > 0 ? 0.6 : 0;
        
        case 'ListItemStrategy':
          return indicators.dom.listItems > 5 ? 0.5 : 0;
        
        case 'DivLayoutStrategy':
          return (indicators.dom.cardElements > 3) ? 0.4 : 0;
        
        default:
          return 0;
      }
    }

    /**
     * 选择最佳策略
     */
    selectBestStrategy(analysis) {
      if (analysis.bestStrategy !== 'None') {
        return this.strategies.find(s => s.constructor.name === analysis.bestStrategy);
      }
      
      // 备选方案：按优先级排序
      return this.strategies.find(strategy => strategy.canHandle(analysis)) || this.strategies[0];
    }

    /**
     * 初始化简历抓取
     */
    async initResumeScraping(config = {}) {
      try {
        this.isProcessing = true;
        this.config = config;

        const pageAnalysis = this.analyzePageType();
        console.log('🔍 页面分析结果:', pageAnalysis);
        
        if (pageAnalysis.confidence > 0.3) {
          console.log(`✅ 检测到简历管理页面 (${pageAnalysis.bestStrategy})，置信度: ${Math.round(pageAnalysis.confidence * 100)}%`);
          
          const result = await this.scrapeResumeList(config);
          return result;
        } else {
          console.log('⚠️ 未检测到简历管理页面');
          return { error: '页面类型不匹配', analysis: pageAnalysis };
        }
      } catch (error) {
        this.logError('简历抓取初始化错误', error);
        return { error: error.message };
      }
    }

    /**
     * 抓取简历列表
     */
    async scrapeResumeList(config = {}) {
      const startTime = performance.now();
      
      try {
        const pageAnalysis = this.analyzePageType();
        const strategy = this.selectBestStrategy(pageAnalysis);
        
        console.log(`🎯 使用策略: ${strategy.constructor.name}`);
        
        const resumes = await strategy.extract(this);
        
        // 更新性能统计
        this.updateStrategyStats(strategy.constructor.name, performance.now() - startTime);
        
        const result = {
          success: true,
          resumes: resumes,
          count: resumes.length,
          strategy: strategy.constructor.name,
          confidence: pageAnalysis.confidence,
          pageAnalysis: pageAnalysis
        };
        
        console.log(`✅ 抓取完成: 提取到 ${resumes.length} 份简历`);
        return result;
        
      } catch (error) {
        this.logError('简历列表抓取错误', error);
        this.performance.errorCount++;
        return { success: false, error: error.message };
      }
    }

    /**
     * 从表格行提取简历信息
     */
    extractResumeFromRow(row) {
      const cells = row.querySelectorAll('td');
      const resume = {
        name: '',
        phone: '',
        email: '',
        position: '',
        experience: '',
        location: '',
        id: ''
      };

      // 姓名提取
      for (let i = 0; i < cells.length; i++) {
        const text = cells[i].textContent.trim();
        const name = this.extractCandidateName({ textContent: text });
        if (name) {
          resume.name = name;
          break;
        }
      }

      // 其他字段提取
      const allText = row.textContent;
      resume.phone = this.extractPhone({ textContent: allText });
      resume.email = this.extractEmail({ textContent: allText });
      resume.location = this.extractLocation({ textContent: allText });
      
      return resume;
    }

    /**
     * 从卡片提取简历信息
     */
    extractResumeFromCard(card) {
      const resume = {
        name: '',
        phone: '',
        email: '',
        position: '',
        experience: '',
        location: '',
        id: ''
      };

      const text = card.textContent;
      resume.name = this.extractCandidateName({ textContent: text });
      resume.phone = this.extractPhone({ textContent: text });
      resume.email = this.extractEmail({ textContent: text });
      resume.location = this.extractLocation({ textContent: text });

      return resume;
    }

    /**
     * 从通用行提取简历信息
     */
    extractResumeFromGenericRow(row) {
      return this.extractResumeFromRow(row); // 复用表格行逻辑
    }

    /**
     * 从列表项提取简历信息
     */
    extractResumeFromListItem(item) {
      const resume = {
        name: '',
        phone: '',
        email: '',
        position: '',
        experience: '',
        location: '',
        id: ''
      };

      const text = item.textContent;
      resume.name = this.extractCandidateName({ textContent: text });
      resume.phone = this.extractPhone({ textContent: text });
      resume.email = this.extractEmail({ textContent: text });
      resume.location = this.extractLocation({ textContent: text });

      return resume;
    }

    /**
     * 从Div元素提取简历信息
     */
    extractResumeFromDiv(div) {
      return this.extractResumeFromCard(div); // 复用卡片逻辑
    }

    /**
     * 提取候选人姓名（增强版）
     */
    extractCandidateName(element) {
      const text = element.textContent || '';
      
      const namePatterns = [
        // 中文姓名模式
        /([A-Z][a-z]+\s+[A-Z][a-z]+)/g,  // 英文名
        /([一-龥]{2,4})/g,               // 中文名
        // 姓名标识符
        /(?:姓名|name)[:\s]*([A-Za-z一-龥]+)/gi,
        /(?:候选人|candidate)[:\s]*([A-Za-z一-龥]+)/gi,
        // 职位前姓名
        /([A-Za-z一-龥]+)\s*[-–—]\s*(?:工程师|经理|总监|developer|manager)/gi
      ];

      for (const pattern of namePatterns) {
        const matches = text.match(pattern);
        if (matches) {
          for (const match of matches) {
            const name = match.replace(/^(?:姓名|name|候选人|candidate)[:\s]*/i, '').trim();
            if (this.isValidName(name)) {
              return name;
            }
          }
        }
      }

      return '';
    }

    /**
     * 提取电话号码
     */
    extractPhone(element) {
      const text = element.textContent || '';
      
      const phonePatterns = [
        /(?:手机|tel|电话|phone)[:\s]*([1][3-9]\d{9})/gi,
        /([1][3-9]\d{9})/g,
        /(\d{3}[-.\s]?\d{4}[-.\s]?\d{4})/g
      ];

      for (const pattern of phonePatterns) {
        const matches = text.match(pattern);
        if (matches) {
          for (const match of matches) {
            const phone = match.replace(/^(?:手机|tel|电话|phone)[:\s]*/i, '').trim();
            if (this.isValidPhone(phone)) {
              return phone;
            }
          }
        }
      }

      return '';
    }

    /**
     * 提取邮箱地址
     */
    extractEmail(element) {
      const text = element.textContent || '';
      
      const emailPattern = /([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/g;
      const matches = text.match(emailPattern);
      
      return matches ? matches[0] : '';
    }

    /**
     * 提取地址信息
     */
    extractLocation(element) {
      const text = element.textContent || '';
      
      const locationPatterns = [
        /(?:地址|location|所在地)[:\s]*([^,\n\r]{2,20})/gi,
        /([一-龥]{2,8}[市区县])/g,
        /(北京|上海|广州|深圳|杭州|南京|苏州|无锡|成都|武汉)[一-龥]*/g
      ];

      for (const pattern of locationPatterns) {
        const matches = text.match(pattern);
        if (matches) {
          for (const match of matches) {
            const location = match.replace(/^(?:地址|location|所在地)[:\s]*/i, '').trim();
            if (location.length >= 2 && location.length <= 20) {
              return location;
            }
          }
        }
      }

      return '';
    }

    /**
     * 姓名有效性验证
     */
    isValidName(name) {
      if (!name || name.length < 2 || name.length > 10) return false;
      
      // 排除职位、技术词汇等
      const excludeWords = ['工程师', '经理', '总监', 'developer', 'manager', '前端', '后端', '产品'];
      return !excludeWords.some(word => name.includes(word));
    }

    /**
     * 电话号码有效性验证
     */
    isValidPhone(phone) {
      return /^1[3-9]\d{9}$/.test(phone.replace(/[-.\s]/g, ''));
    }

    /**
     * 统计关键词
     */
    countKeywords() {
      const text = document.body.textContent.toLowerCase();
      const keywords = ['简历', '候选人', '职位', '经验', '技能', '教育', '工作'];
      
      const counts = {};
      keywords.forEach(keyword => {
        counts[keyword] = (text.match(new RegExp(keyword, 'g')) || []).length;
      });
      
      return counts;
    }

    /**
     * 更新策略统计
     */
    updateStrategyStats(strategyName, executionTime) {
      if (!this.performance.strategyUsage[strategyName]) {
        this.performance.strategyUsage[strategyName] = { count: 0, totalTime: 0 };
      }
      
      this.performance.strategyUsage[strategyName].count++;
      this.performance.strategyUsage[strategyName].totalTime += executionTime;
    }

    /**
     * 记录错误
     */
    logError(message, error) {
      console.error(`❌ ${message}:`, error);
      this.performance.errorCount++;
      
      if (!isExtensionEnvironment) {
        // 测试环境下也发送错误到背景脚本（如果存在）
        try {
          if (chrome.runtime) {
            chrome.runtime.sendMessage({
              action: 'RESUME_SCRAPING_ERROR',
              data: { error: error.message }
            });
          }
        } catch (e) {
          // 忽略错误
        }
      }
    }

    /**
     * 获取性能统计
     */
    getStats() {
      return {
        extractionTime: this.performance.extractionTime,
        strategyUsage: this.performance.strategyUsage,
        errorCount: this.performance.errorCount,
        lastReset: this.performance.lastReset,
        isProcessing: this.isProcessing,
        currentPageType: this.pageType
      };
    }

    /**
     * 重置统计
     */
    resetStats() {
      this.performance = {
        extractionTime: 0,
        strategyUsage: {},
        errorCount: 0,
        lastReset: Date.now()
      };
      console.log('📊 性能统计已重置');
    }

    /**
     * 发送消息到背景脚本（测试环境兼容）
     */
    sendMessageToBackground(message) {
      if (isExtensionEnvironment && chrome.runtime) {
        chrome.runtime.sendMessage(message);
      } else {
        console.log('📤 发送到背景脚本:', message);
      }
    }
  }

  // 在全局作用域中暴露类和实例
  window.SmartResumeParser = SmartResumeParser;
  window.AntDesignTableStrategy = AntDesignTableStrategy;
  window.CardLayoutStrategy = CardLayoutStrategy;
  window.GenericTableStrategy = GenericTableStrategy;
  window.ListItemStrategy = ListItemStrategy;
  window.DivLayoutStrategy = DivLayoutStrategy;

  // 创建全局实例
  window.smartResumeParser = new SmartResumeParser();

  // 全局调试函数
  window.debugSmartResumeParser = function() {
    console.log('🔍 Smart Resume Parser 调试信息');
    console.log('===================');
    
    const parser = window.smartResumeParser;
    const analysis = parser.analyzePageType();
    const stats = parser.getStats();
    
    console.log('📊 页面分析:');
    console.log('  类型:', analysis.type);
    console.log('  置信度:', Math.round(analysis.confidence * 100) + '%');
    console.log('  推荐策略:', analysis.bestStrategy);
    console.log('  DOM指标:', analysis.indicators.dom);
    
    console.log('📈 性能统计:');
    console.log('  策略使用情况:', stats.strategyUsage);
    console.log('  错误计数:', stats.errorCount);
    console.log('  总执行时间:', stats.extractionTime.toFixed(2) + 'ms');
    
    return { analysis, stats };
  };

  window.getSmartParserStats = function() {
    return window.smartResumeParser.getStats();
  };

  console.log('🎯 Smart Resume Parser 测试版本已加载完成！');
  console.log('📋 可用命令:');
  console.log('  - smartResumeParser.initResumeScraping()');
  console.log('  - smartResumeParser.analyzePageType()');
  console.log('  - smartResumeParser.scrapeResumeList()');
  console.log('  - getSmartParserStats()');
  console.log('  - debugSmartResumeParser()');

})();