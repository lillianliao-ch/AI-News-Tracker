// 简历详情页抓取功能验证测试
console.log('=== 简历详情页功能测试 ===');

// 1. 测试消息处理器是否正确注册
console.log('\n1. 检查消息处理器注册状态:');
console.log('消息监听器注册状态:', !!window.jobScraperListenerRegistered);

// 2. 测试简历详情抓取函数
console.log('\n2. 测试简历详情抓取函数:');
console.log('scrapeResumeDetail 函数:', typeof scrapeResumeDetail);
console.log('findAndClickResumeLink 函数:', typeof findAndClickResumeLink);
console.log('extractResumeDetail 函数:', typeof extractResumeDetail);
console.log('extractText 辅助函数:', typeof extractText);

// 3. 测试当前页面状态
console.log('\n3. 检查当前页面状态:');
const currentUrl = window.location.href;
console.log('当前URL:', currentUrl);
console.log('是否为简历详情页:', 
  currentUrl.includes('resumeCode') || 
  currentUrl.includes('FORM-') ||
  currentUrl.includes('resume'));

// 4. 模拟简历详情抓取测试
console.log('\n4. 模拟简历详情抓取:');
const testResumeData = {
  resumeId: 'test_001',
  url: currentUrl
};

console.log('测试数据:', testResumeData);

// 5. 测试链接查找功能
console.log('\n5. 测试简历链接查找:');
const linkSelectors = [
  'a[href*="resumeCode"]',
  'a[href*="FORM-"]',
  'a[href*="resume"]',
  'a[href*="candidate"]',
  'a[href*="detail"]'
];

let totalLinks = 0;
let resumeLinks = 0;

linkSelectors.forEach(selector => {
  const links = document.querySelectorAll(selector);
  totalLinks += links.length;
  
  links.forEach(link => {
    const href = link.href || link.getAttribute('href');
    if (href && (href.includes('resumeCode') || href.includes('FORM-') || href.includes('resume'))) {
      resumeLinks++;
    }
  });
});

console.log(`找到 ${totalLinks} 个候选链接，其中 ${resumeLinks} 个可能是简历链接`);

// 6. 测试页面内容提取
console.log('\n6. 测试页面内容提取:');
try {
  const name = extractText('h1, h2, [class*="name"], [class*="title"]');
  const phone = extractText('[class*="phone"], [class*="mobile"]');
  const email = extractText('[class*="email"], [class*="mail"]');
  
  console.log('姓名:', name);
  console.log('电话:', phone);
  console.log('邮箱:', email);
} catch (error) {
  console.error('内容提取测试失败:', error);
}

// 7. 模拟点击测试（仅记录，不实际执行）
console.log('\n7. 模拟点击测试:');
const firstResumeLink = document.querySelector('a[href*="resumeCode"], a[href*="FORM-"], a[href*="resume"]');
if (firstResumeLink) {
  console.log('找到第一个简历链接:', firstResumeLink.href);
  console.log('模拟点击事件...');
  
  // 创建模拟点击事件
  const clickEvent = new MouseEvent('click', {
    view: window,
    bubbles: true,
    cancelable: true
  });
  
  console.log('点击事件已创建（未实际执行）');
} else {
  console.log('未找到简历链接供测试');
}

// 8. 总结测试结果
console.log('\n=== 测试总结 ===');
const allTests = [
  !!window.jobScraperListenerRegistered,
  typeof scrapeResumeDetail === 'function',
  typeof findAndClickResumeLink === 'function',
  typeof extractResumeDetail === 'function',
  typeof extractText === 'function'
];

const passedTests = allTests.filter(test => test).length;
console.log(`测试通过: ${passedTests}/${allTests.length}`);

if (passedTests === allTests.length) {
  console.log('✅ 所有测试通过！简历详情页抓取功能已就绪');
} else {
  console.log('❌ 部分测试失败，需要进一步检查');
}

// 9. 提供下一步操作建议
console.log('\n=== 操作建议 ===');
console.log('1. 刷新简历列表页面');
console.log('2. 启动简历抓取功能');
console.log('3. 观察是否能正确打开简历详情页');
console.log('4. 检查控制台是否有相关日志输出');