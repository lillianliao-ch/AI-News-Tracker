// 最终调试测试脚本 - 验证姓名提取修复
// 在浏览器控制台运行此脚本

console.log("🔍 最终调试测试 - 验证姓名提取修复");
console.log("=".repeat(50));

// 立即测试当前页面
async function runFinalTest() {
  try {
    // 1. 检查页面基本信息
    console.log("📄 页面基本信息:");
    console.log("  URL:", window.location.href);
    console.log("  页面标题:", document.title);
    
    // 2. 获取页面文本内容
    const fullText = document.body.innerText || '';
    console.log("📄 页面文本长度:", fullText.length);
    
    // 3. 查找"猎头系统"在页面中的位置
    const猎头系统位置 = fullText.indexOf('猎头系统');
    console.log("🔍 '猎头系统'在页面中的位置:", 猎头系统位置);
    if (猎头系统位置 !== -1) {
      console.log("  上下文:", fullText.substring(猎头系统位置 - 20, 猎头系统位置 + 20));
    }
    
    // 4. 测试姓名验证函数
    console.log("\n🧪 测试姓名验证函数:");
    const testNames = ['张三', '李四', '王五', '猎头系统', '页面管理', '管理系统', '真实姓名'];
    testNames.forEach(name => {
      const isValid = isValidPersonName(name);
      console.log(`  ${name}: ${isValid ? '✅ 有效' : '❌ 无效'}`);
    });
    
    // 5. 测试智能姓名提取
    console.log("\n🔍 测试智能姓名提取:");
    const extractedName = extractNameFromContentSmart(fullText);
    console.log(`提取的姓名: ${extractedName}`);
    
    // 6. 查找所有可能的姓名候选
    console.log("\n📝 查找所有可能的姓名候选:");
    const lines = fullText.split('\n').map(line => line.trim()).filter(line => line.length > 0);
    const nameCandidates = [];
    lines.forEach((line, index) => {
      if (line.length >= 2 && line.length <= 6 && 
          !line.includes('猎头') && !line.includes('系统') && 
          !line.includes('管理') && !line.includes('平台') &&
          !line.includes('页面') && !line.includes('列表') &&
          /^[一-龯]{2,4}$/.test(line)) {
        nameCandidates.push({ index, line });
      }
    });
    
    if (nameCandidates.length > 0) {
      console.log("找到的有效姓名候选:");
      nameCandidates.forEach(candidate => {
        console.log(`  行 ${candidate.index}: "${candidate.line}"`);
      });
    } else {
      console.log("未找到任何有效的姓名候选");
    }
    
    // 7. 测试表格结构提取
    console.log("\n📋 测试表格结构提取:");
    const tableData = extractFieldsFromTable();
    console.log("表格提取的数据:", tableData);
    
    // 8. 测试完整提取函数
    console.log("\n🚀 运行完整的简历详情提取函数:");
    const result = await extractResumeDetail();
    
    if (result) {
      console.log("✅ 完整提取成功!");
      console.log("📊 最终提取结果:");
      console.log(`  姓名: ${result.name || '未找到'}`);
      console.log(`  电话: ${result.phone || '未找到'}`);
      console.log(`  邮箱: ${result.email || '未找到'}`);
      console.log(`  现居地: ${result.location || '未找到'}`);
      console.log(`  当前职位: ${result.currentTitle || '未找到'}`);
      console.log(`  工作年限: ${result.yearsExp || '未找到'}`);
      console.log(`  期望职位: ${result.expectedTitle || '未找到'}`);
      console.log(`  期望薪资: ${result.expectedSalary || '未找到'}`);
      
      // 验证关键结果
      const 姓名验证成功 = result.name && 
                          result.name !== '未知' && 
                          !result.name.includes('猎头系统') &&
                          !result.name.includes('系统') &&
                          !result.name.includes('管理');
      
      console.log("\n📊 验证结果:");
      console.log(`姓名验证: ${姓名验证成功 ? '✅ 通过' : '❌ 失败'}`);
      if (result.name) {
        console.log(`提取的姓名: "${result.name}"`);
      }
      
      if (姓名验证成功) {
        console.log("\n🎉 姓名提取修复成功！");
        console.log("💡 现在应该能够正确提取真实的人名了。");
        return true;
      } else {
        console.log("\n⚠️ 姓名提取仍有问题，需要进一步调试。");
        console.log("💡 请查看上面的调试信息，找出问题的原因。");
        return false;
      }
    } else {
      console.log("❌ 提取失败");
      return false;
    }
    
  } catch (error) {
    console.error("❌ 测试过程中出错:", error);
    return false;
  }
}

// 如果在浏览器环境中，自动运行测试
if (typeof window !== 'undefined' && typeof document !== 'undefined') {
  console.log("🌐 检测到浏览器环境，开始最终调试测试...");
  
  // 检查必要的函数是否存在
  if (typeof extractResumeDetail === 'function') {
    console.log("✅ extractResumeDetail 函数已定义");
    console.log("✅ 准备运行最终测试...");
    setTimeout(runFinalTest, 2000); // 等待2秒让页面稳定
  } else {
    console.log("❌ extractResumeDetail 函数未定义");
    console.log("请确保先加载 content.js 文件");
  }
}

// 导出函数供手动调用
window.finalDebugTest = {
  runFinalTest
};