// 简历数据提取优化测试脚本
// 在浏览器控制台中运行此脚本，测试修复后的简历详情提取功能

console.log("🚀 开始测试优化后的简历详情提取功能...");

// 测试1：检查新增的函数是否正确加载
function checkFunctionsLoaded() {
  console.log("📋 检查关键函数加载状态:");
  
  const functions = [
    'extractTextFromSelectors',
    'extractFieldsFromTable', 
    'extractSectionByKeyword',
    'extractNameFromContent',
    'extractLocationFromContent',
    'extractExpectedTitleFromContent'
  ];
  
  functions.forEach(funcName => {
    const loaded = typeof window[funcName] === 'function';
    console.log(`  ${loaded ? '✅' : '❌'} ${funcName}: ${loaded ? '已加载' : '未加载'}`);
  });
  
  return functions.every(funcName => typeof window[funcName] === 'function');
}

// 测试2：提取页面基本信息
function extractBasicInfo() {
  console.log("📄 提取页面基本信息...");
  
  const info = {
    title: document.title,
    url: window.location.href,
    headings: Array.from(document.querySelectorAll('h1, h2, h3')).map(h => h.textContent.trim()),
    paragraphs: document.querySelectorAll('p').length
  };
  
  console.log("页面信息:", info);
  return info;
}

// 测试3：测试增强的数据提取功能
function testEnhancedExtraction() {
  console.log("🔍 测试增强的数据提取功能...");
  
  try {
    // 测试多选择器文本提取
    const testSelectors = ['h1', 'h2', '[class*="name"]'];
    const extractedName = extractTextFromSelectors(testSelectors);
    console.log(`提取的姓名: ${extractedName || '未找到'}`);
    
    // 测试文本模式匹配
    const fullText = document.body.innerText || '';
    
    // 测试电话提取
    const phonePattern = /(?:电话[:：]\s*|手机[:：]\s*|联系电话[:：]\s*)(\d{11})/;
    const phoneMatch = fullText.match(phonePattern);
    console.log(`提取的电话: ${phoneMatch ? phoneMatch[1] : '未找到'}`);
    
    // 测试邮箱提取
    const emailPattern = /([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/;
    const emailMatch = fullText.match(emailPattern);
    console.log(`提取的邮箱: ${emailMatch ? emailMatch[1] : '未找到'}`);
    
    // 测试表格字段提取
    const tableData = extractFieldsFromTable();
    console.log("表格提取的数据:", tableData);
    
    return {
      name: extractedName,
      phone: phoneMatch ? phoneMatch[1] : '',
      email: emailMatch ? emailMatch[1] : '',
      tableData: tableData
    };
    
  } catch (error) {
    console.error("❌ 测试增强提取功能时出错:", error);
    return null;
  }
}

// 测试4：测试全局存储功能（后台脚本）
function testGlobalStorage() {
  console.log("💾 测试全局简历存储功能...");
  
  // 向后台脚本发送消息检查存储状态
  chrome.runtime.sendMessage({
    action: 'CHECK_GLOBAL_STORAGE'
  }, (response) => {
    if (chrome.runtime.lastError) {
      console.log("⚠️ 无法检查全局存储（扩展未运行或消息传递失败）");
    } else {
      console.log("全局存储状态:", response);
    }
  });
}

// 测试5：模拟完整的简历详情提取流程
async function testFullExtraction() {
  console.log("🔄 测试完整简历详情提取流程...");
  
  try {
    // 调用完整的提取函数
    const resumeData = await extractResumeDetail();
    
    if (resumeData) {
      console.log("✅ 完整提取成功!");
      console.log("📊 提取的简历数据:");
      
      // 格式化输出关键字段
      const keyFields = ['name', 'phone', 'email', 'location', 'currentTitle', 'expectedTitle'];
      keyFields.forEach(field => {
        const value = resumeData[field] || '';
        console.log(`  ${field}: ${value || '(未找到)'}`);
      });
      
      // 检查数据质量
      const hasBasicInfo = resumeData.name && resumeData.name !== '未知';
      const hasContactInfo = resumeData.phone || resumeData.email;
      
      console.log(`📈 数据质量检查:`);
      console.log(`  基本信息: ${hasBasicInfo ? '✅' : '❌'}`);
      console.log(`  联系信息: ${hasContactInfo ? '✅' : '❌'}`);
      
      return resumeData;
    } else {
      console.log("❌ 提取失败");
      return null;
    }
  } catch (error) {
    console.error("❌ 完整提取测试失败:", error);
    return null;
  }
}

// 主测试函数
async function runAllTests() {
  console.log("=".repeat(50));
  console.log("📋 简历数据提取优化测试开始");
  console.log("=".repeat(50));
  
  // 1. 检查函数加载
  const functionsLoaded = checkFunctionsLoaded();
  console.log();
  
  // 2. 提取基本信息
  const basicInfo = extractBasicInfo();
  console.log();
  
  // 3. 测试增强提取
  const enhancedData = testEnhancedExtraction();
  console.log();
  
  // 4. 检查全局存储
  testGlobalStorage();
  console.log();
  
  // 5. 完整提取测试
  const fullData = await testFullExtraction();
  console.log();
  
  // 6. 总结
  console.log("=".repeat(50));
  console.log("📊 测试总结");
  console.log("=".repeat(50));
  console.log(`函数加载状态: ${functionsLoaded ? '✅ 通过' : '❌ 失败'}`);
  console.log(`基本信息提取: ${basicInfo ? '✅ 通过' : '❌ 失败'}`);
  console.log(`增强提取测试: ${enhancedData ? '✅ 通过' : '❌ 失败'}`);
  console.log(`完整提取测试: ${fullData ? '✅ 通过' : '❌ 失败'}`);
  
  if (fullData) {
    console.log("\n🎉 测试通过！简历详情提取功能正常工作。");
    console.log("💡 接下来可以：");
    console.log("   1. 在后台控制台查看数据导出信息");
    console.log("   2. 检查下载的CSV文件包含完整的简历数据");
    console.log("   3. 验证多批次数据是否正确合并到同一个文件");
  } else {
    console.log("\n⚠️ 测试未完全通过，请检查控制台错误信息。");
  }
  
  return {
    functionsLoaded,
    basicInfo,
    enhancedData,
    fullData
  };
}

// 自动运行测试（如果是在浏览器环境中）
if (typeof window !== 'undefined' && typeof document !== 'undefined') {
  // 等待DOM完全加载
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', runAllTests);
  } else {
    // DOM已经加载完成
    setTimeout(runAllTests, 1000);
  }
} else {
  // 导出测试函数供手动调用
  window.testResumeOptimization = {
    checkFunctionsLoaded,
    extractBasicInfo,
    testEnhancedExtraction,
    testGlobalStorage,
    testFullExtraction,
    runAllTests
  };
}