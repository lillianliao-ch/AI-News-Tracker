#!/usr/bin/env python3
"""
Gmail API 授权测试程序
"""

import os
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

# Gmail API 权限范围
SCOPES = ['https://www.googleapis.com/auth/gmail.readonly']

def test_gmail_auth():
    """测试 Gmail API 授权"""
    print("🔑 Gmail API 授权测试")
    print("=" * 50)
    
    credentials_path = 'config/credentials.json'
    token_path = 'data/token.json'
    
    # 检查凭证文件
    if not os.path.exists(credentials_path):
        print(f"❌ 未找到凭证文件: {credentials_path}")
        return False
    
    print(f"✅ 凭证文件存在: {credentials_path}")
    
    creds = None
    
    # 检查是否已有 token
    if os.path.exists(token_path):
        print("📋 加载已保存的 token...")
        creds = Credentials.from_authorized_user_file(token_path, SCOPES)
    
    # 如果没有有效凭证，进行授权
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            print("🔄 刷新过期的 token...")
            creds.refresh(Request())
        else:
            print("🌐 开始 OAuth 授权流程...")
            print("   - 浏览器将会打开")
            print("   - 请选择你的 Google 账号")
            print("   - 点击'允许'完成授权")
            print()
            
            flow = InstalledAppFlow.from_client_secrets_file(
                credentials_path, SCOPES
            )
            creds = flow.run_local_server(port=0)
        
        # 保存 token
        os.makedirs(os.path.dirname(token_path), exist_ok=True)
        with open(token_path, 'w') as token:
            token.write(creds.to_json())
        print(f"✅ Token 已保存: {token_path}")
    
    # 测试 Gmail API
    try:
        print("📧 测试 Gmail API 连接...")
        service = build('gmail', 'v1', credentials=creds)
        
        # 获取用户基本信息
        profile = service.users().getProfile(userId='me').execute()
        print(f"✅ Gmail API 连接成功！")
        print(f"   邮箱地址: {profile.get('emailAddress')}")
        print(f"   总邮件数: {profile.get('messagesTotal', 0):,}")
        
        # 测试搜索邮件
        print("🔍 测试邮件搜索...")
        results = service.users().messages().list(
            userId='me',
            q='subject:"推荐了简历候选人"',
            maxResults=5
        ).execute()
        
        messages = results.get('messages', [])
        print(f"✅ 找到 {len(messages)} 封匹配的邮件")
        
        return True
        
    except Exception as e:
        print(f"❌ Gmail API 测试失败: {e}")
        return False

if __name__ == '__main__':
    try:
        success = test_gmail_auth()
        if success:
            print("\n🎉 Gmail API 授权和测试完全成功！")
            print("现在可以运行完整的程序了：")
            print("python src/main_simple.py")
        else:
            print("\n❌ 授权测试失败，请检查配置")
    except KeyboardInterrupt:
        print("\n\n⚠️ 用户中断操作")
    except Exception as e:
        print(f"\n❌ 测试过程中出错: {e}")
        import traceback
        traceback.print_exc()
