#!/usr/bin/env python3
"""
高级邮件调试 - 深度分析邮件结构
"""

import sys
import json
import base64
from pathlib import Path
from src.gmail_client_clean import CleanGmailClient

def debug_emails_advanced():
    """深度调试邮件结构"""
    print("🔍 深度调试邮件结构")
    print("=" * 50)
    
    credentials_path = 'config/credentials.json'
    token_path = 'data/token.json'
    
    try:
        # 初始化客户端
        client = CleanGmailClient(credentials_path, token_path)
        
        # 搜索邮件
        query = 'subject:"推荐了简历候选人"'
        messages = client.search_emails(query, max_results=1)  # 只分析第一封
        
        if not messages:
            print("⚠️ 未找到邮件")
            return
        
        message_id = messages[0]['id']
        print(f"📧 分析邮件 ID: {message_id}")
        
        # 获取完整的邮件内容
        email_detail = client.service.users().messages().get(
            userId='me', id=message_id, format='full'
        ).execute()
        
        # 分析邮件结构
        print("\n📋 邮件结构分析:")
        print(f"Message ID: {email_detail.get('id')}")
        print(f"Thread ID: {email_detail.get('threadId')}")
        print(f"Label IDs: {email_detail.get('labelIds', [])}")
        
        # 分析 payload
        payload = email_detail.get('payload', {})
        print(f"\nPayload 信息:")
        print(f"MIME Type: {payload.get('mimeType')}")
        print(f"Filename: {payload.get('filename', 'N/A')}")
        
        # 递归分析所有 parts
        all_content = []
        analyze_parts(payload, all_content, depth=0)
        
        # 显示所有找到的内容
        print(f"\n📄 找到 {len(all_content)} 个内容部分:")
        for i, content in enumerate(all_content, 1):
            print(f"\n--- 内容部分 {i} ---")
            print(f"MIME Type: {content['mimeType']}")
            print(f"长度: {len(content['data'])} 字符")
            
            # 查找URL
            import re
            urls = re.findall(r'https?://[^\s<>"\'()]+', content['data'])
            print(f"URL数量: {len(urls)}")
            
            for url in urls:
                print(f"  - {url}")
                if 'zhipin' in url.lower() or 'boss' in url.lower():
                    print(f"    *** Boss直聘链接! ***")
            
            # 显示内容片段
            if content['data']:
                print(f"内容片段 (前200字符):")
                print(content['data'][:200])
                print("...")
        
        # 保存调试信息到文件
        debug_info = {
            'message_id': message_id,
            'payload_structure': payload,
            'extracted_content': all_content
        }
        
        with open('debug_email_structure.json', 'w', encoding='utf-8') as f:
            json.dump(debug_info, f, ensure_ascii=False, indent=2)
        
        print(f"\n💾 详细调试信息已保存到: debug_email_structure.json")
    
    except Exception as e:
        print(f"❌ 调试失败: {e}")
        import traceback
        traceback.print_exc()

def analyze_parts(payload, all_content, depth=0):
    """递归分析邮件的所有部分"""
    indent = "  " * depth
    
    mime_type = payload.get('mimeType', '')
    print(f"{indent}📂 Part: {mime_type}")
    
    # 如果有body数据，尝试解码
    body = payload.get('body', {})
    if body.get('data'):
        try:
            decoded_data = base64.urlsafe_b64decode(body['data']).decode('utf-8', errors='ignore')
            all_content.append({
                'mimeType': mime_type,
                'data': decoded_data
            })
            print(f"{indent}  ✅ 提取到 {len(decoded_data)} 字符")
        except Exception as e:
            print(f"{indent}  ❌ 解码失败: {e}")
    
    # 递归处理子部分
    if 'parts' in payload:
        print(f"{indent}  📁 包含 {len(payload['parts'])} 个子部分")
        for i, part in enumerate(payload['parts']):
            print(f"{indent}    📄 子部分 {i+1}:")
            analyze_parts(part, all_content, depth + 2)

if __name__ == '__main__':
    debug_emails_advanced()
