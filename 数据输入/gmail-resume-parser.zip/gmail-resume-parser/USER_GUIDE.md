# 📖 Gmail简历解析器 - 完整使用指南

## 🎯 程序功能

这个程序的作用是：
1. 从你的Gmail邮箱中搜索Boss直聘的简历推荐邮件
2. 自动提取邮件中的Boss简历链接
3. 访问Boss页面并解析简历内容
4. 将所有简历信息导出到Excel文件

---

## 🚀 正常使用流程

### 第一次使用（需要配置）

#### 步骤1：安装依赖（已完成 ✅）
```bash
cd /Users/lillianliao/notion_rag/gmail-resume-parser
pip install -r requirements.txt
```
**状态**：✅ 已完成，依赖都已安装

---

#### 步骤2：配置Gmail API（已完成 ✅）
- ✅ Gmail OAuth凭证：`config/credentials.json`
- ✅ 授权Token：`data/token.json`
- ✅ 首次授权已完成，可以直接使用

**状态**：✅ 已完成，无需重新配置

---

#### 步骤3：配置搜索条件（可选调整）

编辑配置文件：
```bash
cd /Users/lillianliao/notion_rag/gmail-resume-parser
nano config/config.env
```

**当前配置**：
```env
# Gmail搜索查询
GMAIL_QUERY=subject:"推荐了简历候选人"

# 输出文件名
OUTPUT_FILE=resumes_export.xlsx

# 最大邮件数量（0=不限制）
MAX_EMAILS=0

# 使用Selenium（Boss页面需要）
USE_SELENIUM=true
```

**常用搜索条件**：
```env
# 1. 搜索最近7天的Boss推荐
GMAIL_QUERY=subject:"推荐了简历候选人" from:cv@notice.zhipin.com newer_than:7d

# 2. 搜索最近30天的
GMAIL_QUERY=subject:"推荐了简历候选人" from:cv@notice.zhipin.com newer_than:30d

# 3. 搜索特定时间段
GMAIL_QUERY=subject:"推荐了简历候选人" from:cv@notice.zhipin.com after:2024/11/01 before:2024/11/20

# 4. 限制处理数量（测试用）
MAX_EMAILS=10
```

---

### 日常使用（已配置好后）

#### 使用方法A：直接运行主程序（推荐）

```bash
cd /Users/lillianliao/notion_rag/gmail-resume-parser

# 运行主程序
python3 src/main.py
```

**程序会自动**：
1. 🔍 连接Gmail API（使用已保存的Token）
2. 📧 搜索匹配的邮件
3. 🔗 提取Boss简历链接
4. 📄 访问Boss页面解析简历
5. 📊 导出到Excel文件

**输出**：
```
output/resumes_export.xlsx
```

---

#### 使用方法B：使用启动脚本（更友好）

```bash
cd /Users/lillianliao/notion_rag/gmail-resume-parser

# 运行启动脚本（会先检查环境）
python3 start.py
```

**优点**：
- ✅ 自动检查环境配置
- ✅ 显示友好的提示信息
- ✅ 自动运行主程序

---

#### 使用方法C：测试模式（小批量测试）

```bash
cd /Users/lillianliao/notion_rag/gmail-resume-parser

# 1. 修改配置限制数量
echo "MAX_EMAILS=5" >> config/config.env

# 2. 运行测试
python3 final_test.py

# 3. 查看结果
open output/
```

---

## 📊 预期的正常流程

### 1. 程序启动
```
============================================================
📧 Gmail 简历批量解析工具
============================================================

📋 配置信息:
   Gmail 查询: subject:"推荐了简历候选人" from:cv@notice.zhipin.com
   输出文件: /path/to/output/resumes_export.xlsx
   最大邮件数: 无限制
```

### 2. Gmail认证
```
✅ Gmail API 认证成功
```
（使用已保存的Token，不需要重新授权）

### 3. 搜索邮件
```
🔍 正在搜索邮件...
📧 找到 25 封邮件
📧 找到 25 封邮件，开始处理...
```

### 4. 处理邮件（带进度条）
```
处理邮件: 100%|██████████| 25/25 [00:10<00:00,  2.50it/s]
```

### 5. 提取Boss链接
```
📧 邮件 1: 找到 2 个Boss链接
📧 邮件 2: 找到 1 个Boss链接
...
```

### 6. 解析简历
```
📄 正在解析: 张三 - 高级算法工程师
✅ 解析成功

📄 正在解析: 李四 - 产品经理
✅ 解析成功
...
```

### 7. 导出结果
```
============================================================
📊 处理完成
============================================================
✅ 成功解析: 20 份简历
❌ 解析失败: 5 个

📁 输出文件: output/resumes_export.xlsx
```

### 8. 查看结果
```bash
# 打开Excel文件
open output/resumes_export.xlsx
```

---

## 📋 输出的Excel文件格式

### Excel列结构
```
序号 | 姓名 | 职位 | 年龄 | 工作年限 | 学历 | 
当前公司 | 当前职位 | 工作状态 | 
期望职位 | 期望薪资 | 期望地点 | 期望行业 |
工作经历(JSON) | 项目经历(JSON) | 教育经历(JSON) | 
资格证书 | 技能标签 | 简历链接 | 解析时间
```

### 数据示例
```
序号: 1
姓名: 张三
职位: 高级算法工程师
年龄: 30岁
工作年限: 7年
学历: 硕士
当前公司: 腾讯科技
期望薪资: 45-75K
简历链接: https://m.zhipin.com/mpa/v3/html/resume/detail?...
```

---

## 🔄 常见使用场景

### 场景1：每周批量获取新简历

```bash
# 1. 修改配置（只获取最近7天）
nano config/config.env
# 设置：GMAIL_QUERY=subject:"推荐了简历候选人" from:cv@notice.zhipin.com newer_than:7d

# 2. 运行程序
python3 src/main.py

# 3. 查看结果
open output/resumes_export.xlsx
```

**时间**：取决于邮件数量，通常5-10分钟

---

### 场景2：获取特定时间段的简历

```bash
# 例如：获取11月1-15日的简历
nano config/config.env
# 设置：GMAIL_QUERY=subject:"推荐了简历候选人" after:2024/11/01 before:2024/11/15

python3 src/main.py
```

---

### 场景3：测试功能（处理少量邮件）

```bash
# 1. 限制数量
nano config/config.env
# 设置：MAX_EMAILS=5

# 2. 运行
python3 src/main.py

# 3. 检查输出
ls -lh output/
```

---

### 场景4：重新处理之前的邮件

```bash
# 删除旧的输出文件
rm output/resumes_export.xlsx

# 重新运行
python3 src/main.py
```

---

## ⚙️ 配置选项详解

### Gmail搜索语法

支持完整的Gmail搜索语法：

```env
# 按主题搜索
GMAIL_QUERY=subject:"推荐了简历候选人"

# 按发件人搜索
GMAIL_QUERY=from:cv@notice.zhipin.com

# 按时间搜索
GMAIL_QUERY=newer_than:7d  # 最近7天
GMAIL_QUERY=older_than:30d  # 30天前的

# 按日期范围
GMAIL_QUERY=after:2024/11/01 before:2024/11/20

# 组合搜索
GMAIL_QUERY=subject:"推荐了简历候选人" from:cv@notice.zhipin.com newer_than:7d

# 未读邮件
GMAIL_QUERY=is:unread subject:"推荐了简历候选人"
```

### 输出文件配置

```env
# 自定义输出文件名
OUTPUT_FILE=boss_resumes_202411.xlsx

# 文件会保存在 output/ 目录下
```

### 处理数量限制

```env
# 不限制（处理所有匹配的邮件）
MAX_EMAILS=0

# 限制数量（用于测试）
MAX_EMAILS=10
MAX_EMAILS=50
```

---

## 🛠️ 高级功能

### 功能1：使用Selenium处理Boss页面

如果Boss页面需要JavaScript渲染：

```env
# 启用Selenium
USE_SELENIUM=true

# 指定ChromeDriver路径（macOS通常自动检测）
SELENIUM_DRIVER_PATH=/usr/local/bin/chromedriver
```

### 功能2：并行处理（加速）

修改 `src/main.py` 可以添加并行处理：
```python
# 使用线程池并行处理
from concurrent.futures import ThreadPoolExecutor

with ThreadPoolExecutor(max_workers=3) as executor:
    results = executor.map(parse_resume, boss_links)
```

### 功能3：增量更新

只处理新的邮件，跳过已处理的：
```python
# 记录已处理的邮件ID
processed_ids = load_processed_ids()
new_emails = [e for e in emails if e['id'] not in processed_ids]
```

---

## 📈 性能参考

### 处理速度

**Gmail搜索**：
- 时间：1-2秒（API调用）
- 限制：每日配额限制

**Boss页面解析**：
- 时间：3-5秒/页
- 取决于：网络速度、Boss服务器响应

**Excel导出**：
- 时间：1-2秒
- 不受数量影响

**总体时间估算**：
```
10封邮件  → 约1-2分钟
50封邮件  → 约5-8分钟
100封邮件 → 约10-15分钟
```

---

## 🔧 故障处理

### 问题1：Gmail授权过期

**表现**：提示需要重新授权

**解决**：
```bash
# 删除旧token
rm data/token.json

# 重新运行（会打开浏览器授权）
python3 src/main.py
```

### 问题2：找不到Boss链接

**表现**：所有邮件都未找到Boss链接

**解决**：
```bash
# 运行调试脚本
python3 debug_quick.py

# 查看邮件实际内容
python3 debug_emails.py
```

### 问题3：Boss页面解析失败

**表现**：解析失败率高

**解决**：
```bash
# 1. 启用Selenium
nano config/config.env
# 设置：USE_SELENIUM=true

# 2. 或手动测试单个链接
python3 debug_boss_page.py "https://m.zhipin.com/xxx"
```

---

## 📝 使用检查清单

### 首次使用前
- [ ] Python依赖已安装
- [ ] Gmail API已配置
- [ ] OAuth已授权（有token.json）
- [ ] 配置文件已设置

### 每次使用前
- [ ] 确认搜索条件正确
- [ ] 检查输出目录空间
- [ ] 网络连接正常

### 使用中
- [ ] 观察进度条
- [ ] 注意错误提示
- [ ] 等待处理完成

### 使用后
- [ ] 检查输出文件
- [ ] 验证数据质量
- [ ] 备份重要数据

---

## 💡 使用技巧

### 技巧1：定期批量处理

建议每周运行一次：
```bash
# 创建定时任务（cron）
crontab -e

# 每周一上午9点运行
0 9 * * 1 cd /Users/lillianliao/notion_rag/gmail-resume-parser && python3 src/main.py
```

### 技巧2：按时间段分批处理

避免一次处理太多：
```bash
# 第一批：11月1-10日
GMAIL_QUERY="after:2024/11/01 before:2024/11/10" python3 src/main.py

# 第二批：11月11-20日
GMAIL_QUERY="after:2024/11/11 before:2024/11/20" python3 src/main.py
```

### 技巧3：数据去重

合并多次处理的结果：
```python
import pandas as pd

# 读取所有Excel文件
dfs = [pd.read_excel(f) for f in ['file1.xlsx', 'file2.xlsx']]

# 合并并去重
combined = pd.concat(dfs).drop_duplicates(subset=['简历链接'])

# 保存
combined.to_excel('combined_resumes.xlsx', index=False)
```

---

## 🎯 快速开始（复制粘贴即可运行）

```bash
# 进入项目目录
cd /Users/lillianliao/notion_rag/gmail-resume-parser

# 方案A：直接运行（使用默认配置）
python3 src/main.py

# 方案B：使用启动脚本（推荐）
python3 start.py

# 方案C：先测试5封邮件
echo "MAX_EMAILS=5" >> config/config.env
python3 src/main.py

# 查看结果
open output/
ls -lh output/*.xlsx
```

---

## 📞 需要帮助？

### 调试命令
```bash
# 检查环境
python3 -c "import google.auth; print('✅ Gmail API可用')"

# 查看配置
cat config/config.env

# 查看历史输出
ls -lh output/

# 运行快速诊断
python3 debug_quick.py
```

### 查看文档
```bash
# 查看README
cat README.md

# 查看快速开始
cat QUICK_START.md

# 查看故障排查
cat TROUBLESHOOTING.md
```

---

## ✅ 总结：最简单的使用方式

**如果你只想快速使用**：

```bash
cd /Users/lillianliao/notion_rag/gmail-resume-parser
python3 src/main.py
```

**就这么简单！**

程序会自动：
1. 连接Gmail（已授权）
2. 搜索Boss推荐邮件
3. 提取并解析简历
4. 导出到Excel

**结果**：
```
output/resumes_export.xlsx
```

---

现在你可以试试运行 `python3 src/main.py`，我在旁边帮你看结果！🚀

