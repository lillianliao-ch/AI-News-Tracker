#!/usr/bin/env python3
"""
集成现有的 AI Headhunter Assistant 服务
将提取的链接发送到后台服务处理
"""

import json
import requests
from src.gmail_client_fixed import FixedGmailClient
from src.excel_exporter_simple import SimpleExcelExporter

def integrate_with_ai_service():
    """集成AI Headhunter Assistant服务"""
    print("🤖 集成 AI Headhunter Assistant 服务")
    print("=" * 60)
    
    # 检查AI服务是否运行
    ai_service_url = "http://localhost:8000"
    
    try:
        health_response = requests.get(f"{ai_service_url}/health", timeout=5)
        if health_response.status_code == 200:
            service_info = health_response.json()
            print(f"✅ AI服务运行正常")
            print(f"   服务: {service_info.get('service', 'N/A')}")
            print(f"   版本: {service_info.get('version', 'N/A')}")
        else:
            print(f"❌ AI服务不可用 (状态码: {health_response.status_code})")
            return False
    except Exception as e:
        print(f"❌ 无法连接AI服务: {e}")
        print(f"   请确保AI Headhunter Assistant服务正在运行")
        print(f"   启动命令: cd /Users/lillianliao/notion_rag/ai-headhunter-assistant && ./scripts/start_backend.sh")
        return False
    
    # 获取Gmail链接
    print(f"\n📧 获取Gmail中的Boss直聘链接...")
    
    try:
        client = FixedGmailClient('config/credentials.json', 'data/token.json')
        messages = client.search_emails('subject:"推荐了简历候选人"', 3)  # 测试3封
        
        all_links = []
        for message in messages:
            email = client.get_email_content(message['id'])
            if email:
                links = client.extract_boss_zhipin_links(email)
                all_links.extend(links)
        
        print(f"✅ 提取到 {len(all_links)} 个Boss直聘链接")
        
        # 为每个链接创建模拟数据
        results = []
        for idx, link in enumerate(all_links, 1):
            print(f"\n🔗 处理链接 {idx}: {link[:60]}...")
            
            # 创建候选人信息（模拟数据，因为无法直接解析）
            candidate_info = {
                "name": f"从Gmail提取的候选人{idx}",
                "source_platform": "Boss直聘",
                "current_company": "待确认",
                "current_position": "待确认", 
                "work_years": 0,
                "expected_salary": "待确认",
                "education": "待确认",
                "active_status": "从邮件获取"
            }
            
            # JD配置
            jd_config = {
                "position": "AI工程师",
                "location": ["上海", "北京"],
                "salary_range": "30-60K",
                "work_years": "3-5年",
                "education": "本科及以上",
                "required_skills": ["AI", "算法", "Python"],
                "optional_skills": ["大厂背景"],
                "weights": {
                    "skill": 0.4,
                    "experience": 0.3, 
                    "education": 0.15,
                    "stability": 0.15
                }
            }
            
            # 发送到AI服务处理（使用mock模式）
            try:
                ai_response = requests.post(
                    f"{ai_service_url}/api/candidates/process",
                    json={
                        "candidate_info": candidate_info,
                        "jd_config": jd_config,
                        "resume_file": "mock_data",  # 使用mock数据
                        "resume_text": f"来源链接: {link}"
                    },
                    timeout=30
                )
                
                if ai_response.status_code == 200:
                    ai_result = ai_response.json()
                    print(f"✅ AI处理成功")
                    print(f"   候选人: {ai_result.get('structured_resume', {}).get('基本信息', {}).get('姓名', 'N/A')}")
                    print(f"   匹配度: {ai_result.get('evaluation', {}).get('综合匹配度', 'N/A')}")
                    
                    # 转换为简历数据格式
                    structured = ai_result.get('structured_resume', {})
                    evaluation = ai_result.get('evaluation', {})
                    basic_info = structured.get('基本信息', {})
                    
                    resume_data = {
                        'source_url': link,
                        'name': basic_info.get('姓名', f'候选人{idx}'),
                        'position': basic_info.get('当前职位', ''),
                        'age': basic_info.get('年龄', ''),
                        'work_years': basic_info.get('工作年限', ''),
                        'education': basic_info.get('学历', ''),
                        'current_company': basic_info.get('当前公司', ''),
                        'current_position': basic_info.get('当前职位', ''),
                        'employment_status': '',
                        'active_status': basic_info.get('活跃度', ''),
                        'expected_position': '',
                        'expected_salary': basic_info.get('期望薪资', ''),
                        'expected_location': '',
                        'expected_industry': '',
                        'main_job_content': '',
                        'work_experience': structured.get('工作经历', []),
                        'project_experience': structured.get('项目经验', []),
                        'education_background': structured.get('教育背景', []),
                        'certificates': [],
                        'skills': evaluation.get('技能标签', []),
                        'ai_match_score': evaluation.get('综合匹配度', 0),
                        'ai_recommendation': evaluation.get('推荐等级', ''),
                        'ai_advantages': evaluation.get('核心优势', []),
                    }
                    
                    results.append(resume_data)
                    
                else:
                    print(f"❌ AI处理失败 (状态码: {ai_response.status_code})")
                    
            except Exception as e:
                print(f"❌ AI服务调用失败: {e}")
        
        # 导出结果
        if results:
            exporter = SimpleExcelExporter('output/ai_processed_resumes.xlsx')
            output_file = exporter.export(results)
            print(f"\n✅ AI处理结果已导出到: {output_file}")
        
        return True
        
    except Exception as e:
        print(f"❌ 集成失败: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == '__main__':
    success = integrate_with_ai_service()
    if success:
        print(f"\n🎉 AI服务集成测试完成！")
    else:
        print(f"\n❌ 集成失败")





