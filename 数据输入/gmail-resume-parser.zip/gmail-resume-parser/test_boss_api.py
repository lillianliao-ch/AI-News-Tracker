import requests
import urllib.parse
import json

# 用户提供的完整 URL
original_url = "https://m.zhipin.com/mpa/v3/html/resume/detail?expectId=888763223&securityId=4b4A9Pa8S8YkR-D1wGjKp27CNYVSSKbkKj13S7si7rdp1Ct5RZ3b9_qkGbdqM9cCzrJgBflKY83WOPUidKu4stNqRrmFur0nMh1KNkby3PRoA79BSxrwn5L-bcIAi_HlgmmJUbzwXf8k6F2h7OTrcl2UT_M_yrZAnLxqebvYTDOzT_zRMoIecvj9OtD_4V-1PhA-wsM63itMCqDXiQLkeoa_mD2PWNpgu9NO98MmTyyzF-7rqpnySXA-jbdtvQd-kgs31hk_J3J2wmISbhyOKjndmmQ4lAVyZZHmcP2-AhGilEzCQbwmgtEL8QyjmXJ2YIk9WyJ-mfq6b8jr32QkF6Y7pfTQFbd_Tpet-OgDKd93PRJ94vlRAwNg5h-VnS_8sKat8Ft7_8_V3aEmSrQPWV0C1TY1LFktdPRO-Q9sXc0msLAfFOErQud9LrcU9aSHKUwc8vECSVyH7nXEh6QjbPAKOl5DcArLz_umNJ8TKq0wKbXmr49Gnt6EAnPOdh_6I83bbTZkYJ9s7chwt_KtQm_zjyS1umD8RA~~&encryptId=c158da9d833a923003R42d-7EVs~&version=1"

# 解析 URL 参数
parsed = urllib.parse.urlparse(original_url)
params = urllib.parse.parse_qs(parsed.query)

# 构造 API URL
api_url = "https://m.zhipin.com/mpa/v3/html/resume/detail.json"

# 构造 API 参数
# 从截图看，主要参数是 encryptId，我们把其他参数也带上以防万一
api_params = {
    'encryptId': params.get('encryptId', [''])[0],
    'expectId': params.get('expectId', [''])[0],
    'securityId': params.get('securityId', [''])[0],
    'version': params.get('version', [''])[0]
}

print("🔍 尝试直接调用 Boss API...")
print(f"API URL: {api_url}")
print(f"EncryptID: {api_params['encryptId']}")

headers = {
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Referer': original_url,
    'Accept': 'application/json, text/plain, */*',
    'X-Requested-With': 'XMLHttpRequest'
}

try:
    response = requests.get(api_url, params=api_params, headers=headers, timeout=10)
    print(f"\n✅ 状态码: {response.status_code}")
    
    try:
        data = response.json()
        print("✅ 响应是有效的 JSON")
        
        # 检查是否有数据
        if 'zpData' in data and 'resume' in data['zpData']:
            resume = data['zpData']['resume']
            print("\n🎉 成功获取简历数据！")
            print(f"姓名: {resume.get('name')}")
            print(f"职位: {resume.get('expectPosition')}")
            print(f"公司: {resume.get('lastCompany')}")
            print("-" * 50)
            print(json.dumps(resume, indent=2, ensure_ascii=False)[:500] + "...")
        else:
            print("⚠️ JSON 结构中未找到简历数据 (可能是需要 Cookie/Token)")
            print(json.dumps(data, indent=2, ensure_ascii=False))
            
    except json.JSONDecodeError:
        print("❌ 响应不是 JSON，可能需要 Cookie 或验证")
        print(response.text[:200])

except Exception as e:
    print(f"❌ 请求失败: {e}")

