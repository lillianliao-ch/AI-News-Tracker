#!/usr/bin/env python3
"""
调试简历解析过程
"""

import sys
from pathlib import Path
from src.gmail_client_fixed import FixedGmailClient
from src.resume_parser import ResumeParser

def debug_resume_parsing():
    """调试简历解析过程"""
    print("🔍 调试简历解析过程")
    print("=" * 50)
    
    try:
        # 初始化 Gmail 客户端
        client = FixedGmailClient('config/credentials.json', 'data/token.json')
        
        # 获取一封邮件
        messages = client.search_emails('subject:"推荐了简历候选人"', 1)
        if not messages:
            print("❌ 未找到邮件")
            return
        
        # 获取邮件内容
        email = client.get_email_content(messages[0]['id'])
        if not email:
            print("❌ 获取邮件内容失败")
            return
        
        print(f"✅ 邮件内容获取成功")
        print(f"   主题: {email.get('subject', 'N/A')}")
        
        # 提取链接
        links = client.extract_boss_zhipin_links(email)
        if not links:
            print("❌ 未找到 Boss 直聘链接")
            return
        
        print(f"✅ 找到 {len(links)} 个链接")
        test_link = links[0]
        print(f"   测试链接: {test_link[:80]}...")
        
        # 测试简历解析器
        print(f"\n📄 测试简历解析...")
        
        # 首先用 requests 测试
        print(f"🔧 方法1: 使用 requests")
        parser = ResumeParser(use_selenium=False)
        resume_data = parser.parse_from_url(test_link)
        
        if resume_data:
            print(f"✅ requests 解析成功")
            print(f"   姓名: {resume_data.get('name', 'N/A')}")
            print(f"   当前公司: {resume_data.get('current_company', 'N/A')}")
            print(f"   职位: {resume_data.get('current_position', 'N/A')}")
            print(f"   工作年限: {resume_data.get('work_years', 'N/A')}")
        else:
            print(f"❌ requests 解析失败")
        
        # 然后用 Selenium 测试
        print(f"\n🔧 方法2: 使用 Selenium")
        parser_selenium = ResumeParser(use_selenium=True)
        resume_data_selenium = parser_selenium.parse_from_url(test_link)
        
        if resume_data_selenium:
            print(f"✅ Selenium 解析成功")
            print(f"   姓名: {resume_data_selenium.get('name', 'N/A')}")
            print(f"   当前公司: {resume_data_selenium.get('current_company', 'N/A')}")
            print(f"   职位: {resume_data_selenium.get('current_position', 'N/A')}")
            print(f"   工作年限: {resume_data_selenium.get('work_years', 'N/A')}")
        else:
            print(f"❌ Selenium 解析失败")
        
        parser_selenium.close()
        
        # 直接测试页面内容
        print(f"\n🌐 直接获取页面内容测试...")
        test_page_content(test_link)
        
    except Exception as e:
        print(f"❌ 调试失败: {e}")
        import traceback
        traceback.print_exc()

def test_page_content(url):
    """测试页面内容获取"""
    import requests
    from bs4 import BeautifulSoup
    
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36'
        }
        
        response = requests.get(url, headers=headers, timeout=10)
        print(f"   响应状态: {response.status_code}")
        print(f"   响应长度: {len(response.text)} 字符")
        
        # 解析 HTML
        soup = BeautifulSoup(response.text, 'html.parser')
        page_text = soup.get_text()
        
        print(f"   页面文本长度: {len(page_text)} 字符")
        
        # 查找关键信息模式
        import re
        
        # 查找年龄
        age_patterns = [r'(\d+)岁', r'年龄[：:\s]*(\d+)', r'(\d+)\s*岁']
        for pattern in age_patterns:
            match = re.search(pattern, page_text)
            if match:
                print(f"   找到年龄: {match.group(1)}岁")
                break
        
        # 查找工作年限
        exp_patterns = [r'(\d+)年[工作经验]', r'工作[经验]*[：:\s]*(\d+)年', r'(\d+)\s*年']
        for pattern in exp_patterns:
            match = re.search(pattern, page_text)
            if match:
                print(f"   找到工作年限: {match.group(1)}年")
                break
        
        # 查找公司信息
        company_patterns = [r'([^·\n]+)·([^·\n]+)', r'公司[：:\s]*([^\n]+)', r'([^，\n]{2,20}(?:公司|科技|集团)[^，\n]*)']
        for pattern in company_patterns:
            match = re.search(pattern, page_text)
            if match:
                print(f"   找到公司信息: {match.group()}")
                break
        
        # 显示页面内容片段
        if len(page_text) > 50:
            print(f"\n📋 页面内容片段:")
            print(page_text[:200])
            print("...")
        else:
            print(f"\n⚠️  页面内容太少: '{page_text}'")
        
        # 检查是否有登录提示
        login_indicators = ['登录', 'login', '请先', '授权', '验证']
        found_indicators = [ind for ind in login_indicators if ind in page_text.lower()]
        if found_indicators:
            print(f"\n⚠️  可能需要登录: {found_indicators}")
        
    except Exception as e:
        print(f"   ❌ 页面内容测试失败: {e}")

if __name__ == '__main__':
    debug_resume_parsing()
