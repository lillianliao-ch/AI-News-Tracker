#!/usr/bin/env python3
"""
配置 Selenium 支持
"""

import os

def configure_selenium():
    """配置 Selenium 支持"""
    print("🔧 配置 Selenium 支持")
    print("=" * 50)
    
    # 检查 Chrome 是否安装
    chrome_paths = [
        '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
        '/usr/bin/google-chrome',
        '/usr/local/bin/chrome'
    ]
    
    chrome_found = False
    for path in chrome_paths:
        if os.path.exists(path):
            print(f"✅ 找到 Chrome: {path}")
            chrome_found = True
            break
    
    if not chrome_found:
        print("⚠️ 未找到 Chrome 浏览器")
        print("   请安装 Chrome: https://www.google.com/chrome/")
        return False
    
    # 更新配置文件启用 Selenium
    config_file = 'config/config.env'
    
    print(f"📝 更新配置文件: {config_file}")
    
    # 读取现有配置
    config_lines = []
    if os.path.exists(config_file):
        with open(config_file, 'r') as f:
            config_lines = f.readlines()
    
    # 更新或添加 Selenium 配置
    updated = False
    for i, line in enumerate(config_lines):
        if line.startswith('USE_SELENIUM='):
            config_lines[i] = 'USE_SELENIUM=true\n'
            updated = True
            break
    
    if not updated:
        config_lines.append('\n# Boss 直聘页面需要 JavaScript 渲染\nUSE_SELENIUM=true\n')
    
    # 保存配置
    with open(config_file, 'w') as f:
        f.writelines(config_lines)
    
    print("✅ 已启用 Selenium 支持")
    
    # 显示当前配置
    print(f"\n📋 当前配置:")
    with open(config_file, 'r') as f:
        for line in f:
            if line.strip() and not line.startswith('#'):
                print(f"   {line.strip()}")
    
    return True

def test_selenium():
    """测试 Selenium 是否工作"""
    print(f"\n🧪 测试 Selenium")
    print("=" * 30)
    
    try:
        from selenium import webdriver
        from selenium.webdriver.chrome.options import Options
        from selenium.webdriver.common.by import By
        from selenium.webdriver.support.ui import WebDriverWait
        from selenium.webdriver.support import expected_conditions as EC
        
        # 配置 Chrome 选项
        chrome_options = Options()
        chrome_options.add_argument('--headless')  # 无头模式
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--disable-dev-shm-usage')
        chrome_options.add_argument('--disable-gpu')
        chrome_options.add_argument('user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36')
        
        print("🚀 启动 Chrome WebDriver...")
        driver = webdriver.Chrome(options=chrome_options)
        
        # 测试访问 Boss 直聘页面
        test_url = "https://m.zhipin.com/mpa/v3/html/resume/detail?expectId=1339620490&securityId=BXssJknwB1kcc-51_U7u-OcP9F2LriXAEMxKg2_LxrjIuwaUVf5ePgK4X5eiUKfrAgzy04IppQQ4a2gEXSx4nVV_q8Ml5Tc7bsK9JGZS6AdUAmncVDF1xXfZHnh8vv8uAdG3s_8ukuTgyEQ-wPN2m6W89pKVDu1Etesxd0fYAh0NKlXC3sHgJSi6cBmV7iTkY_-3NLH2OlJ0yx5OS88igrXCQruHvetlnVQ4lbvEybw_m69n3KlCHA2yup4zyV0YWnGBJXbtiv5iqMRuuCGPQtClLJmsmfYYQxOPgjBrZl8UhVGwOrqtBAvejCbx6A4qVHTKA1KawKy0w0lqwGwZkJjZF7DbVgaO-ZViY5_vCwzuNjn7l_rCBGT1SgMrbV005-XSgXz9rlypEAey0GfaxrFJeXbrc_vwG6Rfscxhh_gvdcWPnxIrvBGHpTKGeSa6XIEEAYZMb92AfpudgyHuWOrJH2OaJP9VScxZCV2IOVgbXfogo5MiPWeef9uVU1dqaZ90xvCg5aAItEqS8-Bdj2xquXU_jNUAsnY~&encryptId=d1fce857fce390f303R72t61GFY~&version=1"
        
        print(f"🌐 访问页面...")
        driver.get(test_url)
        
        # 等待页面加载
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.TAG_NAME, "body"))
        )
        
        # 获取页面标题和内容
        title = driver.title
        page_source = driver.page_source
        text_content = driver.find_element(By.TAG_NAME, "body").text
        
        print(f"✅ 页面加载成功")
        print(f"   标题: {title}")
        print(f"   HTML 长度: {len(page_source)} 字符")
        print(f"   文本长度: {len(text_content)} 字符")
        
        # 分析页面内容
        if len(text_content) > 100:
            print(f"✅ 页面内容丰富，Selenium 解析成功")
            
            # 显示内容片段
            print(f"\n📋 页面内容片段 (前300字符):")
            print(text_content[:300])
            print("...")
            
            # 查找关键信息
            keywords = ['年', '岁', '经验', '学历', '公司', '职位', '工作']
            found = [kw for kw in keywords if kw in text_content]
            print(f"\n🔍 找到关键词: {found}")
            
        else:
            print(f"⚠️  页面内容仍然很少，可能需要登录或有其他限制")
        
        # 保存渲染后的页面
        with open('debug_boss_page_selenium.html', 'w', encoding='utf-8') as f:
            f.write(page_source)
        
        print(f"\n💾 Selenium 渲染的页面已保存到: debug_boss_page_selenium.html")
        
        driver.quit()
        return True
        
    except Exception as e:
        print(f"❌ Selenium 测试失败: {e}")
        if 'driver' in locals():
            driver.quit()
        return False

if __name__ == '__main__':
    configure_selenium()
    test_selenium()
