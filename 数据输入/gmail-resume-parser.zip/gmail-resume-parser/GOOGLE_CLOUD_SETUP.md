# 🔧 Google Cloud Console 重定向 URI 配置指南

## ⚠️ 重要：必须配置重定向 URI

根据错误信息，程序使用的重定向 URI 是：`http://localhost:8082/`

你需要在 Google Cloud Console 中添加以下所有重定向 URI。

## 📋 配置步骤

### 1. 访问 Google Cloud Console

打开：https://console.cloud.google.com/apis/credentials

### 2. 选择项目和 OAuth 客户端

- **项目**: `gen-lang-client-0240713157`
- **OAuth 客户端 ID**: `395360022878-u7ieoksaba7kcc1hidamg62bepuabrpj`
- 点击 **编辑**（铅笔图标）

### 3. 添加重定向 URI

在 **已授权的重定向 URI** 部分，点击 **+ 添加 URI**，**依次添加以下所有 URI**：

```
http://localhost:8080/
http://localhost:8081/
http://localhost:8082/
http://localhost:8083/
http://localhost:8084/
http://127.0.0.1:8080/
http://127.0.0.1:8081/
http://127.0.0.1:8082/
http://127.0.0.1:8083/
http://127.0.0.1:8084/
http://localhost/
http://127.0.0.1/
```

**重要**：
- 必须包含 **localhost** 和 **127.0.0.1** 两种格式
- 必须包含端口号（8080-8084）
- 每个 URI 末尾的 `/` 不能省略

### 4. 保存配置

- 点击底部的 **保存** 按钮
- **等待 1-2 分钟**让配置生效

### 5. 验证配置

保存后，你应该能在列表中看到所有添加的 URI。

## 🚀 配置完成后

重新运行程序：

```bash
cd /Users/lillianliao/notion_rag/gmail-resume-parser
python src/main.py
```

## ⚠️ 常见问题

### Q: 为什么需要添加这么多 URI？

A: 程序会自动尝试使用 8080-8084 端口，如果某个端口被占用会使用下一个。为了确保无论使用哪个端口都能正常工作，需要添加所有可能的组合。

### Q: 可以只添加通配符吗？

A: Google Cloud Console 不支持通配符，必须明确列出每个 URI。

### Q: 配置保存后还是报错？

A: 
1. 确认保存成功
2. 等待 1-2 分钟让配置生效
3. 清除浏览器缓存
4. 重新运行程序

## 📝 快速检查清单

- [ ] 已添加 `http://localhost:8080/` 到 `http://localhost:8084/`
- [ ] 已添加 `http://127.0.0.1:8080/` 到 `http://127.0.0.1:8084/`
- [ ] 已添加 `http://localhost/` 和 `http://127.0.0.1/`
- [ ] 所有 URI 末尾都有 `/`
- [ ] 已点击保存
- [ ] 已等待 1-2 分钟

