#!/usr/bin/env python3
"""
修复 OAuth 配置
"""

import json
import os

def fix_credentials():
    """修复凭证文件配置"""
    credentials_path = 'config/credentials.json'
    
    if not os.path.exists(credentials_path):
        print("❌ 凭证文件不存在")
        return False
    
    # 读取当前配置
    with open(credentials_path, 'r') as f:
        data = json.load(f)
    
    print("原始配置:")
    print(json.dumps(data, indent=2))
    
    # 修复桌面应用配置
    if 'installed' in data:
        # 确保有正确的重定向 URI
        if 'redirect_uris' not in data['installed']:
            data['installed']['redirect_uris'] = ['http://localhost']
        else:
            # 确保包含正确的本地重定向 URI
            redirect_uris = data['installed']['redirect_uris']
            if 'http://localhost' not in redirect_uris:
                redirect_uris.append('http://localhost')
            # 添加端口变体
            for port in [8080, 8081, 8082]:
                uri = f'http://localhost:{port}'
                if uri not in redirect_uris:
                    redirect_uris.append(uri)
        
        # 保存修复后的配置
        with open(credentials_path, 'w') as f:
            json.dump(data, f, indent=2)
        
        print("\n修复后配置:")
        print(json.dumps(data, indent=2))
        print("✅ 凭证文件已修复")
        return True
    
    else:
        print("❌ 不是桌面应用类型的凭证")
        return False

if __name__ == '__main__':
    fix_credentials()
