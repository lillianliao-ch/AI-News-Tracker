#!/usr/bin/env python3
"""
Gmail API 完整测试脚本
"""

import os
import sys
import json
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/gmail.readonly']

def main():
    """完整的Gmail API测试流程"""
    print("🧪 Gmail API 完整测试")
    print("=" * 60)
    
    credentials_path = 'config/credentials.json'
    token_path = 'data/token.json'
    
    # 检查凭证文件
    if not os.path.exists(credentials_path):
        print(f"❌ 未找到凭证文件: {credentials_path}")
        return False
    
    # 显示当前配置
    with open(credentials_path, 'r') as f:
        config = json.load(f)
    
    client_id = config.get('installed', config.get('web', {})).get('client_id', 'N/A')
    print(f"📋 当前配置:")
    print(f"   Client ID: {client_id}")
    print()
    
    creds = None
    
    # 检查现有token
    if os.path.exists(token_path):
        print("📋 发现已保存的授权信息，正在验证...")
        try:
            creds = Credentials.from_authorized_user_file(token_path, SCOPES)
            if creds and creds.valid:
                print("✅ 授权信息有效，跳过授权流程")
            elif creds and creds.expired and creds.refresh_token:
                print("🔄 刷新过期的授权...")
                creds.refresh(Request())
                print("✅ 授权已刷新")
            else:
                print("⚠️  授权信息无效，需要重新授权")
                creds = None
        except Exception as e:
            print(f"⚠️  授权信息解析失败: {e}")
            creds = None
    
    # 如果需要授权
    if not creds or not creds.valid:
        print("\n🌐 开始授权流程...")
        print("=" * 60)
        
        # 生成授权URL（确保包含redirect_uri）
        flow = InstalledAppFlow.from_client_secrets_file(credentials_path, SCOPES)
        # 明确设置redirect_uri
        flow.redirect_uri = 'http://localhost'
        auth_url, _ = flow.authorization_url(prompt='consent', access_type='offline')
        
        print("📋 授权步骤:")
        print("1. 复制下面的URL到浏览器中打开")
        print("2. 选择Google账号并完成授权")
        print("3. 复制显示的授权码")
        print("4. 将授权码粘贴到这里")
        print()
        print("🔗 授权URL:")
        print(auth_url)
        print()
        print("-" * 60)
        
        # 获取授权码
        try:
            auth_code = input("请输入授权码: ").strip()
            
            if not auth_code:
                print("❌ 未输入授权码")
                return False
            
            # 使用授权码获取token
            print("🔄 正在获取访问令牌...")
            flow.fetch_token(code=auth_code)
            creds = flow.credentials
            
            # 保存token
            os.makedirs(os.path.dirname(token_path), exist_ok=True)
            with open(token_path, 'w') as token:
                token.write(creds.to_json())
            print("✅ 授权信息已保存")
            
        except KeyboardInterrupt:
            print("\n⚠️  用户中断授权")
            return False
        except Exception as e:
            print(f"❌ 授权失败: {e}")
            return False
    
    # 测试Gmail API
    print("\n📧 测试Gmail API...")
    print("=" * 60)
    
    try:
        service = build('gmail', 'v1', credentials=creds)
        
        # 获取用户资料
        print("👤 获取用户资料...")
        profile = service.users().getProfile(userId='me').execute()
        email = profile.get('emailAddress')
        total_messages = profile.get('messagesTotal', 0)
        
        print(f"✅ 连接成功!")
        print(f"   邮箱地址: {email}")
        print(f"   总邮件数: {total_messages:,}")
        
        # 测试搜索邮件
        print(f"\n🔍 测试邮件搜索...")
        
        # 搜索简历相关邮件
        search_queries = [
            'subject:"推荐了简历候选人"',
            'subject:"简历"',
            'subject:"候选人"',
            'is:unread'  # 未读邮件
        ]
        
        for query in search_queries:
            try:
                results = service.users().messages().list(
                    userId='me', q=query, maxResults=5
                ).execute()
                messages = results.get('messages', [])
                print(f"   '{query}': 找到 {len(messages)} 封邮件")
                
                if messages:
                    break  # 找到邮件就停止
                    
            except Exception as e:
                print(f"   '{query}': 搜索失败 - {e}")
        
        print(f"\n🎉 Gmail API 测试完成!")
        print(f"✅ 授权和连接都正常工作")
        
        # 提示下一步
        print(f"\n📋 下一步:")
        print(f"   可以运行完整程序: python3 src/main_simple.py")
        
        return True
        
    except Exception as e:
        print(f"❌ Gmail API 测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == '__main__':
    try:
        success = main()
        if success:
            print(f"\n🎉 所有测试通过! 🎉")
        else:
            print(f"\n❌ 测试失败，请检查配置")
    except KeyboardInterrupt:
        print(f"\n\n⚠️  测试被中断")
    except Exception as e:
        print(f"\n❌ 未预期的错误: {e}")
        import traceback
        traceback.print_exc()
