#!/usr/bin/env python3
"""
生成正确的 OAuth URL（包含 redirect_uri）
"""

import json
from google_auth_oauthlib.flow import InstalledAppFlow
from urllib.parse import urlencode

SCOPES = ['https://www.googleapis.com/auth/gmail.readonly']

def generate_correct_oauth_url():
    """生成包含正确 redirect_uri 的 OAuth URL"""
    print("🔗 生成正确的 OAuth 授权 URL")
    print("=" * 50)
    
    credentials_path = 'config/credentials.json'
    
    try:
        # 读取凭证配置
        with open(credentials_path, 'r') as f:
            client_config = json.load(f)
        
        print("📋 当前配置:")
        print(f"   Client ID: {client_config['installed']['client_id']}")
        print(f"   Redirect URIs: {client_config['installed']['redirect_uris']}")
        
        # 创建授权流程
        flow = InstalledAppFlow.from_client_config(
            client_config, SCOPES
        )
        
        # 设置重定向 URI（使用配置中的第一个）
        redirect_uri = client_config['installed']['redirect_uris'][0]
        flow.redirect_uri = redirect_uri
        
        # 生成授权 URL
        auth_url, state = flow.authorization_url(
            prompt='consent',
            access_type='offline'
        )
        
        print(f"\n🔗 正确的授权 URL:")
        print(auth_url)
        print("\n" + "=" * 50)
        print("📋 使用步骤:")
        print("1. 复制上面的 URL 到浏览器中打开")
        print("2. 选择 Google 账号并完成授权")
        print("3. 授权后会显示授权码或重定向到本地页面")
        print("4. 复制授权码并运行:")
        print("   python3 complete_auth.py '授权码'")
        
        return auth_url, state
        
    except Exception as e:
        print(f"❌ 生成 URL 失败: {e}")
        return None, None

if __name__ == '__main__':
    generate_correct_oauth_url()
