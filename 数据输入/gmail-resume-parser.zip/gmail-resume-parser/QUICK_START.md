# 快速开始指南

## 📋 前置准备

### 1. 安装 Python 依赖

```bash
cd /Users/lillianliao/notion_rag/gmail-resume-parser
pip install -r requirements.txt
```

### 2. 配置 Gmail API

#### 步骤 1: 创建 Google Cloud 项目

1. 访问 [Google Cloud Console](https://console.cloud.google.com/)
2. 创建新项目或选择现有项目
3. 启用 **Gmail API**

#### 步骤 2: 创建 OAuth 2.0 凭证

1. 进入 **API 和服务** > **凭据**
2. 点击 **创建凭据** > **OAuth 客户端 ID**
3. 应用类型选择 **桌面应用**
4. 下载 JSON 凭证文件
5. 将文件保存为 `config/credentials.json`

#### 步骤 3: 配置环境变量

```bash
# 复制配置模板
cp config.env.example config/config.env

# 编辑配置文件
# 可以使用任何文本编辑器，或运行：
nano config/config.env
```

编辑 `config/config.env`：

```env
# Gmail 搜索查询（支持 Gmail 搜索语法）
GMAIL_QUERY=subject:"推荐了简历候选人"

# 输出 Excel 文件名
OUTPUT_FILE=resumes_export.xlsx

# 最大处理邮件数量（0 表示不限制）
MAX_EMAILS=0
```

## 🚀 运行程序

### 首次运行

```bash
python src/main.py
```

首次运行会：
1. 打开浏览器进行 Gmail 授权
2. 授权后自动保存 token 到 `data/token.json`
3. 开始搜索和处理邮件

### 后续运行

直接运行即可（已保存授权信息）：

```bash
python src/main.py
```

## 📊 输出结果

程序运行完成后，会在 `output/` 目录生成 Excel 文件，包含以下信息：

- 基本信息：姓名、职位、年龄、工作年限、学历等
- 工作信息：当前公司、职位、工作状态
- 求职期望：期望职位、薪资、地点、行业
- 详细经历：工作经历、项目经历、教育经历
- 其他：资格证书、简历链接、解析时间

## 🔧 高级配置

### 使用 Selenium（如果需要）

如果 Boss 直聘页面需要 JavaScript 渲染，可以启用 Selenium：

1. 安装 ChromeDriver：
   ```bash
   # macOS
   brew install chromedriver
   ```

2. 修改 `config/config.env`：
   ```env
   USE_SELENIUM=true
   SELENIUM_DRIVER_PATH=/usr/local/bin/chromedriver
   ```

### 自定义 Gmail 查询

支持 Gmail 搜索语法，例如：

```env
# 搜索最近 30 天的邮件
GMAIL_QUERY=subject:"推荐了简历候选人" newer_than:30d

# 搜索特定发件人
GMAIL_QUERY=from:cv@notice.zhipin.com subject:"推荐了简历候选人"

# 组合查询
GMAIL_QUERY=subject:"推荐了简历候选人" from:cv@notice.zhipin.com newer_than:7d
```

## ⚠️ 常见问题

### Q1: Gmail API 授权失败

**解决**：
- 删除 `data/token.json` 文件
- 重新运行程序进行授权

### Q2: 找不到邮件

**解决**：
- 检查 Gmail 查询语法是否正确
- 尝试更宽泛的查询条件，如：`subject:"简历"`

### Q3: 无法解析简历页面

**解决**：
- Boss 直聘页面可能需要登录，考虑使用 Selenium
- 检查网络连接
- 查看错误日志了解具体原因

### Q4: 解析结果不完整

**解决**：
- Boss 直聘页面结构可能变化，需要更新解析逻辑
- 可以查看 `src/resume_parser.py` 调整解析规则

## 📝 下一步

- 查看 [README.md](README.md) 了解详细功能
- 根据实际需求调整解析逻辑
- 可以集成到自动化流程中

