#!/usr/bin/env python3
"""
手动授权测试 - 避免回调问题
"""

import os
import json
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/gmail.readonly']

def manual_auth_test():
    """使用手动授权码的测试"""
    print("🔑 Gmail API 手动授权测试")
    print("=" * 50)
    
    credentials_path = 'config/credentials.json'
    token_path = 'data/token.json'
    
    # 删除旧的 token（重新开始）
    if os.path.exists(token_path):
        os.remove(token_path)
        print("🗑️  已清除旧的授权信息")
    
    creds = None
    
    try:
        print("🌐 开始手动授权流程...")
        
        # 读取凭证配置
        with open(credentials_path, 'r') as f:
            client_config = json.load(f)
        
        # 创建授权流程
        flow = InstalledAppFlow.from_client_config(
            client_config, SCOPES
        )
        
        # 使用手动授权码模式
        print("\n📋 手动授权步骤:")
        print("1. 复制下面的 URL 到浏览器中打开")
        print("2. 完成授权后，复制返回的授权码")
        print("3. 将授权码粘贴回这里")
        print("-" * 50)
        
        # 获取授权 URL
        auth_url, _ = flow.authorization_url(prompt='consent')
        print(f"\n🔗 授权 URL:")
        print(auth_url)
        print("-" * 50)
        
        # 手动输入授权码
        auth_code = input("\n请输入授权码: ").strip()
        
        if not auth_code:
            print("❌ 未输入授权码")
            return False
        
        # 使用授权码获取访问令牌
        print("🔄 交换访问令牌...")
        flow.fetch_token(code=auth_code)
        creds = flow.credentials
        
        # 保存 token
        os.makedirs(os.path.dirname(token_path), exist_ok=True)
        with open(token_path, 'w') as token:
            token.write(creds.to_json())
        print("✅ 授权信息已保存")
        
        # 测试 Gmail API
        print("📧 测试 Gmail API...")
        service = build('gmail', 'v1', credentials=creds)
        
        # 获取用户资料
        profile = service.users().getProfile(userId='me').execute()
        print(f"✅ Gmail API 连接成功！")
        print(f"   邮箱: {profile.get('emailAddress')}")
        print(f"   总邮件数: {profile.get('messagesTotal', 0):,}")
        
        # 测试搜索邮件
        print("🔍 测试邮件搜索...")
        results = service.users().messages().list(
            userId='me',
            q='subject:"推荐了简历候选人"',
            maxResults=3
        ).execute()
        
        messages = results.get('messages', [])
        print(f"✅ 找到 {len(messages)} 封匹配邮件")
        
        if len(messages) == 0:
            # 尝试更宽泛的搜索
            results = service.users().messages().list(
                userId='me',
                q='简历',
                maxResults=3
            ).execute()
            messages = results.get('messages', [])
            print(f"✅ 找到 {len(messages)} 封包含'简历'的邮件")
        
        return True
        
    except Exception as e:
        print(f"❌ 授权失败: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == '__main__':
    try:
        success = manual_auth_test()
        if success:
            print("\n🎉 手动授权成功！")
            print("现在可以使用 Gmail API 了")
        else:
            print("\n❌ 授权失败")
    except KeyboardInterrupt:
        print("\n⚠️ 用户取消授权")
    except Exception as e:
        print(f"\n❌ 未预期的错误: {e}")
