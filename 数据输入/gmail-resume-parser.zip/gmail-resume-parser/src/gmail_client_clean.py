"""
简化版 Gmail API 客户端
使用标准的桌面应用授权流程，不做任何复杂处理
"""

import os
from typing import List, Dict, Optional
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError


class CleanGmailClient:
    """简化版 Gmail API 客户端"""
    
    SCOPES = ['https://www.googleapis.com/auth/gmail.readonly']
    
    def __init__(self, credentials_path: str, token_path: str):
        """
        初始化 Gmail 客户端
        
        Args:
            credentials_path: Gmail API 凭证文件路径
            token_path: Token 保存路径
        """
        self.credentials_path = credentials_path
        self.token_path = token_path
        self.service = None
        self._authenticate()
    
    def _authenticate(self):
        """Gmail API 认证 - 使用标准流程"""
        creds = None
        
        # 检查是否已有 token
        if os.path.exists(self.token_path):
            print("📋 加载已保存的授权信息...")
            creds = Credentials.from_authorized_user_file(self.token_path, self.SCOPES)
        
        # 如果没有有效凭证，进行授权
        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                print("🔄 刷新过期的授权...")
                creds.refresh(Request())
            else:
                if not os.path.exists(self.credentials_path):
                    raise FileNotFoundError(
                        f"未找到 Gmail API 凭证文件: {self.credentials_path}\n"
                        "请确保凭证文件存在"
                    )
                
                print("🌐 开始授权流程...")
                print("   - 浏览器将会打开")
                print("   - 请选择你的 Google 账号并授权")
                
                # 使用标准的桌面应用授权流程
                flow = InstalledAppFlow.from_client_secrets_file(
                    self.credentials_path, self.SCOPES
                )
                creds = flow.run_local_server(port=0)
            
            # 保存 token
            os.makedirs(os.path.dirname(self.token_path), exist_ok=True)
            with open(self.token_path, 'w') as token:
                token.write(creds.to_json())
            print("✅ 授权信息已保存")
        
        # 构建 Gmail 服务
        self.service = build('gmail', 'v1', credentials=creds)
        print("✅ Gmail API 连接成功")
    
    def get_profile(self):
        """获取用户资料"""
        try:
            profile = self.service.users().getProfile(userId='me').execute()
            return profile
        except HttpError as error:
            print(f"❌ 获取用户资料失败: {error}")
            return None
    
    def search_emails(self, query: str, max_results: int = 10) -> List[Dict]:
        """
        搜索邮件
        
        Args:
            query: Gmail 搜索查询
            max_results: 最大返回结果数
        
        Returns:
            邮件列表
        """
        try:
            results = self.service.users().messages().list(
                userId='me',
                q=query,
                maxResults=max_results
            ).execute()
            
            messages = results.get('messages', [])
            print(f"📧 找到 {len(messages)} 封邮件")
            return messages
        
        except HttpError as error:
            print(f"❌ 搜索邮件失败: {error}")
            return []
