"""
Gmail API 客户端
用于获取指定查询条件的邮件
"""

import os
import base64
import re
from typing import List, Dict, Optional
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError


class GmailClient:
    """Gmail API 客户端"""
    
    SCOPES = ['https://www.googleapis.com/auth/gmail.modify']
    
    def __init__(self, credentials_path: str, token_path: str):
        """
        初始化 Gmail 客户端
        
        Args:
            credentials_path: Gmail API 凭证文件路径
            token_path: Token 保存路径
        """
        self.credentials_path = credentials_path
        self.token_path = token_path
        self.service = None
        self._authenticate()
    
    def _authenticate(self):
        """Gmail API 认证"""
        creds = None
        
        # 检查是否已有 token
        if os.path.exists(self.token_path):
            creds = Credentials.from_authorized_user_file(self.token_path, self.SCOPES)
        
        # 如果没有有效凭证，进行授权
        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                creds.refresh(Request())
            else:
                if not os.path.exists(self.credentials_path):
                    raise FileNotFoundError(
                        f"未找到 Gmail API 凭证文件: {self.credentials_path}\n"
                        "请访问 https://console.cloud.google.com/ 创建凭证"
                    )
                
                # 支持桌面应用和 web 类型的凭证
                import json
                with open(self.credentials_path, 'r') as f:
                    client_config = json.load(f)
                
                # 使用固定端口，方便配置重定向 URI
                # 如果 8080 被占用，尝试其他端口
                REDIRECT_PORT = 8080
                import socket
                for port in [8080, 8081, 8082, 8083, 8084]:
                    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    result = sock.connect_ex(('127.0.0.1', port))
                    sock.close()
                    if result != 0:  # 端口可用
                        REDIRECT_PORT = port
                        break
                
                # 使用 127.0.0.1（与 Google Cloud Console 配置保持一致）
                REDIRECT_URI = f'http://127.0.0.1:{REDIRECT_PORT}/'
                
                # 如果是 web 类型，转换为 installed 格式
                if 'web' in client_config and 'installed' not in client_config:
                    client_config['installed'] = client_config['web'].copy()
                    # 添加重定向 URI（使用 127.0.0.1）
                    client_config['installed']['redirect_uris'] = [
                        REDIRECT_URI,
                        f'http://127.0.0.1:{REDIRECT_PORT}/',
                        'http://127.0.0.1:8080/',
                        'http://127.0.0.1:8081/',
                        'http://127.0.0.1:8082/',
                        'http://127.0.0.1/'
                    ]
                
                # 使用 InstalledAppFlow，指定固定端口和重定向 URI
                # 注意：InstalledAppFlow 可能会将 127.0.0.1 转换为 localhost
                # 所以需要在 Google Cloud Console 中同时配置 localhost 和 127.0.0.1
                flow = InstalledAppFlow.from_client_config(
                    client_config, self.SCOPES, redirect_uri=REDIRECT_URI
                )
                print(f"🌐 请在浏览器中完成授权")
                print(f"   重定向 URI: {REDIRECT_URI}")
                print(f"   如果遇到 redirect_uri_mismatch 错误，请在 Google Cloud Console 中添加：")
                print(f"   - {REDIRECT_URI}")
                print(f"   - http://localhost:{REDIRECT_PORT}/")
                print(f"   - http://127.0.0.1:{REDIRECT_PORT}/")
                creds = flow.run_local_server(port=REDIRECT_PORT, host='127.0.0.1')
            
            # 保存 token
            os.makedirs(os.path.dirname(self.token_path), exist_ok=True)
            with open(self.token_path, 'w') as token:
                token.write(creds.to_json())
        
        # 构建 Gmail 服务
        self.service = build('gmail', 'v1', credentials=creds)
        print("✅ Gmail API 认证成功")
    
    def search_emails(self, query: str, max_results: int = 100) -> List[Dict]:
        """
        搜索邮件
        
        Args:
            query: Gmail 搜索查询（支持 Gmail 搜索语法）
            max_results: 最大返回结果数
        
        Returns:
            邮件列表，每个邮件包含 id, threadId, snippet 等信息
        """
        try:
            results = self.service.users().messages().list(
                userId='me',
                q=query,
                maxResults=max_results
            ).execute()
            
            messages = results.get('messages', [])
            print(f"📧 找到 {len(messages)} 封邮件")
            return messages
        
        except HttpError as error:
            print(f"❌ Gmail API 错误: {error}")
            return []
    
    def get_email_content(self, message_id: str) -> Optional[Dict]:
        """
        获取邮件完整内容
        
        Args:
            message_id: 邮件 ID
        
        Returns:
            邮件内容字典，包含 subject, from, body, html_body 等
        """
        try:
            message = self.service.users().messages().get(
                userId='me',
                id=message_id,
                format='full'
            ).execute()
            
            # 提取邮件头信息
            headers = message['payload'].get('headers', [])
            email_data = {
                'id': message_id,
                'threadId': message.get('threadId'),
                'snippet': message.get('snippet', ''),
                'subject': self._get_header(headers, 'Subject'),
                'from': self._get_header(headers, 'From'),
                'date': self._get_header(headers, 'Date'),
            }
            
            # 提取邮件正文
            body_text, body_html = self._extract_body(message['payload'])
            email_data['body'] = body_text
            email_data['html_body'] = body_html
            
            return email_data
        
        except HttpError as error:
            print(f"❌ 获取邮件内容失败 (ID: {message_id}): {error}")
            return None
    
    def _get_header(self, headers: List[Dict], name: str) -> str:
        """从邮件头中获取指定字段"""
        for header in headers:
            if header['name'].lower() == name.lower():
                return header['value']
        return ''
    
    def get_or_create_label(self, label_name: str) -> str:
        """
        获取标签 ID，如果不存在则创建
        
        Args:
            label_name: 标签名称
            
        Returns:
            标签 ID
        """
        try:
            # 获取所有标签
            results = self.service.users().labels().list(userId='me').execute()
            labels = results.get('labels', [])
            
            # 查找是否存在
            for label in labels:
                if label['name'].lower() == label_name.lower():
                    return label['id']
            
            # 不存在则创建
            print(f"🏷️ 创建新标签: {label_name}")
            label_object = {
                'name': label_name,
                'labelListVisibility': 'labelShow',
                'messageListVisibility': 'show'
            }
            created_label = self.service.users().labels().create(
                userId='me', body=label_object
            ).execute()
            return created_label['id']
            
        except HttpError as error:
            print(f"❌ 获取/创建标签失败: {error}")
            return None

    def archive_and_label_email(self, message_id: str, label_name: str = 'boss'):
        """
        归档邮件并添加标签
        
        Args:
            message_id: 邮件 ID
            label_name: 标签名称
        """
        try:
            # 获取标签 ID
            label_id = self.get_or_create_label(label_name)
            if not label_id:
                return False
            
            # 修改邮件标签
            # addLabelIds: 添加新标签
            # removeLabelIds: 移除 INBOX 标签（即归档）
            body = {
                'addLabelIds': [label_id],
                'removeLabelIds': ['INBOX']
            }
            
            self.service.users().messages().modify(
                userId='me', id=message_id, body=body
            ).execute()
            
            # print(f"✅ 邮件已归档并标记为 '{label_name}'")
            return True
            
        except HttpError as error:
            print(f"❌ 归档邮件失败 (ID: {message_id}): {error}")
            return False

    def _extract_body(self, payload: Dict) -> tuple:
        """
        提取邮件正文（支持嵌套parts）
        
        Returns:
            (text_body, html_body)
        """
        text_body = ''
        html_body = ''
        
        def extract_from_part(part):
            """递归提取part内容"""
            nonlocal text_body, html_body
            
            mime_type = part.get('mimeType', '')
            
            # 如果这个part有嵌套的parts，递归处理
            if 'parts' in part:
                for sub_part in part['parts']:
                    extract_from_part(sub_part)
            else:
                # 这是最终的内容part
                data = part.get('body', {}).get('data')
                if data:
                    try:
                        decoded = base64.urlsafe_b64decode(data).decode('utf-8', errors='ignore')
                        if mime_type == 'text/plain' and not text_body:
                            text_body = decoded
                        elif mime_type == 'text/html' and not html_body:
                            html_body = decoded
                    except Exception as e:
                        print(f"⚠️ 解码邮件内容失败: {e}")
        
        if 'parts' in payload:
            # 多部分邮件 - 递归处理所有parts
            for part in payload['parts']:
                extract_from_part(part)
        else:
            # 单部分邮件
            mime_type = payload.get('mimeType', '')
            data = payload['body'].get('data')
            if data:
                try:
                    decoded = base64.urlsafe_b64decode(data).decode('utf-8', errors='ignore')
                    if mime_type == 'text/plain':
                        text_body = decoded
                    elif mime_type == 'text/html':
                        html_body = decoded
                except Exception as e:
                    print(f"⚠️ 解码邮件内容失败: {e}")
        
        return text_body, html_body
    
    def extract_boss_zhipin_links(self, email_content: Dict) -> List[str]:
        """
        从邮件内容中提取 Boss 直聘简历链接
        
        Args:
            email_content: 邮件内容字典
        
        Returns:
            Boss 直聘链接列表
        """
        links = []
        text = email_content.get('html_body', '') or email_content.get('body', '')
        
        # 匹配 Boss 直聘链接
        # 格式: https://m.zhipin.com/... 或 https://www.zhipin.com/...
        patterns = [
            r'https://[mw]\.zhipin\.com/[^\s<>"\'\)]+',
            r'https://[mw]\.zhipin\.com/[^\s<>"\'\)]+',
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, text)
            links.extend(matches)
        
        # 去重并清理
        links = list(set(links))
        links = [link.rstrip('.,;:!?') for link in links]
        
        return links

