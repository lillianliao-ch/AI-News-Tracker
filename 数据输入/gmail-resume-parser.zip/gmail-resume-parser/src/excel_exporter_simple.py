"""
简化版 Excel 导出器
不使用 pandas，直接用 openpyxl 处理 Excel
"""

import os
import json
from datetime import datetime
from typing import List, Dict


class SimpleExcelExporter:
    """简化版 Excel 导出器"""
    
    def __init__(self, output_file: str):
        """
        初始化导出器
        
        Args:
            output_file: 输出文件路径
        """
        self.output_file = output_file
        self.ensure_output_dir()
    
    def ensure_output_dir(self):
        """确保输出目录存在"""
        output_dir = os.path.dirname(self.output_file)
        if output_dir:
            os.makedirs(output_dir, exist_ok=True)
    
    def export(self, resumes: List[Dict]) -> str:
        """
        导出简历数据到 Excel
        
        Args:
            resumes: 简历数据列表
        
        Returns:
            输出文件路径
        """
        if not resumes:
            print("⚠️ 没有简历数据可导出")
            return self.output_file
        
        try:
            import openpyxl
            from openpyxl.styles import Font, Alignment, PatternFill
        except ImportError:
            # 如果 openpyxl 也有问题，使用 CSV 格式
            return self._export_to_csv(resumes)
        
        # 创建工作簿
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = '简历列表'
        
        # 定义表头
        headers = [
            '序号', '姓名', '职位', '年龄', '工作年限', '学历', 
            '当前公司', '当前职位', '工作状态', '活跃状态',
            '期望职位', '期望薪资', '期望地点', '期望行业',
            '主要工作内容', '工作经历', '项目经历', '教育经历',
            '资格证书', '简历链接', '解析时间'
        ]
        
        # 写入表头
        for col, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col, value=header)
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
            cell.alignment = Alignment(horizontal='center', vertical='center')
        
        # 写入数据
        for idx, resume in enumerate(resumes, 1):
            row = idx + 1
            
            data = [
                idx,
                resume.get('name', ''),
                resume.get('position', ''),
                resume.get('age', ''),
                resume.get('work_years', ''),
                resume.get('education', ''),
                resume.get('current_company', ''),
                resume.get('current_position', ''),
                resume.get('employment_status', ''),
                resume.get('active_status', ''),
                resume.get('expected_position', ''),
                resume.get('expected_salary', ''),
                resume.get('expected_location', ''),
                resume.get('expected_industry', ''),
                resume.get('main_job_content', ''),
                self._format_json(resume.get('work_experience', [])),
                self._format_json(resume.get('project_experience', [])),
                self._format_json(resume.get('education_background', [])),
                ', '.join(resume.get('certificates', [])),
                resume.get('source_url', ''),
                datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            ]
            
            for col, value in enumerate(data, 1):
                cell = ws.cell(row=row, column=col, value=str(value))
                cell.alignment = Alignment(vertical='top', wrap_text=True)
        
        # 设置列宽
        column_widths = [8, 12, 15, 8, 10, 10, 25, 15, 15, 12, 15, 12, 12, 20, 40, 50, 50, 30, 20, 50, 20]
        for col, width in enumerate(column_widths, 1):
            ws.column_dimensions[openpyxl.utils.get_column_letter(col)].width = width
        
        # 冻结首行
        ws.freeze_panes = 'A2'
        
        # 保存文件
        wb.save(self.output_file)
        
        print(f"✅ 已导出 {len(resumes)} 份简历到: {self.output_file}")
        return self.output_file
    
    def _export_to_csv(self, resumes: List[Dict]) -> str:
        """备用方案：导出为 CSV 文件"""
        import csv
        
        csv_file = self.output_file.replace('.xlsx', '.csv')
        
        headers = [
            '序号', '姓名', '职位', '年龄', '工作年限', '学历',
            '当前公司', '当前职位', '工作状态', '活跃状态',
            '期望职位', '期望薪资', '期望地点', '期望行业',
            '主要工作内容', '简历链接', '解析时间'
        ]
        
        with open(csv_file, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(headers)
            
            for idx, resume in enumerate(resumes, 1):
                row = [
                    idx,
                    resume.get('name', ''),
                    resume.get('position', ''),
                    resume.get('age', ''),
                    resume.get('work_years', ''),
                    resume.get('education', ''),
                    resume.get('current_company', ''),
                    resume.get('current_position', ''),
                    resume.get('employment_status', ''),
                    resume.get('active_status', ''),
                    resume.get('expected_position', ''),
                    resume.get('expected_salary', ''),
                    resume.get('expected_location', ''),
                    resume.get('expected_industry', ''),
                    resume.get('main_job_content', ''),
                    resume.get('source_url', ''),
                    datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                ]
                writer.writerow(row)
        
        print(f"✅ 已导出 {len(resumes)} 份简历到 CSV: {csv_file}")
        return csv_file
    
    def _format_json(self, data: List[Dict]) -> str:
        """将 JSON 数据格式化为字符串"""
        if not data:
            return ''
        
        try:
            return json.dumps(data, ensure_ascii=False, indent=2)
        except:
            return str(data)
