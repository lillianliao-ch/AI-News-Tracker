"""
Boss 直聘简历页面解析器
解析简历页面内容，提取结构化信息
"""

import re
import json
from typing import Dict, List, Optional
from bs4 import BeautifulSoup
import requests
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


class ResumeParser:
    """Boss 直聘简历解析器"""
    
    def __init__(self, use_selenium: bool = False, driver_path: Optional[str] = None, cookies: Optional[str] = None):
        """
        初始化解析器
        
        Args:
            use_selenium: 是否使用 Selenium
            driver_path: ChromeDriver 路径
            cookies: 浏览器 Cookie 字符串 (key=value; key2=value2)
        """
        self.use_selenium = use_selenium
        self.driver_path = driver_path
        self.cookies = cookies
        self.driver = None
        
        if use_selenium:
            self._init_selenium()

    def _init_selenium(self):
        """初始化 Selenium WebDriver（连接已打开的浏览器）"""
        chrome_options = Options()
        
        # 关键：连接到已打开的 Chrome
        chrome_options.add_experimental_option("debuggerAddress", "127.0.0.1:9222")
        
        try:
            self.driver = webdriver.Chrome(options=chrome_options)
            print("✅ 成功连接到已打开的 Chrome 浏览器")
        except Exception as e:
            print(f"❌ 连接浏览器失败: {e}")
            print("请确保已运行: /Applications/Google\\ Chrome.app/Contents/MacOS/Google\\ Chrome --remote-debugging-port=9222 --user-data-dir=\"/tmp/chrome_debug_profile\"")
            raise e

    def parse_from_url(self, url: str) -> Optional[Dict]:
        """
        从 URL 解析简历
        
        Args:
            url: Boss 直聘简历页面 URL
        
        Returns:
            解析后的简历数据字典
        """
        try:
            if self.use_selenium and self.driver:
                html = self._fetch_with_selenium(url)
            else:
                html = self._fetch_with_requests(url)
            
            if not html:
                return None
            
            return self.parse_from_html(html, url)
        
        except Exception as e:
            print(f"❌ 解析简历失败 ({url}): {e}")
            return None

    def _fetch_with_requests(self, url: str) -> Optional[str]:
        """使用 requests 获取页面内容"""
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
                'Cookie': self.cookies if self.cookies else ''
            }
            response = requests.get(url, headers=headers, timeout=10)
            response.raise_for_status()
            return response.text
        except Exception as e:
            print(f"⚠️ 使用 requests 获取页面失败: {e}")
            return None
    
    def _fetch_with_selenium(self, url: str) -> Optional[str]:
        """使用 Selenium 获取页面内容（连接模式）"""
        try:
            # 连接模式下不需要再注入 Cookie，直接访问即可
            self.driver.get(url)
            
            # 1. 等待基础框架加载
            WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.TAG_NAME, "body"))
            )
            
            # 2. 尝试等待简历核心内容出现
            try:
                WebDriverWait(self.driver, 15).until(
                    lambda d: d.find_elements(By.CLASS_NAME, "resume-content") or \
                              d.find_elements(By.CLASS_NAME, "item-base") or \
                              "求职期望" in d.page_source
                )
                import time
                time.sleep(2)
            except Exception:
                print(f"⚠️ 等待简历内容超时，将尝试解析当前页面...")
            
            return self.driver.page_source
        except Exception as e:
            print(f"⚠️ 使用 Selenium 获取页面失败: {e}")
            return None
    
    def parse_from_html(self, html: str, source_url: str = '') -> Dict:
        """
        从 HTML 解析简历内容（针对 Boss 直聘动态类名优化）
        """
        soup = BeautifulSoup(html, 'lxml')
        
        resume_data = {
            'source_url': source_url,
            'name': '',
            'position': '',
            'age': '',
            'work_years': '',
            'education': '',
            'current_company': '',
            'current_position': '',
            'employment_status': '',
            'active_status': '',
            'expected_position': '',
            'expected_salary': '',
            'expected_location': '',
            'expected_industry': '',
            'work_experience': [],
            'project_experience': [],
            'education_background': [],
            'skills': [],
            'certificates': [],
            'main_job_content': '',
        }
        
        # 辅助函数：按类名前缀查找
        def find_text_by_class_prefix(prefix, parent=soup):
            elem = parent.find(class_=re.compile(f'^{prefix}', re.I))
            return elem.get_text(strip=True) if elem else ''

        def find_all_by_class_prefix(prefix, parent=soup):
            return parent.find_all(class_=re.compile(f'^{prefix}', re.I))

        # 1. 解析基本信息
        # 姓名（通常在 baseInfo 下的 name_ 开头）
        base_info = soup.find(class_=re.compile('^baseInfo_'))
        if base_info:
            resume_data['name'] = find_text_by_class_prefix('name_', base_info)
            
            # 当前职位/期望职位（在基本信息里的 position_）
            pos_text = find_text_by_class_prefix('position_', base_info)
            if '期望职位' in pos_text:
                resume_data['expected_position'] = pos_text.replace('期望职位', '').strip()
            else:
                resume_data['current_position'] = pos_text

        # 2. 解析工作状态和活跃度
        job_info = soup.find(class_=re.compile('^jobInfo_'))
        if job_info:
            # 工作状态 (复用了 name_ 类名)
            status_div = job_info.find(class_=re.compile('^jobStatus_'))
            if status_div:
                resume_data['employment_status'] = find_text_by_class_prefix('name_', status_div)
                resume_data['active_status'] = find_text_by_class_prefix('active_', status_div)
            
            # 年龄、年限 (在 item_ 下，通过图标区分)
            items = find_all_by_class_prefix('item_', job_info)
            for item in items:
                text = item.get_text(strip=True)
                if '岁' in text:
                    resume_data['age'] = text.replace('岁', '')
                elif '年' in text:
                    resume_data['work_years'] = text.replace('年', '')
                elif any(deg in text for deg in ['博士', '硕士', '本科', '专科', '高中']):
                    resume_data['education'] = text
            
            # 自我介绍
            resume_data['main_job_content'] = find_text_by_class_prefix('intro_', job_info)

        # 3. 解析列表项（求职期望、工作经历、项目经历、教育经历）
        # 它们通常都在 list_ 下的 item_ 结构中
        list_container = soup.find(class_=re.compile('^list_'))
        if list_container:
            items = find_all_by_class_prefix('item_', list_container)
            
            for item in items:
                title_div = item.find(class_=re.compile('^title_'))
                if not title_div:
                    continue
                
                section_title = title_div.get_text(strip=True)
                
                # 解析求职期望
                if '求职期望' in section_title:
                    exp_content = item.find(class_=re.compile('^experience_'))
                    if exp_content:
                        # 职位和地点在 title_ 中
                        pos_loc_text = find_text_by_class_prefix('title_', exp_content)
                        parts = pos_loc_text.split('，')
                        if len(parts) >= 2:
                            resume_data['expected_position'] = parts[0].strip()
                            resume_data['expected_location'] = parts[1].strip()
                        elif len(parts) == 1:
                             resume_data['expected_position'] = parts[0].strip()
                        
                        # 薪资
                        resume_data['expected_salary'] = find_text_by_class_prefix('salary_', exp_content)
                        # 行业
                        resume_data['expected_industry'] = find_text_by_class_prefix('info_', exp_content)

                # 解析工作经历
                elif '工作经历' in section_title:
                    # 查找该板块下所有的经历项
                    experiences = item.find_all(class_=re.compile('^experience_'))
                    for exp in experiences:
                        exp_data = self._parse_generic_item(exp)
                        if exp_data.get('company') or exp_data.get('position'):
                            resume_data['work_experience'].append(exp_data)
                    
                    # 尝试提取最近一家公司作为 current_company
                    if not resume_data['current_company'] and resume_data['work_experience']:
                        resume_data['current_company'] = resume_data['work_experience'][0].get('company', '')

                # 解析项目经历
                elif '项目经历' in section_title:
                    experiences = item.find_all(class_=re.compile('^experience_'))
                    for exp in experiences:
                        exp_data = self._parse_generic_item(exp)
                        if exp_data.get('project_name') or exp_data.get('role'):
                            resume_data['project_experience'].append(exp_data)

                # 解析教育经历
                elif '教育经历' in section_title:
                    experiences = item.find_all(class_=re.compile('^experience_'))
                    # print(f"DEBUG: 找到 {len(experiences)} 条教育经历") # 调试用
                    for exp in experiences:
                        # print(f"DEBUG: 处理教育经历项: {exp.get_text(strip=True)[:50]}...") # 调试用
                        edu_item = self._parse_generic_item(exp)
                        # print(f"DEBUG: 解析结果: {edu_item}") # 调试用
                        
                        edu_data = {
                            'school': edu_item.get('title', ''),
                            'time_range': edu_item.get('time', ''),
                            'major': edu_item.get('subtitle', '')
                        }
                        resume_data['education_background'].append(edu_data)
                        
                        # 补充学历信息
                        if not resume_data['education'] and edu_item.get('content'):
                             # 只有当内容看起来像学历时才采纳
                             content = edu_item.get('content', '')
                             if any(deg in content for deg in ['博士', '硕士', '本科', '专科']):
                                 resume_data['education'] = content

        return resume_data

    def _parse_generic_item(self, item_soup) -> Dict:
        """解析通用的经历项结构"""
        data = {}
        # 1. 尝试查找标题（学校/公司）
        # 优先在 titleWrap_ 下查找 title_
        title_wrap = item_soup.find(class_=re.compile('^titleWrap_'))
        if title_wrap:
            title_elem = title_wrap.find(class_=re.compile('^title_'))
            if title_elem:
                data['title'] = title_elem.get_text(strip=True)
            
            # 时间通常也在 titleWrap_ 下
            time_elem = title_wrap.find(class_=re.compile('^time_'))
            if time_elem:
                data['time'] = time_elem.get_text(strip=True)
        
        # 如果没找到，尝试直接查找 title_ (兜底)
        if not data.get('title'):
            title_elem = item_soup.find(class_=re.compile('^title_'))
            # 排除掉 section title (如 "工作经历")
            if title_elem and title_elem.get_text(strip=True) not in ['工作经历', '项目经历', '教育经历', '求职期望']:
                 data['title'] = title_elem.get_text(strip=True)

        # 如果没找到时间，尝试直接查找 time_ (兜底)
        if not data.get('time'):
            time_elem = item_soup.find(class_=re.compile('^time_'))
            if time_elem:
                data['time'] = time_elem.get_text(strip=True)
            
        # 2. 副标题（职位/角色/专业）
        # 增加 info_ 匹配，因为教育经历的专业通常在 info_ 中
        sub_title = item_soup.find(class_=re.compile('^subTitle_')) or \
                    item_soup.find(class_=re.compile('^text_')) or \
                    item_soup.find(class_=re.compile('^info_'))
        
        if sub_title:
            data['subtitle'] = sub_title.get_text(strip=True)
            
        # 3. 内容/描述
        intro = item_soup.find(class_=re.compile('^intro_'))
        if intro:
            data['content'] = intro.get_text(strip=True)
            
        return {
            'title': data.get('title', ''),
            'time': data.get('time', ''),
            'subtitle': data.get('subtitle', ''),
            'content': data.get('content', ''),
            # 兼容旧键名
            'company': data.get('title', ''), 
            'project_name': data.get('title', ''), 
            'time_range': data.get('time', ''),
            'position': data.get('subtitle', ''), 
            'role': data.get('subtitle', ''), 
        }
    
    def _parse_work_experience(self, text: str) -> List[Dict]:
        """解析工作经历"""
        experiences = []
        
        # 查找工作经历部分
        work_section_match = re.search(r'工作经历\s*(.+?)(?=项目经历|教育经历|资格证书|$)', text, re.DOTALL)
        if not work_section_match:
            return experiences
        
        work_section = work_section_match.group(1)
        
        # 匹配公司名称和时间
        # 格式: "公司名称\n时间范围\n职位\n内容：..."
        company_pattern = r'([^\n]+(?:公司|科技|集团|有限|股份)[^\n]*)\s*\n\s*(\d{4}\.\d{2}-\d{4}\.\d{2}|至今|\d{4}\.\d{2}-\d{4}\.\d{2})\s*\n\s*([^\n]+)\s*\n\s*内容[：:]\s*(.+?)(?=\n[^\n]+(?:公司|科技|集团|有限|股份)|$)'
        
        matches = re.finditer(company_pattern, work_section, re.DOTALL)
        
        for match in matches:
            company = match.group(1).strip()
            time_range = match.group(2).strip()
            position = match.group(3).strip()
            content = match.group(4).strip()
            
            # 解析工作内容列表
            content_items = []
            content_lines = re.split(r'\d+\.', content)
            for line in content_lines:
                line = line.strip()
                if line:
                    content_items.append(line)
            
            experiences.append({
                'company': company,
                'time_range': time_range,
                'position': position,
                'content': content_items
            })
        
        return experiences
    
    def _parse_project_experience(self, text: str) -> List[Dict]:
        """解析项目经历"""
        projects = []
        
        project_section_match = re.search(r'项目经历\s*(.+?)(?=教育经历|资格证书|$)', text, re.DOTALL)
        if not project_section_match:
            return projects
        
        project_section = project_section_match.group(1)
        
        # 匹配项目
        project_pattern = r'([^\n]+)\s*\n\s*(\d{4}\.\d{2}-\d{4}\.\d{2}|至今)\s*\n\s*([^\n]+)\s*\n\s*内容[：:]\s*(.+?)(?=\n[^\n]+\s*\n\s*\d{4}\.\d{2}|$)'
        
        matches = re.finditer(project_pattern, project_section, re.DOTALL)
        
        for match in matches:
            project_name = match.group(1).strip()
            time_range = match.group(2).strip()
            role = match.group(3).strip()
            content = match.group(4).strip()
            
            projects.append({
                'project_name': project_name,
                'time_range': time_range,
                'role': role,
                'content': content
            })
        
        return projects
    
    def _parse_education(self, text: str) -> List[Dict]:
        """解析教育经历"""
        educations = []
        
        education_section_match = re.search(r'教育经历\s*(.+?)(?=资格证书|$)', text, re.DOTALL)
        if not education_section_match:
            return educations
        
        education_section = education_section_match.group(1)
        
        # 匹配学校信息
        # 格式: "学校名称\n时间范围\n专业"
        school_pattern = r'([^\n]+)\s*\n\s*(\d{4}-\d{4})\s*\n\s*([^\n]+)'
        
        matches = re.finditer(school_pattern, education_section)
        
        for match in matches:
            school = match.group(1).strip()
            time_range = match.group(2).strip()
            major = match.group(3).strip()
            
            educations.append({
                'school': school,
                'time_range': time_range,
                'major': major
            })
        
        return educations
    
    def _parse_certificates(self, text: str) -> List[str]:
        """解析资格证书"""
        certificates = []
        
        cert_section_match = re.search(r'资格证书\s*(.+?)$', text, re.DOTALL)
        if not cert_section_match:
            return certificates
        
        cert_section = cert_section_match.group(1)
        
        # 提取证书名称
        cert_lines = cert_section.split('\n')
        for line in cert_lines:
            line = line.strip()
            if line and line not in ['CET-6', '大学英语六级']:  # 过滤一些重复项
                certificates.append(line)
        
        return list(set(certificates))  # 去重
    
    def close(self):
        """关闭 Selenium WebDriver"""
        if self.driver:
            self.driver.quit()

