"""
简化版主程序
避免使用有问题的依赖包
"""

import os
import sys
from pathlib import Path
from dotenv import load_dotenv
from tqdm import tqdm

# 添加项目根目录到路径
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from src.gmail_client_fixed import FixedGmailClient
from src.resume_parser import ResumeParser
from src.excel_exporter_simple import SimpleExcelExporter


def load_config():
    """加载配置"""
    config_file = project_root / 'config' / 'config.env'
    
    if not config_file.exists():
        print(f"❌ 配置文件不存在: {config_file}")
        print("请复制 config.env.example 为 config/config.env 并配置")
        sys.exit(1)
    
    load_dotenv(config_file)
    
    config = {
        'gmail_query': os.getenv('GMAIL_QUERY', 'subject:"推荐了简历候选人"'),
        'output_file': os.getenv('OUTPUT_FILE', 'resumes_export.xlsx'),
        'max_emails': int(os.getenv('MAX_EMAILS', '0')),
        'use_selenium': os.getenv('USE_SELENIUM', 'false').lower() == 'true',
        'selenium_driver_path': os.getenv('SELENIUM_DRIVER_PATH', ''),
    }
    
    # 确保输出文件路径完整
    if not os.path.isabs(config['output_file']):
        config['output_file'] = str(project_root / 'output' / config['output_file'])
    
    return config


def main():
    """主函数"""
    print("=" * 60)
    print("📧 Gmail 简历批量解析工具 (简化版)")
    print("=" * 60)
    print()
    
    try:
        # 加载配置
        config = load_config()
        print(f"📋 配置信息:")
        print(f"   Gmail 查询: {config['gmail_query']}")
        print(f"   输出文件: {config['output_file']}")
        print(f"   最大邮件数: {config['max_emails'] if config['max_emails'] > 0 else '无限制'}")
        print()
        
        # 初始化客户端
        credentials_path = project_root / 'config' / 'credentials.json'
        token_path = project_root / 'data' / 'token.json'
        
        print("🔑 初始化 Gmail 客户端...")
        gmail_client = FixedGmailClient(
            credentials_path=str(credentials_path),
            token_path=str(token_path)
        )
        
        # 搜索邮件
        print("🔍 正在搜索邮件...")
        max_results = config['max_emails'] if config['max_emails'] > 0 else 10  # 限制为 10 封进行测试
        messages = gmail_client.search_emails(config['gmail_query'], max_results=max_results)
        
        if not messages:
            print("⚠️ 未找到符合条件的邮件")
            return
        
        print(f"📧 找到 {len(messages)} 封邮件，开始处理...")
        print()
        
        # 初始化解析器和导出器
        resume_parser = ResumeParser(
            use_selenium=config['use_selenium'],
            driver_path=config['selenium_driver_path'] if config['selenium_driver_path'] else None
        )
        
        excel_exporter = SimpleExcelExporter(config['output_file'])
        
        # 处理每封邮件
        all_resumes = []
        failed_count = 0
        
        for idx, message in enumerate(messages[:3], 1):  # 仅处理前3封邮件进行测试
            print(f"\n📧 处理邮件 {idx}/{min(3, len(messages))}")
            
            # 获取邮件内容
            email_content = gmail_client.get_email_content(message['id'])
            if not email_content:
                print(f"❌ 获取邮件内容失败")
                failed_count += 1
                continue
            
            print(f"   主题: {email_content.get('subject', 'N/A')[:50]}...")
            
            # 提取 Boss 直聘链接
            links = gmail_client.extract_boss_zhipin_links(email_content)
            if not links:
                print(f"⚠️ 未找到 Boss 直聘链接")
                failed_count += 1
                continue
            
            print(f"   找到 {len(links)} 个链接")
            
            # 解析每份简历（一封邮件可能包含多个链接）
            for link_idx, link in enumerate(links[:1], 1):  # 仅处理第一个链接
                print(f"   📄 解析简历 {link_idx}: {link[:50]}...")
                resume_data = resume_parser.parse_from_url(link)
                
                if resume_data:
                    all_resumes.append(resume_data)
                    name = resume_data.get('name', '未知')
                    company = resume_data.get('current_company', '未知')
                    print(f"   ✅ 解析成功: {name} ({company})")
                else:
                    print(f"   ❌ 解析失败")
                    failed_count += 1
        
        # 关闭解析器
        resume_parser.close()
        
        # 导出到 Excel
        print()
        print("=" * 60)
        print("📊 处理完成")
        print("=" * 60)
        print(f"✅ 成功解析: {len(all_resumes)} 份简历")
        print(f"❌ 解析失败: {failed_count} 个")
        print()
        
        if all_resumes:
            output_path = excel_exporter.export(all_resumes)
            print(f"📁 文件已保存: {output_path}")
        else:
            print("⚠️ 没有成功解析的简历，未生成文件")
    
    except Exception as e:
        print(f"\n❌ 程序执行出错: {e}")
        import traceback
        traceback.print_exc()
        return


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n⚠️ 用户中断操作")
        sys.exit(0)
    except Exception as e:
        print(f"\n❌ 程序执行出错: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
