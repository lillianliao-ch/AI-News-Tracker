"""
Excel 导出器
将解析后的简历数据导出到 Excel 文件
"""

import os
import json
from datetime import datetime
from typing import List, Dict
import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Font, Alignment, PatternFill
from openpyxl.utils import get_column_letter


class ExcelExporter:
    """Excel 导出器"""
    
    def __init__(self, output_file: str):
        """
        初始化导出器
        
        Args:
            output_file: 输出文件路径
        """
        self.output_file = output_file
        self.ensure_output_dir()
    
    def ensure_output_dir(self):
        """确保输出目录存在"""
        output_dir = os.path.dirname(self.output_file)
        if output_dir:
            os.makedirs(output_dir, exist_ok=True)
    
    def export(self, resumes: List[Dict]) -> str:
        """
        导出简历数据到 Excel
        
        Args:
            resumes: 简历数据列表
        
        Returns:
            输出文件路径
        """
        if not resumes:
            print("⚠️ 没有简历数据可导出")
            return self.output_file
        
        # 准备数据
        data_rows = []
        for idx, resume in enumerate(resumes, 1):
            row = {
                '序号': idx,
                '姓名': resume.get('name', ''),
                '职位': resume.get('position', ''),
                '年龄': resume.get('age', ''),
                '工作年限': resume.get('work_years', ''),
                '学历': resume.get('education', ''),
                '当前公司': resume.get('current_company', ''),
                '当前职位': resume.get('current_position', ''),
                '工作状态': resume.get('employment_status', ''),
                '活跃状态': resume.get('active_status', ''),
                '期望职位': resume.get('expected_position', ''),
                '期望薪资': resume.get('expected_salary', ''),
                '期望地点': resume.get('expected_location', ''),
                '期望行业': resume.get('expected_industry', ''),
                '主要工作内容': resume.get('main_job_content', ''),
                '工作经历': self._format_json(resume.get('work_experience', [])),
                '项目经历': self._format_json(resume.get('project_experience', [])),
                '教育经历': self._format_json(resume.get('education_background', [])),
                '资格证书': ', '.join(resume.get('certificates', [])),
                '简历链接': resume.get('source_url', ''),
                '解析时间': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            }
            data_rows.append(row)
        
        # 创建 DataFrame
        df = pd.DataFrame(data_rows)
        
        # 导出到 Excel
        with pd.ExcelWriter(self.output_file, engine='openpyxl') as writer:
            df.to_excel(writer, sheet_name='简历列表', index=False)
            
            # 获取工作表
            worksheet = writer.sheets['简历列表']
            
            # 设置样式
            self._format_worksheet(worksheet, df)
        
        print(f"✅ 已导出 {len(resumes)} 份简历到: {self.output_file}")
        return self.output_file
    
    def _format_json(self, data: List[Dict]) -> str:
        """将 JSON 数据格式化为字符串"""
        if not data:
            return ''
        
        try:
            return json.dumps(data, ensure_ascii=False, indent=2)
        except:
            return str(data)
    
    def _format_worksheet(self, worksheet, df: pd.DataFrame):
        """格式化工作表"""
        # 设置标题行样式
        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF", size=11)
        
        for cell in worksheet[1]:
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal='center', vertical='center')
        
        # 设置列宽
        column_widths = {
            'A': 8,   # 序号
            'B': 12,  # 姓名
            'C': 15,  # 职位
            'D': 8,   # 年龄
            'E': 10,  # 工作年限
            'F': 10,  # 学历
            'G': 25,  # 当前公司
            'H': 15,  # 当前职位
            'I': 15,  # 工作状态
            'J': 12,  # 活跃状态
            'K': 15,  # 期望职位
            'L': 12,  # 期望薪资
            'M': 12,  # 期望地点
            'N': 20,  # 期望行业
            'O': 40,  # 主要工作内容
            'P': 50,  # 工作经历
            'Q': 50,  # 项目经历
            'R': 30,  # 教育经历
            'S': 20,  # 资格证书
            'T': 50,  # 简历链接
            'U': 20,  # 解析时间
        }
        
        for col_letter, width in column_widths.items():
            worksheet.column_dimensions[col_letter].width = width
        
        # 设置数据行样式
        for row in worksheet.iter_rows(min_row=2, max_row=worksheet.max_row):
            for cell in row:
                cell.alignment = Alignment(vertical='top', wrap_text=True)
        
        # 冻结首行
        worksheet.freeze_panes = 'A2'
        
        # 设置行高（自动调整）
        for row in worksheet.iter_rows(min_row=2):
            worksheet.row_dimensions[row[0].row].height = None

