"""
修复版 Gmail API 客户端
支持复杂的邮件结构解析
"""

import os
import base64
import re
from typing import List, Dict, Optional
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError


class FixedGmailClient:
    """修复版 Gmail API 客户端"""
    
    SCOPES = ['https://www.googleapis.com/auth/gmail.readonly']
    
    def __init__(self, credentials_path: str, token_path: str):
        """
        初始化 Gmail 客户端
        
        Args:
            credentials_path: Gmail API 凭证文件路径
            token_path: Token 保存路径
        """
        self.credentials_path = credentials_path
        self.token_path = token_path
        self.service = None
        self._authenticate()
    
    def _authenticate(self):
        """Gmail API 认证"""
        creds = None
        
        # 检查是否已有 token
        if os.path.exists(self.token_path):
            creds = Credentials.from_authorized_user_file(self.token_path, self.SCOPES)
        
        # 如果没有有效凭证，进行授权
        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                creds.refresh(Request())
            else:
                raise RuntimeError("需要重新授权，请先运行授权脚本")
        
        # 构建 Gmail 服务
        self.service = build('gmail', 'v1', credentials=creds)
        print("✅ Gmail API 连接成功")
    
    def search_emails(self, query: str, max_results: int = 10) -> List[Dict]:
        """
        搜索邮件
        
        Args:
            query: Gmail 搜索查询
            max_results: 最大返回结果数
        
        Returns:
            邮件列表
        """
        try:
            results = self.service.users().messages().list(
                userId='me',
                q=query,
                maxResults=max_results
            ).execute()
            
            messages = results.get('messages', [])
            print(f"📧 找到 {len(messages)} 封邮件")
            return messages
        
        except HttpError as error:
            print(f"❌ 搜索邮件失败: {error}")
            return []
    
    def get_email_content(self, message_id: str) -> Optional[Dict]:
        """
        获取邮件完整内容（修复版，支持复杂结构）
        
        Args:
            message_id: 邮件 ID
        
        Returns:
            邮件内容字典
        """
        try:
            message = self.service.users().messages().get(
                userId='me',
                id=message_id,
                format='full'
            ).execute()
            
            # 提取邮件头信息
            headers = message['payload'].get('headers', [])
            email_data = {
                'id': message_id,
                'threadId': message.get('threadId'),
                'snippet': message.get('snippet', ''),
                'subject': self._get_header(headers, 'Subject'),
                'from': self._get_header(headers, 'From'),
                'date': self._get_header(headers, 'Date'),
            }
            
            # 提取邮件正文（使用递归方法处理复杂结构）
            all_content = []
            self._extract_all_content(message['payload'], all_content)
            
            # 合并所有内容
            text_body = ""
            html_body = ""
            
            for content in all_content:
                if content['mimeType'] == 'text/plain':
                    text_body += content['data'] + "\n"
                elif content['mimeType'] == 'text/html':
                    html_body += content['data'] + "\n"
            
            email_data['body'] = text_body.strip()
            email_data['html_body'] = html_body.strip()
            
            return email_data
        
        except HttpError as error:
            print(f"❌ 获取邮件内容失败 (ID: {message_id}): {error}")
            return None
    
    def _extract_all_content(self, payload: Dict, all_content: List):
        """递归提取所有邮件内容"""
        # 如果有body数据，尝试解码
        body = payload.get('body', {})
        if body.get('data'):
            try:
                decoded_data = base64.urlsafe_b64decode(body['data']).decode('utf-8', errors='ignore')
                all_content.append({
                    'mimeType': payload.get('mimeType', ''),
                    'data': decoded_data
                })
            except Exception:
                pass  # 忽略解码错误
        
        # 递归处理子部分
        if 'parts' in payload:
            for part in payload['parts']:
                self._extract_all_content(part, all_content)
    
    def _get_header(self, headers: List[Dict], name: str) -> str:
        """从邮件头中获取指定字段"""
        for header in headers:
            if header['name'].lower() == name.lower():
                return header['value']
        return ''
    
    def extract_boss_zhipin_links(self, email_content: Dict) -> List[str]:
        """
        从邮件内容中提取 Boss 直聘简历链接（增强版）
        
        Args:
            email_content: 邮件内容字典
        
        Returns:
            Boss 直聘链接列表
        """
        links = []
        
        # 合并所有文本内容进行搜索
        text_to_search = ""
        if email_content.get('html_body'):
            text_to_search += email_content['html_body'] + " "
        if email_content.get('body'):
            text_to_search += email_content['body'] + " "
        
        # 增强的 Boss 直聘链接匹配模式
        patterns = [
            # 标准 Boss 直聘链接
            r'https://m\.zhipin\.com/[^\s<>"\'\)]+',
            r'https://www\.zhipin\.com/[^\s<>"\'\)]+',
            # 带参数的简历详情链接
            r'https://[mw]\.zhipin\.com/mpa/v\d+/html/resume/detail[^\s<>"\'\)]+',
            # 其他可能的格式
            r'https://[^/]*zhipin\.com[^\s<>"\'\)]+',
        ]
        
        print(f"🔍 搜索文本长度: {len(text_to_search)} 字符")
        
        for pattern in patterns:
            matches = re.findall(pattern, text_to_search, re.IGNORECASE)
            links.extend(matches)
            if matches:
                print(f"   找到 {len(matches)} 个链接 (模式: {pattern})")
        
        # 去重并清理
        links = list(set(links))
        
        # 过滤掉图片等非简历链接
        resume_links = []
        for link in links:
            link = link.rstrip('.,;:!?')  # 清理末尾标点
            
            # 跳过图片、CSS、JS等资源链接
            if any(ext in link.lower() for ext in ['.jpg', '.png', '.gif', '.css', '.js', '.ico']):
                continue
            
            # 优先保留简历详情链接
            if '/resume/detail' in link or '/mpa/' in link:
                resume_links.insert(0, link)  # 插入到前面，优先级高
            else:
                resume_links.append(link)
        
        print(f"✅ 提取到 {len(resume_links)} 个简历链接")
        for i, link in enumerate(resume_links, 1):
            print(f"   {i}. {link[:80]}...")
        
        return resume_links
