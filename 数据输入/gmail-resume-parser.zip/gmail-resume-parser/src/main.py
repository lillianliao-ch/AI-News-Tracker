"""
主程序
从 Gmail 获取简历邮件，解析简历并导出到 Excel
"""

import os
import sys
import argparse
from pathlib import Path
from datetime import datetime
from dotenv import load_dotenv
from tqdm import tqdm

# 添加项目根目录到路径
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from src.gmail_client import GmailClient
from src.resume_parser import ResumeParser
from src.excel_exporter import ExcelExporter


def load_config():
    """加载配置"""
    config_file = project_root / 'config' / 'config.env'
    
    if not config_file.exists():
        print(f"❌ 配置文件不存在: {config_file}")
        print("请复制 config.env.example 为 config.env 并配置")
        sys.exit(1)
    
    load_dotenv(config_file)
    
    # 解析命令行参数
    parser = argparse.ArgumentParser(description='Gmail 简历批量解析工具')
    parser.add_argument('-n', '--limit', type=int, help='最大处理邮件数量 (覆盖配置文件)', default=None)
    args, unknown = parser.parse_known_args()
    
    # 优先使用命令行参数，其次是环境变量
    max_emails = args.limit if args.limit is not None else int(os.getenv('MAX_EMAILS', '0'))
    
    # 构建 Gmail 查询
    base_query = os.getenv('GMAIL_QUERY', 'subject:"推荐了简历候选人"')
    # 自动添加 label:INBOX 以排除已归档邮件
    if 'label:INBOX' not in base_query and 'is:inbox' not in base_query:
        gmail_query = f"{base_query} label:INBOX"
    else:
        gmail_query = base_query
    
    # 处理输出文件名，添加时间戳
    base_output_name = os.getenv('OUTPUT_FILE', 'resumes_export.xlsx')
    name, ext = os.path.splitext(base_output_name)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_filename = f"{name}_{timestamp}{ext}"
    
    config = {
        'gmail_query': gmail_query,
        'output_file': output_filename,
        'max_emails': max_emails,
        'use_selenium': os.getenv('USE_SELENIUM', 'false').lower() == 'true',
        'selenium_driver_path': os.getenv('SELENIUM_DRIVER_PATH', ''),
        'boss_cookies': os.getenv('BOSS_COOKIES', '')
    }
    
    # 确保输出文件路径完整
    if not os.path.isabs(config['output_file']):
        config['output_file'] = str(project_root / 'output' / config['output_file'])
    
    return config


def main():
    """主函数"""
    print("=" * 60)
    print("📧 Gmail 简历批量解析工具")
    print("=" * 60)
    print()
    
    # 加载配置
    config = load_config()
    print(f"📋 配置信息:")
    print(f"   Gmail 查询: {config['gmail_query']}")
    print(f"   输出文件: {config['output_file']}")
    print(f"   最大邮件数: {config['max_emails'] if config['max_emails'] > 0 else '无限制'}")
    if config['boss_cookies']:
        print(f"   ✅ 已配置 Boss Cookies")
    print()
    
    # 初始化客户端
    credentials_path = project_root / 'config' / 'credentials.json'
    token_path = project_root / 'data' / 'token.json'
    
    try:
        gmail_client = GmailClient(
            credentials_path=str(credentials_path),
            token_path=str(token_path)
        )
    except Exception as e:
        print(f"❌ Gmail 客户端初始化失败: {e}")
        sys.exit(1)
    
    # 搜索邮件
    print("🔍 正在搜索邮件...")
    max_results = config['max_emails'] if config['max_emails'] > 0 else 100
    messages = gmail_client.search_emails(config['gmail_query'], max_results=max_results)
    
    if not messages:
        print("⚠️ 未找到符合条件的邮件")
        return
    
    print(f"📧 找到 {len(messages)} 封邮件，开始处理...")
    print()
    
    # 初始化解析器和导出器
    resume_parser = ResumeParser(
        use_selenium=config['use_selenium'],
        driver_path=config['selenium_driver_path'] if config['selenium_driver_path'] else None,
        cookies=config['boss_cookies']
    )
    
    excel_exporter = ExcelExporter(config['output_file'])
    
    # 处理每封邮件
    all_resumes = []
    failed_count = 0
    
    for idx, message in enumerate(tqdm(messages, desc="处理邮件"), 1):
        # 获取邮件内容
        email_content = gmail_client.get_email_content(message['id'])
        if not email_content:
            failed_count += 1
            continue
        
        # 提取 Boss 直聘链接
        links = gmail_client.extract_boss_zhipin_links(email_content)
        if not links:
            print(f"\n⚠️ 邮件 {idx} 中未找到 Boss 直聘链接")
            failed_count += 1
            continue
        
        # 解析每份简历（一封邮件可能包含多个链接）
        parse_success = False
        for link in links:
            print(f"\n📄 正在解析简历: {link}")
            resume_data = resume_parser.parse_from_url(link)
            
            if resume_data:
                all_resumes.append(resume_data)
                print(f"✅ 解析成功: {resume_data.get('name', '未知')}")
                parse_success = True
            else:
                print(f"❌ 解析失败")
                failed_count += 1
        
        # 如果该邮件中的简历都成功解析，则归档并打标签
        if parse_success:
            print(f"📦 正在归档邮件并添加标签 'boss'...")
            gmail_client.archive_and_label_email(message['id'], label_name='boss')
    
    # 关闭解析器
    resume_parser.close()
    
    # 导出到 Excel
    print()
    print("=" * 60)
    print("📊 处理完成")
    print("=" * 60)
    print(f"✅ 成功解析: {len(all_resumes)} 份简历")
    print(f"❌ 解析失败: {failed_count} 个")
    print()
    
    if all_resumes:
        output_path = excel_exporter.export(all_resumes)
        print(f"📁 文件已保存: {output_path}")
    else:
        print("⚠️ 没有成功解析的简历，未生成文件")


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n⚠️ 用户中断操作")
        sys.exit(0)
    except Exception as e:
        print(f"\n❌ 程序执行出错: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
