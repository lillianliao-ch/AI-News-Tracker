# OAuth 设置完整指南

## 🚨 当前问题

**错误**: "AIING"尚未完成 Google 验证流程 - 错误 403: access_denied

**原因**: OAuth 应用处于测试状态，需要配置测试用户或发布应用。

## ✅ 解决方案

### 方案 1：添加测试用户（推荐）

1. **访问 OAuth 同意屏幕**
   - URL: https://console.cloud.google.com/apis/credentials/consent
   - 项目: `gen-lang-client-0240713157`

2. **编辑应用**
   - 点击 **"编辑应用"** 按钮

3. **配置测试用户**
   - 向下滚动找到 **"测试用户"** 部分
   - 点击 **"+ 添加用户"**
   - 输入邮箱: `liao412@gmail.com`
   - 点击 **"保存"**

4. **重新授权**
   - 重新访问授权 URL
   - 完成授权流程

### 方案 2：发布应用

1. **在 OAuth 同意屏幕页面**
2. **点击 "发布应用"**
3. **确认发布**

**注意**: 发布后任何人都可以使用，但不需要审核（因为只请求 Gmail 只读权限）。

### 方案 3：重新创建应用（如果上述方法不行）

1. **访问**: https://console.cloud.google.com/apis/credentials
2. **创建凭据** → **OAuth 客户端 ID**
3. **应用类型**: 桌面应用
4. **名称**: Gmail Resume Parser
5. **下载凭据文件**

## 🔍 检查当前配置

当前使用的 OAuth 客户端：
- **Client ID**: `395360022878-erp7n14if4d85a7fqumk0rn2omtga6d8`
- **项目**: `gen-lang-client-0240713157`
- **类型**: 桌面应用

## 📋 验证步骤

配置完成后：

1. **访问授权 URL**:
   ```
   https://accounts.google.com/o/oauth2/auth?response_type=code&client_id=395360022878-erp7n14if4d85a7fqumk0rn2omtga6d8.apps.googleusercontent.com&redirect_uri=http%3A%2F%2Flocalhost&scope=https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fgmail.readonly&state=52mIw9hWAWsbeREclc2KKwHEaHYgKU&prompt=consent&access_type=offline
   ```

2. **完成授权**
3. **复制授权码**
4. **运行**: `python3 complete_auth.py "授权码"`

## 🆘 如果仍有问题

请提供以下信息：
- OAuth 同意屏幕的截图
- 是否找到了"测试用户"配置
- 应用当前的发布状态
