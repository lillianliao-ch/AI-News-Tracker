# ⚡ 快速修复 redirect_uri_mismatch 错误

## 🔴 当前错误

错误信息显示：`redirect_uri=http://localhost:8082/`

## ✅ 解决方案

### 在 Google Cloud Console 中添加以下 URI：

1. **访问**: https://console.cloud.google.com/apis/credentials
2. **找到**: OAuth 客户端 ID `395360022878-u7ieoksaba7kcc1hidamg62bepuabrpj`
3. **点击编辑**
4. **在"已授权的重定向 URI"中添加**：

```
http://localhost:8080/
http://localhost:8081/
http://localhost:8082/
http://localhost:8083/
http://localhost:8084/
http://127.0.0.1:8080/
http://127.0.0.1:8081/
http://127.0.0.1:8082/
http://127.0.0.1:8083/
http://127.0.0.1:8084/
```

5. **保存**并等待 1-2 分钟

### 为什么需要添加这么多？

程序会自动尝试使用 8080-8084 端口，如果某个端口被占用会使用下一个。为了确保无论使用哪个端口都能工作，需要添加所有可能的组合。

### 配置完成后

重新运行程序：
```bash
cd /Users/lillianliao/notion_rag/gmail-resume-parser
python src/main.py
```

## 📝 详细说明

查看 `GOOGLE_CLOUD_SETUP.md` 获取完整配置指南。

