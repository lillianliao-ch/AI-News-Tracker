#!/usr/bin/env python3
"""
最终测试 - 完整流程测试
"""

import os
from pathlib import Path
from dotenv import load_dotenv
from src.gmail_client_fixed import FixedGmailClient
from src.excel_exporter_simple import SimpleExcelExporter

def final_test():
    """最终完整测试"""
    print("🧪 Gmail 简历解析工具 - 最终测试")
    print("=" * 60)
    
    # 加载配置
    project_root = Path(__file__).parent
    config_file = project_root / 'config' / 'config.env'
    load_dotenv(config_file)
    
    gmail_query = os.getenv('GMAIL_QUERY', 'subject:"推荐了简历候选人"')
    output_file = str(project_root / 'output' / 'final_test_result.xlsx')
    
    print(f"📋 配置:")
    print(f"   Gmail 查询: {gmail_query}")
    print(f"   输出文件: {output_file}")
    
    try:
        # 1. Gmail API 测试
        print(f"\n🔑 步骤1: Gmail API 连接")
        client = FixedGmailClient('config/credentials.json', 'data/token.json')
        
        # 2. 搜索邮件
        print(f"\n📧 步骤2: 搜索邮件")
        messages = client.search_emails(gmail_query, 5)  # 测试5封邮件
        
        if not messages:
            print("❌ 未找到邮件")
            return False
        
        # 3. 处理邮件和提取链接
        print(f"\n🔗 步骤3: 提取Boss直聘链接")
        all_links = []
        email_info = []
        
        for idx, message in enumerate(messages, 1):
            email = client.get_email_content(message['id'])
            if email:
                links = client.extract_boss_zhipin_links(email)
                all_links.extend(links)
                
                email_info.append({
                    'email_id': message['id'],
                    'subject': email.get('subject', 'N/A'),
                    'links_count': len(links),
                    'links': links
                })
                
                print(f"   邮件 {idx}: {len(links)} 个链接")
        
        print(f"✅ 总计提取到 {len(all_links)} 个Boss直聘链接")
        
        # 4. 创建结果记录
        print(f"\n📊 步骤4: 生成结果记录")
        
        results = []
        for idx, info in enumerate(email_info, 1):
            for link_idx, link in enumerate(info['links'], 1):
                result = {
                    'source_url': link,
                    'name': f'候选人{idx}-{link_idx}',  # 临时标识
                    'position': '待解析',
                    'age': '',
                    'work_years': '',
                    'education': '',
                    'current_company': '待解析', 
                    'current_position': '待解析',
                    'employment_status': '',
                    'active_status': '',
                    'expected_position': '',
                    'expected_salary': '',
                    'expected_location': '',
                    'expected_industry': '',
                    'main_job_content': '',
                    'work_experience': [],
                    'project_experience': [],
                    'education_background': [],
                    'certificates': [],
                    'skills': [],
                    'email_subject': info['subject'],
                    'extraction_status': '链接提取成功，内容待解析'
                }
                results.append(result)
        
        # 5. 导出Excel
        print(f"\n📁 步骤5: 导出Excel文件")
        exporter = SimpleExcelExporter(output_file)
        final_file = exporter.export(results)
        
        # 6. 生成详细报告
        print(f"\n📋 最终测试报告")
        print("=" * 60)
        print(f"✅ Gmail API: 连接成功")
        print(f"✅ 邮件搜索: 找到 {len(messages)} 封邮件")
        print(f"✅ 链接提取: 提取到 {len(all_links)} 个Boss直聘链接")
        print(f"✅ Excel导出: 已生成 {len(results)} 行记录")
        print(f"✅ 输出文件: {final_file}")
        
        # 显示邮件和链接详情
        print(f"\n📧 邮件详情:")
        for info in email_info:
            print(f"   • {info['subject'][:50]}... ({info['links_count']} 个链接)")
        
        print(f"\n🔗 Boss直聘链接样本:")
        for i, link in enumerate(all_links[:3], 1):
            print(f"   {i}. {link[:80]}...")
        
        print(f"\n🎯 下一步:")
        print(f"1. 查看Excel文件: open {final_file}")
        print(f"2. 手动验证链接在浏览器中是否可访问")  
        print(f"3. 根据需要改进简历内容解析逻辑")
        
        return True
        
    except Exception as e:
        print(f"❌ 测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == '__main__':
    success = final_test()
    if success:
        print(f"\n🎉 测试完成！基础功能正常工作。")
    else:
        print(f"\n❌ 测试失败，请检查配置。")
