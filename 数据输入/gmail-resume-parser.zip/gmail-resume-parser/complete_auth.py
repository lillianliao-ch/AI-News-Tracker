#!/usr/bin/env python3
"""
完成授权 - 使用提供的授权码
"""

import os
import sys
import json
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/gmail.readonly']

def complete_auth_with_code(auth_code):
    """使用授权码完成授权"""
    print(f"🔑 使用授权码完成授权...")
    
    credentials_path = 'config/credentials.json'
    token_path = 'data/token.json'
    
    try:
        # 读取凭证配置
        with open(credentials_path, 'r') as f:
            client_config = json.load(f)
        
        # 创建授权流程
        flow = InstalledAppFlow.from_client_config(
            client_config, SCOPES
        )
        # 设置正确的redirect_uri
        flow.redirect_uri = 'http://localhost'
        
        # 使用授权码获取访问令牌
        print("🔄 交换访问令牌...")
        flow.fetch_token(code=auth_code)
        creds = flow.credentials
        
        # 保存 token
        os.makedirs(os.path.dirname(token_path), exist_ok=True)
        with open(token_path, 'w') as token:
            token.write(creds.to_json())
        print("✅ 授权信息已保存")
        
        # 测试 Gmail API
        print("📧 测试 Gmail API...")
        service = build('gmail', 'v1', credentials=creds)
        
        # 获取用户资料
        profile = service.users().getProfile(userId='me').execute()
        print(f"✅ Gmail API 连接成功！")
        print(f"   邮箱: {profile.get('emailAddress')}")
        print(f"   总邮件数: {profile.get('messagesTotal', 0):,}")
        
        # 测试搜索邮件
        print("🔍 测试邮件搜索...")
        results = service.users().messages().list(
            userId='me',
            q='subject:"推荐了简历候选人"',
            maxResults=3
        ).execute()
        
        messages = results.get('messages', [])
        print(f"✅ 找到 {len(messages)} 封匹配邮件")
        
        return True
        
    except Exception as e:
        print(f"❌ 授权失败: {e}")
        return False

if __name__ == '__main__':
    if len(sys.argv) != 2:
        print("使用方法: python complete_auth.py <授权码>")
        print("\n请先访问授权 URL 获取授权码:")
        print("https://accounts.google.com/o/oauth2/auth?response_type=code&client_id=395360022878-m14qnhpg2h2nr2be4bjk91aci4l4ihcs.apps.googleusercontent.com&scope=https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fgmail.readonly&prompt=consent&access_type=offline")
        sys.exit(1)
    
    auth_code = sys.argv[1].strip()
    success = complete_auth_with_code(auth_code)
    
    if success:
        print("\n🎉 授权完成！现在可以使用 Gmail API 了")
    else:
        print("\n❌ 授权失败，请重试")
