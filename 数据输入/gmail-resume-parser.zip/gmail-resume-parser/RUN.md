# 🚀 运行程序

## 快速运行

```bash
cd /Users/lillianliao/notion_rag/gmail-resume-parser
python src/main.py
```

## 首次运行流程

1. **程序启动** - 会显示配置信息
2. **打开浏览器** - 自动打开浏览器进行 Gmail 授权
3. **选择 Google 账号** - 选择要使用的 Gmail 账号
4. **授权访问** - 点击"允许"授权程序访问 Gmail
5. **自动保存 Token** - 授权后自动保存到 `data/token.json`
6. **开始处理** - 搜索邮件并解析简历

## 配置说明

当前配置（可在 `config/config.env` 中修改）：

- **Gmail 查询**: `subject:"推荐了简历候选人"`
- **输出文件**: `output/resumes_export.xlsx`
- **最大邮件数**: 无限制

## 自定义查询

编辑 `config/config.env` 可以修改 Gmail 查询条件：

```env
# 搜索最近 30 天的邮件
GMAIL_QUERY=subject:"推荐了简历候选人" newer_than:30d

# 搜索特定发件人
GMAIL_QUERY=from:cv@notice.zhipin.com subject:"推荐了简历候选人"

# 组合查询
GMAIL_QUERY=subject:"推荐了简历候选人" from:cv@notice.zhipin.com newer_than:7d
```

## 输出结果

程序运行完成后，会在 `output/` 目录生成 Excel 文件，包含所有解析的简历信息。

## 常见问题

### Q: 提示 "redirect_uri_mismatch" 错误

**解决**: 需要在 Google Cloud Console 中配置重定向 URI（见上方说明）

### Q: 找不到邮件

**解决**: 检查 Gmail 查询条件是否正确，可以尝试更宽泛的查询

### Q: 解析失败

**解决**: Boss 直聘页面可能需要登录，考虑使用 Selenium（在配置中启用）

