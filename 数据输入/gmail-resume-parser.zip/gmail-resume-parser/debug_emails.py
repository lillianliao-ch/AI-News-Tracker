#!/usr/bin/env python3
"""
调试邮件内容 - 查看实际的邮件格式和链接
"""

import sys
from pathlib import Path
from src.gmail_client_clean import CleanGmailClient

def debug_emails():
    """调试邮件内容"""
    print("🔍 调试邮件内容")
    print("=" * 50)
    
    credentials_path = 'config/credentials.json'
    token_path = 'data/token.json'
    
    try:
        # 初始化客户端
        client = CleanGmailClient(credentials_path, token_path)
        
        # 搜索邮件
        query = 'subject:"推荐了简历候选人"'
        messages = client.search_emails(query, max_results=3)
        
        if not messages:
            print("⚠️ 未找到邮件")
            return
        
        # 检查每封邮件的内容
        for idx, message in enumerate(messages, 1):
            print(f"\n📧 邮件 {idx}")
            print("-" * 30)
            
            try:
                # 获取邮件详细内容
                email_detail = client.service.users().messages().get(
                    userId='me', id=message['id'], format='full'
                ).execute()
                
                # 提取邮件头信息
                headers = email_detail['payload'].get('headers', [])
                subject = next((h['value'] for h in headers if h['name'] == 'Subject'), 'N/A')
                from_addr = next((h['value'] for h in headers if h['name'] == 'From'), 'N/A')
                
                print(f"主题: {subject}")
                print(f"发件人: {from_addr}")
                
                # 提取邮件正文
                body_text, body_html = extract_body(email_detail['payload'])
                
                print(f"正文长度: 文本={len(body_text)} 字符, HTML={len(body_html)} 字符")
                
                # 查找所有 URL
                import re
                
                # 在HTML和文本中查找所有URL
                text_to_search = body_html + " " + body_text
                urls = re.findall(r'https?://[^\s<>"\']+', text_to_search)
                
                print(f"找到 {len(urls)} 个URL:")
                for url in urls:
                    print(f"  - {url}")
                    if 'zhipin' in url.lower() or 'boss' in url.lower():
                        print(f"    *** 这是Boss直聘相关链接! ***")
                
                # 显示部分内容用于分析
                if body_html:
                    print(f"\nHTML内容片段 (前500字符):")
                    print(body_html[:500])
                elif body_text:
                    print(f"\n文本内容片段 (前500字符):")
                    print(body_text[:500])
                
            except Exception as e:
                print(f"❌ 处理邮件失败: {e}")
    
    except Exception as e:
        print(f"❌ 调试失败: {e}")

def extract_body(payload):
    """提取邮件正文"""
    import base64
    
    text_body = ''
    html_body = ''
    
    if 'parts' in payload:
        # 多部分邮件
        for part in payload['parts']:
            if part['mimeType'] == 'text/plain':
                data = part['body'].get('data')
                if data:
                    text_body = base64.urlsafe_b64decode(data).decode('utf-8', errors='ignore')
            elif part['mimeType'] == 'text/html':
                data = part['body'].get('data')
                if data:
                    html_body = base64.urlsafe_b64decode(data).decode('utf-8', errors='ignore')
    else:
        # 单部分邮件
        mime_type = payload.get('mimeType', '')
        data = payload['body'].get('data')
        if data:
            decoded = base64.urlsafe_b64decode(data).decode('utf-8', errors='ignore')
            if mime_type == 'text/plain':
                text_body = decoded
            elif mime_type == 'text/html':
                html_body = decoded
    
    return text_body, html_body

if __name__ == '__main__':
    debug_emails()
