#!/usr/bin/env python3
"""
测试解析结果的质量
"""

import os
import json

def test_excel_results():
    """测试 Excel 结果文件"""
    print("📊 测试解析结果")
    print("=" * 50)
    
    excel_file = 'output/resumes_export.xlsx'
    
    if not os.path.exists(excel_file):
        print(f"❌ 未找到结果文件: {excel_file}")
        return
    
    try:
        # 尝试读取 Excel 文件
        import openpyxl
        wb = openpyxl.load_workbook(excel_file)
        ws = wb.active
        
        print(f"✅ Excel 文件读取成功")
        print(f"   文件: {excel_file}")
        print(f"   工作表: {ws.title}")
        print(f"   总行数: {ws.max_row} (包含标题行)")
        print(f"   总列数: {ws.max_column}")
        
        # 显示表头
        print(f"\n📋 表头信息:")
        for col in range(1, min(ws.max_column + 1, 11)):  # 显示前10列
            header = ws.cell(row=1, column=col).value
            print(f"   第{col}列: {header}")
        
        # 显示数据样本
        print(f"\n📄 数据样本 (前3行):")
        for row in range(2, min(ws.max_row + 1, 5)):  # 显示前3行数据
            print(f"\n--- 第{row-1}份简历 ---")
            for col in range(1, 8):  # 显示前7列的基本信息
                header = ws.cell(row=1, column=col).value
                value = ws.cell(row=row, column=col).value
                print(f"   {header}: {value}")
        
        wb.close()
        return True
        
    except ImportError:
        # 如果 openpyxl 有问题，尝试用 pandas
        try:
            import pandas as pd
            df = pd.read_excel(excel_file)
            
            print(f"✅ Excel 文件读取成功 (使用 pandas)")
            print(f"   文件: {excel_file}")
            print(f"   总记录数: {len(df)}")
            print(f"   总列数: {len(df.columns)}")
            
            print(f"\n📋 列名:")
            for i, col in enumerate(df.columns[:10], 1):
                print(f"   {i}. {col}")
            
            print(f"\n📄 数据样本:")
            print(df[['姓名', '职位', '当前公司', '期望薪资']].head())
            
            return True
            
        except Exception as e:
            print(f"❌ 无法读取 Excel 文件: {e}")
            return False
    
    except Exception as e:
        print(f"❌ 测试失败: {e}")
        return False

def test_resume_links():
    """测试简历链接是否可访问"""
    print(f"\n🔗 测试简历链接")
    print("=" * 30)
    
    debug_file = 'debug_email_structure.json'
    
    if os.path.exists(debug_file):
        with open(debug_file, 'r') as f:
            debug_data = json.load(f)
        
        # 从调试数据中提取链接
        import re
        all_content = debug_data.get('extracted_content', [])
        
        for content in all_content:
            text = content.get('data', '')
            urls = re.findall(r'https://[mw]\.zhipin\.com/[^\s<>"\'\)]+', text)
            
            for url in urls[:3]:  # 测试前3个链接
                print(f"🔗 测试链接: {url[:60]}...")
                
                try:
                    import requests
                    response = requests.head(url, timeout=5, allow_redirects=True)
                    if response.status_code == 200:
                        print(f"   ✅ 链接可访问 (状态码: {response.status_code})")
                    else:
                        print(f"   ⚠️  链接状态: {response.status_code}")
                except Exception as e:
                    print(f"   ❌ 链接测试失败: {e}")
    else:
        print("ℹ️  未找到调试文件，跳过链接测试")

if __name__ == '__main__':
    success = test_excel_results()
    if success:
        test_resume_links()
        print(f"\n🎉 测试完成！")
    else:
        print(f"\n❌ 测试失败")
