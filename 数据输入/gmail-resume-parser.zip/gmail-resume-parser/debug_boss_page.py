#!/usr/bin/env python3
"""
调试 Boss 直聘页面内容
"""

import requests
from bs4 import BeautifulSoup

def debug_boss_page():
    """调试 Boss 直聘页面"""
    print("🔍 调试 Boss 直聘页面内容")
    print("=" * 50)
    
    # 使用从邮件中提取的真实链接（从之前的调试输出中）
    test_url = "https://m.zhipin.com/mpa/v3/html/resume/detail?expectId=1339620490&securityId=BXssJknwB1kcc-51_U7u-OcP9F2LriXAEMxKg2_LxrjIuwaUVf5ePgK4X5eiUKfrAgzy04IppQQ4a2gEXSx4nVV_q8Ml5Tc7bsK9JGZS6AdUAmncVDF1xXfZHnh8vv8uAdG3s_8ukuTgyEQ-wPN2m6W89pKVDu1Etesxd0fYAh0NKlXC3sHgJSi6cBmV7iTkY_-3NLH2OlJ0yx5OS88igrXCQruHvetlnVQ4lbvEybw_m69n3KlCHA2yup4zyV0YWnGBJXbtiv5iqMRuuCGPQtClLJmsmfYYQxOPgjBrZl8UhVGwOrqtBAvejCbx6A4qVHTKA1KawKy0w0lqwGwZkJjZF7DbVgaO-ZViY5_vCwzuNjn7l_rCBGT1SgMrbV005-XSgXz9rlypEAey0GfaxrFJeXbrc_vwG6Rfscxhh_gvdcWPnxIrvBGHpTKGeSa6XIEEAYZMb92AfpudgyHuWOrJH2OaJP9VScxZCV2IOVgbXfogo5MiPWeef9uVU1dqaZ90xvCg5aAItEqS8-Bdj2xquXU_jNUAsnY~&encryptId=d1fce857fce390f303R72t61GFY~&version=1"
    
    print(f"🔗 测试 URL: {test_url[:80]}...")
    
    try:
        # 使用模拟浏览器的 headers
        headers = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
            'Accept-Encoding': 'gzip, deflate, br',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
        }
        
        response = requests.get(test_url, headers=headers, timeout=10)
        
        print(f"📊 响应信息:")
        print(f"   状态码: {response.status_code}")
        print(f"   内容长度: {len(response.text)} 字符")
        print(f"   Content-Type: {response.headers.get('Content-Type', 'N/A')}")
        
        if response.status_code != 200:
            print(f"❌ 页面访问失败")
            return
        
        # 解析 HTML
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # 分析页面结构
        print(f"\n📄 页面分析:")
        print(f"   标题: {soup.title.string if soup.title else 'N/A'}")
        
        # 查找可能的简历信息
        text_content = soup.get_text()
        print(f"   文本内容长度: {len(text_content)} 字符")
        
        # 查找关键信息
        keywords = ['年', '岁', '经验', '学历', '公司', '职位', '工作', '项目']
        found_keywords = []
        for keyword in keywords:
            if keyword in text_content:
                found_keywords.append(keyword)
        
        print(f"   找到关键词: {found_keywords}")
        
        # 显示页面内容片段
        print(f"\n📋 页面内容片段 (前500字符):")
        print(text_content[:500])
        print("...")
        
        # 检查是否需要登录
        if '登录' in text_content or '请先登录' in text_content or 'login' in text_content.lower():
            print(f"\n⚠️  页面可能需要登录才能查看完整内容")
        
        # 检查是否是 JavaScript 渲染
        if len(text_content.strip()) < 100:
            print(f"\n⚠️  页面内容很少，可能需要 JavaScript 渲染")
        
        # 保存页面内容到文件用于分析
        with open('debug_boss_page.html', 'w', encoding='utf-8') as f:
            f.write(response.text)
        
        print(f"\n💾 页面内容已保存到: debug_boss_page.html")
        
    except Exception as e:
        print(f"❌ 页面调试失败: {e}")

if __name__ == '__main__':
    debug_boss_page()
