# 🔧 修复 redirect_uri_mismatch 错误

## 问题说明

错误信息显示：`redirect_uri=http://localhost:52671/` 不匹配。

这是因为 Google Cloud Console 中没有配置正确的重定向 URI。

## ✅ 解决方案

### 在 Google Cloud Console 中添加重定向 URI

1. **访问 Google Cloud Console**
   - 打开：https://console.cloud.google.com/apis/credentials
   - 选择项目：`gen-lang-client-0240713157`

2. **编辑 OAuth 客户端**
   - 找到 OAuth 2.0 客户端 ID：`395360022878-u7ieoksaba7kcc1hidamg62bepuabrpj`
   - 点击 **编辑**（铅笔图标）

3. **添加重定向 URI**
   在 **已授权的重定向 URI** 部分，点击 **+ 添加 URI**，依次添加以下所有 URI：
   ```
   http://localhost:8080/
   http://localhost:8081/
   http://localhost:8082/
   http://localhost:8083/
   http://localhost:8084/
   http://127.0.0.1:8080/
   http://127.0.0.1:8081/
   http://127.0.0.1:8082/
   http://localhost/
   http://127.0.0.1/
   ```

   **或者** 如果支持通配符，可以添加：
   ```
   http://localhost:*/
   http://127.0.0.1:*/
   ```

4. **保存**
   - 点击底部的 **保存** 按钮
   - 等待几秒钟让配置生效

5. **重新运行程序**
   ```bash
   cd /Users/lillianliao/notion_rag/gmail-resume-parser
   python src/main.py
   ```

## 📝 注意事项

- 代码会自动尝试使用 8080-8084 端口，如果某个端口被占用会自动选择下一个
- 配置保存后可能需要等待几秒钟才能生效
- 如果仍有问题，可以尝试清除浏览器缓存或使用无痕模式

## ✅ 验证配置

配置完成后，重新运行程序，应该能够正常打开授权页面并完成授权。
