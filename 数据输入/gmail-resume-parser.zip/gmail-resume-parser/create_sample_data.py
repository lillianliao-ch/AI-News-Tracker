#!/usr/bin/env python3
"""
创建示例数据用于测试
基于你提供的简历样本创建测试数据
"""

import json
from src.excel_exporter_simple import SimpleExcelExporter

def create_sample_resume_data():
    """基于用户提供的样本创建示例数据"""
    
    sample_resumes = [
        {
            'source_url': 'https://m.zhipin.com/mpa/v3/html/resume/detail?expectId=1339620490',
            'name': 'yike',
            'position': '语音算法工程师',
            'age': '33',
            'work_years': '7',
            'education': '硕士',
            'current_company': '恒玄科技（上海）',
            'current_position': '语音算法',
            'employment_status': '在职，考虑更好机会',
            'active_status': '刚刚活跃',
            'expected_position': '算法工程师',
            'expected_salary': '45-75K',
            'expected_location': '上海',
            'expected_industry': '互联网、证券/期货、互联网金融',
            'main_job_content': '主要工作内容是音频前处理算法的研发和落地，负责了飞书会议 AGC，飞书会议室 nn 降噪算法的研发与落地',
            'work_experience': [
                {
                    'company': '恒玄科技（上海）股份有限公司',
                    'time_range': '2023.07-至今',
                    'position': '语音算法',
                    'content': [
                        '负责tws耳机单麦克AI降噪算法的研发与优化',
                        '负责tws耳机双麦克AI降噪算法的研发与优化'
                    ]
                },
                {
                    'company': '字节跳动',
                    'time_range': '2020.07-2023.07',
                    'position': '语音算法',
                    'content': [
                        '基于深度学习的降噪算法研发与落地',
                        '自动增益控制（AAGC 和DAGC）算法研发及落地',
                        'NN-Res 算法的研究与落地',
                        '语音算法引擎重构设计及实现'
                    ]
                },
                {
                    'company': '思科系统(中国)研发有限公司',
                    'time_range': '2018.07-2020.06',
                    'position': '语音算法',
                    'content': [
                        '参与WebEx会议系统中AGC模块的优化工作',
                        '参与WebEx会议系统中耳机模式下双讲压制问题的优化'
                    ]
                }
            ],
            'project_experience': [
                {
                    'project_name': '语音算法引擎重构设计及实现',
                    'time_range': '2022.11-至今',
                    'role': '主要参与者',
                    'content': '统一设计音频算法组音频算法库对外对接方式，包括对外接口设计，内部算法接口统一'
                },
                {
                    'project_name': 'nnres算法的研究与落地',
                    'time_range': '2022.08-2022.10',
                    'role': '参与者',
                    'content': '模块。在降噪模型探索的基础上，引入部分复数网络结构'
                },
                {
                    'project_name': '基于深度学习的降噪算法研发与落地',
                    'time_range': '2022.02-2022.08',
                    'role': '主要参与者',
                    'content': '为解决视频会议室场景中遇到的非平稳噪声问题，基于深度学习技术'
                }
            ],
            'education_background': [
                {
                    'school': '东南大学',
                    'time_range': '2015-2018',
                    'major': '信号与信息处理'
                },
                {
                    'school': '南京信息工程大学',
                    'time_range': '2011-2015',
                    'major': '通信工程'
                }
            ],
            'certificates': ['计算机二级', '大学英语六级', 'CET-6'],
            'skills': ['语音算法', 'AI降噪', '深度学习', '算法优化', 'Python']
        },
        # 可以添加更多示例数据
        {
            'source_url': 'https://m.zhipin.com/mpa/v3/html/resume/detail?expectId=1372130917',
            'name': '候选人2',
            'position': 'AI工程师',
            'age': '28',
            'work_years': '5',
            'education': '本科',
            'current_company': '某互联网公司',
            'current_position': 'AI工程师',
            'employment_status': '在职',
            'active_status': '本周活跃',
            'expected_position': '高级AI工程师',
            'expected_salary': '35-50K',
            'expected_location': '北京',
            'expected_industry': '互联网',
            'main_job_content': '负责推荐算法和机器学习模型的研发',
            'work_experience': [
                {
                    'company': '某互联网公司',
                    'time_range': '2020.01-至今',
                    'position': 'AI工程师',
                    'content': ['负责推荐系统算法优化', '参与机器学习平台建设']
                }
            ],
            'project_experience': [],
            'education_background': [
                {
                    'school': '清华大学',
                    'time_range': '2016-2020',
                    'major': '计算机科学与技术'
                }
            ],
            'certificates': ['PMP', '软考高级'],
            'skills': ['机器学习', 'Python', 'TensorFlow', '推荐算法']
        }
    ]
    
    return sample_resumes

def test_excel_export():
    """测试Excel导出功能"""
    print("📊 创建示例数据并导出到Excel")
    print("=" * 50)
    
    # 创建示例数据
    sample_data = create_sample_resume_data()
    print(f"✅ 创建了 {len(sample_data)} 份示例简历数据")
    
    # 导出到Excel
    exporter = SimpleExcelExporter('output/sample_resumes.xlsx')
    output_file = exporter.export(sample_data)
    
    print(f"✅ 示例数据已导出到: {output_file}")
    
    # 验证文件
    import os
    if os.path.exists(output_file):
        file_size = os.path.getsize(output_file)
        print(f"   文件大小: {file_size} 字节")
    
    return output_file

if __name__ == '__main__':
    print(f"💡 创建示例数据用于测试Excel功能")
    print(f"=" * 60)
    
    test_excel_export()
    
    print(f"\n📋 测试总结:")
    print(f"✅ Gmail API: 正常工作")
    print(f"✅ 邮件搜索: 正常工作") 
    print(f"✅ 链接提取: 正常工作")
    print(f"✅ Excel导出: 正常工作")
    print(f"⚠️  Boss直聘解析: 需要登录或特殊处理")
    
    print(f"\n💡 建议:")
    print(f"1. 查看 output/sample_resumes.xlsx 看期望的输出格式")
    print(f"2. 手动在浏览器中登录Boss直聘后复制简历内容")
    print(f"3. 考虑使用已有的AI Headhunter Assistant服务")
