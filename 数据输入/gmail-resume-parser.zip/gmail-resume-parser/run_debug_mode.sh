#!/bin/bash

# 1. 关闭 Chrome
echo "⚠️  请先手动关闭所有 Chrome 窗口！"
echo "⚠️  Please close all Chrome windows manually!"
read -p "按回车键继续..."

# 2. 启动调试版 Chrome
echo "🚀 启动调试版 Chrome..."
/Applications/Google\ Chrome.app/Contents/MacOS/Google\ Chrome --remote-debugging-port=9222 --user-data-dir="/tmp/chrome_debug_profile" &

echo "✅ Chrome 已启动"
echo "👉 请在弹出的 Chrome 窗口中："
echo "   1. 访问 zhipin.com"
echo "   2. 扫码登录 Boss 直聘"
echo "   3. 确保登录成功"
echo ""
read -p "登录完成后，按回车键开始运行解析程序..."

# 3. 运行解析程序
echo "🚀 开始运行解析程序..."
cd /Users/lillianliao/notion_rag/gmail-resume-parser
python3 src/main.py

