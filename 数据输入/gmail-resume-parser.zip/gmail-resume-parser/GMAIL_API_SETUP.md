# Gmail API 配置指南

## ✅ 凭证文件已配置

你的 Gmail API 凭证文件已经复制到：
```
config/credentials.json
```

## ⚠️ 重要：配置 OAuth 重定向 URI

由于你使用的是 **Web 应用**类型的 OAuth 客户端，需要在 Google Cloud Console 中配置授权重定向 URI。

### 配置步骤

1. 访问 [Google Cloud Console](https://console.cloud.google.com/)
2. 进入 **API 和服务** > **凭据**
3. 找到你的 OAuth 2.0 客户端 ID（`395360022878-u7ieoksaba7kcc1hidamg62bepuabrpj`）
4. 点击编辑
5. 在 **已授权的重定向 URI** 中添加：
   ```
   http://localhost:8080
   http://127.0.0.1:8080
   http://localhost
   ```
6. 保存更改

### 或者：创建桌面应用类型的凭证（推荐）

如果你遇到问题，可以创建一个新的桌面应用类型的凭证：

1. 在 Google Cloud Console 中，点击 **创建凭据** > **OAuth 客户端 ID**
2. 应用类型选择 **桌面应用**
3. 下载新的凭证文件
4. 替换 `config/credentials.json`

## 🚀 测试配置

配置完成后，运行程序测试：

```bash
cd /Users/lillianliao/notion_rag/gmail-resume-parser
python src/main.py
```

首次运行会：
1. 打开浏览器进行 Gmail 授权
2. 授权后自动保存 token
3. 开始处理邮件

## 🔧 如果遇到问题

### 问题 1: "redirect_uri_mismatch" 错误

**原因**：重定向 URI 未在 Google Cloud Console 中配置

**解决**：
- 按照上面的步骤添加重定向 URI
- 或者创建桌面应用类型的凭证

### 问题 2: "access_denied" 错误

**原因**：用户拒绝了授权

**解决**：
- 重新运行程序
- 在授权页面点击"允许"

### 问题 3: 无法打开浏览器

**解决**：
- 检查是否有防火墙阻止
- 尝试手动访问显示的 URL

## 📝 下一步

配置完成后，继续：

1. 配置环境变量（`config/config.env`）
2. 运行程序测试
3. 查看输出结果

