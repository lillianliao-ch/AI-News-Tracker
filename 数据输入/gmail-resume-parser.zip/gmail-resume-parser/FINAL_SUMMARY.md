# 🏆 Gmail 简历解析器 - 项目结项总结

## 📅 项目概述
**目标**：自动化从 Gmail 中提取 Boss 直聘推荐的候选人简历，解析详细信息并导出为 Excel 报表。
**状态**：✅ 已完成，功能稳定运行。

---

## ✨ 核心功能

1.  **自动化邮件搜索**：基于 Gmail API，支持按时间、发件人、关键词精准搜索。
2.  **智能链接提取**：自动从复杂的邮件 HTML 结构中提取 Boss 直聘简历链接。
3.  **深度简历解析**：
    *   无需手动登录（复用本地浏览器状态）。
    *   解析动态渲染的页面（React/Vue 前端渲染）。
    *   提取完整字段：姓名、职位、薪资、**工作经历**、**教育经历**、项目经历等。
4.  **结构化导出**：生成包含所有详细信息的 Excel 文件，便于筛选和归档。

---

## 🛠️ 技术挑战与解决方案（经验沉淀）

在开发过程中，我们遇到了三个主要技术挑战，最终的解决方案非常值得后续项目借鉴：

### 挑战 1：Gmail 邮件内容提取失败
*   **问题**：部分邮件提取不到 HTML 内容，导致找不到 Boss 链接。
*   **原因**：Gmail 邮件使用了复杂的嵌套 MIME 结构 (`multipart/mixed` -> `multipart/alternative` -> `text/html`)，原代码只处理了顶层。
*   **✅ 解决方案**：
    *   重写内容提取逻辑，使用**递归算法**遍历所有 MIME parts，直到找到 `text/html` 类型的内容。

### 挑战 2：Boss 直聘页面无法解析（空数据）
*   **问题**：`requests` 请求返回的 HTML 是空的，只有骨架。
*   **原因**：Boss 页面采用**纯前端渲染 (Client-side Rendering)**，数据通过 JavaScript 异步加载或嵌入在 JS 变量中。
*   **✅ 解决方案**：
    *   引入 **Selenium** 进行浏览器自动化，等待 JavaScript 执行完毕。
    *   实现**智能等待机制** (`WebDriverWait`)，不只等待页面加载，而是等待具体的简历元素（如“求职期望”）出现后再提取。

### 挑战 3：反爬虫检测（"Oops" 页面 / 无法登录）
*   **问题**：即使使用了 Selenium，Boss 直聘依然能检测到自动化工具，拦截访问或显示脱敏数据（只有姓名，无详细经历）。
*   **尝试过的失败方案**：
    *   ❌ 直接 requests 请求（需要复杂 Cookie/Token）。
    *   ❌ 纯无头模式 Selenium（特征太明显）。
    *   ❌ `undetected_chromedriver`（环境配置复杂，不稳定）。
*   **✅ 最终解决方案（最佳实践）**：
    *   **复用本地浏览器 (Remote Debugging)**。
    *   启动 Chrome 时开启调试端口：`--remote-debugging-port=9222`。
    *   Selenium 通过 `debuggerAddress` 连接到这个已打开且已登录的浏览器。
    *   **优势**：完全模拟真实用户行为，共享登录状态（Cookie/Session），完美绕过指纹检测。

### 挑战 4：HTML 类名动态化
*   **问题**：页面类名包含随机哈希（如 `name_dWp13QSM`），导致解析失效。
*   **✅ 解决方案**：
    *   使用**正则表达式匹配**类名前缀（如 `re.compile('^name_')`）。
    *   放弃精确匹配，改用模糊匹配策略，提高了解析器的鲁棒性。

---

## 🚀 如何复用此项目（Best Practices）

### 1. 启动方式
使用 `run_debug_mode.sh` 脚本，它封装了复杂的启动流程：
```bash
./run_debug_mode.sh
```
1.  脚本提示关闭 Chrome。
2.  脚本自动以调试模式启动 Chrome。
3.  用户手动登录 Boss 直聘。
4.  脚本自动运行 Python 解析程序。

### 2. 关键代码片段（复用浏览器）
```python
from selenium.webdriver.chrome.options import Options

chrome_options = Options()
# 关键：连接到已打开的 Chrome，而不是启动新的
chrome_options.add_experimental_option("debuggerAddress", "127.0.0.1:9222")
driver = webdriver.Chrome(options=chrome_options)
```

---

## 📂 文件清单
*   `src/main.py`: 主程序入口。
*   `src/gmail_client.py`: Gmail API 客户端（含递归解析修复）。
*   `src/resume_parser.py`: 简历解析器（含 Selenium 复用和动态正则解析）。
*   `run_debug_mode.sh`: 一键启动脚本。
*   `config/config.env`: 配置文件。

---

🎉 **总结**：通过“浏览器复用”技术，我们将一个极其复杂的反爬虫攻防战，转化为了简单的自动化操作，极大降低了维护成本和封号风险。这是处理此类高防护网站的最佳轻量级方案。

