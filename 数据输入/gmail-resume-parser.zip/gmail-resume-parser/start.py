#!/usr/bin/env python3
"""
Gmail简历解析器 - 启动脚本
快速检查并运行主程序
"""

import os
import sys

def check_environment():
    """检查运行环境"""
    print("=" * 60)
    print("🔍 Gmail简历解析器 - 环境检查")
    print("=" * 60)
    
    # 检查Python版本
    print(f"\n✅ Python版本: {sys.version.split()[0]}")
    
    # 检查配置文件
    config_file = "config/config.env"
    if os.path.exists(config_file):
        print(f"✅ 配置文件存在: {config_file}")
    else:
        print(f"❌ 配置文件不存在: {config_file}")
        return False
    
    # 检查Gmail凭证
    credentials_file = "config/credentials.json"
    if os.path.exists(credentials_file):
        print(f"✅ Gmail凭证存在: {credentials_file}")
    else:
        print(f"❌ Gmail凭证不存在: {credentials_file}")
        return False
    
    # 检查Token
    token_file = "data/token.json"
    if os.path.exists(token_file):
        print(f"✅ OAuth Token存在: {token_file}")
        print(f"   （说明已授权，可以直接运行）")
    else:
        print(f"⚠️  OAuth Token不存在: {token_file}")
        print(f"   （首次运行会打开浏览器进行授权）")
    
    # 检查必要的包
    print("\n📦 检查Python依赖...")
    required_packages = [
        'google.auth',
        'google_auth_oauthlib',
        'googleapiclient',
        'bs4',
        'openpyxl',
        'pandas',
        'dotenv'
    ]
    
    missing = []
    for package in required_packages:
        try:
            __import__(package)
            print(f"  ✅ {package}")
        except ImportError:
            print(f"  ❌ {package}")
            missing.append(package)
    
    if missing:
        print(f"\n❌ 缺少依赖包，请运行:")
        print(f"   pip install -r requirements.txt")
        return False
    
    print("\n" + "=" * 60)
    print("✅ 环境检查通过！可以运行程序")
    print("=" * 60)
    return True

def show_usage():
    """显示使用说明"""
    print("\n📋 使用说明:")
    print("   python src/main.py              # 运行主程序")
    print("   python src/main_simple.py       # 运行简化版")
    print("   python final_test.py            # 运行完整测试")
    print("\n📁 输出目录:")
    print("   output/resumes_export.xlsx      # 导出的Excel文件")
    print("\n⚙️  修改配置:")
    print("   编辑 config/config.env          # 修改Gmail查询条件")
    print()

if __name__ == '__main__':
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    
    if check_environment():
        show_usage()
        
        print("🚀 准备运行主程序...")
        print("-" * 60)
        
        # 运行主程序
        try:
            from src import main
            main.main()
        except KeyboardInterrupt:
            print("\n\n⏹️  用户中断程序")
        except Exception as e:
            print(f"\n❌ 程序运行出错: {e}")
            import traceback
            traceback.print_exc()
    else:
        print("\n❌ 环境检查失败，请先解决上述问题")
        sys.exit(1)

