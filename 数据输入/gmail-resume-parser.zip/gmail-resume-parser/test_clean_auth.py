#!/usr/bin/env python3
"""
简化版 Gmail API 测试
"""

import sys
from pathlib import Path

# 添加项目根目录到路径
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from src.gmail_client_clean import CleanGmailClient

def main():
    """测试 Gmail API 授权和基本功能"""
    print("🧪 Gmail API 简化测试")
    print("=" * 50)
    
    credentials_path = 'config/credentials.json'
    token_path = 'data/token.json'
    
    try:
        # 初始化客户端
        print("🔑 初始化 Gmail 客户端...")
        client = CleanGmailClient(credentials_path, token_path)
        
        # 获取用户资料
        print("\n👤 获取用户资料...")
        profile = client.get_profile()
        if profile:
            print(f"✅ 用户邮箱: {profile.get('emailAddress')}")
            print(f"✅ 总邮件数: {profile.get('messagesTotal', 0):,}")
        
        # 测试搜索邮件
        print("\n🔍 测试邮件搜索...")
        query = 'subject:"推荐了简历候选人"'
        messages = client.search_emails(query, max_results=5)
        
        if messages:
            print(f"✅ 搜索成功，找到 {len(messages)} 封匹配邮件")
        else:
            print("⚠️ 未找到匹配邮件，尝试更宽泛的搜索...")
            messages = client.search_emails('subject:"简历"', max_results=3)
            if messages:
                print(f"✅ 找到 {len(messages)} 封包含'简历'的邮件")
            else:
                print("ℹ️ 未找到相关邮件，但 API 连接正常")
        
        print("\n🎉 测试完成！Gmail API 工作正常。")
        return True
        
    except Exception as e:
        print(f"\n❌ 测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == '__main__':
    try:
        success = main()
        if success:
            print("\n✅ 所有测试通过！可以使用 Gmail API 了。")
        else:
            print("\n❌ 测试失败，请检查配置。")
    except KeyboardInterrupt:
        print("\n⚠️ 测试被用户中断")
    except Exception as e:
        print(f"\n❌ 未预期的错误: {e}")
