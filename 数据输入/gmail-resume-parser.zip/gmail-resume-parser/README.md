# Gmail 简历批量解析工具

从 Gmail 中批量获取 Boss 直聘推荐的候选人简历邮件，解析简历内容并保存到 Excel。

## 📋 功能特性

- ✅ 从 Gmail 批量获取指定主题的邮件
- ✅ 自动提取邮件中的 Boss 直聘简历链接
- ✅ 解析简历页面内容（姓名、职位、工作经历、教育背景等）
- ✅ 将解析结果按顺序保存到 Excel 文件

## 🚀 快速开始

### 1. 安装依赖

```bash
pip install -r requirements.txt
```

### 2. 配置 Gmail API

1. 访问 [Google Cloud Console](https://console.cloud.google.com/)
2. 创建项目并启用 Gmail API
3. 创建 OAuth 2.0 凭证
4. 下载凭证文件保存为 `config/credentials.json`

### 3. 配置环境变量

复制 `config.env.example` 为 `config.env` 并填入配置：

```bash
cp config.env.example config.env
```

编辑 `config.env`：
- `GMAIL_QUERY`: Gmail 搜索查询（例如：`subject:"推荐了简历候选人"`）
- `OUTPUT_FILE`: 输出 Excel 文件名

### 4. 运行程序

```bash
python src/main.py
```

首次运行会打开浏览器进行 Gmail 授权。

## 📁 项目结构

```
gmail-resume-parser/
├── src/
│   ├── main.py              # 主程序
│   ├── gmail_client.py      # Gmail API 客户端
│   ├── resume_parser.py     # 简历页面解析器
│   └── excel_exporter.py    # Excel 导出器
├── config/
│   ├── credentials.json     # Gmail API 凭证（需自行配置）
│   └── config.env           # 环境配置（需自行配置）
├── data/                    # 临时数据目录
├── output/                  # 输出 Excel 文件目录
├── requirements.txt         # Python 依赖
└── README.md               # 本文件
```

## 🔧 配置说明

### Gmail 查询语法

在 `config.env` 中的 `GMAIL_QUERY` 支持 Gmail 搜索语法：

- `subject:"推荐了简历候选人"` - 主题包含指定文字
- `from:cv@notice.zhipin.com` - 来自指定发件人
- `subject:"推荐了简历候选人" from:cv@notice.zhipin.com` - 组合查询

### 输出 Excel 格式

Excel 文件包含以下列：
- 序号
- 姓名
- 职位
- 年龄
- 工作年限
- 学历
- 当前公司
- 当前职位
- 期望职位
- 期望薪资
- 期望地点
- 工作经历（JSON 格式）
- 项目经历（JSON 格式）
- 教育经历（JSON 格式）
- 技能标签
- 简历链接
- 解析时间

## 📝 使用示例

### 示例 1: 获取最近 30 天的简历推荐邮件

```python
# 在 config.env 中设置
GMAIL_QUERY=subject:"推荐了简历候选人" newer_than:30d
```

### 示例 2: 获取特定发件人的邮件

```python
GMAIL_QUERY=from:cv@notice.zhipin.com subject:"推荐了简历候选人"
```

## ⚠️ 注意事项

1. **Gmail API 配额**：Gmail API 有每日配额限制，大量邮件可能需要分批处理
2. **Boss 直聘页面访问**：需要确保能够访问 Boss 直聘的简历页面（可能需要登录）
3. **数据隐私**：简历数据涉及隐私，请妥善保管输出文件

## 🐛 故障排查

### 问题 1: Gmail API 授权失败

**解决**：删除 `data/token.json` 文件，重新运行程序进行授权

### 问题 2: 无法访问 Boss 直聘页面

**解决**：检查网络连接，可能需要配置代理或使用浏览器自动化工具

### 问题 3: 简历解析失败

**解决**：检查 Boss 直聘页面结构是否变化，可能需要更新解析逻辑

## 📄 许可证

MIT License

