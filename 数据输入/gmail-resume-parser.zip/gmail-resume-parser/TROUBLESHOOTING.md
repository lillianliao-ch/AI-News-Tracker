# 🔍 问题诊断和测试指南

## 🤔 为什么之前能运行，现在出问题了？

### 可能的原因分析

#### 1. Boss直聘邮件格式变化 ⚠️
**最可能的原因**

Boss直聘可能更新了邮件模板：
- 链接格式改变（URL结构调整）
- HTML结构改变（影响正则匹配）
- 使用了短链接或重定向
- 邮件内容编码方式改变

**证据**：
- 之前的输出文件存在：`output/final_test_result.xlsx` ✅
- 说明项目之前是正常工作的
- Gmail API认证正常 ✅
- 找到了100封邮件 ✅
- 但是0个链接被提取 ❌

#### 2. 搜索到的不是简历推荐邮件
**也有可能**

当前的搜索条件：`subject:"推荐了简历候选人"`

可能匹配到了其他类型的邮件：
- 系统通知邮件
- 已过期的推荐
- 其他产品的推荐邮件

#### 3. Gmail API返回内容不同
**可能性较小**

Gmail API可能调整了：
- 返回的邮件内容格式
- HTML/文本内容的提取方式
- 需要不同的API参数

---

## 🧪 测试步骤（一步步诊断问题）

### 第一步：查看之前成功的输出文件 ✅

```bash
cd /Users/lillianliao/notion_rag/gmail-resume-parser

# 查看之前的输出文件
ls -lh output/

# 用Excel打开查看
open output/final_test_result.xlsx
# 或
open output/sample_resumes.xlsx
```

**目的**：
- 确认之前确实成功解析过
- 查看之前的Boss链接格式
- 对比当前情况

---

### 第二步：运行快速调试脚本 🔍

我刚创建了一个快速调试脚本：

```bash
cd /Users/lillianliao/notion_rag/gmail-resume-parser

# 运行调试脚本（只分析最近5封邮件）
python3 debug_quick.py
```

**这个脚本会显示**：
1. 邮件的主题、发件人、日期
2. 邮件内容的各个字段（body, htmlBody, textBody）
3. 内容预览（前500字符）
4. Boss链接提取尝试（使用多个正则表达式）
5. 如果找不到链接，会搜索任何'zhipin'关键词

**预期结果**：
- ✅ 如果找到链接 → 说明正则表达式有问题
- ❌ 如果没找到链接 → 查看邮件内容预览，判断是否是简历推荐邮件

---

### 第三步：检查邮件实际内容

如果第二步没有找到链接，需要查看邮件原始内容：

```bash
cd /Users/lillianliao/notion_rag/gmail-resume-parser

# 运行详细的邮件调试
python3 debug_emails.py
```

**查看内容**：
1. 邮件是否真的是Boss简历推荐？
2. 邮件内容中是否包含'zhipin'？
3. 链接的实际格式是什么？

---

### 第四步：手动测试Boss链接解析

如果能从邮件中手动找到Boss链接：

```bash
cd /Users/lillianliao/notion_rag/gmail-resume-parser

# 测试Boss页面解析（替换为实际链接）
python3 debug_boss_page.py "https://m.zhipin.com/xxx/resume/xxx"
```

**目的**：
- 验证Boss简历解析功能是否正常
- 确认不是Boss网站结构变化导致的问题

---

### 第五步：在Gmail中手动验证

**最直接的方式**：

1. **打开Gmail**: https://mail.google.com
2. **搜索框输入**: `subject:"推荐了简历候选人"`
3. **查看搜索结果**：
   - 这些邮件是Boss简历推荐吗？
   - 打开一封查看内容
   - 邮件中是否有Boss链接？
   - 链接格式是什么样的？

4. **尝试更精确的搜索**：
   ```
   subject:"推荐了简历候选人" from:cv@notice.zhipin.com
   ```

---

## 📋 诊断清单

### 环境检查 ✅
- [x] Python版本正常（3.12.5）
- [x] 依赖包已安装
- [x] Gmail OAuth Token有效
- [x] Gmail API认证成功

### 功能检查 ⚠️
- [x] Gmail搜索功能正常（找到100封）
- [ ] Boss链接提取（0个链接）← **问题所在**
- [ ] Boss简历解析（未测试）
- [x] Excel导出功能正常（代码完整）

### 需要确认的问题
1. [ ] 搜索到的邮件是否真的是Boss简历推荐？
2. [ ] 邮件内容中是否包含Boss链接？
3. [ ] Boss链接格式是否发生变化？
4. [ ] 正则表达式是否需要更新？

---

## 🎯 具体的测试步骤（跟着我做）

### 测试1：查看之前的成功记录（2分钟）

```bash
cd /Users/lillianliao/notion_rag/gmail-resume-parser

# 查看输出文件
ls -lh output/

# 查看文件内容（如果有）
python3 << 'EOF'
import pandas as pd
import os

output_dir = 'output'
files = [f for f in os.listdir(output_dir) if f.endswith('.xlsx')]

if files:
    print(f"找到 {len(files)} 个Excel文件:")
    for f in files:
        print(f"\n文件: {f}")
        filepath = os.path.join(output_dir, f)
        try:
            df = pd.read_excel(filepath)
            print(f"  行数: {len(df)}")
            print(f"  列数: {len(df.columns)}")
            if '简历链接' in df.columns:
                print(f"  链接示例: {df['简历链接'].iloc[0] if len(df) > 0 else 'N/A'}")
        except Exception as e:
            print(f"  读取失败: {e}")
else:
    print("没有找到输出文件")
EOF
```

---

### 测试2：运行快速诊断（3分钟）

```bash
cd /Users/lillianliao/notion_rag/gmail-resume-parser

# 运行快速诊断
python3 debug_quick.py
```

**看什么**：
1. 邮件主题是什么？（确认是Boss推荐吗？）
2. 内容预览中有没有'zhipin'？
3. 是否找到了Boss链接？

---

### 测试3：Gmail手动验证（5分钟）

1. 打开: https://mail.google.com
2. 搜索: `subject:"推荐了简历候选人"`
3. 打开第一封邮件
4. 查看：
   - 这是Boss简历推荐邮件吗？
   - 有没有"查看简历"或类似的链接？
   - 链接指向哪里？
5. 复制一个链接测试

---

### 测试4：更新搜索条件（如果需要）

如果发现搜索到的不是Boss邮件，更新配置：

```bash
cd /Users/lillianliao/notion_rag/gmail-resume-parser

# 编辑配置文件
nano config/config.env

# 修改为更精确的搜索
# GMAIL_QUERY=subject:"推荐了简历候选人" from:cv@notice.zhipin.com
```

然后重新运行主程序。

---

## 💡 根据测试结果的解决方案

### 情况A：邮件中确实有Boss链接，但提取不到

**解决方案**：更新正则表达式

1. 查看链接的实际格式
2. 更新 `src/gmail_client.py` 中的正则表达式
3. 重新测试

### 情况B：邮件不是Boss简历推荐

**解决方案**：更新搜索条件

```env
# 更精确的搜索
GMAIL_QUERY=subject:"推荐了简历候选人" from:cv@notice.zhipin.com

# 或者搜索特定时间段
GMAIL_QUERY=subject:"推荐了简历候选人" from:cv@notice.zhipin.com newer_than:7d
```

### 情况C：邮件格式完全改变了

**解决方案**：
1. 手动从邮件中复制Boss链接
2. 直接测试Boss解析功能
3. 或者使用新的Chrome插件项目（有更好的UI）

---

## 🚀 立即开始测试

**第一个命令（最重要）**：

```bash
cd /Users/lillianliao/notion_rag/gmail-resume-parser && python3 debug_quick.py
```

运行后把输出发给我，我帮你分析问题！

**或者**，你也可以：
1. 先在Gmail中手动搜索确认邮件内容
2. 截图或描述一下邮件的样子
3. 我根据实际情况给你调整方案

---

## 📝 测试记录模板

```
测试时间: ____________

【测试1：之前的输出文件】
- 是否存在: [ ] 是 / [ ] 否
- 文件日期: ____________
- 包含简历数: ____________

【测试2：快速诊断】
- 找到邮件数: ____________
- 邮件主题: ____________
- 是Boss推荐吗: [ ] 是 / [ ] 否
- 找到链接数: ____________

【测试3：Gmail手动验证】
- 搜索到邮件数: ____________
- 是否是简历推荐: [ ] 是 / [ ] 否
- 链接格式: ____________

【问题诊断】
可能原因: 
1. [ ] Boss邮件格式变化
2. [ ] 搜索条件不精确
3. [ ] 正则表达式需要更新
4. [ ] 其他: ____________

【解决方案】
____________
```

---

准备好了吗？先运行 `python3 debug_quick.py` 看看结果！🔍

