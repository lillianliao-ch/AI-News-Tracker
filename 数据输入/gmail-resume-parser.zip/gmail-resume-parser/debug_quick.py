#!/usr/bin/env python3
"""
快速调试脚本 - 查看邮件内容和Boss链接提取
"""

import os
import sys
import json
import re

sys.path.insert(0, 'src')

from gmail_client import GmailClient
from dotenv import load_dotenv

def analyze_email_content():
    """分析邮件内容，查看为什么提取不到Boss链接"""
    
    print("=" * 70)
    print("🔍 邮件内容分析 - Boss链接提取调试")
    print("=" * 70)
    
    # 加载配置
    load_dotenv('config/config.env')
    
    # 初始化Gmail客户端
    print("\n1️⃣ 初始化Gmail客户端...")
    client = GmailClient('config/credentials.json', 'data/token.json')
    
    # 搜索邮件（只取最近5封）
    query = os.getenv('GMAIL_QUERY', 'subject:"推荐了简历候选人"')
    print(f"\n2️⃣ 搜索邮件: {query}")
    print("   （只分析最近5封邮件）")
    
    emails = client.search_emails(query, max_results=5)
    print(f"\n✅ 找到 {len(emails)} 封邮件\n")
    
    if not emails:
        print("❌ 没有找到邮件")
        return
    
    # 分析每封邮件
    for i, email in enumerate(emails, 1):
        print("=" * 70)
        print(f"📧 邮件 #{i}")
        print("=" * 70)
        
        # 获取邮件详细内容
        email_content = client.get_email_content(email['id'])
        
        # 显示基本信息
        print(f"\n📋 基本信息:")
        print(f"  主题: {email_content.get('subject', 'N/A')[:80]}")
        print(f"  发件人: {email_content.get('from', 'N/A')}")
        print(f"  日期: {email_content.get('date', 'N/A')}")
        
        # 检查各种内容字段
        print(f"\n📝 内容字段检查:")
        has_body = bool(email_content.get('body'))
        has_html_body = bool(email_content.get('html_body'))
        
        print(f"  body: {'✅ 存在' if has_body else '❌ 不存在'}")
        print(f"  html_body: {'✅ 存在' if has_html_body else '❌ 不存在'}")
        
        # 合并所有内容
        all_content = ""
        if has_body:
            all_content += email_content.get('body', '')
        if has_html_body:
            all_content += " " + email_content.get('html_body', '')
        
        print(f"\n📏 内容长度: {len(all_content)} 字符")
        
        # 显示内容片段
        if all_content:
            print(f"\n📄 内容预览（前500字符）:")
            print("-" * 70)
            print(all_content[:500])
            print("-" * 70)
        
        # 尝试提取Boss链接
        print(f"\n🔗 Boss链接提取尝试:")
        
        # 使用项目中的正则表达式
        patterns = [
            r'https://m\.zhipin\.com/mpa/v\d+/html/resume/detail[^\s<>"\'()]+',
            r'https://www\.zhipin\.com/geek/[^\s<>"\'()]+',
            r'https://[mw]\.zhipin\.com/[^\s<>"\'()]*resume[^\s<>"\'()]*',
            r'https://[^/]*zhipin\.com[^\s<>"\'()]*',  # 更宽松的匹配
        ]
        
        found_links = []
        for j, pattern in enumerate(patterns, 1):
            matches = re.findall(pattern, all_content, re.IGNORECASE)
            if matches:
                print(f"  ✅ 模式{j} 找到 {len(matches)} 个链接:")
                for link in matches[:3]:  # 最多显示3个
                    print(f"     - {link[:80]}...")
                    found_links.extend(matches)
            else:
                print(f"  ❌ 模式{j} 未找到")
        
        # 去重
        unique_links = list(set(found_links))
        
        if unique_links:
            print(f"\n✅ 总共找到 {len(unique_links)} 个唯一链接")
        else:
            print(f"\n❌ 未找到任何Boss链接")
            
            # 尝试搜索任何zhipin.com链接
            print(f"\n🔍 尝试搜索任何zhipin相关内容:")
            if 'zhipin' in all_content.lower():
                print(f"  ✅ 内容中包含'zhipin'关键词")
                # 显示包含zhipin的片段
                lines = all_content.split('\n')
                zhipin_lines = [line for line in lines if 'zhipin' in line.lower()]
                if zhipin_lines:
                    print(f"  找到 {len(zhipin_lines)} 行包含'zhipin':")
                    for line in zhipin_lines[:5]:
                        print(f"    {line[:100]}")
            else:
                print(f"  ❌ 内容中不包含'zhipin'关键词")
        
        print("\n")
    
    # 总结
    print("=" * 70)
    print("📊 分析总结")
    print("=" * 70)
    print(f"\n检查项目:")
    print(f"1. 邮件数量: {len(emails)} 封")
    print(f"2. 邮件主题是否正确?")
    print(f"3. 邮件内容是否包含Boss链接?")
    print(f"4. 正则表达式是否匹配当前格式?")
    
    print(f"\n💡 可能的原因:")
    print(f"1. 邮件主题匹配了，但不是Boss简历推荐邮件")
    print(f"2. Boss邮件格式发生了变化")
    print(f"3. 链接被编码或使用了短链接")
    print(f"4. Gmail API返回的内容不完整")

if __name__ == '__main__':
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    
    try:
        analyze_email_content()
    except KeyboardInterrupt:
        print("\n\n⏹️  用户中断")
    except Exception as e:
        print(f"\n❌ 错误: {e}")
        import traceback
        traceback.print_exc()

